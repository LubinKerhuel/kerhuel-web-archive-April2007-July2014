%Sauve 3 data, 10000 points
[R T] = padr(Rn,1,t_Rn);
AxelX_GyroY_AxelZ = [T R]';
AxelX_GyroY_AxelZ(1,:) = [0:33332]*1e-3;
save AxelX_GyroY_AxelZ AxelX_GyroY_AxelZ;