%load Regulated_vsUnregulated
load Perturbation

R = padr(R,1);
t = 0:.002:(length(R)-1)*.002;

BackEMF = R(:,1) * 3.3/1024;    % scaling in Volt 
Cmd = R(:,3) ./ 119.99;
SetPoint = R(:,4) * 3.3/1024;

figure(1);
subplot(2,1,1)
plot(t,BackEMF,'k'); hold on;
plot(t,SetPoint,'r','linewidth',2); hold off;
legend('Back EMF','Set Point')
ylabel('Volt');
xlabel('time (s)')
axis tight; ylim([1.3 2.6])
subplot(2,1,2)
plot(t,Cmd);
ylabel('PWM duty cycle (%)');
xlabel('time (s)')
axis tight;

%print -dpng -r200 ./Illustrations/OpenLoopVsCloseLoop





