%load 2009_03_01_at_23h13_37s;   %% watch out : ADC output is signed !
load 2009_03_02_at_00h52_28s;

R = padr(Rtotal,1);

PosSample = ( max(R(:,2))-min(R(:,2)) ) / 10 +1;

idx = find( diff(R(:,2)) < 0);
idx = idx(1);
R = R([(idx+1):end],:);

[m,n] = size(R);
R = R(1:(floor(m/PosSample)*PosSample),:);
[m,n] = size(R);

R = reshape(R',n,PosSample,m/PosSample);

R(1,:,:) = R(1,:,:)*3.3/1023;   % Back EMF in Volt
R(2,:,:) = R(2,:,:)./119.99;   % PWM duty cycle in %
R(3,:,:) = R(3,:,:)./119.99;   % PWM duty cycle in %

figure(1);
subplot(2,1,1)
plot(squeeze(R(2,:,100)),squeeze(R(1,:,100)),'+')
ylim([0 3.22]); xlim([0 100])
ylabel('Back EMF (V)')
xlabel('Sampling instant within a PWM period (%)')


subplot(2,1,2)
plot(squeeze(R(3,1198,:)),squeeze(R(1,1198,:)),'+')
ylim([0 3.22]); xlim([0 100]);
ylabel('Back EMF measured at 99.84%')
xlabel('PWM duty cycle (%)')

%print -depsc2 ./Illustrations/figure
