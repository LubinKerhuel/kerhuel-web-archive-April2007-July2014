load 2009_03_02_at_02h46_00s;
%load 2009_03_02_at_02h44_33s;

R = padr(Rtotal,1);

T = 0:.002:((length(R)-1)*.002);

ADC = R(:,1);
Chirp = R(:,3);
Up = R(:,4);
Down = R(:,5);
count = R(:,6);

Periode = diff(count);
PeriodeIdx = find(Periode ~= 0);
Periode = diff(PeriodeIdx);
%Periode = .002./Periode;

PeriodeIdx = [1 PeriodeIdx'];
for(i=1:length(Periode))
    RPM(PeriodeIdx(i):PeriodeIdx(i+1)) = Periode(i);
end
RPM(PeriodeIdx(i+1):end) = Periode(i)


RPMfft = fft(RPM);
RPMfft(round(10*length(RPMfft)/500):end) = 0;
RPM = ifft(RPMfft,'symmetric');

RPM = (500./(RPM*5));

plot(T(1:length(RPM)),RPM);
%hold on;
%plot(T,Chirp*.0001,'r');
