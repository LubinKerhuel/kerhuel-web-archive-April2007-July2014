try
    Ts = .002;  % Controller Sample time 

Picooz_Mrotor = zpk([],[-78.68 -9.787],-24.6222);
Picooz_Mrotor_z = c2d(Picooz_Mrotor,Ts,'zoh');
[Picooz_Mrotor_z_ss,T] = canon(Picooz_Mrotor_z,'modal');     %% transformation pour calculs plus simple x ==> T*x

[Az,Bz,Cz,Dz,Te] = ssdata(Picooz_Mrotor_z_ss);
[m,n] = size(Az);

%% Augmented state space synthesis (K)

R = 1;
Q = diag([1 1 2e6]);
[K,Z,e] = lqi(Picooz_Mrotor_z_ss,Q,R,0);

%Poles en continue : 
log(eig(Az))/Ts     % System Natural Poles
log(e)/Ts           % Poles in close loop

PolesControlleur_s = log(e)/Ts ;


%% Observer L Synthesis
poleLent = abs(PolesControlleur_s(1:end-1))
PlacementPolesObs = exp(-poleLent * Ts * 1 );  %*3 usually

L = acker(Az',Cz',PlacementPolesObs');

%% Simplification
% Az is diagonal (thanks to the cannon command)
Az = diag(Az)';

catch
    % if one toolbox is missing, set directly values as :
    Az = [0.8544 0.9806];
    Bz = [-0.0207 0.0659]';
    Cz = [-0.0319   -0.0107];
    K =  1e3*[0.0005    0.0012    1.3639];
    L = [-0.0593   -0.8260];
end

