% Script to plot data logged with simulink model file:
% dsPIC_32MX460F512L_Explorer16_HyperSampling

load R;
OCmax = 9599;  % Should already be set in the workspace by the simulink model
ANmax = 1024;  % Should already be set in the workspace by the simulink model
% OCmax code for 1ms
MIPS = 96e6; 

Tsampling = .0001/OCmax; % OCmax sample within 1 ms

R = padr(R,1);  % remove NaN values

R(:,1) = R(:,1)*3.3/ANmax;      % convert ADC output (column 1) into volt
R(:,2) = R(:,2)*Tsampling;      % convert integer value (column 2) into delay

 %Ts sample : 4.884e-6
 %T ADC total : 6.719e-6
ADC_delaySample =  ( 4.884e-6 / 1.7 ) / Tsampling;    % delay due to sampling : (Ts/2) here Ts/1.7 ? 

PWM_reconstruct = zeros(1,length(R));
idx = find(R(:,2) == OCmax*Tsampling);
idx = idx - round(ADC_delaySample); %200;%
for i=1:length(idx)
    PWM_reconstruct(idx(i):min(idx(i)+(OCmax/2-1),end)) = max(R(:,1));    % do not reach 100%
end

T = 0:Tsampling:( (length(R)-1)*Tsampling);
T = (T-T(idx(1)) ) *1e6;    % set 0 at first rising edge and in micro second
%plot(T+ADC_delaySample*Tsampling,PWM_reconstruct,'k-','linewidth',2); hold on;    % plot PWM signal in the real time
plot(T,PWM_reconstruct,'c-','linewidth',2); hold on;    % plot PWM signal with delayed due to ADC

figure(1);
[AX,H1,H2] = plotyy(T,R(:,1)',T,R(:,2)'*1e6);
set(get(AX(1),'Ylabel'),'String','U (Volt)') 
set(get(AX(2),'Ylabel'),'String','Delay (\mus)') 
set(AX(1),'Xlim',[-5 105]) ;
set(AX(2),'Xlim',[-5 105]) ;
set(H2,'LineStyle',':')
set(H1,'LineWidth',3)
xlabel('Time (\mus)') 
title('RC system response to steps') 
hold on;

% simulate usual sampling time
idx = diff(floor(T/6.719));
idx = find(idx == 1);
Tclassic = reshape([T(idx(1:(end-1)));T(idx(2:end))-eps],(length(T(idx))-1)*2,1);
Uclassic = reshape([R(idx(1:(end-1)),1)  R(idx(1:(end-1)),1) ]',(length(R(idx,1))-1)*2,1);
plot(Tclassic,Uclassic,'k');
%stem(T(idx),R(idx,1)','k')

R = 1e3;    % 1Kohm
C = 100e-9;   %100nF

if exist('c2d') == 2    % check if that function exist
 RCFilt = tf(1,[R*C 1]);               % design filter 
 RCFilt_z = c2d(RCFilt,.001/OCmax);    % discretize
else    % else use directe coefficient
    RCFilt_z.num{1} = [0   0.001041232725537];         % filter result
    RCFilt_z.den{1} =  [1 -0.998958767274463];     % if missing toolbox signal
end    

plot(T,filter(RCFilt_z.num{1},RCFilt_z.den{1},PWM_reconstruct),'r--','linewidth',2);

hold off;

legend('Reconstructed PWM output','Hyper Sampling','Fastest Classical Sampling (reconstructed)','Theorical RC response','PWM delay relative to ADC trigger')

%print figure -depsc2