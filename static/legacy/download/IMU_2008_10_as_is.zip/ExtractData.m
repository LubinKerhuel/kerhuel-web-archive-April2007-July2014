%fid = fopen('2008_10_7_at_20h50_4.1s.txt'  ); % static
%fid = fopen('2008_10_7_at_1h31_19s.txt'  ); %static
%fid = fopen('2008_10_7_at_20h58_29s.txt'  ); % calibrating z gyro

%fid = fopen('2008_10_7_at_23h53_0.72s_Static.txt'  ); %static
%fid = fopen('2008_10_7_at_23h54_33s_Pitch.txt'  ); %static
%fid = fopen('2008_10_7_at_23h55_37s_Roll.txt'  ); %static
%fid = fopen('2008_10_8_at_0h3_26s_Yaw.txt'  ); %static


%fid = fopen('2008_10_8_at_23h8_6.5s_Pitch.txt');
%fid = fopen('2008_10_8_at_23h10_29s_Roll.txt');
%fid = fopen('2008_10_8_at_23h11_56s_Yaw.txt');

%fid = fopen('Pitch_Up_Calibration.txt');
%fid = fopen('Roll_Right_Calibration.txt');
%fid = fopen('Turn_Left_Roll_Pitch_Yaw.txt');
%fid = fopen('Turn_Left_Right_Roll_Pitch_Yaw.txt');
%fid = fopen('Turn_Left_Right.txt');
%fid = fopen('2008_10_14_at_00h12_25s.txt');
%fid = fopen('2008_10_14_at_00h13_50s.txt');

%fid = fopen('2008_10_15_at_23h21_26s.txt');    % Long Log
%fid = fopen('2008_10_15_at_23h38_25s.txt');    % even Longer Log

%fid = fopen('2008_10_16_at_20h00_44s.txt');    % even Longer Log
% fid = fopen('2008_10_16_at_20h31_15s.txt');    % Long Static log
% 
% Rn = fread(fid);
% fclose(fid);   
    

Rr = uint16(Rn);
idx = find(Rr==0);
Rr = Rr(idx(1):end);

sizeR = floor(length(Rr)/10)*10;
Rr = Rr(1:sizeR);
Rr = reshape(Rr,10,sizeR/10)';

V1 = Rr(:,2)+bitand(Rr(:,3),15)*256;
V2 = Rr(:,4)*16 + bitand(Rr(:,3),240) ./ 16;

V3 = Rr(:,5)+bitand(Rr(:,6),15)*256;
V4 = Rr(:,7)*16 + bitand(Rr(:,6),240) ./ 16;

V5 = Rr(:,8)+bitand(Rr(:,9),15)*256;
V6 = Rr(:,10)*16 + bitand(Rr(:,9),240) ./ 16;

L = length(V6);

t = 0:.001:L*.001-.001;

Rr = [t;double(V1');double(V2');double(V3');double(V4');double(V5');double(V6')];

%save CalibrationGyroZ Rr;
%save Static Rr;

figure(1);
plot(V1,'r') ; hold on; plot(V4,'b'); plot(V6,'g'); hold off;
figure(2);
plot(V2,'r') ; hold on; plot(V3,'b'); plot(V5,'g'); hold off;

