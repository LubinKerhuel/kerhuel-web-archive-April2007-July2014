% Script to compute g ain of the non adaptive Kalman filter (Alpha Beta
% Filter)

disp('continuous')
A = [0 -1; 0 0];
B = [1 0]';
C = [1 0];

if ( exist('acker') == 2)    % if toolbox containing acker function is not present

    K = acker(A',C',[-.2+i*sqrt(2)*.2 -.2-i*sqrt(2)*.2])';
%    K = acker(A',C',[-.2 -.2])';
else
    K = [0.4 -0.04];  % set the result
end

Poles_s = eig(A-K*C)


%% Discret
disp('Discrete')
Ts = .001;

Az = [1 -Ts ;0 1];
Bz = [Ts 0]';
Cz = [1 0];


if ( exist('acker') == 2)    % if toolbox containing acker function is not present
    %PlacementPolesObs = exp([-1/5 -1/5] * Ts ); % pole placement
    KPlacementPolesObs = exp([-.2+i*sqrt(2)*.2 -.2-i*sqrt(2)*.2] * Ts ); % pole placement
    
%    PlacementPolesObs = exp([-1 -1] * Ts ); % pole placement
    Kz = acker(Az',Cz',PlacementPolesObs')';
else
    Kz = 1e-3*[.4 ; -.04];  % set the result
end

Poles_z = log(eig(Az-Kz*Cz))/Ts
%Kz = Kz*0;