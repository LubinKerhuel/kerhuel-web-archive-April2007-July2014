/*
 * File: IConly.c
 *
 * Real-Time Workshop code generated for Simulink model IConly.
 *
 * Model version                        : 1.7
 * Real-Time Workshop file version      : 7.4.1  (R2009bSP1)  02-Mar-2010
 * Real-Time Workshop file generated on : Mon May 03 12:31:17 2010
 * TLC version                          : 7.4 (Jul 14 2009)
 * C source code generated on           : Mon May 03 12:31:17 2010
 *--------------------------------------------------------------
 *   Embedded Coder for Microchip dsPIC family.                 |
 *   Generate .c and .h files from your Matlab/simulink model   |
 *   and compile the diagram to .hex and .coff file that can be |
 *   downloaded directly into the microcontroller               |
 *                                                              |
 * Licence Accorded to John Rogers, Ph.D., P.E.                 |
 *                     West Point University                    |
 *                                                              |
 *   Written by Lubin KERHUEL -  http://www.kerhuel.eu          |
 *  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - |
 *   Version 3.1a                              16-Mar-2010      |
 *   For Matlab 7.8             R2009a                          |
 *--------------------------------------------------------------
 */

#include "IConly.h"
#include "IConly_private.h"

/* Real-time model */
RT_MODEL_IConly IConly_M_;
RT_MODEL_IConly *IConly_M = &IConly_M_;

/* Model step function */
void IConly_step(void)
{
  /* local block i/o variables */
  uint16_T rtb_ICTimerCapture;

  /* S-Function (dsPIC_IPCTimerCapture_sfun): '<Root>/IC TimerCapture' */
  rtb_ICTimerCapture = IC2BUF;
}

/* Model initialize function */
void IConly_initialize(boolean_T firstTime)
{
  (void)firstTime;

  /* Registration code */

  /* initialize error status */
  rtmSetErrorStatus(IConly_M, (NULL));

  /* Start for S-Function (dspic33fxx_masterconfig_sfun): '<Root>/dsPIC33fxx Main' */

  /* CONFIG TIMER 1 for scheduling steps 	*/
  ConfigIntTimer1(T1_INT_PRIOR_0 & T1_INT_OFF);
  T1CON = T1_ON & T1_IDLE_CON & T1_GATE_OFF & T1_PS_1_1 & T1_SYNC_EXT_OFF &
    T1_SOURCE_INT;
  PR1 = 40000;
  T1CONbits.TCKPS = 0;

  /* S-Function "dsPIC_Timerconfig_sfun.c" Block: <Root>/Timer Config */

  /* Configure Timer 2 */
  T2CONbits.TON = 0;                   // Stop any 16-bit Timer2 operation
  T2CONbits.TCS = 0;                   // internal instruction cycle clock
  T2CONbits.TGATE = 0;                 //Timer2 Gated Time Accumulation
  T2CONbits.TCKPS = 2;                 // Prescaler
  TMR2 = 0x00;                         // Clear 32-bit Timer (lsw)
  PR2 = 0x30D4;                        // Load 32-bit period value (lsw)
  T2CONbits.TON = 1;                   // Start 32-bit Timer

  /* Start for S-Function (dsPIC_IPCTimerCapture_sfun): '<Root>/IC TimerCapture' */
  IC2CONbits.ICSIDL = 1;               //Input Capture Module Stop/Continue in Idle
  IC2CONbits.ICTMR = 2;                //Input Capture Timer Select bits(1)
  IC2CONbits.ICI = 1;                  //Select Number of Captures per Interrupt
  IC2CONbits.ICM = 3;                  //Input Capture Mode Select
  IPC1bits.IC2IP = 4;                  // Set Input Capture 2 Interrupt Priority Level
  IFS0bits.IC2IF = 0;                  // Clear Input Capture 2Interrupt Flag
  IEC0bits.IC2IE = 1;                  // Enable Input Capture 2 interrupt
}

/* File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
