/*
 * File: SD_Datalogger5.c
 *
 * Real-Time Workshop code generated for Simulink model SD_Datalogger5.
 *
 * Model version                        : 1.22
 * Real-Time Workshop file version      : 8.0 (R2011a) 09-Mar-2011
 * Real-Time Workshop file generated on : Tue Nov 22 09:24:00 2011
 * TLC version                          : 8.0 (Feb  3 2011)
 * C source code generated on           : Tue Nov 22 09:24:01 2011
 *--------------------------------------------------------------
 *   Embedded Coder for Microchip dsPIC family.                 |
 *   Generate .c and .h files from your Matlab/simulink model   |
 *   and compile the diagram to .hex and .coff file that can be |
 *   downloaded directly into the microcontroller               |
 *                                                              |
 * Licence Accorded to John Rogers, Ph.D., P.E.                 |
 *                     West Point University                    |
 *                                                              |
 *   Written by Lubin KERHUEL -  http://www.kerhuel.eu          |
 *  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - |
 *   Version 3.7                               08-Oct-2011      |
 *   For Matlab 7.11            R2010b                          |
 *--------------------------------------------------------------
 */

#include "SD_Datalogger5.h"
#include "SD_Datalogger5_private.h"

/* Block signals (auto storage) */
BlockIO_SD_Datalogger5 SD_Datalogger5_B;

/* Model step function */
void SD_Datalogger5_step(void)
{
  /* DataTypeConversion: '<Root>/Data Type Conversion' incorporates:
   *  Constant: '<Root>/Constant'
   */
  SD_Datalogger5_B.DataTypeConversion = ((SD_Datalogger5_P.Constant_Value != 0.0));

  /* S-Function "dsPIC_Digital_OutputWrite" Block: <Root>/Digital Output Write */
  LATFbits.LATF2 = SD_Datalogger5_B.DataTypeConversion;
}

/* Model initialize function */
void SD_Datalogger5_initialize(boolean_T firstTime)
{
  (void)firstTime;

  /* Registration code */

  /* block I/O */
  (void) memset(((void *) &SD_Datalogger5_B), 0,
                sizeof(BlockIO_SD_Datalogger5));

  /* S-Function "dsPIC_MASTER" initialization Block: <Root>/Master */
  /* Solver mode : SingleTasking */
  /* CONFIG TIMER 1 for scheduling steps 	*/
  ConfigIntTimer1(T1_INT_PRIOR_0 | T1_INT_OFF);
  OpenTimer1(T1_ON | T1_GATE_OFF |
             T1_PS_1_1 | T1_SOURCE_INT | T1_IDLE_CON , 39999);

  /* Configuration TRIS */
  TRISF = 65531;

  /* Configuration ADCHS */
  AD1PCFG = 0U;
  INTEnableSystemMultiVectoredInt();
}

/* File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
