/*
 * File: SD_Datalogger5_main.c
 *
 * Real-Time Workshop code generated for Simulink model SD_Datalogger5.
 *
 * Model version                        : 1.22
 * Real-Time Workshop file version      : 8.0 (R2011a) 09-Mar-2011
 * Real-Time Workshop file generated on : Tue Nov 22 09:24:00 2011
 * TLC version                          : 8.0 (Feb  3 2011)
 * C source code generated on           : Tue Nov 22 09:24:01 2011
 *--------------------------------------------------------------
 *   Embedded Coder for Microchip dsPIC family.                 |
 *   Generate .c and .h files from your Matlab/simulink model   |
 *   and compile the diagram to .hex and .coff file that can be |
 *   downloaded directly into the microcontroller               |
 *                                                              |
 * Licence Accorded to John Rogers, Ph.D., P.E.                 |
 *                     West Point University                    |
 *                                                              |
 *   Written by Lubin KERHUEL -  http://www.kerhuel.eu          |
 *  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - |
 *   Version 3.7                               08-Oct-2011      |
 *   For Matlab 7.11            R2010b                          |
 *--------------------------------------------------------------
 */

#include "SD_Datalogger5.h"
#include "SD_Datalogger5_private.h"

#pragma config FPLLMUL = MUL_20, FPLLIDIV = DIV_2, FPLLODIV = DIV_2, FWDTEN = OFF
#pragma config POSCMOD = XT, FNOSC = PRIPLL, FPBDIV = DIV_1

void rt_OneStep()
{
  /* Disable interrupts here */
  /* Save FPU context here (if necessary) */
  /* Re-enable timer or interrupt here */
  SD_Datalogger5_step();

  /* Get model outputs here */

  /* Disable interrupts here */
  /* Restore FPU context here (if necessary) */
  /* Enable interrupts here */
}

int main(void)
{
  /* Initialize model */
  SD_Datalogger5_initialize(1);
  for (;;) {
    /* Associate rt_OneStep() with a timer that executes at the base rate of the model */
    while (!_T1IF) ;
    _T1IF = 0;
    rt_OneStep();
  }
}

/* File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
