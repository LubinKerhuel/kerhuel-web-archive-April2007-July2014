/*
 * File: SD_Datalogger5_data.c
 *
 * Real-Time Workshop code generated for Simulink model SD_Datalogger5.
 *
 * Model version                        : 1.22
 * Real-Time Workshop file version      : 8.0 (R2011a) 09-Mar-2011
 * Real-Time Workshop file generated on : Tue Nov 22 09:24:00 2011
 * TLC version                          : 8.0 (Feb  3 2011)
 * C source code generated on           : Tue Nov 22 09:24:01 2011
 *--------------------------------------------------------------
 *   Embedded Coder for Microchip dsPIC family.                 |
 *   Generate .c and .h files from your Matlab/simulink model   |
 *   and compile the diagram to .hex and .coff file that can be |
 *   downloaded directly into the microcontroller               |
 *                                                              |
 * Licence Accorded to John Rogers, Ph.D., P.E.                 |
 *                     West Point University                    |
 *                                                              |
 *   Written by Lubin KERHUEL -  http://www.kerhuel.eu          |
 *  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - |
 *   Version 3.7                               08-Oct-2011      |
 *   For Matlab 7.11            R2010b                          |
 *--------------------------------------------------------------
 */

#include "SD_Datalogger5.h"
#include "SD_Datalogger5_private.h"

/* Block parameters (auto storage) */
Parameters_SD_Datalogger5 SD_Datalogger5_P = {
  1.0                                  /* Expression: 1
                                        * Referenced by: '<Root>/Constant'
                                        */
};

/* File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
