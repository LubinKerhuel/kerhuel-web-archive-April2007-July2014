/*
 * File: mika.h
 *
 * Real-Time Workshop code generated for Simulink model mika.
 *
 * Model version                        : 1.6
 * Real-Time Workshop file version      : 7.0  (R2007b)  02-Aug-2007
 * Real-Time Workshop file generated on : Sun Feb 17 19:50:29 2008
 * TLC version                          : 7.0 (Jul 26 2007)
 * C source code generated on           : Sun Feb 17 19:50:30 2008
 *--------------------------------------------------------------
 *   Embedded Coder for Microchip dsPIC family.                 |
 *   Generate .c and .h files from your Matlab/simulink model   |
 *   and compile the diagram to .hex and .coff file that can be |
 *   downloaded directly into the microcontroller               |
 *                                                              |
 * Licence Accorded to Demonstration Version                    |
 *                                                              |
 *                                                              |
 *   Written by Lubin KERHUEL -  http://www.kerhuel.eu          |
 *  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - |
 *   Version 0.96b                             13-Feb-2008      |
 *   For Matlab 7.5             R2007b                          |
 *--------------------------------------------------------------
 */

#ifndef RTW_HEADER_mika_h_
#define RTW_HEADER_mika_h_
#ifndef mika_COMMON_INCLUDES_
# define mika_COMMON_INCLUDES_
#include <math.h>
#include <stddef.h>
#include <string.h>
#include "rtwtypes.h"
#endif                                 /* mika_COMMON_INCLUDES_ */

#include "mika_types.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((void*) 0)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((void) 0)
#endif

#ifndef rtmGetStopRequested
# define rtmGetStopRequested(rtm)      ((void*) 0)
#endif

/* Block signals (auto storage) */
typedef struct {
  boolean_T DigitalInput;              /* '<Root>/Digital Input' */
} BlockIO_mika;

/* Block signals (auto storage) */
extern BlockIO_mika mika_B;

/* Model entry point functions */
extern void mika_initialize(boolean_T firstTime);
extern void mika_step(void);

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : mika
 */
#endif                                 /* RTW_HEADER_mika_h_ */

/* File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
