/*
 * File: mika_types.h
 *
 * Real-Time Workshop code generated for Simulink model mika.
 *
 * Model version                        : 1.6
 * Real-Time Workshop file version      : 7.0  (R2007b)  02-Aug-2007
 * Real-Time Workshop file generated on : Sun Feb 17 19:50:29 2008
 * TLC version                          : 7.0 (Jul 26 2007)
 * C source code generated on           : Sun Feb 17 19:50:30 2008
 *--------------------------------------------------------------
 *   Embedded Coder for Microchip dsPIC family.                 |
 *   Generate .c and .h files from your Matlab/simulink model   |
 *   and compile the diagram to .hex and .coff file that can be |
 *   downloaded directly into the microcontroller               |
 *                                                              |
 * Licence Accorded to Demonstration Version                    |
 *                                                              |
 *                                                              |
 *   Written by Lubin KERHUEL -  http://www.kerhuel.eu          |
 *  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - |
 *   Version 0.96b                             13-Feb-2008      |
 *   For Matlab 7.5             R2007b                          |
 *--------------------------------------------------------------
 */

#ifndef RTW_HEADER_mika_types_h_
#define RTW_HEADER_mika_types_h_
#endif                                 /* RTW_HEADER_mika_types_h_ */

/* File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
