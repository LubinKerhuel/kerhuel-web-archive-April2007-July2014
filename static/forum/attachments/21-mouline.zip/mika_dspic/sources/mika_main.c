/*
 * File: mika_main.c
 *
 * Real-Time Workshop code generated for Simulink model mika.
 *
 * Model version                        : 1.6
 * Real-Time Workshop file version      : 7.0  (R2007b)  02-Aug-2007
 * Real-Time Workshop file generated on : Sun Feb 17 19:50:29 2008
 * TLC version                          : 7.0 (Jul 26 2007)
 * C source code generated on           : Sun Feb 17 19:50:30 2008
 *--------------------------------------------------------------
 *   Embedded Coder for Microchip dsPIC family.                 |
 *   Generate .c and .h files from your Matlab/simulink model   |
 *   and compile the diagram to .hex and .coff file that can be |
 *   downloaded directly into the microcontroller               |
 *                                                              |
 * Licence Accorded to Demonstration Version                    |
 *                                                              |
 *                                                              |
 *   Written by Lubin KERHUEL -  http://www.kerhuel.eu          |
 *  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - |
 *   Version 0.96b                             13-Feb-2008      |
 *   For Matlab 7.5             R2007b                          |
 *--------------------------------------------------------------
 */

#include "mika.h"
#include "mika_private.h"

_FOSC(CSW_FSCM_OFF & HS)
  _FWDT(WDT_OFF)
  _FBORPOR(PBOR_OFF & PWRT_OFF & MCLR_EN)
  _FGS(CODE_PROT_OFF)
  static boolean_T OverrunFlag = 0;
void rt_OneStep()
{
  /* Disable interrupts here */
  /* Save FPU context here (if necessary) */
  /* Re-enable timer or interrupt here */
  mika_step();

  /* Disable interrupts here */
  /* Restore FPU context here (if necessary) */
  /* Enable interrupts here */
}

void main()
{
  /* Initialize model */
  mika_initialize(1);
  for (;;) {
    /* Associate rt_OneStep() with a timer that executes at the base rate of the model */
    while (!_T1IF) ;
    _T1IF = 0;
    rt_OneStep();
  }

  return 0;
}

/* File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
