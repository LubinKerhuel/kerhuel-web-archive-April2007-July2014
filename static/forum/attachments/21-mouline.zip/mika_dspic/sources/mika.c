/*
 * File: mika.c
 *
 * Real-Time Workshop code generated for Simulink model mika.
 *
 * Model version                        : 1.6
 * Real-Time Workshop file version      : 7.0  (R2007b)  02-Aug-2007
 * Real-Time Workshop file generated on : Sun Feb 17 19:50:29 2008
 * TLC version                          : 7.0 (Jul 26 2007)
 * C source code generated on           : Sun Feb 17 19:50:30 2008
 *--------------------------------------------------------------
 *   Embedded Coder for Microchip dsPIC family.                 |
 *   Generate .c and .h files from your Matlab/simulink model   |
 *   and compile the diagram to .hex and .coff file that can be |
 *   downloaded directly into the microcontroller               |
 *                                                              |
 * Licence Accorded to Demonstration Version                    |
 *                                                              |
 *                                                              |
 *   Written by Lubin KERHUEL -  http://www.kerhuel.eu          |
 *  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - |
 *   Version 0.96b                             13-Feb-2008      |
 *   For Matlab 7.5             R2007b                          |
 *--------------------------------------------------------------
 */

#include "mika.h"
#include "mika_private.h"

/* Block signals (auto storage) */
BlockIO_mika mika_B;

/* Model step function */
void mika_step(void)
{
  /* S-Function "dsPIC_Digital_Input" Block: <Root>/Digital Input */
  mika_B.DigitalInput = PORTBbits.RB1;

  /* S-Function "dsPIC_Digital_OutputWrite" Block: <Root>/Digital Output Write */
  LATBbits.LATB2 = mika_B.DigitalInput;
}

/* Model initialize function */
void mika_initialize(boolean_T firstTime)
{
  (void)firstTime;

  /* Registration code */

  /* block I/O */
  (void) memset(((void *) &mika_B),0,
                sizeof(BlockIO_mika));

  /* S-Function "dsPIC_MASTER" initialization Block: <Root>/Master */
  /* 0 testfcy 	*/
  /*  2.5E+006	*/
  /* CONFIG TIMER 1 for scheduling steps 	*/
  ConfigIntTimer1(T1_INT_PRIOR_0 & T1_INT_OFF);
  T1CON = 0x8000 ;                     /* T1_PS_1_1	*/
  PR1 = 2499;

  /* Configuration TRIS */
  TRISB = 65531;

  /* Configuration ADCHS */
  ADPCFG = 6;
}

/* File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
