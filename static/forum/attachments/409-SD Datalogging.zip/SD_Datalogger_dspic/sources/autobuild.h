/*
 * File: autobuild.h
 *
 * Real-Time Workshop code generated for Simulink model SD_Datalogger.
 *
 * Model version                        : 1.123
 * Real-Time Workshop file version      : 7.5  (R2010a)  25-Jan-2010
 * Real-Time Workshop file generated on : Wed Apr 27 14:35:55 2011
 * TLC version                          : 7.5 (Jan 19 2010)
 * C source code generated on           : Wed Apr 27 14:35:55 2011
 *--------------------------------------------------------------
 *   Embedded Coder for Microchip dsPIC family.                 |
 *   Generate .c and .h files from your Matlab/simulink model   |
 *   and compile the diagram to .hex and .coff file that can be |
 *   downloaded directly into the microcontroller               |
 *                                                              |
 * Licence Accorded to John Rogers, Ph.D., P.E.                 |
 *                     West Point University                    |
 *                                                              |
 *   Written by Lubin KERHUEL -  http://www.kerhuel.eu          |
 *  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - |
 *   Version 3.4cb                             11-Apr-2011      |
 *   For Matlab 7.11            R2010b                          |
 *--------------------------------------------------------------
 */

#ifndef RTW_HEADER_autobuild_h_
#define RTW_HEADER_autobuild_h_
#include "SD_Datalogger.h"
#define INCLUDE_FIRST_TIME_ARG         1
#endif                                 /* RTW_HEADER_autobuild_h_ */

/* File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
