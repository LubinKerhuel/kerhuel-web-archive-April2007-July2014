/*
 * File: SD_Datalogger_data.c
 *
 * Real-Time Workshop code generated for Simulink model SD_Datalogger.
 *
 * Model version                        : 1.123
 * Real-Time Workshop file version      : 7.5  (R2010a)  25-Jan-2010
 * Real-Time Workshop file generated on : Wed Apr 27 14:35:55 2011
 * TLC version                          : 7.5 (Jan 19 2010)
 * C source code generated on           : Wed Apr 27 14:35:55 2011
 *--------------------------------------------------------------
 *   Embedded Coder for Microchip dsPIC family.                 |
 *   Generate .c and .h files from your Matlab/simulink model   |
 *   and compile the diagram to .hex and .coff file that can be |
 *   downloaded directly into the microcontroller               |
 *                                                              |
 * Licence Accorded to John Rogers, Ph.D., P.E.                 |
 *                     West Point University                    |
 *                                                              |
 *   Written by Lubin KERHUEL -  http://www.kerhuel.eu          |
 *  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - |
 *   Version 3.4cb                             11-Apr-2011      |
 *   For Matlab 7.11            R2010b                          |
 *--------------------------------------------------------------
 */

#include "SD_Datalogger.h"
#include "SD_Datalogger_private.h"

/* Block parameters (auto storage) */
Parameters_SD_Datalogger SD_Datalogger_P = {
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S2>/Constant'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S2>/Pulse Generator'
                                        */
  2.0,                                 /* Expression: 2
                                        * Referenced by: '<S2>/Pulse Generator'
                                        */
  2.0,                                 /* Expression: 2
                                        * Referenced by: '<S2>/Pulse Generator'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S2>/Pulse Generator'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<Root>/Constant'
                                        */
  0U,                                  /* Computed Parameter: Memory_X0
                                        * Referenced by: '<S2>/Memory'
                                        */
  0U,                                  /* Computed Parameter: Switch_Threshold
                                        * Referenced by: '<S2>/Switch'
                                        */

  /*  Computed Parameter: StringTXT_Value
   * Referenced by: '<Root>/String.TXT'
   */
  { 83U, 116U, 114U, 105U, 110U, 103U, 46U, 84U, 88U, 84U },
  0                                    /* Computed Parameter: Constant_Value_k
                                        * Referenced by: '<S1>/Constant'
                                        */
};

/* File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
