/*
 * File: SD_Datalogger_main.c
 *
 * Real-Time Workshop code generated for Simulink model SD_Datalogger.
 *
 * Model version                        : 1.123
 * Real-Time Workshop file version      : 7.5  (R2010a)  25-Jan-2010
 * Real-Time Workshop file generated on : Wed Apr 27 14:35:55 2011
 * TLC version                          : 7.5 (Jan 19 2010)
 * C source code generated on           : Wed Apr 27 14:35:55 2011
 *--------------------------------------------------------------
 *   Embedded Coder for Microchip dsPIC family.                 |
 *   Generate .c and .h files from your Matlab/simulink model   |
 *   and compile the diagram to .hex and .coff file that can be |
 *   downloaded directly into the microcontroller               |
 *                                                              |
 * Licence Accorded to John Rogers, Ph.D., P.E.                 |
 *                     West Point University                    |
 *                                                              |
 *   Written by Lubin KERHUEL -  http://www.kerhuel.eu          |
 *  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - |
 *   Version 3.4cb                             11-Apr-2011      |
 *   For Matlab 7.11            R2010b                          |
 *--------------------------------------------------------------
 */

#include "SD_Datalogger.h"
#include "SD_Datalogger_private.h"

#pragma config FPLLMUL = MUL_20, FPLLIDIV = DIV_2, FPLLODIV = DIV_2, FWDTEN = OFF
#pragma config POSCMOD = XT, FNOSC = PRIPLL, FPBDIV = DIV_1

void rt_OneStep()
{
  /* Disable interrupts here */
  /* Save FPU context here (if necessary) */
  /* Re-enable timer or interrupt here */
  SD_Datalogger_step();

  /* Get model outputs here */

  /* Disable interrupts here */
  /* Restore FPU context here (if necessary) */
  /* Enable interrupts here */
}

int main(void)
{
  /* Initialize model */
  SD_Datalogger_initialize(1);
  for (;;) {
    /* Associate rt_OneStep() with a timer that executes at the base rate of the model */
    while (!_T1IF) ;
    _T1IF = 0;
    rt_OneStep();
  }
}

/* File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
