SD_Datalogger_dspic\sources\CustomSD.o: .\CustomSD.c \
  C:/PROGRA~1/MICROC~1/MPLABC~1/pic32mx/include/p32xxxx.h \
  C:/PROGRA~1/MICROC~1/MPLABC~1/pic32mx/include/proc/p32mx360f512l.h \
  C:/PROGRA~1/MICROC~1/MPLABC~1/pic32mx/include/proc/ppic32mx.h \
  C:/PROGRA~1/MICROC~1/MPLABC~1/pic32mx/include/cp0defs.h \
  C:/PROGRA~1/MICROC~1/MPLABC~1/pic32mx/include/sys/appio.h \
  C:/PROGRA~1/MICROC~1/MPLABC~1/pic32mx/include/stdlib.h \
  C:/PROGRA~1/MICROC~1/MPLABC~1/pic32mx/include/stddef.h \
  C:/PROGRA~1/MICROC~1/MPLABC~1/pic32mx/include/machine/ansi.h \
  C:/PROGRA~1/MICROC~1/MPLABC~1/pic32mx/include/string.h \
  C:/PROGRA~1/MICROC~1/MPLABC~1/pic32mx/include/stdio.h \
  C:/PROGRA~1/MICROC~1/MPLABC~1/pic32mx/include/sys/posix.h \
  C:/PROGRA~1/MICROC~1/MPLABC~1/pic32mx/include/pthread/unistd.h \
  C:/PROGRA~1/MICROC~1/MPLABC~1/pic32mx/include/stdarg.h \
  C:/PROGRA~1/MICROC~1/MPLABC~1/pic32mx/include/sys/types.h \
  C:/PROGRA~1/MICROC~1/MPLABC~1/pic32mx/include/machine/types.h \
  C:/PROGRA~1/MICROC~1/MPLABC~1/pic32mx/include/machine/int_types.h \
  C:/PROGRA~1/MICROC~1/MPLABC~1/pic32mx/include/machine/endian.h \
  C:/PROGRA~1/MICROC~1/MPLABC~1/pic32mx/include/sys/endian.h \
  C:/PROGRA~1/MICROC~1/MPLABC~1/pic32mx/include/sys/cdefs.h \
  C:/PROGRA~1/MICROC~1/MPLABC~1/pic32mx/include/machine/cdefs.h \
  C:/PROGRA~1/MICROC~1/MPLABC~1/pic32mx/include/sys/swap.h \
  C:/PROGRA~1/MICROC~1/MPLABC~1/pic32mx/include/libc_thread.h \
  C:/PROGRA~1/MICROC~1/MPLABC~1/pic32mx/include/pthread.h \
  C:/PROGRA~1/MICROC~1/MPLABC~1/pic32mx/include/signal.h \
  C:/PROGRA~1/MICROC~1/MPLABC~1/pic32mx/include/sys/signal.h \
  C:/PROGRA~1/MICROC~1/MPLABC~1/pic32mx/include/sys/time.h \
  C:/PROGRA~1/MICROC~1/MPLABC~1/pic32mx/include/sched.h \
  C:/PROGRA~1/MICROC~1/MPLABC~1/pic32mx/include/pthread/impl.h \
  C:/PROGRA~1/MICROC~1/MPLABC~1/pic32mx/include/pthread/limits.h \
  .\/FSconfig.h .\/HardwareProfile.h .\/HardwareProfile.h \
  C:/PROGRA~1/MICROC~1/MPLABC~1/pic32mx/include/GenericTypeDefs.h \
  C:/Users/Konstantin.Avdashche/Documents/USMA_projects/CEREBOT\ code/Microchip/Include/MDD\ File\ System/FSIO.h \
  C:/PROGRA~1/MICROC~1/MPLABC~1/pic32mx/include/GenericTypeDefs.h \
  ./FSconfig.h ./HardwareProfile.h \
  C:/Users/Konstantin.Avdashche/Documents/USMA_projects/CEREBOT\ code/Microchip/Include/MDD\ File\ System/FSDefs.h \
  C:/Users/Konstantin.Avdashche/Documents/USMA_projects/CEREBOT\ code/Microchip/Include/MDD\ File\ System/SD-SPI.h
