/*
 * File: SD_Datalogger.h
 *
 * Real-Time Workshop code generated for Simulink model SD_Datalogger.
 *
 * Model version                        : 1.123
 * Real-Time Workshop file version      : 7.5  (R2010a)  25-Jan-2010
 * Real-Time Workshop file generated on : Wed Apr 27 14:35:55 2011
 * TLC version                          : 7.5 (Jan 19 2010)
 * C source code generated on           : Wed Apr 27 14:35:55 2011
 *--------------------------------------------------------------
 *   Embedded Coder for Microchip dsPIC family.                 |
 *   Generate .c and .h files from your Matlab/simulink model   |
 *   and compile the diagram to .hex and .coff file that can be |
 *   downloaded directly into the microcontroller               |
 *                                                              |
 * Licence Accorded to John Rogers, Ph.D., P.E.                 |
 *                     West Point University                    |
 *                                                              |
 *   Written by Lubin KERHUEL -  http://www.kerhuel.eu          |
 *  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - |
 *   Version 3.4cb                             11-Apr-2011      |
 *   For Matlab 7.11            R2010b                          |
 *--------------------------------------------------------------
 */

#ifndef RTW_HEADER_SD_Datalogger_h_
#define RTW_HEADER_SD_Datalogger_h_
#ifndef SD_Datalogger_COMMON_INCLUDES_
# define SD_Datalogger_COMMON_INCLUDES_
#include <string.h>
#include "rtwtypes.h"
#include "string.h"
#endif                                 /* SD_Datalogger_COMMON_INCLUDES_ */

#include "SD_Datalogger_types.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((void*) 0)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((void) 0)
#endif

#ifndef rtmGetStopRequested
# define rtmGetStopRequested(rtm)      ((void*) 0)
#endif

/* Block signals (auto storage) */
typedef struct {
  uint16_T ADCInput;                   /* '<Root>/ADC Input' */
  uint8_T CFunctionCall;               /* '<S10>/C Function Call' */
  uint8_T CFunctionCall_b;             /* '<S6>/C Function Call' */
  boolean_T Button1;                   /* '<Root>/Button1' */
  boolean_T DataTypeConversion;        /* '<Root>/Data Type Conversion' */
  boolean_T CardDetect;                /* '<Root>/Card Detect' */
  boolean_T Toggle;                    /* '<Root>/Toggle' */
  boolean_T DataTypeConversion_d;      /* '<S3>/Data Type Conversion' */
} BlockIO_SD_Datalogger;

/* Block states (auto storage) for system '<Root>' */
typedef struct {
  int32_T clockTickCounter;            /* '<S2>/Pulse Generator' */
  boolean_T Delay_IC_BUFF;             /* '<S5>/Delay' */
  uint8_T Memory_PreviousInput;        /* '<S2>/Memory' */
} D_Work_SD_Datalogger;

/* Zero-crossing (trigger) state */
typedef struct {
  ZCSigState Writetofile_Trig_ZCE;     /* '<Root>/Write to file' */
  ZCSigState FSopen_Trig_ZCE;          /* '<S3>/FSopen' */
  ZCSigState FSclose_Trig_ZCE;         /* '<S3>/FSclose' */
  ZCSigState FSinit_Trig_ZCE;          /* '<S2>/FSinit' */
} PrevZCSigStates_SD_Datalogger;

/* Parameters (auto storage) */
struct Parameters_SD_Datalogger_ {
  real_T Constant_Value;               /* Expression: 0
                                        * Referenced by: '<S2>/Constant'
                                        */
  real_T PulseGenerator_Amp;           /* Expression: 1
                                        * Referenced by: '<S2>/Pulse Generator'
                                        */
  real_T PulseGenerator_Period;        /* Expression: 2
                                        * Referenced by: '<S2>/Pulse Generator'
                                        */
  real_T PulseGenerator_Duty;          /* Expression: 2
                                        * Referenced by: '<S2>/Pulse Generator'
                                        */
  real_T PulseGenerator_PhaseDelay;    /* Expression: 0
                                        * Referenced by: '<S2>/Pulse Generator'
                                        */
  real_T Constant_Value_d;             /* Expression: 1
                                        * Referenced by: '<Root>/Constant'
                                        */
  uint8_T Memory_X0;                   /* Computed Parameter: Memory_X0
                                        * Referenced by: '<S2>/Memory'
                                        */
  uint8_T Switch_Threshold;            /* Computed Parameter: Switch_Threshold
                                        * Referenced by: '<S2>/Switch'
                                        */
  uint8_T StringTXT_Value[10];         /* Computed Parameter: StringTXT_Value
                                        * Referenced by: '<Root>/String.TXT'
                                        */
  boolean_T Constant_Value_k;          /* Computed Parameter: Constant_Value_k
                                        * Referenced by: '<S1>/Constant'
                                        */
};

/* Block parameters (auto storage) */
extern Parameters_SD_Datalogger SD_Datalogger_P;

/* Block signals (auto storage) */
extern BlockIO_SD_Datalogger SD_Datalogger_B;

/* Block states (auto storage) */
extern D_Work_SD_Datalogger SD_Datalogger_DWork;

/* Model entry point functions */
extern void SD_Datalogger_initialize(boolean_T firstTime);
extern void SD_Datalogger_step(void);

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : SD_Datalogger
 * '<S1>'   : SD_Datalogger/Compare To Zero
 * '<S2>'   : SD_Datalogger/FSinit
 * '<S3>'   : SD_Datalogger/File_oper
 * '<S4>'   : SD_Datalogger/Write to file
 * '<S5>'   : SD_Datalogger/FSinit/Edge Detector
 * '<S6>'   : SD_Datalogger/FSinit/FSinit
 * '<S7>'   : SD_Datalogger/FSinit/Edge Detector/Check Signal Attributes
 * '<S8>'   : SD_Datalogger/FSinit/Edge Detector/Check Signal Attributes1
 * '<S9>'   : SD_Datalogger/File_oper/FSclose
 * '<S10>'  : SD_Datalogger/File_oper/FSopen
 */
#endif                                 /* RTW_HEADER_SD_Datalogger_h_ */

/* File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
