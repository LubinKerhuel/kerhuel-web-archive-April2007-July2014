/*
 * File: SD_Datalogger.c
 *
 * Real-Time Workshop code generated for Simulink model SD_Datalogger.
 *
 * Model version                        : 1.123
 * Real-Time Workshop file version      : 7.5  (R2010a)  25-Jan-2010
 * Real-Time Workshop file generated on : Wed Apr 27 14:35:55 2011
 * TLC version                          : 7.5 (Jan 19 2010)
 * C source code generated on           : Wed Apr 27 14:35:55 2011
 *--------------------------------------------------------------
 *   Embedded Coder for Microchip dsPIC family.                 |
 *   Generate .c and .h files from your Matlab/simulink model   |
 *   and compile the diagram to .hex and .coff file that can be |
 *   downloaded directly into the microcontroller               |
 *                                                              |
 * Licence Accorded to John Rogers, Ph.D., P.E.                 |
 *                     West Point University                    |
 *                                                              |
 *   Written by Lubin KERHUEL -  http://www.kerhuel.eu          |
 *  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - |
 *   Version 3.4cb                             11-Apr-2011      |
 *   For Matlab 7.11            R2010b                          |
 *--------------------------------------------------------------
 */

#include "SD_Datalogger.h"
#include "SD_Datalogger_private.h"

/* Block signals (auto storage) */
BlockIO_SD_Datalogger SD_Datalogger_B;

/* Block states (auto storage) */
D_Work_SD_Datalogger SD_Datalogger_DWork;

/* Previous zero-crossings (trigger) states */
PrevZCSigStates_SD_Datalogger SD_Datalogger_PrevZCSigState;

/* Model step function */
void SD_Datalogger_step(void)
{
  /* local block i/o variables */
  boolean_T rtb_LogicalConverter;
  uint8_T rtb_Compare;
  real_T rtb_Switch;
  boolean_T rtb_LogicalOperator_d;

  /* S-Function "ADC" Block: <Root>/ADC Input */
  SD_Datalogger_B.ADCInput = ADC1BUF0;

  /* S-Function "dsPIC_Digital_Input" Block: <Root>/Button1 */
  SD_Datalogger_B.Button1 = PORTAbits.RA6;

  /* Outputs for trigger SubSystem: '<Root>/Write to file' incorporates:
   *  TriggerPort: '<S4>/Trigger'
   */
  if (SD_Datalogger_B.Button1 &&
      (SD_Datalogger_PrevZCSigState.Writetofile_Trig_ZCE != POS_ZCSIG)) {
    /* S-Function "dsPIC_C_function_Call" Block: <S4>/C Function Call */
    FSprint(SD_Datalogger_B.ADCInput);
  }

  SD_Datalogger_PrevZCSigState.Writetofile_Trig_ZCE = (uint8_T)
    (SD_Datalogger_B.Button1 ? (int32_T)POS_ZCSIG : (int32_T)ZERO_ZCSIG);

  /* end of Outputs for SubSystem: '<Root>/Write to file' */

  /* DataTypeConversion: '<Root>/Data Type Conversion' incorporates:
   *  Constant: '<Root>/Constant'
   */
  SD_Datalogger_B.DataTypeConversion = (SD_Datalogger_P.Constant_Value_d != 0.0);

  /* S-Function "dsPIC_Digital_OutputWrite" Block: <Root>/Digital Output Write */
  LATFbits.LATF2 = SD_Datalogger_B.DataTypeConversion;

  /* S-Function "dsPIC_Digital_Input" Block: <Root>/Card Detect */
  SD_Datalogger_B.CardDetect = PORTDbits.RD4;

  /* Outputs for atomic SubSystem: '<Root>/FSinit' */

  /* S-Function (sdspdelay): '<S5>/Delay' */
  rtb_LogicalConverter = SD_Datalogger_DWork.Delay_IC_BUFF;

  /* Logic: '<S5>/Logical Operator1' incorporates:
   *  Logic: '<S5>/Logical Operator'
   */
  rtb_LogicalConverter = (SD_Datalogger_B.CardDetect && (!rtb_LogicalConverter));

  /* DiscretePulseGenerator: '<S2>/Pulse Generator' */
  rtb_Switch = ((real_T)SD_Datalogger_DWork.clockTickCounter <
                SD_Datalogger_P.PulseGenerator_Duty) &&
    (SD_Datalogger_DWork.clockTickCounter >= 0) ?
    SD_Datalogger_P.PulseGenerator_Amp : 0.0;
  if ((real_T)SD_Datalogger_DWork.clockTickCounter >=
      SD_Datalogger_P.PulseGenerator_Period - 1.0) {
    SD_Datalogger_DWork.clockTickCounter = 0;
  } else {
    SD_Datalogger_DWork.clockTickCounter = SD_Datalogger_DWork.clockTickCounter
      + 1;
  }

  /* Switch: '<S2>/Switch' incorporates:
   *  Constant: '<S2>/Constant'
   *  Memory: '<S2>/Memory'
   */
  if (SD_Datalogger_DWork.Memory_PreviousInput >
      SD_Datalogger_P.Switch_Threshold) {
    rtb_Switch = SD_Datalogger_P.Constant_Value;
  }

  /* Logic: '<S2>/Logical Operator' */
  rtb_LogicalOperator_d = (rtb_LogicalConverter || (rtb_Switch != 0.0));

  /* Outputs for trigger SubSystem: '<S2>/FSinit' incorporates:
   *  TriggerPort: '<S6>/Trigger'
   */
  if (rtb_LogicalOperator_d && (SD_Datalogger_PrevZCSigState.FSinit_Trig_ZCE !=
       POS_ZCSIG)) {
    /* S-Function "dsPIC_C_function_Call" Block: <S6>/C Function Call */
    SD_Datalogger_B.CFunctionCall_b = FS_init_loop();
  }

  SD_Datalogger_PrevZCSigState.FSinit_Trig_ZCE = (uint8_T)(rtb_LogicalOperator_d
    ? (int32_T)POS_ZCSIG : (int32_T)ZERO_ZCSIG);

  /* end of Outputs for SubSystem: '<S2>/FSinit' */

  /* Update for S-Function (sdspdelay): '<S5>/Delay' */
  SD_Datalogger_DWork.Delay_IC_BUFF = SD_Datalogger_B.CardDetect;

  /* Update for Memory: '<S2>/Memory' */
  SD_Datalogger_DWork.Memory_PreviousInput = SD_Datalogger_B.CFunctionCall_b;

  /* end of Outputs for SubSystem: '<Root>/FSinit' */
  /* S-Function "dsPIC_Digital_Input" Block: <Root>/Toggle */
  SD_Datalogger_B.Toggle = PORTFbits.RF8;

  /* RelationalOperator: '<S1>/Compare' incorporates:
   *  Constant: '<S1>/Constant'
   */
  rtb_Compare = ((int32_T)SD_Datalogger_B.Toggle == (int32_T)
                 SD_Datalogger_P.Constant_Value_k);

  /* Outputs for atomic SubSystem: '<Root>/File_oper' */

  /* Outputs for trigger SubSystem: '<S3>/FSopen' incorporates:
   *  TriggerPort: '<S10>/Trigger'
   */
  if (SD_Datalogger_B.Toggle && (SD_Datalogger_PrevZCSigState.FSopen_Trig_ZCE !=
       POS_ZCSIG)) {
    /* S-Function "dsPIC_C_function_Call" Block: <S10>/C Function Call */
    SD_Datalogger_B.CFunctionCall = FSopen(SD_Datalogger_P.StringTXT_Value);
  }

  SD_Datalogger_PrevZCSigState.FSopen_Trig_ZCE = (uint8_T)
    (SD_Datalogger_B.Toggle ? (int32_T)POS_ZCSIG : (int32_T)ZERO_ZCSIG);

  /* end of Outputs for SubSystem: '<S3>/FSopen' */

  /* DataTypeConversion: '<S3>/Data Type Conversion' */
  SD_Datalogger_B.DataTypeConversion_d = (SD_Datalogger_B.CFunctionCall != 0);

  /* S-Function "dsPIC_Digital_OutputWrite" Block: <S3>/Digital Output Write */
  LATBbits.LATB10 = SD_Datalogger_B.DataTypeConversion_d;

  /* Outputs for trigger SubSystem: '<S3>/FSclose' incorporates:
   *  TriggerPort: '<S9>/Trigger'
   */
  if ((rtb_Compare > 0) && (SD_Datalogger_PrevZCSigState.FSclose_Trig_ZCE !=
       POS_ZCSIG)) {
    /* S-Function "dsPIC_C_function_Call" Block: <S9>/C Function Call */
    FSclose();
  }

  SD_Datalogger_PrevZCSigState.FSclose_Trig_ZCE = (uint8_T)(rtb_Compare > 0 ?
    (int32_T)POS_ZCSIG : (int32_T)ZERO_ZCSIG);

  /* end of Outputs for SubSystem: '<S3>/FSclose' */

  /* end of Outputs for SubSystem: '<Root>/File_oper' */
}

/* Model initialize function */
void SD_Datalogger_initialize(boolean_T firstTime)
{
  (void)firstTime;

  /* Registration code */

  /* block I/O */
  (void) memset(((void *) &SD_Datalogger_B), 0,
                sizeof(BlockIO_SD_Datalogger));

  /* states (dwork) */
  (void) memset((void *)&SD_Datalogger_DWork, 0,
                sizeof(D_Work_SD_Datalogger));

  /* S-Function "dsPIC_MASTER" initialization Block: <Root>/Master */
  /* Solver mode : SingleTasking */
  /* CONFIG TIMER 1 for scheduling steps 	*/
  ConfigIntTimer1(T1_INT_PRIOR_0 | T1_INT_OFF);
  OpenTimer1(T1_ON | T1_GATE_OFF |
             T1_PS_1_1 | T1_SOURCE_INT | T1_IDLE_CON , 39999);

  /* Configuration TRIS */
  TRISB = 64511;
  TRISF = 65531;

  /* Configuration ADCHS */
  AD1PCFG = 1024U;
  INTEnableSystemMultiVectoredInt();

  /* S-Function "dsPIC_ADC" initialization Block: <Root>/ADC Input */
  /* Initialise ADC converter */
  /* 0 mean each 1 conversion */
#define NoSamplesADC                   0
#define ADCSval                        12
#define SAMCval                        (1 << 8)
#define OutFormatBitsval               (0 << 8)
#define VoltRef                        (0 << 13)

  /* Use internal counter Trigger, continuous simulatenous sampling */
  AD1CON1 = 0x0004 | (7 << 5) | (0 << 10)| OutFormatBitsval;
  AD1CON2 = 0x0400 | (NoSamplesADC << 2) | VoltRef;
  AD1CSSL = 1 ;
  AD1CON3 = (ADCSval | SAMCval) & 0xff7f;
  AD1CHS = 0x0000;
  IPC2 = (IPC2 | (6 << 12));           /*Interrupt Priority : 6*/
  _AD1IF = 0;

  /* We set _ADIE = 1 in the main file if necessary*/
  /* Clear Off Any Interrupt Due To Configuration */
  /* Turn on ADC Module */
  AD1CON1bits.ADON= 1;

  /* Start for atomic SubSystem: '<Root>/FSinit' */

  /* Start for DiscretePulseGenerator: '<S2>/Pulse Generator' */
  SD_Datalogger_DWork.clockTickCounter = 0;

  /* end of Start for SubSystem: '<Root>/FSinit' */
  SD_Datalogger_PrevZCSigState.Writetofile_Trig_ZCE = POS_ZCSIG;
  SD_Datalogger_PrevZCSigState.FSopen_Trig_ZCE = POS_ZCSIG;
  SD_Datalogger_PrevZCSigState.FSclose_Trig_ZCE = POS_ZCSIG;
  SD_Datalogger_PrevZCSigState.FSinit_Trig_ZCE = POS_ZCSIG;

  /* InitializeConditions for atomic SubSystem: '<Root>/FSinit' */

  /* InitializeConditions for S-Function (sdspdelay): '<S5>/Delay' */
  SD_Datalogger_DWork.Delay_IC_BUFF = TRUE;

  /* InitializeConditions for Memory: '<S2>/Memory' */
  SD_Datalogger_DWork.Memory_PreviousInput = SD_Datalogger_P.Memory_X0;

  /* end of InitializeConditions for SubSystem: '<Root>/FSinit' */
}

/* File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
