/*
 * File: SD_Datalogger_private.h
 *
 * Real-Time Workshop code generated for Simulink model SD_Datalogger.
 *
 * Model version                        : 1.123
 * Real-Time Workshop file version      : 7.5  (R2010a)  25-Jan-2010
 * Real-Time Workshop file generated on : Wed Apr 27 14:35:55 2011
 * TLC version                          : 7.5 (Jan 19 2010)
 * C source code generated on           : Wed Apr 27 14:35:55 2011
 *--------------------------------------------------------------
 *   Embedded Coder for Microchip dsPIC family.                 |
 *   Generate .c and .h files from your Matlab/simulink model   |
 *   and compile the diagram to .hex and .coff file that can be |
 *   downloaded directly into the microcontroller               |
 *                                                              |
 * Licence Accorded to John Rogers, Ph.D., P.E.                 |
 *                     West Point University                    |
 *                                                              |
 *   Written by Lubin KERHUEL -  http://www.kerhuel.eu          |
 *  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - |
 *   Version 3.4cb                             11-Apr-2011      |
 *   For Matlab 7.11            R2010b                          |
 *--------------------------------------------------------------
 */

#ifndef RTW_HEADER_SD_Datalogger_private_h_
#define RTW_HEADER_SD_Datalogger_private_h_
#include "rtwtypes.h"

/* dsPIC library */
#include "p32xxxx.h"
#include "timer.h"
#define fcy                            40000000
#include "dsp_rt.h"                    /* Signal Processing Blockset general run time support functions */
#ifndef __RTWTYPES_H__
#error This file requires rtwtypes.h to be included
#else
#ifdef TMWTYPES_PREVIOUSLY_INCLUDED
#error This file requires rtwtypes.h to be included before tmwtypes.h
#else

/* Check for inclusion of an incorrect version of rtwtypes.h */
#ifndef RTWTYPES_ID_C08S16I32L32N32F1
#error This code was generated with a different "rtwtypes.h" than the file included
#endif                                 /* RTWTYPES_ID_C08S16I32L32N32F1 */
#endif                                 /* TMWTYPES_PREVIOUSLY_INCLUDED */
#endif                                 /* __RTWTYPES_H__ */

#define _T1IF                          (IFS0bits.T1IF)
#define _SPI1IF                        (IFS0bits.SPI1TXIF)
#define _SPI1IE                        (IEC0bits.SPI1TXIE)
#define _SPI1EN                        (SPI1CONbits.ON)
#define _SPI2EN                        (SPI2CONbits.ON)
#define _AD1IF                         (IFS1bits.AD1IF)

extern void FSprint(uint16_T u1);
extern uint8_T FS_init_loop();
extern uint8_T FSopen(uint8_T* u1);
extern void FSclose();

#endif                                 /* RTW_HEADER_SD_Datalogger_private_h_ */

/* File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
