/*
 * File: SD_Datalogger5_types.h
 *
 * Real-Time Workshop code generated for Simulink model SD_Datalogger5.
 *
 * Model version                        : 1.22
 * Real-Time Workshop file version      : 8.0 (R2011a) 09-Mar-2011
 * Real-Time Workshop file generated on : Tue Jan 17 11:54:59 2012
 * TLC version                          : 8.0 (Feb  3 2011)
 * C source code generated on           : Tue Jan 17 11:54:59 2012
 *--------------------------------------------------------------
 *   Embedded Coder for Microchip dsPIC family.                 |
 *   Generate .c and .h files from your Matlab/simulink model   |
 *   and compile the diagram to .hex and .coff file that can be |
 *   downloaded directly into the microcontroller               |
 *                                                              |
 * Licence Accorded to &&               Licence Name          &&|
 *                     &&               Companie              &&|
 *                                                              |
 *   Written by Lubin KERHUEL -  http://www.kerhuel.eu          |
 *  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - |
 *   Version &&Version&&                       &&  Date       &&|
 *   For Matlab && VerMatlab && && Release &&                   |
 *--------------------------------------------------------------
 */

#ifndef RTW_HEADER_SD_Datalogger5_types_h_
#define RTW_HEADER_SD_Datalogger5_types_h_
#include "rtwtypes.h"

/* Parameters (auto storage) */
typedef struct Parameters_SD_Datalogger5_ Parameters_SD_Datalogger5;

#endif                                 /* RTW_HEADER_SD_Datalogger5_types_h_ */

/* File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
