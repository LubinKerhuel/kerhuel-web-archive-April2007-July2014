/*
 * File: SD_Datalogger5.h
 *
 * Real-Time Workshop code generated for Simulink model SD_Datalogger5.
 *
 * Model version                        : 1.22
 * Real-Time Workshop file version      : 8.0 (R2011a) 09-Mar-2011
 * Real-Time Workshop file generated on : Tue Jan 17 11:54:59 2012
 * TLC version                          : 8.0 (Feb  3 2011)
 * C source code generated on           : Tue Jan 17 11:54:59 2012
 *--------------------------------------------------------------
 *   Embedded Coder for Microchip dsPIC family.                 |
 *   Generate .c and .h files from your Matlab/simulink model   |
 *   and compile the diagram to .hex and .coff file that can be |
 *   downloaded directly into the microcontroller               |
 *                                                              |
 * Licence Accorded to &&               Licence Name          &&|
 *                     &&               Companie              &&|
 *                                                              |
 *   Written by Lubin KERHUEL -  http://www.kerhuel.eu          |
 *  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - |
 *   Version &&Version&&                       &&  Date       &&|
 *   For Matlab && VerMatlab && && Release &&                   |
 *--------------------------------------------------------------
 */

#ifndef RTW_HEADER_SD_Datalogger5_h_
#define RTW_HEADER_SD_Datalogger5_h_
#ifndef SD_Datalogger5_COMMON_INCLUDES_
# define SD_Datalogger5_COMMON_INCLUDES_
#include <string.h>
#include "rtwtypes.h"
#endif                                 /* SD_Datalogger5_COMMON_INCLUDES_ */

#include "SD_Datalogger5_types.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((void*) 0)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((void) 0)
#endif

#ifndef rtmGetStopRequested
# define rtmGetStopRequested(rtm)      ((void*) 0)
#endif

/* Block signals (auto storage) */
typedef struct {
  boolean_T DataTypeConversion;        /* '<Root>/Data Type Conversion' */
} BlockIO_SD_Datalogger5;

/* Parameters (auto storage) */
struct Parameters_SD_Datalogger5_ {
  real_T Constant_Value;               /* Expression: 1
                                        * Referenced by: '<Root>/Constant'
                                        */
};

/* Block parameters (auto storage) */
extern Parameters_SD_Datalogger5 SD_Datalogger5_P;

/* Block signals (auto storage) */
extern BlockIO_SD_Datalogger5 SD_Datalogger5_B;

/* Model entry point functions */
extern void SD_Datalogger5_initialize(boolean_T firstTime);
extern void SD_Datalogger5_step(void);

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : SD_Datalogger5
 */
#endif                                 /* RTW_HEADER_SD_Datalogger5_h_ */

/* File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
