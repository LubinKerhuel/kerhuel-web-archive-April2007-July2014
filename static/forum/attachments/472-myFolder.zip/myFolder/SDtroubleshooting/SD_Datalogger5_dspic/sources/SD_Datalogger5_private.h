/*
 * File: SD_Datalogger5_private.h
 *
 * Real-Time Workshop code generated for Simulink model SD_Datalogger5.
 *
 * Model version                        : 1.22
 * Real-Time Workshop file version      : 8.0 (R2011a) 09-Mar-2011
 * Real-Time Workshop file generated on : Tue Jan 17 11:54:59 2012
 * TLC version                          : 8.0 (Feb  3 2011)
 * C source code generated on           : Tue Jan 17 11:54:59 2012
 *--------------------------------------------------------------
 *   Embedded Coder for Microchip dsPIC family.                 |
 *   Generate .c and .h files from your Matlab/simulink model   |
 *   and compile the diagram to .hex and .coff file that can be |
 *   downloaded directly into the microcontroller               |
 *                                                              |
 * Licence Accorded to &&               Licence Name          &&|
 *                     &&               Companie              &&|
 *                                                              |
 *   Written by Lubin KERHUEL -  http://www.kerhuel.eu          |
 *  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - |
 *   Version &&Version&&                       &&  Date       &&|
 *   For Matlab && VerMatlab && && Release &&                   |
 *--------------------------------------------------------------
 */

#ifndef RTW_HEADER_SD_Datalogger5_private_h_
#define RTW_HEADER_SD_Datalogger5_private_h_
#include "rtwtypes.h"

/* dsPIC library */
#include "p32xxxx.h"
#include "timer.h"
#define fcy                            40000000
#ifndef __RTWTYPES_H__
#error This file requires rtwtypes.h to be included
#else
#ifdef TMWTYPES_PREVIOUSLY_INCLUDED
#error This file requires rtwtypes.h to be included before tmwtypes.h
#else

/* Check for inclusion of an incorrect version of rtwtypes.h */
#ifndef RTWTYPES_ID_C08S16I32L32N32F1
#error This code was generated with a different "rtwtypes.h" than the file included
#endif                                 /* RTWTYPES_ID_C08S16I32L32N32F1 */
#endif                                 /* TMWTYPES_PREVIOUSLY_INCLUDED */
#endif                                 /* __RTWTYPES_H__ */

#define _T1IF                          (IFS0bits.T1IF)
#define _SPI1IF                        (IFS0bits.SPI1TXIF)
#define _SPI1IE                        (IEC0bits.SPI1TXIE)
#define _SPI1EN                        (SPI1CONbits.ON)
#define _SPI2EN                        (SPI2CONbits.ON)
#endif                                 /* RTW_HEADER_SD_Datalogger5_private_h_ */

/* File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
