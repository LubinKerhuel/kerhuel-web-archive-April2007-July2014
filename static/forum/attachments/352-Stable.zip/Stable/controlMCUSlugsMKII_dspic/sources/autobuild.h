/*
 * File: autobuild.h
 *
 * Real-Time Workshop code generated for Simulink model controlMCUSlugsMKII.
 *
 * Model version                        : 1.716
 * Real-Time Workshop file version      : 6.6  (R2007a)  01-Feb-2007
 * Real-Time Workshop file generated on : Sat Nov 27 11:43:56 2010
 * TLC version                          : 6.6 (Jan 16 2007)
 * C source code generated on           : Sat Nov 27 11:43:58 2010
 *--------------------------------------------------------------
 *   Embedded Coder for Microchip dsPIC family.                 |
 *   Generate .c and .h files from your Matlab/simulink model   |
 *   and compile the diagram to .hex and .coff file that can be |
 *   downloaded directly into the microcontroller               |
 *                                                              |
 * Licence Accorded to Mariano I. Lizarraga                     |
 *                     University of California Santa Cruz (UCSC)|
 *                                                              |
 *   Written by Lubin KERHUEL -  http://www.kerhuel.eu          |
 *  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - |
 *   Version 0.99b+                            17-Mar-2009      |
 *   For Matlab 7.4             R2007a                          |
 *--------------------------------------------------------------
 */

#ifndef _RTW_HEADER_autobuild_h_
#define _RTW_HEADER_autobuild_h_
#include "controlMCUSlugsMKII.h"
#define INCLUDE_FIRST_TIME_ARG         1
#endif                                 /* _RTW_HEADER_autobuild_h_ */

/* File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
