/*
 * File: controlMCUSlugsMKII.c
 *
 * Real-Time Workshop code generated for Simulink model controlMCUSlugsMKII.
 *
 * Model version                        : 1.716
 * Real-Time Workshop file version      : 6.6  (R2007a)  01-Feb-2007
 * Real-Time Workshop file generated on : Sat Nov 27 11:43:56 2010
 * TLC version                          : 6.6 (Jan 16 2007)
 * C source code generated on           : Sat Nov 27 11:43:58 2010
 *--------------------------------------------------------------
 *   Embedded Coder for Microchip dsPIC family.                 |
 *   Generate .c and .h files from your Matlab/simulink model   |
 *   and compile the diagram to .hex and .coff file that can be |
 *   downloaded directly into the microcontroller               |
 *                                                              |
 * Licence Accorded to Mariano I. Lizarraga                     |
 *                     University of California Santa Cruz (UCSC)|
 *                                                              |
 *   Written by Lubin KERHUEL -  http://www.kerhuel.eu          |
 *  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - |
 *   Version 0.99b+                            17-Mar-2009      |
 *   For Matlab 7.4             R2007a                          |
 *--------------------------------------------------------------
 */

#include "controlMCUSlugsMKII.h"
#include "controlMCUSlugsMKII_private.h"

/* Block signals (auto storage) */
BlockIO_controlMCUSlugsMKII controlMCUSlugsMKII_B;

/* Block states (auto storage) */
D_Work_controlMCUSlugsMKII controlMCUSlugsMKII_DWork;

/* Previous zero-crossings (trigger) states */
PrevZCSigStates_controlMCUSlugs controlMCUSlugsM_PrevZCSigState;

/* Real-time model */
RT_MODEL_controlMCUSlugsMKII controlMCUSlugsMKII_M_;
RT_MODEL_controlMCUSlugsMKII *controlMCUSlugsMKII_M = &controlMCUSlugsMKII_M_;
static void rate_monotonic_scheduler(void);

/* Set which subrates need to run this base step (base rate always runs).
 * This function must be called prior to calling the model step function
 * in order to "remember" which rates need to run this base step.  The
 * buffering of events allows for overlapping preemption.
 */
void controlMCUSlugsMKII_SetEventsForThisBaseStep(boolean_T *eventFlags)
{
  /* Task runs when its counter is zero, computed via rtmStepTask macro */
  eventFlags[1] = ((boolean_T)rtmStepTask(controlMCUSlugsMKII_M, 1));
}

/* This function updates active task flag for each subrate
 * and rate transition flags for tasks that exchagne data.
 * The function assumes rate-monotonic multitasking scheduler.
 * The function must be called at model base rate so that
 * the generated code self-manages all its subrates and rate
 * transition flags.
 */
static void rate_monotonic_scheduler(void)
{
  /* Compute which subrates run during the next base time step.  Subrates
   * are an integer multiple of the base rate counter.  Therefore, the subtask
   * counter is reset when it reaches its limit (zero means run).
   */
  if (++controlMCUSlugsMKII_M->Timing.TaskCounters.TID[1] == 100) {/* Sample time: [1.0s, 0.0s] */
    controlMCUSlugsMKII_M->Timing.TaskCounters.TID[1] = 0;
  }
}

/* Output and update for atomic system:
 *   '<S70>/negprotect'
 *   '<S113>/negprotect'
 *   '<S237>/negprotect'
 *   '<S239>/negprotect1'
 */
void controlMCUSlugsM_negprotect(real32_T rtu_val,
  rtB_negprotect_controlMCUSlugsM *localB)
{
  /* Embedded MATLAB: '<S70>/negprotect' */
  if (rtu_val >= 1.000000047E-003F) {
    /*  This block supports an embeddable subset of the MATLAB language. */
    /*  See the help menu for details.  */
    localB->zpVal = rtu_val;
  } else {
    localB->zpVal = 1.000000047E-003F;
  }
}

/* Output and update for atomic system:
 *   '<S14>/myMux Fun1'
 *   '<S16>/myMux Fun1'
 *   '<S2>/myMux Fun2'
 */
void controlMCUSlugsMK_myMuxFun1(real32_T rtu_u1, real32_T rtu_u2, real32_T
  rtu_u3, rtB_myMuxFun1_controlMCUSlugsMK *localB)
{
  /* Embedded MATLAB: '<S14>/myMux Fun1' */
  /*  This block supports an embeddable subset of the MATLAB language. */
  /*  See the help menu for details.  */
  localB->y[0] = rtu_u1;
  localB->y[1] = rtu_u2;
  localB->y[2] = rtu_u3;
}

/* Output and update for atomic system:
 *   '<S129>/Embedded MATLAB Function'
 *   '<S183>/Embedded MATLAB Function'
 */
void cont_EmbeddedMATLABFunction(const real32_T rtu_x[3], const real32_T rtu_y[3],
  rtB_EmbeddedMATLABFunction_cont *localB)
{
  /* Embedded MATLAB: '<S129>/Embedded MATLAB Function' */
  /*  This block supports an embeddable subset of the MATLAB language. */
  /*  See the help menu for details.  */
  localB->xDoty = (rtu_x[0] * rtu_y[0] + rtu_x[1] * rtu_y[1]) + rtu_x[2] * rtu_y
    [2];
}

/* Output and update for atomic system:
 *   '<S149>/negprotect'
 *   '<S188>/negprotect'
 *   '<S214>/negprotect'
 *   '<S221>/negprotect'
 *   '<S247>/negprotect'
 *   '<S255>/negprotect'
 *   '<S264>/negprotect'
 */
void controlMCUSlug_negprotect_e(real32_T rtu_val,
  rtB_negprotect_controlMCUSlug_p *localB)
{
  /* Embedded MATLAB: '<S149>/negprotect' */
  if (rtu_val >= 1.000000047E-003F) {
    /*  This block supports an embeddable subset of the MATLAB language. */
    /*  See the help menu for details.  */
    localB->zpVal_k = rtu_val;
  } else {
    localB->zpVal_k = 1.000000047E-003F;
  }
}

/* Output and update for atomic system:
 *   '<S150>/Embedded MATLAB Function'
 *   '<S189>/Embedded MATLAB Function'
 */
void co_EmbeddedMATLABFunction_a(const real32_T rtu_x[3],
  rtB_EmbeddedMATLABFunction_co_e *localB)
{
  /* Embedded MATLAB: '<S150>/Embedded MATLAB Function' */
  /*  This block supports an embeddable subset of the MATLAB language. */
  /*  See the help menu for details.  */
  localB->xDoty_g = (rtu_x[0] * rtu_x[0] + rtu_x[1] * rtu_x[1]) + rtu_x[2] *
    rtu_x[2];
}

/* Output and update for atomic system:
 *   '<S215>/Embedded MATLAB Function'
 *   '<S222>/Embedded MATLAB Function'
 *   '<S248>/Embedded MATLAB Function'
 */
void co_EmbeddedMATLABFunction_h(const real32_T rtu_x[3],
  rtB_EmbeddedMATLABFunction_co_l *localB)
{
  /* Embedded MATLAB: '<S215>/Embedded MATLAB Function' */
  /*  This block supports an embeddable subset of the MATLAB language. */
  /*  See the help menu for details.  */
  localB->xDoty_j = (rtu_x[0] * rtu_x[0] + rtu_x[1] * rtu_x[1]) + rtu_x[2] *
    rtu_x[2];
}

/* Output and update for atomic system:
 *   '<S293>/myMux Fun1'
 *   '<S296>/myMux Fun1'
 *   '<S294>/myMux Fun1'
 *   '<S295>/myMux Fun1'
 */
void controlMCUSlugs_myMuxFun1_a(uint16_T rtu_u1, uint16_T rtu_u2, uint16_T
  rtu_u3, uint16_T rtu_u4, uint16_T rty_0[4])
{
  /* Embedded MATLAB: '<S293>/myMux Fun1' */
  /*  This block supports an embeddable subset of the MATLAB language. */
  /*  See the help menu for details.  */
  rty_0[0] = rtu_u1;
  rty_0[1] = rtu_u2;
  rty_0[2] = rtu_u3;
  rty_0[3] = rtu_u4;
}

/* Output and update for atomic system:
 *   '<S333>/myMux Fun1'
 *   '<S350>/myMux Fun1'
 */
void controlMCUSlugs_myMuxFun1_n(real32_T rtu_u1, real32_T rtu_u2, real32_T
  rtu_u3, real32_T rtu_u4, real32_T rtu_u5, real32_T rtu_u6, real32_T rtu_u7,
  real32_T rtu_u8, real32_T rtu_u9, rtB_myMuxFun1_controlMCUSlugs_p *localB)
{
  /* Embedded MATLAB: '<S333>/myMux Fun1' */
  /*  This block supports an embeddable subset of the MATLAB language. */
  /*  See the help menu for details.  */
  localB->y_l[0] = rtu_u1;
  localB->y_l[1] = rtu_u2;
  localB->y_l[2] = rtu_u3;
  localB->y_l[3] = rtu_u4;
  localB->y_l[4] = rtu_u5;
  localB->y_l[5] = rtu_u6;
  localB->y_l[6] = rtu_u7;
  localB->y_l[7] = rtu_u8;
  localB->y_l[8] = rtu_u9;
}

/* Output and update for atomic system:
 *   '<S334>/myMux Fun1'
 *   '<S334>/myMux Fun2'
 *   '<S351>/myMux Fun1'
 *   '<S351>/myMux Fun2'
 *   '<S9>/myMux Fun1'
 */
void controlMCUSlugs_myMuxFun1_o(real32_T rtu_u1, real32_T rtu_u2, real32_T
  rtu_u3, rtB_myMuxFun1_controlMCUSlugs_b *localB)
{
  /* Embedded MATLAB: '<S334>/myMux Fun1' */
  /*  This block supports an embeddable subset of the MATLAB language. */
  /*  See the help menu for details.  */
  localB->y_i[0] = rtu_u1;
  localB->y_i[1] = rtu_u2;
  localB->y_i[2] = rtu_u3;
}

/* Model step function for TID0 */
void controlMCUSlugsMKII_step0(void)   /* Sample time: [0.01s, 0.0s] */
{
  /* local block i/o variables */
  real_T rtb_DataTypeConversion;
  real_T rtb_IntegerDelay2;
  real_T rtb_IC1;
  real_T rtb_IntegerDelay2_b;
  real_T rtb_Switch3;
  real_T rtb_swIncrement;
  real_T rtb_AntiWindup;
  real_T rtb_Switch3_n;
  real_T rtb_IntegerDelay;
  real_T rtb_IntegerDelay1;
  real_T rtb_AntiWindup_e;
  real_T rtb_Switch3_k;
  real_T rtb_IntegerDelay_g;
  real_T rtb_IntegerDelay1_n;
  real_T rtb_AntiWindup_d;
  real_T rtb_Switch3_o;
  real_T rtb_IntegerDelay_i;
  real_T rtb_IntegerDelay1_j;
  real_T rtb_AntiWindup_k;
  real_T rtb_Switch3_g;
  real_T rtb_IntegerDelay_b;
  real_T rtb_IntegerDelay1_o;
  real_T rtb_UnitConversion;
  real_T rtb_AntiWindup_m;
  real_T rtb_Switch3_na;
  real_T rtb_IntegerDelay_c;
  real_T rtb_IntegerDelay1_d;
  real_T rtb_IntegerDelay1_c;
  real_T rtb_IntegerDelay3;
  real_T rtb_IntegerDelay3_l;
  real_T rtb_IntegerDelay3_k;
  real32_T rtb_Switch3_ov;
  real32_T rtb_u020;
  real32_T rtb_u5u6;
  real32_T rtb_Sum;
  real32_T rtb_Sum_o;
  real32_T rtb_u3u5;
  real32_T rtb_Sum_oz;
  real32_T rtb_Sum_m;
  real32_T rtb_Gain2;
  real32_T rtb_u1u3_g;
  real32_T rtb_u4u5;
  real32_T rtb_u5u6_l;
  real32_T rtb_Sum_od;
  real32_T rtb_Sum_i;
  real32_T rtb_u3u5_b;
  real32_T rtb_Sum_p;
  real32_T rtb_Sum_pu;
  real32_T rtb_Gain2_m;
  real32_T rtb_u1u3_l;
  real32_T rtb_u4u5_a;
  real32_T rtb_Product;
  real32_T rtb_Subtract;
  real32_T rtb_Switch3_oe;
  real32_T rtb_Sum_l[3];
  real32_T rtb_y[4];
  real32_T rtb_y_d;
  real32_T rtb_u525[3];
  real32_T rtb_Switch3_h;
  real32_T rtb_u45;
  real32_T rtb_Divide4;
  real32_T rtb_Add_id[3];
  real32_T rtb_Switch3_nn;
  real32_T rtb_Gain_m;
  real32_T rtb_NPey[3];
  real32_T rtb_Divide5[3];
  real32_T rtb_Switch3_a;
  real32_T rtb_Product_m;
  real32_T rtb_Switch3_m;
  real32_T rtb_Product_c;
  real32_T rtb_stWP;
  real32_T rtb_Saturation1;
  real32_T rtb_Saturation1_a;
  real32_T rtb_IC;
  real32_T rtb_Subtract_h[3];
  real32_T rtb_DataTypeConversion_d;
  real32_T rtb_DataTypeConversion2;
  real32_T rtb_Switch3_e;
  real32_T rtb_Switch3_c;
  real32_T rtb_xDoty;
  real32_T rtb_sinphi;
  real32_T rtb_Rh;
  real32_T rtb_Deg2R1;
  real32_T rtb_Add_fn[3];
  real32_T rtb_sinphi_a;
  real32_T rtb_Rh_o;
  real32_T rtb_Deg2R1_j;
  real32_T rtb_UEN2NEU[3];
  real32_T rtb_Add_d[3];
  real32_T rtb_Subtract1;
  real32_T rtb_sinphi_m;
  real32_T rtb_Rh_i;
  real32_T rtb_Deg2R1_d;
  real32_T rtb_Product1_m;
  real32_T rtb_Add_k[3];
  real32_T rtb_Add_ir;
  real32_T rtb_Product1_b;
  real32_T rtb_sinphi_c;
  real32_T rtb_Rh_m;
  real32_T rtb_Deg2R1_g;
  real32_T rtb_UEN2NEU_l[3];
  real32_T rtb_P;
  real32_T rtb_Divide1_d;
  real32_T rtb_Divide2;
  real32_T rtb_Switch3_f;
  real32_T rtb_ScheduleLPF;
  real32_T rtb_Add2;
  real32_T rtb_Switch3_c1;
  real32_T rtb_IntegerDelay2_f;
  real32_T rtb_Sum2;
  real32_T rtb_Switch1;
  real32_T rtb_Switch3_b;
  real32_T rtb_Add2_i;
  real32_T rtb_Theta_cLimit;
  real32_T rtb_Switch3_mx;
  real32_T rtb_Add_b1;
  real32_T rtb_Add4;
  real32_T rtb_Switch3_kr;
  real32_T rtb_Product1_j;
  real32_T rtb_NDelays;
  real32_T rtb_IntegerDelay2_fm;
  real32_T rtb_Sum2_k;
  real32_T rtb_Add3;
  real32_T rtb_Switch1_o;
  real32_T rtb_Switch3_p;
  real32_T rtb_Add2_d;
  real32_T rtb_Add1;
  real32_T rtb_Add3_i;
  real32_T rtb_Add4_k;
  real32_T rtb_Switch3_f3;
  real32_T rtb_Product1_a;
  real32_T rtb_NDelays_n;
  real32_T rtb_IntegerDelay2_h;
  real32_T rtb_Sum2_a;
  real32_T rtb_Add3_b;
  real32_T rtb_Switch1_k;
  real32_T rtb_Switch3_el;
  real32_T rtb_Add2_a;
  real32_T rtb_Enforceupperlimit_m;
  real32_T rtb_Add4_ki;
  real32_T rtb_ElevatorLimit;
  real32_T rtb_ThrottleLimit;
  real32_T rtb_y_g;
  real32_T rtb_y_o;
  real32_T rtb_y_i;
  real32_T rtb_Switch3_gn;
  real32_T rtb_Switch3_h4;
  real32_T rtb_PsiDotLimit;
  real32_T rtb_Switch;
  real32_T rtb_BankLimitCommand;
  real32_T rtb_Switch3_pa;
  real32_T rtb_u020_g;
  real32_T rtb_Switch3_fx;
  real32_T rtb_u2;
  real32_T rtb_Switch2;
  real32_T rtb_Switch3_my;
  real32_T rtb_Add4_m;
  real32_T rtb_Product1_p;
  real32_T rtb_NDelays_no;
  real32_T rtb_IntegerDelay2_ih;
  real32_T rtb_Sum2_c;
  real32_T rtb_Add3_k;
  real32_T rtb_Switch1_i;
  real32_T rtb_Switch3_pf;
  real32_T rtb_Add2_af;
  real32_T rtb_RudderLimit;
  real32_T rtb_UnitConversion_a;
  real32_T rtb_Add1_j;
  real32_T rtb_Add4_p;
  real32_T rtb_Switch3_i;
  real32_T rtb_Product1_mf;
  real32_T rtb_NDelays_m;
  real32_T rtb_IntegerDelay2_k;
  real32_T rtb_Sum2_b;
  real32_T rtb_Add3_o;
  real32_T rtb_Switch1_g;
  real32_T rtb_Switch3_cv;
  real32_T rtb_Add2_n;
  real32_T rtb_AileronLimit;
  real32_T rtb_y_om[3];
  real32_T rtb_Divide_l;
  real32_T rtb_Divide1_a;
  real32_T rtb_Divide_cm;
  real32_T rtb_Switch3_pq;
  real32_T rtb_IntegerDelay_k;
  real32_T rtb_IntegerDelay1_a;
  real32_T rtb_u2_o;
  real32_T rtb_y_m;
  real32_T rtb_IC_n;
  real32_T rtb_Divide_p;
  real32_T rtb_Subtract_b;
  real32_T rtb_Switch3_cj;
  real32_T rtb_IC_j;
  real32_T rtb_Divide_f4;
  real32_T rtb_Subtract_c;
  real32_T rtb_Gain_ey;
  real32_T rtb_Divide4_a;
  real32_T rtb_Divide3;
  real32_T rtb_Projection;
  real32_T rtb_Switch3_ae;
  real32_T rtb_IntegerDelay1_ov;
  real32_T rtb_Switch3_gq;
  real32_T rtb_Subtract1_d;
  real32_T rtb_Switch3_im;
  real32_T rtb_MathFunction[9];
  real32_T rtb_Product2_cp[3];
  real32_T rtb_Product3_ep[3];
  real32_T rtb_u525_m[3];
  real32_T rtb_Sum_mb[3];
  real32_T rtb_TmpHiddenBufferAtProduct1In[9];
  real32_T rtb_Product1_az[3];
  real32_T rtb_Deg2R_g;
  real32_T rtb_Sum2_j;
  real32_T rtb_Sum1_f[3];
  real32_T rtb_TmpHiddenBufferAtProduct1_h[9];
  real32_T rtb_Product1_jw[3];
  real32_T rtb_Deg2R_i;
  real32_T rtb_Sum2_jc;
  real32_T rtb_Add_n;
  real32_T rtb_TmpHiddenBufferAtProduct1_g[9];
  real32_T rtb_Sum1_g[3];
  real32_T rtb_Product1_d4[3];
  real32_T rtb_O[3];
  real32_T rtb_Pch[3];
  real32_T rtb_PchB[3];
  real32_T rtb_Diff;
  real32_T rtb_Subtract_a;
  real32_T rtb_IntegerDelay2_j;
  real32_T rtb_Sum2_d;
  real32_T rtb_Deg2R_c;
  real32_T rtb_UEN2NEU_f[3];
  real32_T rtb_Sum2_g0;
  real32_T rtb_Deg2R_a;
  real32_T rtb_Enforcelowerlimit_c;
  real32_T rtb_Product1_ma;
  real32_T rtb_Saturation1_pt;
  real32_T rtb_jxk;
  real32_T rtb_Add1_b;
  real32_T rtb_psi_ad;
  real32_T rtb_Gain2_f;
  real32_T rtb_IntegerDelay3_j;
  real32_T rtb_Abs2;
  real32_T rtb_Sum_k;
  real32_T rtb_Add1_l;
  real32_T rtb_IntegerDelay3_d;
  real32_T rtb_IntegerDelay3_hu;
  real32_T rtb_IntegerDelay3_p;
  uint16_T rtb_Switch_k;
  uint16_T rtb_Switch1_bs;
  uint16_T rtb_Switch2_l;
  uint16_T rtb_Switch3_c5;
  uint16_T rtb_Gain_pn;
  uint16_T rtb_Gain1_c;
  uint16_T rtb_Gain2_d;
  uint16_T rtb_Gain3_p;
  uint16_T rtb_DataTypeConversion_k;
  uint16_T rtb_DataTypeConversion_o;
  uint16_T rtb_DataTypeConversion_o5;
  uint16_T rtb_DataTypeConversion_j;
  uint16_T rtb_Gain_fi;
  uint16_T rtb_Gain1_cp;
  uint16_T rtb_Gain2_fp;
  uint16_T rtb_Gain3_j;
  uint16_T rtb_y_n[5];
  uint16_T rtb_TmpHiddenBufferAtSFunctionI[4];
  uint8_T rtb_Add_mo;
  uint8_T rtb_RelationalOperator2;
  uint8_T rtb_RelationalOperator2_k;
  uint8_T rtb_Add1_i;
  uint8_T rtb_RelationalOperator2_g;
  uint8_T rtb_IntegerDelay1_l;
  uint8_T rtb_RelationalOperator2_i;
  uint8_T rtb_SwitchDistanceLessthan;
  uint8_T rtb_RelationalOperator2_h;
  uint8_T rtb_Compare_l;
  uint8_T rtb_RelationalOperator2_a;
  uint8_T rtb_RelationalOperator2_j4;
  uint8_T rtb_RelationalOperator2_m3;
  uint8_T rtb_LogicalOperator;
  uint8_T rtb_LogicalOperator2;
  boolean_T rtb_LogicalOperator_e;
  boolean_T rtb_Largerthan180;
  boolean_T rtb_IntegerDelay1_oe;

  {                                    /* Sample time: [0.01s, 0.0s] */
    rate_monotonic_scheduler();
  }

  /* S-Function "dsPIC_PWM_IC" Block: <S277>/Input Capture */
  controlMCUSlugsMKII_B.InputCapture_o1 = ic2up;
  controlMCUSlugsMKII_B.InputCapture_o2 = ic3up;
  controlMCUSlugsMKII_B.InputCapture_o3 = ic4up;
  controlMCUSlugsMKII_B.InputCapture_o4 = ic5up;
  controlMCUSlugsMKII_B.InputCapture_o5 = ic8up;

  /* Embedded MATLAB: '<S277>/myMux Fun5' */

  /*  This block supports an embeddable subset of the MATLAB language. */
  /*  See the help menu for details.  */
  rtb_y_n[0] = controlMCUSlugsMKII_B.InputCapture_o1;
  rtb_y_n[1] = controlMCUSlugsMKII_B.InputCapture_o2;
  rtb_y_n[2] = controlMCUSlugsMKII_B.InputCapture_o3;
  rtb_y_n[3] = controlMCUSlugsMKII_B.InputCapture_o4;
  rtb_y_n[4] = controlMCUSlugsMKII_B.InputCapture_o5;

  /* S-Function "dsPIC_C_function_Call" Block: <S8>/Get Control Type [navSupport.c] */
  controlMCUSlugsMKII_B.GetControlTypenavSupportc = getApControlType();

  /* S-Function "UART_RX" Block: <S11>/Calculus Time Step */
  controlMCUSlugsMKII_B.CalculusTimeStep_o1 = CalculusTimeStep;
  controlMCUSlugsMKII_B.CalculusTimeStep_o2 = PR1;

  {
    real_T tmp;

    /* DataTypeConversion: '<S11>/Data Type Conversion12' incorporates:
     *  DataTypeConversion: '<S11>/Data Type Conversion3'
     *  DataTypeConversion: '<S11>/Data Type Conversion4'
     *  Gain: '<S11>/Gain'
     *  Product: '<S11>/Divide'
     *  Rounding: '<S11>/Rounding Function'
     */
    tmp = fmod(floor(floor((real_T)controlMCUSlugsMKII_B.CalculusTimeStep_o1 /
      (real_T)controlMCUSlugsMKII_B.CalculusTimeStep_o2 * 100.0)), 256.0);
    if (tmp < 0.0) {
      tmp += 256.0;
    }

    controlMCUSlugsMKII_B.DataTypeConversion12 = (uint8_T)tmp;
  }

  /* S-Function "dsPIC_C_function_Call" Block: <S1>/Data from GS [groundStationDriver.c] */
  gsRead(&controlMCUSlugsMKII_B.DatafromGSgroundStationDriverc[0]);

  /* S-Function "dsPIC_C_function_Call" Block: <S1>/Data from IPC [interProcCommSlave.c] */
  readIpc(&controlMCUSlugsMKII_B.DatafromIPCinterProcCommSlavec[0]);

  /* S-Function "dsPIC_C_function_Call" Block: <S7>/Parser//Decoder [protDecoder.c] */
  protParseDecode(controlMCUSlugsMKII_B.DatafromIPCinterProcCommSlavec);

  /* S-Function "dsPIC_C_function_Call" Block: <S7>/GS Messages  Parser//Decoder [groundStationDriver.c] */
  protParseDecodeGS(controlMCUSlugsMKII_B.DatafromGSgroundStationDriverc);

  /* S-Function "dsPIC_C_function_Call" Block: <S7>/update Load of  Control MCU [groundStationDriver.c] */
  updateLoad(controlMCUSlugsMKII_B.DataTypeConversion12);

  /* S-Function "dsPIC_C_function_Call" Block: <Root>/Get MidLevel Commands [navSupport.c] */
  getMidLevelCommands(&controlMCUSlugsMKII_B.GetMidLevelCommandsnavSupportc[0]);

  /* S-Function "dsPIC_C_function_Call" Block: <Root>/Get Dynamic P [navSupport.c] */
  controlMCUSlugsMKII_B.GetDynamicPnavSupportc = getDynamic();

  /* S-Function "dsPIC_C_function_Call" Block: <S3>/Get Pid according to Index */
  getPidIdx(((uint8_T)0U),&controlMCUSlugsMKII_B.GetPidaccordingtoIndex[0]);

  /* Embedded MATLAB: '<S276>/Buffer IC Channel' */
  {
    int16_T eml_i;

    /*  This block supports an embeddable subset of the MATLAB language. */
    /*  See the help menu for details.  */
    for (eml_i = 0; eml_i < 7; eml_i++) {
      controlMCUSlugsMKII_B.history_n[eml_i] = 0U;
    }

    for (eml_i = 7; eml_i > 1; eml_i += -1) {
      controlMCUSlugsMKII_DWork.BufferICChannel.oldValues[eml_i - 1] =
        controlMCUSlugsMKII_DWork.BufferICChannel.oldValues[eml_i - 2];
      controlMCUSlugsMKII_B.history_n[eml_i - 1] =
        controlMCUSlugsMKII_DWork.BufferICChannel.oldValues[eml_i - 2];
    }

    controlMCUSlugsMKII_DWork.BufferICChannel.oldValues[0] = rtb_y_n[0];
    controlMCUSlugsMKII_B.history_n[0] = rtb_y_n[0];
  }

  /* Embedded MATLAB: '<S276>/Buffer IC Channel1' */
  {
    int16_T eml_i;

    /*  This block supports an embeddable subset of the MATLAB language. */
    /*  See the help menu for details.  */
    for (eml_i = 0; eml_i < 7; eml_i++) {
      controlMCUSlugsMKII_B.history_ec[eml_i] = 0U;
    }

    for (eml_i = 7; eml_i > 1; eml_i += -1) {
      controlMCUSlugsMKII_DWork.BufferICChannel1.oldValues[eml_i - 1] =
        controlMCUSlugsMKII_DWork.BufferICChannel1.oldValues[eml_i - 2];
      controlMCUSlugsMKII_B.history_ec[eml_i - 1] =
        controlMCUSlugsMKII_DWork.BufferICChannel1.oldValues[eml_i - 2];
    }

    controlMCUSlugsMKII_DWork.BufferICChannel1.oldValues[0] = rtb_y_n[1];
    controlMCUSlugsMKII_B.history_ec[0] = rtb_y_n[1];
  }

  /* Embedded MATLAB: '<S276>/Buffer IC Channel2' */
  {
    int16_T eml_i;

    /*  This block supports an embeddable subset of the MATLAB language. */
    /*  See the help menu for details.  */
    for (eml_i = 0; eml_i < 7; eml_i++) {
      controlMCUSlugsMKII_B.history_e[eml_i] = 0U;
    }

    for (eml_i = 7; eml_i > 1; eml_i += -1) {
      controlMCUSlugsMKII_DWork.BufferICChannel2.oldValues[eml_i - 1] =
        controlMCUSlugsMKII_DWork.BufferICChannel2.oldValues[eml_i - 2];
      controlMCUSlugsMKII_B.history_e[eml_i - 1] =
        controlMCUSlugsMKII_DWork.BufferICChannel2.oldValues[eml_i - 2];
    }

    controlMCUSlugsMKII_DWork.BufferICChannel2.oldValues[0] = rtb_y_n[3];
    controlMCUSlugsMKII_B.history_e[0] = rtb_y_n[3];
  }

  /* Embedded MATLAB: '<S276>/Buffer IC Channel3' */
  {
    int16_T eml_i;

    /*  This block supports an embeddable subset of the MATLAB language. */
    /*  See the help menu for details.  */
    for (eml_i = 0; eml_i < 7; eml_i++) {
      controlMCUSlugsMKII_B.history[eml_i] = 0U;
    }

    for (eml_i = 7; eml_i > 1; eml_i += -1) {
      controlMCUSlugsMKII_DWork.BufferICChannel3.oldValues[eml_i - 1] =
        controlMCUSlugsMKII_DWork.BufferICChannel3.oldValues[eml_i - 2];
      controlMCUSlugsMKII_B.history[eml_i - 1] =
        controlMCUSlugsMKII_DWork.BufferICChannel3.oldValues[eml_i - 2];
    }

    controlMCUSlugsMKII_DWork.BufferICChannel3.oldValues[0] = rtb_y_n[2];
    controlMCUSlugsMKII_B.history[0] = rtb_y_n[2];
  }

  /* S-Function (sfix_udelay): '<S6>/Integer Delay'
   *
   * Regarding '<S6>/Integer Delay':
   * Integer/Tapped Delay Block: '<S6>/Integer Delay'
   */
  controlMCUSlugsMKII_B.IntegerDelay =
    controlMCUSlugsMKII_DWork.IntegerDelay_X_p;

  /* S-Function "dsPIC_C_function_Call" Block: <S6>/Manual or Auto? [navSupport.c] */
  controlMCUSlugsMKII_B.ManualorAutonavSupportc = isApManual();

  {
    ZCEventType zcEvent;

    /* DataTypeConversion: '<S278>/Data Type Conversion' */
    rtb_DataTypeConversion = (real_T)
      controlMCUSlugsMKII_B.ManualorAutonavSupportc;

    /* HitCross: '<S278>/Hit  Crossing' */
    zcEvent = rt_ZCFcn(FALLING_ZERO_CROSSING,
                       &controlMCUSlugsM_PrevZCSigState.HitCrossing_ZCE,
                       (rtb_DataTypeConversion - 0.5));
    if (controlMCUSlugsMKII_DWork.HitCrossing_MODE == 0L) {
      if (zcEvent != NO_ZCEVENT) {
        controlMCUSlugsMKII_B.HitCrossing = ((controlMCUSlugsMKII_B.HitCrossing ==
          1 ? 0 : 1) != 0);
        controlMCUSlugsMKII_DWork.HitCrossing_MODE = 1L;
      } else if ((controlMCUSlugsMKII_B.HitCrossing == 1) &&
                 (rtb_DataTypeConversion != 0.5)) {
        controlMCUSlugsMKII_B.HitCrossing = 0U;
      }
    } else {
      if (rtb_DataTypeConversion != 0.5) {
        controlMCUSlugsMKII_B.HitCrossing = 0U;
      }

      controlMCUSlugsMKII_DWork.HitCrossing_MODE = 0L;
    }

    /* InitialCondition: '<S278>/IC' */
    if (controlMCUSlugsMKII_DWork.IC_FirstOutputTime) {
      controlMCUSlugsMKII_DWork.IC_FirstOutputTime = 0U;
      controlMCUSlugsMKII_B.IC_c = 1U;
    } else {
      controlMCUSlugsMKII_B.IC_c = controlMCUSlugsMKII_B.HitCrossing;
    }

    /* Sum: '<S278>/Add' incorporates:
     *  S-Function (sfix_udelay): '<S278>/Integer Delay2'
     */
    rtb_Add_mo = (uint8_T)((uint16_T)
      (controlMCUSlugsMKII_DWork.IntegerDelay2_X_k) + (uint16_T)
      controlMCUSlugsMKII_B.IC_c);
    if (rtb_Add_mo > 0U) {
      if (controlMCUSlugsMKII_DWork.GrabIC_MODE == (int32_T)SUBSYS_DISABLED) {
        controlMCUSlugsMKII_DWork.GrabIC_MODE = (int32_T)SUBSYS_ENABLED;
      }
    } else if (controlMCUSlugsMKII_DWork.GrabIC_MODE == (int32_T)SUBSYS_ENABLED)
    {
      controlMCUSlugsMKII_DWork.GrabIC_MODE = (int32_T)SUBSYS_DISABLED;
    }

    if (controlMCUSlugsMKII_DWork.GrabIC_MODE == (int32_T)SUBSYS_ENABLED) {
      /* Output and update for enable system: '<S6>/Grab I.C.' */

      /* S-Function "dsPIC_C_function_Call" Block: <S279>/Choose the Median [navSupport.c] */
      controlMCUSlugsMKII_B.ChoosetheMediannavSupportc = meanFilter5
        (controlMCUSlugsMKII_B.history_n);

      /* DataTypeConversion: '<S286>/Data Type Conversion' incorporates:
       *  Constant: '<S286>/Constant1'
       *  Constant: '<S286>/Constant2'
       *  Product: '<S286>/Divide'
       *  Sum: '<S286>/Add'
       */
      controlMCUSlugsMKII_B.DataTypeConversion = (real32_T)((real_T)
        controlMCUSlugsMKII_B.ChoosetheMediannavSupportc *
        3.9246467817896402E-004 + -2.4929356357927808E+000);

      /* S-Function "dsPIC_C_function_Call" Block: <S279>/Choose the Median [navSupport.c]1 */
      controlMCUSlugsMKII_B.ChoosetheMediannavSupportc1 = meanFilter5
        (controlMCUSlugsMKII_B.history_ec);

      /* DataTypeConversion: '<S287>/Data Type Conversion' incorporates:
       *  Constant: '<S287>/Constant1'
       *  Constant: '<S287>/Constant2'
       *  Product: '<S287>/Divide'
       *  Sum: '<S287>/Add'
       */
      controlMCUSlugsMKII_B.DataTypeConversion_f = (real32_T)((real_T)
        controlMCUSlugsMKII_B.ChoosetheMediannavSupportc1 *
        1.4565320234764749E-004 + -1.0755448613357002E+000);

      /* S-Function "dsPIC_C_function_Call" Block: <S279>/Choose the Median [navSupport.c]2 */
      controlMCUSlugsMKII_B.ChoosetheMediannavSupportc2 = meanFilter5
        (controlMCUSlugsMKII_B.history_e);

      /* DataTypeConversion: '<S288>/Data Type Conversion' incorporates:
       *  Constant: '<S288>/Constant1'
       *  Constant: '<S288>/Constant2'
       *  Product: '<S288>/Divide'
       *  Sum: '<S288>/Add'
       */
      controlMCUSlugsMKII_B.DataTypeConversion_b = (real32_T)((real_T)
        controlMCUSlugsMKII_B.ChoosetheMediannavSupportc2 *
        1.7474741230625283E-004 + -1.3006200258793963E+000);

      /* S-Function "dsPIC_C_function_Call" Block: <S279>/Choose the Median [navSupport.c]3 */
      controlMCUSlugsMKII_B.ChoosetheMediannavSupportc3 = meanFilter5
        (controlMCUSlugsMKII_B.history);

      /* DataTypeConversion: '<S289>/Data Type Conversion' incorporates:
       *  Constant: '<S289>/Constant1'
       *  Constant: '<S289>/Constant2'
       *  Product: '<S289>/Divide'
       *  Sum: '<S289>/Add'
       */
      controlMCUSlugsMKII_B.DataTypeConversion_c = (real32_T)((real_T)
        controlMCUSlugsMKII_B.ChoosetheMediannavSupportc3 *
        1.2648319566552172E-004 + -9.5530950783373303E-001);

      /* S-Function "dsPIC_C_function_Call" Block: <S279>/Set Current Height and Airspeed as Commands [navSupport.c] */
      setCurrentCommands(controlMCUSlugsMKII_B.IntegerDelay);
    }
  }

  /* S-Function "dsPIC_C_function_Call" Block: <Root>/Get XYZ [navSupport.c] */
  getXYZ(&controlMCUSlugsMKII_B.GetXYZnavSupportc[0]);

  /* RelationalOperator: '<S17>/Relational Operator2' */
  rtb_RelationalOperator2 = (controlMCUSlugsMKII_B.GetXYZnavSupportc[2] ==
    controlMCUSlugsMKII_B.GetXYZnavSupportc[2]);

  /* Switch: '<S17>/Switch3' incorporates:
   *  S-Function (sfix_udelay): '<S17>/Integer Delay3'
   */
  if (rtb_RelationalOperator2 > 0U) {
    rtb_Switch3_ov = controlMCUSlugsMKII_B.GetXYZnavSupportc[2];
  } else {
    rtb_Switch3_ov = (controlMCUSlugsMKII_DWork.IntegerDelay3_X_j5);
  }

  /* Saturate: '<S2>/[-20 20]' */
  rtb_u020 = rt_SATURATE(rtb_Switch3_ov, 170.0F, 350.0F);

  /* S-Function "dsPIC_C_function_Call" Block: <S3>/Get Pid according to Index1 */
  getPidIdx(((uint8_T)1U),&controlMCUSlugsMKII_B.GetPidaccordingtoIndex1[0]);

  /* S-Function "dsPIC_C_function_Call" Block: <S9>/[navSupport.c]  */
  getPidIdx(((uint8_T)7U),&controlMCUSlugsMKII_B.navSupportc[0]);

  /* Gain: '<S309>/Unit Conversion' */
  controlMCUSlugsMKII_B.UnitConversion[0] = 1.745329238E-002F *
    controlMCUSlugsMKII_B.navSupportc[0];
  controlMCUSlugsMKII_B.UnitConversion[1] = 1.745329238E-002F *
    controlMCUSlugsMKII_B.navSupportc[1];
  controlMCUSlugsMKII_B.UnitConversion[2] = 1.745329238E-002F *
    controlMCUSlugsMKII_B.navSupportc[2];

  /* S-Function "dsPIC_C_function_Call" Block: <S334>/C Function Call1 */
  controlMCUSlugsMKII_B.CFunctionCall1 = myCos
    (controlMCUSlugsMKII_B.UnitConversion[0]);

  /* S-Function "dsPIC_C_function_Call" Block: <S334>/C Function Call4 */
  controlMCUSlugsMKII_B.CFunctionCall4 = myCos
    (controlMCUSlugsMKII_B.UnitConversion[1]);

  /* S-Function "dsPIC_C_function_Call" Block: <S334>/C Function Call5 */
  controlMCUSlugsMKII_B.CFunctionCall5 = myCos
    (controlMCUSlugsMKII_B.UnitConversion[2]);

  /* Stateflow: '<S334>/myMux Fun2' */
  controlMCUSlugs_myMuxFun1_o(controlMCUSlugsMKII_B.CFunctionCall1,
    controlMCUSlugsMKII_B.CFunctionCall4, controlMCUSlugsMKII_B.CFunctionCall5,
    &controlMCUSlugsMKII_B.sf_myMuxFun2);

  /* Product: '<S324>/u(5)*u(6)' */
  rtb_u5u6 = controlMCUSlugsMKII_B.sf_myMuxFun2.y_i[1] *
    controlMCUSlugsMKII_B.sf_myMuxFun2.y_i[2];

  /* S-Function "dsPIC_C_function_Call" Block: <S334>/C Function Call */
  controlMCUSlugsMKII_B.CFunctionCall = mySin
    (controlMCUSlugsMKII_B.UnitConversion[0]);

  /* S-Function "dsPIC_C_function_Call" Block: <S334>/C Function Call2 */
  controlMCUSlugsMKII_B.CFunctionCall2 = mySin
    (controlMCUSlugsMKII_B.UnitConversion[1]);

  /* S-Function "dsPIC_C_function_Call" Block: <S334>/C Function Call3 */
  controlMCUSlugsMKII_B.CFunctionCall3 = mySin
    (controlMCUSlugsMKII_B.UnitConversion[2]);

  /* Stateflow: '<S334>/myMux Fun1' */
  controlMCUSlugs_myMuxFun1_o(controlMCUSlugsMKII_B.CFunctionCall,
    controlMCUSlugsMKII_B.CFunctionCall2, controlMCUSlugsMKII_B.CFunctionCall3,
    &controlMCUSlugsMKII_B.sf_myMuxFun1);

  /* Sum: '<S327>/Sum' incorporates:
   *  Product: '<S327>/u(3)*u(4)'
   *  Product: '<S327>/u(6)*u(1)*u(2)'
   */
  rtb_Sum = controlMCUSlugsMKII_B.sf_myMuxFun2.y_i[2] *
    controlMCUSlugsMKII_B.sf_myMuxFun1.y_i[0] *
    controlMCUSlugsMKII_B.sf_myMuxFun1.y_i[1] -
    controlMCUSlugsMKII_B.sf_myMuxFun1.y_i[2] *
    controlMCUSlugsMKII_B.sf_myMuxFun2.y_i[0];

  /* Sum: '<S330>/Sum' incorporates:
   *  Product: '<S330>/u(1)*u(3)'
   *  Product: '<S330>/u(2)*u(4)*u(6)'
   */
  rtb_Sum_o = controlMCUSlugsMKII_B.sf_myMuxFun1.y_i[1] *
    controlMCUSlugsMKII_B.sf_myMuxFun2.y_i[0] *
    controlMCUSlugsMKII_B.sf_myMuxFun2.y_i[2] +
    controlMCUSlugsMKII_B.sf_myMuxFun1.y_i[0] *
    controlMCUSlugsMKII_B.sf_myMuxFun1.y_i[2];

  /* Product: '<S325>/u(3)*u(5)' */
  rtb_u3u5 = controlMCUSlugsMKII_B.sf_myMuxFun1.y_i[2] *
    controlMCUSlugsMKII_B.sf_myMuxFun2.y_i[1];

  /* Sum: '<S328>/Sum' incorporates:
   *  Product: '<S328>/u(1)*u(2)*u(3)'
   *  Product: '<S328>/u(4)*u(6)'
   */
  rtb_Sum_oz = controlMCUSlugsMKII_B.sf_myMuxFun1.y_i[0] *
    controlMCUSlugsMKII_B.sf_myMuxFun1.y_i[1] *
    controlMCUSlugsMKII_B.sf_myMuxFun1.y_i[2] +
    controlMCUSlugsMKII_B.sf_myMuxFun2.y_i[0] *
    controlMCUSlugsMKII_B.sf_myMuxFun2.y_i[2];

  /* Sum: '<S331>/Sum' incorporates:
   *  Product: '<S331>/u(1)*u(6)'
   *  Product: '<S331>/u(2)*u(3)*u(4)'
   */
  rtb_Sum_m = controlMCUSlugsMKII_B.sf_myMuxFun1.y_i[1] *
    controlMCUSlugsMKII_B.sf_myMuxFun1.y_i[2] *
    controlMCUSlugsMKII_B.sf_myMuxFun2.y_i[0] -
    controlMCUSlugsMKII_B.sf_myMuxFun2.y_i[2] *
    controlMCUSlugsMKII_B.sf_myMuxFun1.y_i[0];

  /* Gain: '<S326>/Gain2' */
  rtb_Gain2 = -1.0F * controlMCUSlugsMKII_B.sf_myMuxFun1.y_i[1];

  /* Product: '<S329>/u(1)*u(3)' */
  rtb_u1u3_g = controlMCUSlugsMKII_B.sf_myMuxFun1.y_i[0] *
    controlMCUSlugsMKII_B.sf_myMuxFun2.y_i[1];

  /* Product: '<S332>/u(4)*u(5)' */
  rtb_u4u5 = controlMCUSlugsMKII_B.sf_myMuxFun2.y_i[0] *
    controlMCUSlugsMKII_B.sf_myMuxFun2.y_i[1];

  /* Stateflow: '<S333>/myMux Fun1' */
  controlMCUSlugs_myMuxFun1_n(rtb_u5u6, rtb_Sum, rtb_Sum_o, rtb_u3u5, rtb_Sum_oz,
    rtb_Sum_m, rtb_Gain2, rtb_u1u3_g, rtb_u4u5,
    &controlMCUSlugsMKII_B.sf_myMuxFun1_n);

  /* Math: '<S9>/Math Function' */

  /* Operator : transpose */
  {
    uint32_T count = 0;
    uint32_T row;
    uint32_T col;
    for (row= 0; row < 3; row++) {
      for (col= 0; col < 3; col++) {
        rtb_MathFunction[row + 3 * col] =
          controlMCUSlugsMKII_B.sf_myMuxFun1_n.y_l[count];
        count++;
      }
    }
  }

  /* S-Function "dsPIC_C_function_Call" Block: <S9>/Get Attitude [navSupport.c] */
  getAttitude(&controlMCUSlugsMKII_B.GetAttitudenavSupportc[0]);

  /* S-Function "dsPIC_C_function_Call" Block: <S351>/C Function Call1 */
  controlMCUSlugsMKII_B.CFunctionCall1_g = myCos
    (controlMCUSlugsMKII_B.GetAttitudenavSupportc[0]);

  /* S-Function "dsPIC_C_function_Call" Block: <S351>/C Function Call4 */
  controlMCUSlugsMKII_B.CFunctionCall4_a = myCos
    (controlMCUSlugsMKII_B.GetAttitudenavSupportc[1]);

  /* S-Function "dsPIC_C_function_Call" Block: <S351>/C Function Call5 */
  controlMCUSlugsMKII_B.CFunctionCall5_d = myCos
    (controlMCUSlugsMKII_B.GetAttitudenavSupportc[2]);

  /* Stateflow: '<S351>/myMux Fun2' */
  controlMCUSlugs_myMuxFun1_o(controlMCUSlugsMKII_B.CFunctionCall1_g,
    controlMCUSlugsMKII_B.CFunctionCall4_a,
    controlMCUSlugsMKII_B.CFunctionCall5_d,
    &controlMCUSlugsMKII_B.sf_myMuxFun2_c);

  /* Product: '<S341>/u(5)*u(6)' */
  rtb_u5u6_l = controlMCUSlugsMKII_B.sf_myMuxFun2_c.y_i[1] *
    controlMCUSlugsMKII_B.sf_myMuxFun2_c.y_i[2];

  /* S-Function "dsPIC_C_function_Call" Block: <S351>/C Function Call */
  controlMCUSlugsMKII_B.CFunctionCall_i = mySin
    (controlMCUSlugsMKII_B.GetAttitudenavSupportc[0]);

  /* S-Function "dsPIC_C_function_Call" Block: <S351>/C Function Call2 */
  controlMCUSlugsMKII_B.CFunctionCall2_e = mySin
    (controlMCUSlugsMKII_B.GetAttitudenavSupportc[1]);

  /* S-Function "dsPIC_C_function_Call" Block: <S351>/C Function Call3 */
  controlMCUSlugsMKII_B.CFunctionCall3_i = mySin
    (controlMCUSlugsMKII_B.GetAttitudenavSupportc[2]);

  /* Stateflow: '<S351>/myMux Fun1' */
  controlMCUSlugs_myMuxFun1_o(controlMCUSlugsMKII_B.CFunctionCall_i,
    controlMCUSlugsMKII_B.CFunctionCall2_e,
    controlMCUSlugsMKII_B.CFunctionCall3_i,
    &controlMCUSlugsMKII_B.sf_myMuxFun1_a);

  /* Sum: '<S344>/Sum' incorporates:
   *  Product: '<S344>/u(3)*u(4)'
   *  Product: '<S344>/u(6)*u(1)*u(2)'
   */
  rtb_Sum_od = controlMCUSlugsMKII_B.sf_myMuxFun2_c.y_i[2] *
    controlMCUSlugsMKII_B.sf_myMuxFun1_a.y_i[0] *
    controlMCUSlugsMKII_B.sf_myMuxFun1_a.y_i[1] -
    controlMCUSlugsMKII_B.sf_myMuxFun1_a.y_i[2] *
    controlMCUSlugsMKII_B.sf_myMuxFun2_c.y_i[0];

  /* Sum: '<S347>/Sum' incorporates:
   *  Product: '<S347>/u(1)*u(3)'
   *  Product: '<S347>/u(2)*u(4)*u(6)'
   */
  rtb_Sum_i = controlMCUSlugsMKII_B.sf_myMuxFun1_a.y_i[1] *
    controlMCUSlugsMKII_B.sf_myMuxFun2_c.y_i[0] *
    controlMCUSlugsMKII_B.sf_myMuxFun2_c.y_i[2] +
    controlMCUSlugsMKII_B.sf_myMuxFun1_a.y_i[0] *
    controlMCUSlugsMKII_B.sf_myMuxFun1_a.y_i[2];

  /* Product: '<S342>/u(3)*u(5)' */
  rtb_u3u5_b = controlMCUSlugsMKII_B.sf_myMuxFun1_a.y_i[2] *
    controlMCUSlugsMKII_B.sf_myMuxFun2_c.y_i[1];

  /* Sum: '<S345>/Sum' incorporates:
   *  Product: '<S345>/u(1)*u(2)*u(3)'
   *  Product: '<S345>/u(4)*u(6)'
   */
  rtb_Sum_p = controlMCUSlugsMKII_B.sf_myMuxFun1_a.y_i[0] *
    controlMCUSlugsMKII_B.sf_myMuxFun1_a.y_i[1] *
    controlMCUSlugsMKII_B.sf_myMuxFun1_a.y_i[2] +
    controlMCUSlugsMKII_B.sf_myMuxFun2_c.y_i[0] *
    controlMCUSlugsMKII_B.sf_myMuxFun2_c.y_i[2];

  /* Sum: '<S348>/Sum' incorporates:
   *  Product: '<S348>/u(1)*u(6)'
   *  Product: '<S348>/u(2)*u(3)*u(4)'
   */
  rtb_Sum_pu = controlMCUSlugsMKII_B.sf_myMuxFun1_a.y_i[1] *
    controlMCUSlugsMKII_B.sf_myMuxFun1_a.y_i[2] *
    controlMCUSlugsMKII_B.sf_myMuxFun2_c.y_i[0] -
    controlMCUSlugsMKII_B.sf_myMuxFun2_c.y_i[2] *
    controlMCUSlugsMKII_B.sf_myMuxFun1_a.y_i[0];

  /* Gain: '<S343>/Gain2' */
  rtb_Gain2_m = -1.0F * controlMCUSlugsMKII_B.sf_myMuxFun1_a.y_i[1];

  /* Product: '<S346>/u(1)*u(3)' */
  rtb_u1u3_l = controlMCUSlugsMKII_B.sf_myMuxFun1_a.y_i[0] *
    controlMCUSlugsMKII_B.sf_myMuxFun2_c.y_i[1];

  /* Product: '<S349>/u(4)*u(5)' */
  rtb_u4u5_a = controlMCUSlugsMKII_B.sf_myMuxFun2_c.y_i[0] *
    controlMCUSlugsMKII_B.sf_myMuxFun2_c.y_i[1];

  /* Stateflow: '<S350>/myMux Fun1' */
  controlMCUSlugs_myMuxFun1_n(rtb_u5u6_l, rtb_Sum_od, rtb_Sum_i, rtb_u3u5_b,
    rtb_Sum_p, rtb_Sum_pu, rtb_Gain2_m, rtb_u1u3_l, rtb_u4u5_a,
    &controlMCUSlugsMKII_B.sf_myMuxFun1_m);

  {
    static const int_T dims[3] = { 3, 3, 3 };

    rt_MatMultRR_Sgl(controlMCUSlugsMKII_B.Product, rtb_MathFunction,
                     controlMCUSlugsMKII_B.sf_myMuxFun1_m.y_l, &dims[0]);
  }

  /* S-Function "dsPIC_C_function_Call" Block: <S317>/C Function Call */
  controlMCUSlugsMKII_B.CFunctionCall_i0 = myAtan2(controlMCUSlugsMKII_B.Product
    [7],controlMCUSlugsMKII_B.Product[8]);

  /* Gain: '<S323>/Gain2' */
  rtb_Abs2 = -1.0F * controlMCUSlugsMKII_B.Product[6];

  /* Saturate: '<S318>/[-1,1]' */
  controlMCUSlugsMKII_B.u1 = rt_SATURATE(rtb_Abs2, -9.990000129E-001F,
    9.998999834E-001F);

  /* S-Function "dsPIC_C_function_Call" Block: <S318>/C Function Call */
  controlMCUSlugsMKII_B.CFunctionCall_c = myAsin(controlMCUSlugsMKII_B.u1);

  /* S-Function "dsPIC_C_function_Call" Block: <S316>/C Function Call */
  controlMCUSlugsMKII_B.CFunctionCall_c5 = myAtan2(controlMCUSlugsMKII_B.Product
    [3],controlMCUSlugsMKII_B.Product[0]);

  /* Embedded MATLAB: '<S9>/Embedded MATLAB Function' */
  if ((real_T)controlMCUSlugsMKII_B.CFunctionCall_c5 < 0.0) {
    /*  This block supports an embeddable subset of the MATLAB language. */
    /*  See the help menu for details.  */
    rtb_y_d = controlMCUSlugsMKII_B.CFunctionCall_c5 + 6.283185482E+000F;
  } else {
    rtb_y_d = controlMCUSlugsMKII_B.CFunctionCall_c5;
  }

  /* Stateflow: '<S9>/myMux Fun1' */
  controlMCUSlugs_myMuxFun1_o(controlMCUSlugsMKII_B.CFunctionCall_i0,
    controlMCUSlugsMKII_B.CFunctionCall_c, rtb_y_d,
    &controlMCUSlugsMKII_B.sf_myMuxFun1_e);

  {
    static const int_T dims[3] = { 3, 3, 1 };

    rt_MatMultRR_Sgl(controlMCUSlugsMKII_B.Product1, rtb_MathFunction,
                     &controlMCUSlugsMKII_B.GetAttitudenavSupportc[3], &dims[0]);
  }

  /* Embedded MATLAB: '<S9>/myMux Fun2' */
  {
    int16_T eml_i0;

    /*  This block supports an embeddable subset of the MATLAB language. */
    /*  See the help menu for details.  */
    for (eml_i0 = 0; eml_i0 < 3; eml_i0++) {
      controlMCUSlugsMKII_B.y_n[eml_i0] =
        controlMCUSlugsMKII_B.sf_myMuxFun1_e.y_i[eml_i0];
    }

    for (eml_i0 = 0; eml_i0 < 3; eml_i0++) {
      controlMCUSlugsMKII_B.y_n[eml_i0 + 3] = controlMCUSlugsMKII_B.Product1
        [eml_i0];
    }
  }

  /* S-Function "dsPIC_C_function_Call" Block: <S3>/Get Pid according to Index2 */
  getPidIdx(((uint8_T)2U),&controlMCUSlugsMKII_B.GetPidaccordingtoIndex2[0]);

  /* S-Function "dsPIC_C_function_Call" Block: <Root>/wp Fly? [navSupport.c] */
  controlMCUSlugsMKII_B.wpFlynavSupportc = isWpFly();

  /* S-Function "dsPIC_C_function_Call" Block: <Root>/Get Max WP [navSupport.c] */
  controlMCUSlugsMKII_B.GetMaxWPnavSupportc = getMaxWp();

  /* S-Function "dsPIC_C_function_Call" Block: <Root>/Get Vned [navSupport.c] */
  getVned(&controlMCUSlugsMKII_B.GetVnednavSupportc[0]);

  /* S-Function "dsPIC_C_function_Call" Block: <Root>/[navSupport.c] */
  getPidIdx(((uint8_T)5U),&controlMCUSlugsMKII_B.navSupportc_o[0]);

  /* Output and update for atomic system: '<S2>/Navigation' */

  /* Saturate: '<S260>/[-25 25]' */
  rtb_u525[0] = rt_SATURATE(controlMCUSlugsMKII_B.GetVnednavSupportc[0], -25.0F,
    25.0F);
  rtb_u525[1] = rt_SATURATE(controlMCUSlugsMKII_B.GetVnednavSupportc[1], -25.0F,
    25.0F);
  rtb_u525[2] = rt_SATURATE(controlMCUSlugsMKII_B.GetVnednavSupportc[2], -25.0F,
    25.0F);

  /* Embedded MATLAB: '<S263>/Embedded MATLAB Function' */

  /*  This block supports an embeddable subset of the MATLAB language. */
  /*  See the help menu for details.  */
  rtb_xDoty = rtb_u525[0] * rtb_u525[0] + rtb_u525[1] * rtb_u525[1];

  /* Stateflow: '<S264>/negprotect' */
  controlMCUSlug_negprotect_e(rtb_xDoty, &controlMCUSlugsMKII_B.sf_negprotect_h);

  /* S-Function "dsPIC_C_function_Call" Block: <S264>/C Function Call */
  controlMCUSlugsMKII_B.CFunctionCall_a = mySqrt
    (controlMCUSlugsMKII_B.sf_negprotect_h.zpVal_k);

  /* Stateflow: '<S239>/negprotect1' */
  controlMCUSlugsM_negprotect(controlMCUSlugsMKII_B.CFunctionCall_a,
    &controlMCUSlugsMKII_B.sf_negprotect1);

  /* RelationalOperator: '<S261>/Relational Operator2' */
  rtb_RelationalOperator2_k = (controlMCUSlugsMKII_B.sf_negprotect1.zpVal ==
    controlMCUSlugsMKII_B.sf_negprotect1.zpVal);

  /* S-Function (sfix_udelay): '<S261>/Integer Delay3'
   *
   * Regarding '<S261>/Integer Delay3':
   * Integer/Tapped Delay Block: '<S261>/Integer Delay3'
   */
  rtb_jxk = controlMCUSlugsMKII_DWork.IntegerDelay3_X_lj;

  /* Switch: '<S261>/Switch3' */
  if (rtb_RelationalOperator2_k > 0U) {
    rtb_Switch3_h = controlMCUSlugsMKII_B.sf_negprotect1.zpVal;
  } else {
    rtb_Switch3_h = rtb_jxk;
  }

  /* Saturate: '<S239>/[0 45]' */
  rtb_u45 = rt_SATURATE(rtb_Switch3_h, 0.0F, 45.0F);

  /* Product: '<S239>/Divide4' */
  rtb_Divide4 = controlMCUSlugsMKII_B.navSupportc_o[0] * rtb_u45;

  /* Saturate: '<S237>/[-25 25]' */
  rtb_u525_m[0] = rt_SATURATE(controlMCUSlugsMKII_B.GetVnednavSupportc[0],
    -25.0F, 25.0F);
  rtb_u525_m[1] = rt_SATURATE(controlMCUSlugsMKII_B.GetVnednavSupportc[1],
    -25.0F, 25.0F);
  rtb_u525_m[2] = rt_SATURATE(controlMCUSlugsMKII_B.GetVnednavSupportc[2],
    -25.0F, 25.0F);

  /* S-Function (sfix_udelay): '<S124>/Integer Delay2'
   *
   * Regarding '<S124>/Integer Delay2':
   * Integer/Tapped Delay Block: '<S124>/Integer Delay2'
   */
  rtb_IntegerDelay2 = controlMCUSlugsMKII_DWork.IntegerDelay2_X;

  /* S-Function (sfix_udelay): '<S138>/Integer Delay1'
   *
   * Regarding '<S138>/Integer Delay1':
   * Integer/Tapped Delay Block: '<S138>/Integer Delay1'
   */
  rtb_IntegerDelay1_oe = controlMCUSlugsMKII_DWork.IntegerDelay1_X_p;

  {
    ZCEventType zcEvent;

    /* InitialCondition: '<S124>/IC1' incorporates:
     *  DataTypeConversion: '<S124>/Data Type Conversion1'
     */
    if (controlMCUSlugsMKII_DWork.IC1_FirstOutputTime) {
      controlMCUSlugsMKII_DWork.IC1_FirstOutputTime = 0U;
      rtb_IC1 = 0.0;
    } else {
      rtb_IC1 = (real_T)controlMCUSlugsMKII_B.wpFlynavSupportc;
    }

    /* HitCross: '<S138>/Hit  Crossing1' */
    zcEvent = rt_ZCFcn(RISING_ZERO_CROSSING,
                       &controlMCUSlugsM_PrevZCSigState.HitCrossing1_ZCE,
                       (rtb_IC1 - 0.3));
    if (controlMCUSlugsMKII_DWork.HitCrossing1_MODE == 0L) {
      if (zcEvent != NO_ZCEVENT) {
        controlMCUSlugsMKII_B.HitCrossing1 =
          ((controlMCUSlugsMKII_B.HitCrossing1 == 1 ? 0 : 1) != 0);
        controlMCUSlugsMKII_DWork.HitCrossing1_MODE = 1L;
      } else if ((controlMCUSlugsMKII_B.HitCrossing1 == 1) && (rtb_IC1 != 0.3))
      {
        controlMCUSlugsMKII_B.HitCrossing1 = 0U;
      }
    } else {
      if (rtb_IC1 != 0.3) {
        controlMCUSlugsMKII_B.HitCrossing1 = 0U;
      }

      controlMCUSlugsMKII_DWork.HitCrossing1_MODE = 0L;
    }

    /* Sum: '<S138>/Add1' */
    rtb_Add1_i = (uint8_T)((uint16_T)rtb_IntegerDelay1_oe + (uint16_T)
      controlMCUSlugsMKII_B.HitCrossing1);

    /* Embedded MATLAB: '<S124>/Embedded MATLAB Function' incorporates:
     *  Constant: '<Root>/Constant1'
     */
    {
      uint16_T eml_u0;
      uint8_T eml_u1;
      uint16_T eml_u2;
      uint8_T eml_u3;
      uint16_T eml_u4;
      uint8_T eml_u5;
      uint16_T eml_u6;
      uint8_T eml_u7;

      /*  Declare static variables */
      if (!controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction_g.fromWP_not_empty)
      {
        /* initialize the static variables */
        controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction_g.fromWP = ((uint8_T)1U);
        controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction_g.fromWP_not_empty =
          true;
        eml_u0 = (uint16_T)
          controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction_g.fromWP + 1U;
        if (eml_u0 > 255U) {
          eml_u1 = MAX_uint8_T;
        } else {
          eml_u1 = (uint8_T)eml_u0;
        }

        controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction_g.toWP = eml_u1;
        eml_u2 = (uint16_T)
          controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction_g.toWP + 1U;
        if (eml_u2 > 255U) {
          eml_u3 = MAX_uint8_T;
        } else {
          eml_u3 = (uint8_T)eml_u2;
        }

        if (controlMCUSlugsMKII_B.GetMaxWPnavSupportc > eml_u3) {
          /*  check if there are more than 2 WPs */
          eml_u4 = (uint16_T)
            controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction_g.toWP + 1U;
          if (eml_u4 > 255U) {
            eml_u5 = MAX_uint8_T;
          } else {
            eml_u5 = (uint8_T)eml_u4;
          }

          controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction_g.totoWP = eml_u5;
        } else {
          controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction_g.totoWP =
            controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction_g.fromWP;
        }
      }

      if (rtb_Add1_i == 1) {
        /* if WP Nav was just enabled */
        controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction_g.fromWP = 0U;
        controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction_g.toWP = 1U;
        controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction_g.totoWP = 2U;
      }

      if (rtb_IntegerDelay2 == 1.0) {
        /*  if there is a change of wp */
        controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction_g.fromWP =
          controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction_g.toWP;
        controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction_g.toWP =
          controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction_g.totoWP;
        eml_u6 = (uint16_T)
          controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction_g.totoWP + 1U;
        if (eml_u6 > 255U) {
          eml_u7 = MAX_uint8_T;
        } else {
          eml_u7 = (uint8_T)eml_u6;
        }

        controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction_g.totoWP = eml_u7;
        if (controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction_g.totoWP >
            controlMCUSlugsMKII_B.GetMaxWPnavSupportc) {
          controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction_g.totoWP = ((uint8_T)
            1U);
        }
      }

      controlMCUSlugsMKII_B.wp0 =
        controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction_g.fromWP;
      controlMCUSlugsMKII_B.wp1 =
        controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction_g.toWP;
      controlMCUSlugsMKII_B.wp2 =
        controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction_g.totoWP;
    }

    if (rtb_Add1_i > 0U) {
      /* Output and update for enable system: '<S124>/Grab IC' */

      /* Inport: '<S136>/UAV Pos' */
      controlMCUSlugsMKII_B.UAVPos[0] = controlMCUSlugsMKII_B.GetXYZnavSupportc
        [0];
      controlMCUSlugsMKII_B.UAVPos[1] = controlMCUSlugsMKII_B.GetXYZnavSupportc
        [1];
      controlMCUSlugsMKII_B.UAVPos[2] = controlMCUSlugsMKII_B.GetXYZnavSupportc
        [2];

      /* S-Function "dsPIC_C_function_Call" Block: <S174>/C Function Call */
      getWP(((uint8_T)11U),&controlMCUSlugsMKII_B.CFunctionCall_aj[0]);

      /* Gain: '<S175>/Deg2R' */
      rtb_Deg2R_i = 1.745329238E-002F * controlMCUSlugsMKII_B.CFunctionCall_aj[0];

      /* Trigonometry: '<S175>/sin(phi)' */
      rtb_sinphi_m = (real32_T)sin(rtb_Deg2R_i);

      /* Product: '<S175>/Rh' incorporates:
       *  Constant: '<S175>/Re=equatorial radius'
       *  Constant: '<S175>/const'
       *  Fcn: '<S175>/f'
       *  Product: '<S175>/Product1'
       *  Product: '<S175>/sin(phi)^2'
       *  Sum: '<S175>/Sum1'
       */
      rtb_Rh_i = 6.378137E+006F / (real32_T)sqrt(1.0F - rtb_sinphi_m *
        rtb_sinphi_m * controlMCUSlugsMKII_ConstB.Sum5_lj);

      /* Sum: '<S175>/Sum2' */
      rtb_Sum2_jc = controlMCUSlugsMKII_B.CFunctionCall_aj[2] + rtb_Rh_i;

      /* Trigonometry: '<S175>/cos(phi)' */
      rtb_Deg2R_i = (real32_T)cos(rtb_Deg2R_i);

      /* Gain: '<S175>/Deg2R1' */
      rtb_Deg2R1_d = 1.745329238E-002F * controlMCUSlugsMKII_B.CFunctionCall_aj
        [1];

      /* Product: '<S175>/(Rh+h)cos(phi)*cos(lamb)=Xe' incorporates:
       *  Trigonometry: '<S175>/cos(lamb)'
       */
      controlMCUSlugsMKII_B.RhhcosphicoslambXe = rtb_Sum2_jc * rtb_Deg2R_i *
        (real32_T)cos(rtb_Deg2R1_d);

      /* Product: '<S175>/(Rh+h)cos(phi)*sin(lamb)=Ye' incorporates:
       *  Trigonometry: '<S175>/sin(lamb)'
       */
      controlMCUSlugsMKII_B.RhhcosphisinlambYe = rtb_Sum2_jc * rtb_Deg2R_i *
        (real32_T)sin(rtb_Deg2R1_d);

      /* Product: '<S175>/Ze' incorporates:
       *  Product: '<S175>/Rh(1-e^2)'
       *  Sum: '<S175>/Sum4'
       */
      controlMCUSlugsMKII_B.Ze = (controlMCUSlugsMKII_ConstB.e2_i * rtb_Rh_i +
        controlMCUSlugsMKII_B.CFunctionCall_aj[2]) * rtb_sinphi_m;
    }
  }

  /* S-Function (sfix_udelay): '<S139>/Integer Delay2'
   *
   * Regarding '<S139>/Integer Delay2':
   * Integer/Tapped Delay Block: '<S139>/Integer Delay2'
   */
  rtb_IntegerDelay2_b = controlMCUSlugsMKII_DWork.IntegerDelay2_X_l;

  /* InitialCondition: '<S139>/IC' */
  if (controlMCUSlugsMKII_DWork.IC_FirstOutputTime_i) {
    controlMCUSlugsMKII_DWork.IC_FirstOutputTime_i = 0U;
    controlMCUSlugsMKII_B.IC = 1.0;
  } else {
    controlMCUSlugsMKII_B.IC = rtb_IntegerDelay2;
  }

  /* Logic: '<S124>/Logical Operator' incorporates:
   *  Sum: '<S139>/Add'
   */
  rtb_LogicalOperator_e = ((rtb_IntegerDelay2_b + controlMCUSlugsMKII_B.IC !=
    0.0) || (rtb_Add1_i != 0U));
  if (rtb_LogicalOperator_e) {
    /* Output and update for enable system: '<S16>/Get Wps Compute Frenet' */

    /* S-Function "dsPIC_C_function_Call" Block: <S208>/C Function Call */
    getWP(controlMCUSlugsMKII_B.wp0,&controlMCUSlugsMKII_B.CFunctionCall_d[0]);

    {
      real32_T cg_in[9];
      int16_T i;
      real32_T rtb_Deg2R_idx;
      real32_T rtb_Deg2R_idx_0;

      /* Switch: '<S125>/Switch' */
      if (controlMCUSlugsMKII_B.wp0 > 0U) {
        {
          real32_T cg_in[9];
          int16_T i;

          /* Gain: '<S233>/Deg2R' */
          rtb_Deg2R_g = 1.745329238E-002F *
            controlMCUSlugsMKII_B.CFunctionCall_d[0];

          /* Trigonometry: '<S233>/sin(phi)' */
          rtb_sinphi_a = (real32_T)sin(rtb_Deg2R_g);

          /* Product: '<S233>/Rh' incorporates:
           *  Constant: '<S233>/Re=equatorial radius'
           *  Constant: '<S233>/const'
           *  Fcn: '<S233>/f'
           *  Product: '<S233>/Product1'
           *  Product: '<S233>/sin(phi)^2'
           *  Sum: '<S233>/Sum1'
           */
          rtb_Rh_o = 6.378137E+006F / (real32_T)sqrt(1.0F - rtb_sinphi_a *
            rtb_sinphi_a * controlMCUSlugsMKII_ConstB.Sum5);

          /* Gain: '<S233>/Deg2R1' */
          rtb_Deg2R1_j = 1.745329238E-002F *
            controlMCUSlugsMKII_B.CFunctionCall_d[1];

          /* Trigonometry: '<S233>/cos(phi)' */
          rtb_Deg2R_g = (real32_T)cos(rtb_Deg2R_g);

          /* Sum: '<S233>/Sum2' */
          rtb_Sum2_j = controlMCUSlugsMKII_B.CFunctionCall_d[2] + rtb_Rh_o;

          /* Sum: '<S207>/Sum1' incorporates:
           *  Product: '<S233>/(Rh+h)cos(phi)*cos(lamb)=Xe'
           *  Product: '<S233>/(Rh+h)cos(phi)*sin(lamb)=Ye'
           *  Product: '<S233>/Rh(1-e^2)'
           *  Product: '<S233>/Ze'
           *  Sum: '<S233>/Sum4'
           *  Trigonometry: '<S233>/cos(lamb)'
           *  Trigonometry: '<S233>/sin(lamb)'
           */
          rtb_Sum1_f[0] = rtb_Sum2_j * rtb_Deg2R_g * (real32_T)cos(rtb_Deg2R1_j)
            - controlMCUSlugsMKII_B.RhhcosphicoslambXe;
          rtb_Sum1_f[1] = rtb_Sum2_j * rtb_Deg2R_g * (real32_T)sin(rtb_Deg2R1_j)
            - controlMCUSlugsMKII_B.RhhcosphisinlambYe;
          rtb_Sum1_f[2] = (controlMCUSlugsMKII_ConstB.e2 * rtb_Rh_o +
                           controlMCUSlugsMKII_B.CFunctionCall_d[2]) *
            rtb_sinphi_a - controlMCUSlugsMKII_B.Ze;

          /* Gain: '<S232>/Deg2R' */
          rtb_Deg2R_g = 1.745329238E-002F *
            controlMCUSlugsMKII_B.CFunctionCall_aj[1];
          rtb_sinphi_a = 1.745329238E-002F *
            controlMCUSlugsMKII_B.CFunctionCall_aj[0];

          /* SignalConversion: '<S232>/TmpHiddenBufferAtProduct1Inport1' incorporates:
           *  Fcn: '<S235>/11'
           *  Fcn: '<S235>/12'
           *  Fcn: '<S235>/13'
           *  Fcn: '<S235>/21'
           *  Fcn: '<S235>/22'
           *  Fcn: '<S235>/23'
           *  Fcn: '<S235>/31'
           *  Fcn: '<S235>/32'
           *  Fcn: '<S235>/33'
           */
          cg_in[0] = (real32_T)(cos(rtb_Deg2R_g) * cos(rtb_sinphi_a));
          cg_in[1] = (real32_T)(-sin(rtb_Deg2R_g));
          cg_in[2] = (real32_T)((-sin(rtb_sinphi_a)) * cos(rtb_Deg2R_g));
          cg_in[3] = (real32_T)(sin(rtb_Deg2R_g) * cos(rtb_sinphi_a));
          cg_in[4] = (real32_T)cos(rtb_Deg2R_g);
          cg_in[5] = (real32_T)((-sin(rtb_Deg2R_g)) * sin(rtb_sinphi_a));
          cg_in[6] = (real32_T)sin(rtb_sinphi_a);
          cg_in[7] = 0.0F;
          cg_in[8] = (real32_T)cos(rtb_sinphi_a);
          for (i = 0; i < 9; i++) {
            rtb_TmpHiddenBufferAtProduct1_h[i] = cg_in[i];
          }
        }

        {
          static const int_T dims[3] = { 3, 3, 1 };

          rt_MatMultRR_Sgl(rtb_Product1_jw, rtb_TmpHiddenBufferAtProduct1_h,
                           rtb_Sum1_f, &dims[0]);
        }

        /* Gain Block: '<S207>/UEN 2 NEU'
         * About '<S207>/UEN 2 NEU :'
         *   Gain value: [0 0 1;0 1 0;1 0 0]


         */
        {
          static const int_T dims[3] = { 3, 3, 1 };

          rt_MatMultRR_Sgl((real32_T *)rtb_UEN2NEU, (real32_T *)
                           &controlMCUSlugsMKII_ConstP.pooled51[0],
                           (real32_T *)rtb_Product1_jw, &dims[0]);
        }

        controlMCUSlugsMKII_B.Switch[0] = rtb_UEN2NEU[0];
        controlMCUSlugsMKII_B.Switch[1] = rtb_UEN2NEU[1];
        controlMCUSlugsMKII_B.Switch[2] = rtb_UEN2NEU[2];
      } else {
        controlMCUSlugsMKII_B.Switch[0] = controlMCUSlugsMKII_B.UAVPos[0];
        controlMCUSlugsMKII_B.Switch[1] = controlMCUSlugsMKII_B.UAVPos[1];
        controlMCUSlugsMKII_B.Switch[2] = controlMCUSlugsMKII_B.UAVPos[2];
      }

      /* Gain: '<S227>/Deg2R' */
      rtb_Deg2R_idx = 1.745329238E-002F * controlMCUSlugsMKII_B.CFunctionCall_aj
        [1];
      rtb_Deg2R_idx_0 = 1.745329238E-002F *
        controlMCUSlugsMKII_B.CFunctionCall_aj[0];

      /* SignalConversion: '<S227>/TmpHiddenBufferAtProduct1Inport1' incorporates:
       *  Fcn: '<S230>/11'
       *  Fcn: '<S230>/12'
       *  Fcn: '<S230>/13'
       *  Fcn: '<S230>/21'
       *  Fcn: '<S230>/22'
       *  Fcn: '<S230>/23'
       *  Fcn: '<S230>/31'
       *  Fcn: '<S230>/32'
       *  Fcn: '<S230>/33'
       */
      cg_in[0] = (real32_T)(cos(rtb_Deg2R_idx) * cos(rtb_Deg2R_idx_0));
      cg_in[1] = (real32_T)(-sin(rtb_Deg2R_idx));
      cg_in[2] = (real32_T)((-sin(rtb_Deg2R_idx_0)) * cos(rtb_Deg2R_idx));
      cg_in[3] = (real32_T)(sin(rtb_Deg2R_idx) * cos(rtb_Deg2R_idx_0));
      cg_in[4] = (real32_T)cos(rtb_Deg2R_idx);
      cg_in[5] = (real32_T)((-sin(rtb_Deg2R_idx)) * sin(rtb_Deg2R_idx_0));
      cg_in[6] = (real32_T)sin(rtb_Deg2R_idx_0);
      cg_in[7] = 0.0F;
      cg_in[8] = (real32_T)cos(rtb_Deg2R_idx_0);
      for (i = 0; i < 9; i++) {
        rtb_TmpHiddenBufferAtProduct1In[i] = cg_in[i];
      }
    }

    /* S-Function "dsPIC_C_function_Call" Block: <S209>/C Function Call */
    getWP(controlMCUSlugsMKII_B.wp1,&controlMCUSlugsMKII_B.CFunctionCall_a1[0]);

    /* Gain: '<S228>/Deg2R' */
    rtb_Deg2R_c = 1.745329238E-002F * controlMCUSlugsMKII_B.CFunctionCall_a1[0];

    /* Trigonometry: '<S228>/sin(phi)' */
    rtb_sinphi = (real32_T)sin(rtb_Deg2R_c);

    /* Product: '<S228>/Rh' incorporates:
     *  Constant: '<S228>/Re=equatorial radius'
     *  Constant: '<S228>/const'
     *  Fcn: '<S228>/f'
     *  Product: '<S228>/Product1'
     *  Product: '<S228>/sin(phi)^2'
     *  Sum: '<S228>/Sum1'
     */
    rtb_Rh = 6.378137E+006F / (real32_T)sqrt(1.0F - rtb_sinphi * rtb_sinphi *
      controlMCUSlugsMKII_ConstB.Sum5_l);

    /* Sum: '<S228>/Sum2' */
    rtb_Sum2_d = controlMCUSlugsMKII_B.CFunctionCall_a1[2] + rtb_Rh;

    /* Trigonometry: '<S228>/cos(phi)' */
    rtb_Deg2R_c = (real32_T)cos(rtb_Deg2R_c);

    /* Gain: '<S228>/Deg2R1' */
    rtb_Deg2R1 = 1.745329238E-002F * controlMCUSlugsMKII_B.CFunctionCall_a1[1];

    /* Sum: '<S206>/Sum1' incorporates:
     *  Product: '<S228>/(Rh+h)cos(phi)*cos(lamb)=Xe'
     *  Product: '<S228>/(Rh+h)cos(phi)*sin(lamb)=Ye'
     *  Product: '<S228>/Rh(1-e^2)'
     *  Product: '<S228>/Ze'
     *  Sum: '<S228>/Sum4'
     *  Trigonometry: '<S228>/cos(lamb)'
     *  Trigonometry: '<S228>/sin(lamb)'
     */
    rtb_UEN2NEU_f[0] = rtb_Sum2_d * rtb_Deg2R_c * (real32_T)cos(rtb_Deg2R1) -
      controlMCUSlugsMKII_B.RhhcosphicoslambXe;
    rtb_UEN2NEU_f[1] = rtb_Sum2_d * rtb_Deg2R_c * (real32_T)sin(rtb_Deg2R1) -
      controlMCUSlugsMKII_B.RhhcosphisinlambYe;
    rtb_UEN2NEU_f[2] = (controlMCUSlugsMKII_ConstB.e2_c * rtb_Rh +
                        controlMCUSlugsMKII_B.CFunctionCall_a1[2]) * rtb_sinphi
      - controlMCUSlugsMKII_B.Ze;

    {
      static const int_T dims[3] = { 3, 3, 1 };

      rt_MatMultRR_Sgl(rtb_Product1_az, rtb_TmpHiddenBufferAtProduct1In,
                       rtb_UEN2NEU_f, &dims[0]);
    }

    /* Gain Block: '<S206>/UEN 2 NEU'
     * About '<S206>/UEN 2 NEU :'
     *   Gain value: [0 0 1;0 1 0;1 0 0]


     */
    {
      static const int_T dims[3] = { 3, 3, 1 };

      rt_MatMultRR_Sgl((real32_T *)rtb_UEN2NEU_f, (real32_T *)
                       &controlMCUSlugsMKII_ConstP.pooled51[0],
                       (real32_T *)rtb_Product1_az, &dims[0]);
    }

    /* Reshape: '<S206>/Reshape1' */
    controlMCUSlugsMKII_B.Reshape1[0] = rtb_UEN2NEU_f[0];
    controlMCUSlugsMKII_B.Reshape1[1] = rtb_UEN2NEU_f[1];
    controlMCUSlugsMKII_B.Reshape1[2] = rtb_UEN2NEU_f[2];

    /* Sum: '<S205>/Add' */
    rtb_Add_fn[0] = controlMCUSlugsMKII_B.Reshape1[0] -
      controlMCUSlugsMKII_B.Switch[0];
    rtb_Add_fn[1] = controlMCUSlugsMKII_B.Reshape1[1] -
      controlMCUSlugsMKII_B.Switch[1];
    rtb_Add_fn[2] = controlMCUSlugsMKII_B.Reshape1[2] -
      controlMCUSlugsMKII_B.Switch[2];

    /* Stateflow: '<S215>/Embedded MATLAB Function' */
    co_EmbeddedMATLABFunction_h(rtb_Add_fn,
      &controlMCUSlugsMKII_B.sf_EmbeddedMATLABFunction_hk);

    /* Stateflow: '<S214>/negprotect' */
    controlMCUSlug_negprotect_e
      (controlMCUSlugsMKII_B.sf_EmbeddedMATLABFunction_hk.xDoty_j,
       &controlMCUSlugsMKII_B.sf_negprotect_g);

    /* S-Function "dsPIC_C_function_Call" Block: <S214>/C Function Call */
    controlMCUSlugsMKII_B.CFunctionCall_b = mySqrt
      (controlMCUSlugsMKII_B.sf_negprotect_g.zpVal_k);

    {
      real32_T rtmax_U0DataInY0Container;

      /* Saturate: '<S210>/Zero Bound' */
      rtmax_U0DataInY0Container = rt_MAX(controlMCUSlugsMKII_B.CFunctionCall_b,
        1.000000047E-003F);

      /* Product: '<S210>/Divide' */
      controlMCUSlugsMKII_B.Divide_n[0] = rtb_Add_fn[0] /
        rtmax_U0DataInY0Container;
      controlMCUSlugsMKII_B.Divide_n[1] = rtb_Add_fn[1] /
        rtmax_U0DataInY0Container;
      controlMCUSlugsMKII_B.Divide_n[2] = rtb_Add_fn[2] /
        rtmax_U0DataInY0Container;

      /* Embedded MATLAB: '<S205>/Select N  Terms' */

      /*  This block supports an embeddable subset of the MATLAB language. */
      /*  See the help menu for details.  */
      controlMCUSlugsMKII_B.N[0] = -controlMCUSlugsMKII_B.Divide_n[1];
      controlMCUSlugsMKII_B.N[1] = controlMCUSlugsMKII_B.Divide_n[0];
      controlMCUSlugsMKII_B.N[2] = 0.0F;
    }

    /* Stateflow: '<S222>/Embedded MATLAB Function' */
    co_EmbeddedMATLABFunction_h(controlMCUSlugsMKII_B.N,
      &controlMCUSlugsMKII_B.sf_EmbeddedMATLABFunction_or);

    /* Stateflow: '<S221>/negprotect' */
    controlMCUSlug_negprotect_e
      (controlMCUSlugsMKII_B.sf_EmbeddedMATLABFunction_or.xDoty_j,
       &controlMCUSlugsMKII_B.sf_negprotect_bp);

    /* S-Function "dsPIC_C_function_Call" Block: <S221>/C Function Call */
    controlMCUSlugsMKII_B.CFunctionCall_c0 = mySqrt
      (controlMCUSlugsMKII_B.sf_negprotect_bp.zpVal_k);

    {
      real32_T rtmax_U0DataInY0Container;

      /* Saturate: '<S211>/Zero Bound' */
      rtmax_U0DataInY0Container = rt_MAX(controlMCUSlugsMKII_B.CFunctionCall_c0,
        1.000000047E-003F);

      /* Product: '<S211>/Divide' */
      controlMCUSlugsMKII_B.Divide_p[0] = controlMCUSlugsMKII_B.N[0] /
        rtmax_U0DataInY0Container;
      controlMCUSlugsMKII_B.Divide_p[1] = controlMCUSlugsMKII_B.N[1] /
        rtmax_U0DataInY0Container;
      controlMCUSlugsMKII_B.Divide_p[2] = controlMCUSlugsMKII_B.N[2] /
        rtmax_U0DataInY0Container;
    }
  }

  /* Sum: '<S123>/Add' */
  rtb_Add_id[0] = controlMCUSlugsMKII_B.Reshape1[0] -
    controlMCUSlugsMKII_B.GetXYZnavSupportc[0];
  rtb_Add_id[1] = controlMCUSlugsMKII_B.Reshape1[1] -
    controlMCUSlugsMKII_B.GetXYZnavSupportc[1];
  rtb_Add_id[2] = controlMCUSlugsMKII_B.Reshape1[2] -
    controlMCUSlugsMKII_B.GetXYZnavSupportc[2];

  /* Stateflow: '<S129>/Embedded MATLAB Function' */
  cont_EmbeddedMATLABFunction(controlMCUSlugsMKII_B.Divide_p, rtb_Add_id,
    &controlMCUSlugsMKII_B.sf_EmbeddedMATLABFunction_m);

  /* RelationalOperator: '<S132>/Relational Operator2' */
  rtb_RelationalOperator2_g =
    (controlMCUSlugsMKII_B.sf_EmbeddedMATLABFunction_m.xDoty ==
     controlMCUSlugsMKII_B.sf_EmbeddedMATLABFunction_m.xDoty);

  /* S-Function (sfix_udelay): '<S132>/Integer Delay3'
   *
   * Regarding '<S132>/Integer Delay3':
   * Integer/Tapped Delay Block: '<S132>/Integer Delay3'
   */
  rtb_jxk = controlMCUSlugsMKII_DWork.IntegerDelay3_X_b3;

  /* Switch: '<S132>/Switch3' */
  if (rtb_RelationalOperator2_g > 0U) {
    rtb_Switch3_nn = controlMCUSlugsMKII_B.sf_EmbeddedMATLABFunction_m.xDoty;
  } else {
    rtb_Switch3_nn = rtb_jxk;
  }

  /* Gain: '<S238>/Gain' */
  rtb_Gain_m = -1.0F * rtb_Switch3_nn;

  /* Product: '<S238>/Divide2' */
  rtb_NPey[0] = controlMCUSlugsMKII_B.Divide_p[0] * rtb_Gain_m;
  rtb_NPey[1] = controlMCUSlugsMKII_B.Divide_p[1] * rtb_Gain_m;
  rtb_NPey[2] = controlMCUSlugsMKII_B.Divide_p[2] * rtb_Gain_m;

  /* Sum: '<S238>/Add' incorporates:
   *  Product: '<S238>/Divide'
   *  Product: '<S238>/Divide1'
   */
  controlMCUSlugsMKII_B.Add = rtb_Divide4 * rtb_Divide4 - rtb_Switch3_nn *
    rtb_Switch3_nn;

  /* S-Function "dsPIC_C_function_Call" Block: <S256>/C Function Call */
  controlMCUSlugsMKII_B.CFunctionCall_o = myAbs(controlMCUSlugsMKII_B.Add);

  /* Stateflow: '<S255>/negprotect' */
  controlMCUSlug_negprotect_e(controlMCUSlugsMKII_B.CFunctionCall_o,
    &controlMCUSlugsMKII_B.sf_negprotect_f);

  /* S-Function "dsPIC_C_function_Call" Block: <S255>/C Function Call */
  controlMCUSlugsMKII_B.CFunctionCall_f = mySqrt
    (controlMCUSlugsMKII_B.sf_negprotect_f.zpVal_k);

  /* Sum: '<S238>/Add2' incorporates:
   *  Product: '<S238>/Divide3'
   */
  controlMCUSlugsMKII_B.L1_vec[0] = controlMCUSlugsMKII_B.Divide_n[0] *
    controlMCUSlugsMKII_B.CFunctionCall_f - rtb_NPey[0];
  controlMCUSlugsMKII_B.L1_vec[1] = controlMCUSlugsMKII_B.Divide_n[1] *
    controlMCUSlugsMKII_B.CFunctionCall_f - rtb_NPey[1];
  controlMCUSlugsMKII_B.L1_vec[2] = controlMCUSlugsMKII_B.Divide_n[2] *
    controlMCUSlugsMKII_B.CFunctionCall_f - rtb_NPey[2];

  /* Sum: '<S241>/Sum' incorporates:
   *  Product: '<S245>/i x j'
   *  Product: '<S245>/j x k'
   *  Product: '<S245>/k x i'
   *  Product: '<S246>/i x k'
   *  Product: '<S246>/j x i'
   *  Product: '<S246>/k x j'
   */
  rtb_Sum_mb[0] = rtb_u525_m[1] * controlMCUSlugsMKII_B.L1_vec[2] - rtb_u525_m[2]
    * controlMCUSlugsMKII_B.L1_vec[1];
  rtb_Sum_mb[1] = rtb_u525_m[2] * controlMCUSlugsMKII_B.L1_vec[0] - rtb_u525_m[0]
    * controlMCUSlugsMKII_B.L1_vec[2];
  rtb_Sum_mb[2] = rtb_u525_m[0] * controlMCUSlugsMKII_B.L1_vec[1] - rtb_u525_m[1]
    * controlMCUSlugsMKII_B.L1_vec[0];

  /* Stateflow: '<S248>/Embedded MATLAB Function' */
  co_EmbeddedMATLABFunction_h(controlMCUSlugsMKII_B.L1_vec,
    &controlMCUSlugsMKII_B.sf_EmbeddedMATLABFunction_d);

  /* Stateflow: '<S247>/negprotect' */
  controlMCUSlug_negprotect_e
    (controlMCUSlugsMKII_B.sf_EmbeddedMATLABFunction_d.xDoty_j,
     &controlMCUSlugsMKII_B.sf_negprotect_b);

  /* S-Function "dsPIC_C_function_Call" Block: <S247>/C Function Call */
  controlMCUSlugsMKII_B.CFunctionCall_m = mySqrt
    (controlMCUSlugsMKII_B.sf_negprotect_b.zpVal_k);

  /* Stateflow: '<S237>/negprotect' */
  controlMCUSlugsM_negprotect(controlMCUSlugsMKII_B.CFunctionCall_m,
    &controlMCUSlugsMKII_B.sf_negprotect_fm);

  /* Product: '<S237>/Divide5' */
  rtb_Divide5[0] = rtb_Sum_mb[0] / controlMCUSlugsMKII_B.sf_negprotect_fm.zpVal /
    rtb_u45;
  rtb_Divide5[1] = rtb_Sum_mb[1] / controlMCUSlugsMKII_B.sf_negprotect_fm.zpVal /
    rtb_u45;
  rtb_Divide5[2] = rtb_Sum_mb[2] / controlMCUSlugsMKII_B.sf_negprotect_fm.zpVal /
    rtb_u45;

  /* S-Function (sfix_udelay): '<S254>/Integer Delay3'
   *
   * Regarding '<S254>/Integer Delay3':
   * Integer/Tapped Delay Block: '<S254>/Integer Delay3'
   */
  rtb_IntegerDelay3_d = controlMCUSlugsMKII_DWork.IntegerDelay3_X_g;

  /* Switch: '<S254>/Switch3' incorporates:
   *  RelationalOperator: '<S254>/Relational Operator2'
   */
  if (((uint8_T)(rtb_Divide5[2] == rtb_Divide5[2])) > 0U) {
    rtb_Switch3_a = rtb_Divide5[2];
  } else {
    rtb_Switch3_a = rtb_IntegerDelay3_d;
  }

  /* Saturate: '<S243>/[-1,1]' */
  controlMCUSlugsMKII_B.u1_h = rt_SATURATE(rtb_Switch3_a, -9.990000129E-001F,
    9.998999834E-001F);

  /* S-Function "dsPIC_C_function_Call" Block: <S243>/C Function Call */
  controlMCUSlugsMKII_B.CFunctionCall_h = myAsin(controlMCUSlugsMKII_B.u1_h);

  /* S-Function "dsPIC_C_function_Call" Block: <S269>/C Function Call */
  controlMCUSlugsMKII_B.CFunctionCall_e = mySin
    (controlMCUSlugsMKII_B.CFunctionCall_h);

  /* Product: '<S240>/Product' incorporates:
   *  Constant: '<S240>/Constant'
   */
  rtb_Product_m = (real32_T)((real_T)(rtb_u45 * rtb_u45) * 2.0) / rtb_Divide4 *
    controlMCUSlugsMKII_B.CFunctionCall_e;

  /* S-Function (sfix_udelay): '<S268>/Integer Delay3'
   *
   * Regarding '<S268>/Integer Delay3':
   * Integer/Tapped Delay Block: '<S268>/Integer Delay3'
   */
  rtb_IntegerDelay3_d = controlMCUSlugsMKII_DWork.IntegerDelay3_X_f;

  /* Switch: '<S268>/Switch3' incorporates:
   *  RelationalOperator: '<S268>/Relational Operator2'
   */
  if (((uint8_T)(rtb_Product_m == rtb_Product_m)) > 0U) {
    rtb_Switch3_m = rtb_Product_m;
  } else {
    rtb_Switch3_m = rtb_IntegerDelay3_d;
  }

  /* Product: '<S126>/Product' incorporates:
   *  Saturate: '<S240>/[-25,25]'
   */
  rtb_Product_c = controlMCUSlugsMKII_B.navSupportc_o[2] * rt_SATURATE
    (rtb_Switch3_m, -25.0F, 25.0F);

  /* Stateflow: '<S16>/myMux Fun1' */
  controlMCUSlugsMK_myMuxFun1(rtb_Product_c, rtb_u45, rtb_Switch3_nn,
    &controlMCUSlugsMKII_B.sf_myMuxFun1_o);

  /* S-Function "dsPIC_C_function_Call" Block: <S16>/Set Log Floats 4-6 [navSupport.c] */
  setLogFloat2(controlMCUSlugsMKII_B.sf_myMuxFun1_o.y);

  /* S-Function (sfix_udelay): '<S124>/Integer Delay3'
   *
   * Regarding '<S124>/Integer Delay3':
   * Integer/Tapped Delay Block: '<S124>/Integer Delay3'
   */
  rtb_IntegerDelay3_d = controlMCUSlugsMKII_DWork.IntegerDelay3_X_a;

  /* S-Function (sfix_udelay): '<S140>/Integer Delay1'
   *
   * Regarding '<S140>/Integer Delay1':
   * Integer/Tapped Delay Block: '<S140>/Integer Delay1'
   */
  rtb_IntegerDelay1_l = controlMCUSlugsMKII_DWork.IntegerDelay1_X_fi;

  /* Switch: '<S140>/1st WP' incorporates:
   *  Constant: '<S140>/Switch Distance WP0'
   *  RelationalOperator: '<S177>/Compare'
   */
  if ((rtb_IntegerDelay1_l > ((uint8_T)0U)) > 0U) {
    rtb_stWP = rtb_IntegerDelay3_d;
  } else {
    rtb_stWP = 100.0F;
  }

  /* S-Function (sfix_udelay): '<S180>/Integer Delay1'
   *
   * Regarding '<S180>/Integer Delay1':
   * Integer/Tapped Delay Block: '<S180>/Integer Delay1'
   */
  rtb_IntegerDelay3_d = controlMCUSlugsMKII_DWork.IntegerDelay1_X_i;

  /* S-Function (sfix_udelay): '<S180>/Integer Delay2'
   *
   * Regarding '<S180>/Integer Delay2':
   * Integer/Tapped Delay Block: '<S180>/Integer Delay2'
   */
  rtb_IntegerDelay2_j = controlMCUSlugsMKII_DWork.IntegerDelay2_X_e[0];

  /* Sum: '<S196>/Diff' incorporates:
   *  UnitDelay: '<S196>/UD'
   */
  controlMCUSlugsMKII_B.Diff = controlMCUSlugsMKII_B.Switch[0] -
    controlMCUSlugsMKII_DWork.UD_DSTATE;

  /* S-Function "dsPIC_C_function_Call" Block: <S197>/C Function Call */
  controlMCUSlugsMKII_B.CFunctionCall_j = myAbs(controlMCUSlugsMKII_B.Diff);

  /* Saturate: '<S193>/Saturation1' */
  rtb_Saturation1 = rt_SATURATE(controlMCUSlugsMKII_B.CFunctionCall_j, 0.0F,
    1.0F);

  /* Sum: '<S199>/Diff' incorporates:
   *  UnitDelay: '<S199>/UD'
   */
  controlMCUSlugsMKII_B.Diff_o = controlMCUSlugsMKII_B.Switch[1] -
    controlMCUSlugsMKII_DWork.UD_DSTATE_e;

  /* S-Function "dsPIC_C_function_Call" Block: <S200>/C Function Call */
  controlMCUSlugsMKII_B.CFunctionCall_l = myAbs(controlMCUSlugsMKII_B.Diff_o);

  /* Saturate: '<S194>/Saturation1' */
  rtb_Saturation1_a = rt_SATURATE(controlMCUSlugsMKII_B.CFunctionCall_l, 0.0F,
    1.0F);

  /* Sum: '<S202>/Diff' incorporates:
   *  UnitDelay: '<S202>/UD'
   */
  controlMCUSlugsMKII_B.Diff_a = controlMCUSlugsMKII_B.Switch[2] -
    controlMCUSlugsMKII_DWork.UD_DSTATE_h;

  /* S-Function "dsPIC_C_function_Call" Block: <S203>/C Function Call */
  controlMCUSlugsMKII_B.CFunctionCall_ep = myAbs(controlMCUSlugsMKII_B.Diff_a);

  /* Sum: '<S181>/Sum' incorporates:
   *  Saturate: '<S195>/Saturation1'
   */
  rtb_Sum_k = (rtb_Saturation1 + rtb_Saturation1_a) + rt_SATURATE
    (controlMCUSlugsMKII_B.CFunctionCall_ep, 0.0F, 1.0F);

  /* InitialCondition: '<S180>/IC' incorporates:
   *  Saturate: '<S181>/Saturation1'
   */
  if (controlMCUSlugsMKII_DWork.IC_FirstOutputTime_b) {
    controlMCUSlugsMKII_DWork.IC_FirstOutputTime_b = 0U;
    controlMCUSlugsMKII_B.IC_e = 1.0F;
  } else {
    controlMCUSlugsMKII_B.IC_e = rt_SATURATE(rtb_Sum_k, 0.0F, 1.0F);
  }

  /* InitialCondition: '<S140>/IC' incorporates:
   *  Sum: '<S180>/Add'
   */
  if (controlMCUSlugsMKII_DWork.IC_FirstOutputTime_d) {
    controlMCUSlugsMKII_DWork.IC_FirstOutputTime_d = 0U;
    rtb_IC = 1.0F;
  } else {
    rtb_IC = (rtb_IntegerDelay3_d + rtb_IntegerDelay2_j) +
      controlMCUSlugsMKII_B.IC_e;
  }

  if (rtb_IC > 0.0F) {
    /* Output and update for enable system: '<S140>/Compute Total Run' */

    /* Sum: '<S185>/Add' */
    rtb_Add_d[0] = controlMCUSlugsMKII_B.Switch[0] -
      controlMCUSlugsMKII_B.Reshape1[0];
    rtb_Add_d[1] = controlMCUSlugsMKII_B.Switch[1] -
      controlMCUSlugsMKII_B.Reshape1[1];
    rtb_Add_d[2] = controlMCUSlugsMKII_B.Switch[2] -
      controlMCUSlugsMKII_B.Reshape1[2];

    /* Stateflow: '<S189>/Embedded MATLAB Function' */
    co_EmbeddedMATLABFunction_a(rtb_Add_d,
      &controlMCUSlugsMKII_B.sf_EmbeddedMATLABFunction_mg);

    /* Stateflow: '<S188>/negprotect' */
    controlMCUSlug_negprotect_e
      (controlMCUSlugsMKII_B.sf_EmbeddedMATLABFunction_mg.xDoty_g,
       &controlMCUSlugsMKII_B.sf_negprotect_l);

    /* S-Function "dsPIC_C_function_Call" Block: <S188>/C Function Call */
    controlMCUSlugsMKII_B.CFunctionCall_fg = mySqrt
      (controlMCUSlugsMKII_B.sf_negprotect_l.zpVal_k);

    /* Sum: '<S179>/Subtract1' */
    rtb_Subtract1 = controlMCUSlugsMKII_B.CFunctionCall_fg - rtb_stWP;

    /* Switch: '<S186>/Switch3' incorporates:
     *  RelationalOperator: '<S186>/Relational Operator2'
     *  S-Function (sfix_udelay): '<S186>/Integer Delay3'
     */
    if ((rtb_Subtract1 == rtb_Subtract1) > 0U) {
      controlMCUSlugsMKII_B.Switch3 = rtb_Subtract1;
    } else {
      controlMCUSlugsMKII_B.Switch3 =
        (controlMCUSlugsMKII_DWork.IntegerDelay3_X_ft);
    }

    /* Integer/Tapped Delay Block: '<S186>/Integer Delay3'
     */
    controlMCUSlugsMKII_DWork.IntegerDelay3_X_ft = controlMCUSlugsMKII_B.Switch3;
  }

  /* Sum: '<S178>/Subtract' */
  rtb_Subtract_h[0] = controlMCUSlugsMKII_B.GetXYZnavSupportc[0] -
    controlMCUSlugsMKII_B.Switch[0];
  rtb_Subtract_h[1] = controlMCUSlugsMKII_B.GetXYZnavSupportc[1] -
    controlMCUSlugsMKII_B.Switch[1];
  rtb_Subtract_h[2] = controlMCUSlugsMKII_B.GetXYZnavSupportc[2] -
    controlMCUSlugsMKII_B.Switch[2];

  /* Stateflow: '<S183>/Embedded MATLAB Function' */
  cont_EmbeddedMATLABFunction(rtb_Subtract_h, controlMCUSlugsMKII_B.Divide_n,
    &controlMCUSlugsMKII_B.sf_EmbeddedMATLABFunction_n);

  /* RelationalOperator: '<S182>/Relational Operator2' */
  rtb_RelationalOperator2_i =
    (controlMCUSlugsMKII_B.sf_EmbeddedMATLABFunction_n.xDoty ==
     controlMCUSlugsMKII_B.sf_EmbeddedMATLABFunction_n.xDoty);

  /* S-Function (sfix_udelay): '<S182>/Integer Delay3'
   *
   * Regarding '<S182>/Integer Delay3':
   * Integer/Tapped Delay Block: '<S182>/Integer Delay3'
   */
  rtb_IntegerDelay3 = controlMCUSlugsMKII_DWork.IntegerDelay3_X;

  /* Switch: '<S182>/Switch3' */
  if (rtb_RelationalOperator2_i > 0U) {
    rtb_Switch3 = (real_T)
      controlMCUSlugsMKII_B.sf_EmbeddedMATLABFunction_n.xDoty;
  } else {
    rtb_Switch3 = rtb_IntegerDelay3;
  }

  /* DataTypeConversion: '<S124>/Data Type Conversion' */
  rtb_DataTypeConversion_d = (real32_T)controlMCUSlugsMKII_B.wp0;

  /* DataTypeConversion: '<S124>/Data Type Conversion2' */
  rtb_DataTypeConversion2 = (real32_T)controlMCUSlugsMKII_B.wp1;

  /* Embedded MATLAB: '<S124>/myMux Fun2' */

  /*  This block supports an embeddable subset of the MATLAB language. */
  /*  See the help menu for details.  */
  controlMCUSlugsMKII_B.y_e[0] = controlMCUSlugsMKII_B.Switch3;
  controlMCUSlugsMKII_B.y_e[1] = (real32_T)rtb_Switch3;
  controlMCUSlugsMKII_B.y_e[2] = rtb_DataTypeConversion_d;
  controlMCUSlugsMKII_B.y_e[3] = rtb_DataTypeConversion2;

  /* S-Function "dsPIC_C_function_Call" Block: <S124>/Set The Nav Vals [navSupport.c] */
  setNavNav(controlMCUSlugsMKII_B.y_e);
  if (rtb_LogicalOperator_e) {
    /* Output and update for enable system: '<S124>/Compute P' */

    /* Product: '<S133>/Product1' */
    rtb_Product1_m = controlMCUSlugsMKII_B.navSupportc_o[1] * rtb_u45;

    /* S-Function (sfix_udelay): '<S133>/Integer Delay1'
     *
     * Regarding '<S133>/Integer Delay1':
     * Integer/Tapped Delay Block: '<S133>/Integer Delay1'
     */
    (void) memcpy(controlMCUSlugsMKII_B.IntegerDelay1,
                  &controlMCUSlugsMKII_DWork.IntegerDelay1_X_k[0],
                  3*sizeof(real32_T));

    /* S-Function "dsPIC_C_function_Call" Block: <S167>/C Function Call */
    controlMCUSlugsMKII_B.CFunctionCall_l0 = myAtan2
      (controlMCUSlugsMKII_B.IntegerDelay1[1],
       controlMCUSlugsMKII_B.IntegerDelay1[0]);

    /* Sum: '<S143>/Add' incorporates:
     *  S-Function (sfix_udelay): '<S133>/Integer Delay2'
     */
    rtb_Add_k[0] = (controlMCUSlugsMKII_DWork.IntegerDelay2_X_e3[0]) -
      controlMCUSlugsMKII_B.Reshape1[0];
    rtb_Add_k[1] = (controlMCUSlugsMKII_DWork.IntegerDelay2_X_e3[1]) -
      controlMCUSlugsMKII_B.Reshape1[1];
    rtb_Add_k[2] = (controlMCUSlugsMKII_DWork.IntegerDelay2_X_e3[2]) -
      controlMCUSlugsMKII_B.Reshape1[2];

    /* Stateflow: '<S150>/Embedded MATLAB Function' */
    co_EmbeddedMATLABFunction_a(rtb_Add_k,
      &controlMCUSlugsMKII_B.sf_EmbeddedMATLABFunction_a);

    /* Stateflow: '<S149>/negprotect' */
    controlMCUSlug_negprotect_e
      (controlMCUSlugsMKII_B.sf_EmbeddedMATLABFunction_a.xDoty_g,
       &controlMCUSlugsMKII_B.sf_negprotect_e);

    /* S-Function "dsPIC_C_function_Call" Block: <S149>/C Function Call */
    controlMCUSlugsMKII_B.CFunctionCall_mb = mySqrt
      (controlMCUSlugsMKII_B.sf_negprotect_e.zpVal_k);

    {
      real32_T rtmax_U0DataInY0Container;

      /* Saturate: '<S147>/Zero Bound' */
      rtmax_U0DataInY0Container = rt_MAX(controlMCUSlugsMKII_B.CFunctionCall_mb,
        1.000000047E-003F);

      /* Product: '<S147>/Divide' */
      controlMCUSlugsMKII_B.Divide_l[0] = rtb_Add_k[0] /
        rtmax_U0DataInY0Container;
      controlMCUSlugsMKII_B.Divide_l[1] = rtb_Add_k[1] /
        rtmax_U0DataInY0Container;
      controlMCUSlugsMKII_B.Divide_l[2] = rtb_Add_k[2] /
        rtmax_U0DataInY0Container;
    }

    /* S-Function "dsPIC_C_function_Call" Block: <S166>/C Function Call */
    controlMCUSlugsMKII_B.CFunctionCall_ir = myAtan2
      (controlMCUSlugsMKII_B.Divide_l[1],controlMCUSlugsMKII_B.Divide_l[0]);

    /* Sum: '<S161>/Add' */
    rtb_Add_ir = controlMCUSlugsMKII_B.CFunctionCall_l0 -
      controlMCUSlugsMKII_B.CFunctionCall_ir;

    /* Embedded MATLAB: '<S161>/Embedded MATLAB Function1' */
    if ((real_T)rtb_Add_ir < 0.0) {
      controlMCUSlugsMKII_B.angle = rtb_Add_ir + 6.283185482E+000F;
    } else {
      controlMCUSlugsMKII_B.angle = rtb_Add_ir;
    }

    /* RelationalOperator: '<S145>/Larger than 180?' incorporates:
     *  Constant: '<S145>/Constant5'
     */
    rtb_Largerthan180 = (controlMCUSlugsMKII_B.angle >= 3.141592741E+000F);

    /* Outputs for enable SubSystem: '<S145>/compute delta Right Turn' */
    if (rtb_Largerthan180) {
      /* Product: '<S164>/Divide' incorporates:
       *  Constant: '<S164>/Constant1'
       *  Constant: '<S164>/Constant5'
       *  Sum: '<S164>/Add'
       */
      controlMCUSlugsMKII_B.Merge4 = (controlMCUSlugsMKII_B.angle -
        3.141592741E+000F) / 2.0F;
    }

    /* end of Outputs for SubSystem: '<S145>/compute delta Right Turn' */

    /* Outputs for enable SubSystem: '<S145>/Compute delta Left Turn' incorporates:
     *  Logic: '<S145>/Logical Operator'
     */
    if (!rtb_Largerthan180) {
      /* Gain: '<S162>/Gain' incorporates:
       *  Constant: '<S162>/Constant1'
       *  Constant: '<S162>/Constant5'
       *  Product: '<S162>/Divide'
       *  Sum: '<S162>/Add'
       */
      controlMCUSlugsMKII_B.Merge4 = (3.141592741E+000F -
        controlMCUSlugsMKII_B.angle) / 2.0F * -1.0F;
    }

    /* end of Outputs for SubSystem: '<S145>/Compute delta Left Turn' */

    /* S-Function "dsPIC_C_function_Call" Block: <S163>/C Function Call */
    controlMCUSlugsMKII_B.CFunctionCall_hb = mySin(controlMCUSlugsMKII_B.Merge4);

    /* S-Function "dsPIC_C_function_Call" Block: <S163>/C Function Call1 */
    controlMCUSlugsMKII_B.CFunctionCall1_i = myCos(controlMCUSlugsMKII_B.Merge4);

    {
      real32_T cg_in[9];
      int16_T i;
      real32_T rtb_Deg2R_b_idx;
      real32_T rtb_Deg2R_b_idx_0;

      /* Product: '<S142>/Product1' incorporates:
       *  Constant: '<S142>/gravity1'
       *  Product: '<S142>/Product'
       */
      rtb_Product1_b = controlMCUSlugsMKII_B.GetMidLevelCommandsnavSupportc[0] *
        controlMCUSlugsMKII_B.GetMidLevelCommandsnavSupportc[0] /
        9.814999580E+000F;

      /* Embedded MATLAB: '<S145>/Compute  Circles' */
      {
        int16_T eml_i0;
        real_T eml_r_vec[3];
        real32_T eml_absVal;

        /*  This block supports an embeddable subset of the MATLAB language. */
        /*  See the help menu for details. */
        /*  rotate the vector delta degrees */
        for (eml_i0 = 0; eml_i0 < 3; eml_i0++) {
          eml_r_vec[eml_i0] = 0.0;
        }

        eml_r_vec[0] = (real_T)((-controlMCUSlugsMKII_B.IntegerDelay1[0]) *
          controlMCUSlugsMKII_B.CFunctionCall1_i -
          controlMCUSlugsMKII_B.IntegerDelay1[1] *
          controlMCUSlugsMKII_B.CFunctionCall_hb);
        eml_r_vec[1] = (real_T)(controlMCUSlugsMKII_B.IntegerDelay1[0] *
          controlMCUSlugsMKII_B.CFunctionCall_hb -
          controlMCUSlugsMKII_B.IntegerDelay1[1] *
          controlMCUSlugsMKII_B.CFunctionCall1_i);
        if ((real_T)controlMCUSlugsMKII_B.CFunctionCall_hb < 0.0) {
          eml_absVal = -1.0F * controlMCUSlugsMKII_B.CFunctionCall_hb;
        } else {
          eml_absVal = controlMCUSlugsMKII_B.CFunctionCall_hb;
        }

        if ((real_T)eml_absVal > 0.01) {
          /* compute M */
          eml_absVal = rtb_Product1_b / controlMCUSlugsMKII_B.CFunctionCall_hb;
          if ((real_T)eml_absVal < 0.0) {
            eml_absVal *= -1.0F;
          }
        } else {
          eml_absVal = 0.0F;
        }

        /* find the distance from WP */
        rtb_P = eml_absVal * controlMCUSlugsMKII_B.CFunctionCall1_i;

        /*  find the center of the circle */
        for (eml_i0 = 0; eml_i0 < 3; eml_i0++) {
          rtb_O[eml_i0] = controlMCUSlugsMKII_B.Reshape1[eml_i0] + (real32_T)
            eml_r_vec[eml_i0] * eml_absVal;

          /*  find the tangent points */
          rtb_Pch[eml_i0] = controlMCUSlugsMKII_B.Reshape1[eml_i0] -
            controlMCUSlugsMKII_B.IntegerDelay1[eml_i0] * rtb_P;
          rtb_PchB[eml_i0] = controlMCUSlugsMKII_B.Reshape1[eml_i0] +
            controlMCUSlugsMKII_B.Divide_l[eml_i0] * rtb_P;
        }
      }

      /* Sum: '<S133>/Add' */
      rtb_Add_n = rtb_Product1_m + rtb_P;

      /* Gain: '<S155>/Deg2R' */
      rtb_Deg2R_b_idx = 1.745329238E-002F *
        controlMCUSlugsMKII_B.CFunctionCall_aj[1];
      rtb_Deg2R_b_idx_0 = 1.745329238E-002F *
        controlMCUSlugsMKII_B.CFunctionCall_aj[0];

      /* SignalConversion: '<S155>/TmpHiddenBufferAtProduct1Inport1' incorporates:
       *  Fcn: '<S158>/11'
       *  Fcn: '<S158>/12'
       *  Fcn: '<S158>/13'
       *  Fcn: '<S158>/21'
       *  Fcn: '<S158>/22'
       *  Fcn: '<S158>/23'
       *  Fcn: '<S158>/31'
       *  Fcn: '<S158>/32'
       *  Fcn: '<S158>/33'
       */
      cg_in[0] = (real32_T)(cos(rtb_Deg2R_b_idx) * cos(rtb_Deg2R_b_idx_0));
      cg_in[1] = (real32_T)(-sin(rtb_Deg2R_b_idx));
      cg_in[2] = (real32_T)((-sin(rtb_Deg2R_b_idx_0)) * cos(rtb_Deg2R_b_idx));
      cg_in[3] = (real32_T)(sin(rtb_Deg2R_b_idx) * cos(rtb_Deg2R_b_idx_0));
      cg_in[4] = (real32_T)cos(rtb_Deg2R_b_idx);
      cg_in[5] = (real32_T)((-sin(rtb_Deg2R_b_idx)) * sin(rtb_Deg2R_b_idx_0));
      cg_in[6] = (real32_T)sin(rtb_Deg2R_b_idx_0);
      cg_in[7] = 0.0F;
      cg_in[8] = (real32_T)cos(rtb_Deg2R_b_idx_0);
      for (i = 0; i < 9; i++) {
        rtb_TmpHiddenBufferAtProduct1_g[i] = cg_in[i];
      }
    }

    /* S-Function "dsPIC_C_function_Call" Block: <S146>/C Function Call */
    getWP(controlMCUSlugsMKII_B.wp2,&controlMCUSlugsMKII_B.CFunctionCall_ap[0]);

    /* Gain: '<S156>/Deg2R' */
    rtb_Deg2R_a = 1.745329238E-002F * controlMCUSlugsMKII_B.CFunctionCall_ap[0];

    /* Trigonometry: '<S156>/sin(phi)' */
    rtb_sinphi_c = (real32_T)sin(rtb_Deg2R_a);

    /* Product: '<S156>/Rh' incorporates:
     *  Constant: '<S156>/Re=equatorial radius'
     *  Constant: '<S156>/const'
     *  Fcn: '<S156>/f'
     *  Product: '<S156>/Product1'
     *  Product: '<S156>/sin(phi)^2'
     *  Sum: '<S156>/Sum1'
     */
    rtb_Rh_m = 6.378137E+006F / (real32_T)sqrt(1.0F - rtb_sinphi_c *
      rtb_sinphi_c * controlMCUSlugsMKII_ConstB.Sum5_c);

    /* Sum: '<S156>/Sum2' */
    rtb_Sum2_g0 = controlMCUSlugsMKII_B.CFunctionCall_ap[2] + rtb_Rh_m;

    /* Trigonometry: '<S156>/cos(phi)' */
    rtb_Deg2R_a = (real32_T)cos(rtb_Deg2R_a);

    /* Gain: '<S156>/Deg2R1' */
    rtb_Deg2R1_g = 1.745329238E-002F * controlMCUSlugsMKII_B.CFunctionCall_ap[1];

    /* Sum: '<S144>/Sum1' incorporates:
     *  Product: '<S156>/(Rh+h)cos(phi)*cos(lamb)=Xe'
     *  Product: '<S156>/(Rh+h)cos(phi)*sin(lamb)=Ye'
     *  Product: '<S156>/Rh(1-e^2)'
     *  Product: '<S156>/Ze'
     *  Sum: '<S156>/Sum4'
     *  Trigonometry: '<S156>/cos(lamb)'
     *  Trigonometry: '<S156>/sin(lamb)'
     */
    rtb_Sum1_g[0] = rtb_Sum2_g0 * rtb_Deg2R_a * (real32_T)cos(rtb_Deg2R1_g) -
      controlMCUSlugsMKII_B.RhhcosphicoslambXe;
    rtb_Sum1_g[1] = rtb_Sum2_g0 * rtb_Deg2R_a * (real32_T)sin(rtb_Deg2R1_g) -
      controlMCUSlugsMKII_B.RhhcosphisinlambYe;
    rtb_Sum1_g[2] = (controlMCUSlugsMKII_ConstB.e2_f * rtb_Rh_m +
                     controlMCUSlugsMKII_B.CFunctionCall_ap[2]) * rtb_sinphi_c -
      controlMCUSlugsMKII_B.Ze;

    {
      static const int_T dims[3] = { 3, 3, 1 };

      rt_MatMultRR_Sgl(rtb_Product1_d4, rtb_TmpHiddenBufferAtProduct1_g,
                       rtb_Sum1_g, &dims[0]);
    }

    /* Gain Block: '<S144>/UEN 2 NEU'
     * About '<S144>/UEN 2 NEU :'
     *   Gain value: [0 0 1;0 1 0;1 0 0]


     */
    {
      static const int_T dims[3] = { 3, 3, 1 };

      rt_MatMultRR_Sgl((real32_T *)rtb_UEN2NEU_l, (real32_T *)
                       &controlMCUSlugsMKII_ConstP.pooled51[0],
                       (real32_T *)rtb_Product1_d4, &dims[0]);
    }

    /* InitialCondition: '<S133>/IC' */
    if (controlMCUSlugsMKII_DWork.IC_FirstOutputTime_k) {
      controlMCUSlugsMKII_DWork.IC_FirstOutputTime_k = 0U;
      controlMCUSlugsMKII_B.IC_l = 50.0F;
    } else {
      controlMCUSlugsMKII_B.IC_l = rtb_Add_n;
    }

    /* Integer/Tapped Delay Block: '<S133>/Integer Delay1'
     */
    (void) memcpy(&controlMCUSlugsMKII_DWork.IntegerDelay1_X_k[0],
                  controlMCUSlugsMKII_B.Divide_n,
                  3*sizeof(real32_T));

    /* Integer/Tapped Delay Block: '<S133>/Integer Delay2'
     */
    (void) memcpy(&controlMCUSlugsMKII_DWork.IntegerDelay2_X_e3[0],rtb_UEN2NEU_l,
                  3*sizeof(real32_T));
  }

  /* RelationalOperator: '<S140>/Switch Distance Less than?' */
  rtb_SwitchDistanceLessthan = (rtb_Switch3 >= (real_T)
    controlMCUSlugsMKII_B.Switch3);

  /* Embedded MATLAB: '<S124>/Embedded MATLAB Function1' incorporates:
   *  Constant: '<S124>/Switch Time Limit (in Samples)'
   */
  {
    uint32_T eml_u0;
    uint16_T eml_u1;

    /*  Declare static variables */
    rtb_swIncrement = 0.0;
    if ((rtb_SwitchDistanceLessthan == 1) &&
        (controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction1.oldSw == 0) &&
        ((real32_T)
         controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction1.internalTimer >
         300.0F)) {
      /* if we just had a flip */
      /*  if enough time has passed that another switch is valid */
      rtb_swIncrement = 1.0;
      controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction1.internalTimer = 0U;
    }

    eml_u0 = (uint32_T)
      controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction1.internalTimer + 1UL;
    if (eml_u0 > 65535UL) {
      eml_u1 = MAX_uint16_T;
    } else {
      eml_u1 = (uint16_T)eml_u0;
    }

    controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction1.internalTimer = eml_u1;
    controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction1.oldSw =
      rtb_SwitchDistanceLessthan;
  }

  /* S-Function (sfix_udelay): '<S137>/Integer Delay3'
   *
   * Regarding '<S137>/Integer Delay3':
   * Integer/Tapped Delay Block: '<S137>/Integer Delay3'
   */
  rtb_IntegerDelay3_d = controlMCUSlugsMKII_DWork.IntegerDelay3_X_n;

  /* Switch: '<S137>/Switch3' incorporates:
   *  RelationalOperator: '<S137>/Relational Operator2'
   */
  if ((controlMCUSlugsMKII_B.IC_l == controlMCUSlugsMKII_B.IC_l) > 0U) {
    rtb_Switch3_e = controlMCUSlugsMKII_B.IC_l;
  } else {
    rtb_Switch3_e = rtb_IntegerDelay3_d;
  }

  /* S-Function "dsPIC_C_function_Call" Block: <S126>/Set Log Floats 1-3 [navSupport.c] */
  setLogFloat1(controlMCUSlugsMKII_B.L1_vec);

  /* Product: '<S127>/Divide' incorporates:
   *  Constant: '<S16>/Gravity'
   */
  controlMCUSlugsMKII_B.Divide = rtb_Product_c / 9.81499958F;

  /* S-Function (sfix_udelay): '<S271>/Integer Delay3'
   *
   * Regarding '<S271>/Integer Delay3':
   * Integer/Tapped Delay Block: '<S271>/Integer Delay3'
   */
  rtb_IntegerDelay3_d = controlMCUSlugsMKII_DWork.IntegerDelay3_X_ch;

  /* S-Function "dsPIC_C_function_Call" Block: <S272>/C Function Call */
  controlMCUSlugsMKII_B.CFunctionCall_g = myAtan(controlMCUSlugsMKII_B.Divide);

  /* Switch: '<S271>/Switch3' incorporates:
   *  RelationalOperator: '<S271>/Relational Operator2'
   */
  if ((controlMCUSlugsMKII_B.CFunctionCall_g ==
       controlMCUSlugsMKII_B.CFunctionCall_g) > 0U) {
    rtb_Switch3_c = controlMCUSlugsMKII_B.CFunctionCall_g;
  } else {
    rtb_Switch3_c = rtb_IntegerDelay3_d;
  }

  /* Integer/Tapped Delay Block: '<S261>/Integer Delay3'
   */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_lj = rtb_Switch3_h;

  /* Integer/Tapped Delay Block: '<S124>/Integer Delay2'
   */
  controlMCUSlugsMKII_DWork.IntegerDelay2_X = rtb_swIncrement;

  /* Integer/Tapped Delay Block: '<S138>/Integer Delay1'
   */
  controlMCUSlugsMKII_DWork.IntegerDelay1_X_p =
    controlMCUSlugsMKII_B.HitCrossing1;

  /* Integer/Tapped Delay Block: '<S139>/Integer Delay2'
   */
  controlMCUSlugsMKII_DWork.IntegerDelay2_X_l = controlMCUSlugsMKII_B.IC;

  /* Integer/Tapped Delay Block: '<S132>/Integer Delay3'
   */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_b3 = rtb_Switch3_nn;

  /* Integer/Tapped Delay Block: '<S254>/Integer Delay3'
   */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_g = rtb_Switch3_a;

  /* Integer/Tapped Delay Block: '<S268>/Integer Delay3'
   */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_f = rtb_Switch3_m;

  /* Integer/Tapped Delay Block: '<S124>/Integer Delay3'
   */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_a = rtb_Switch3_e;

  /* Integer/Tapped Delay Block: '<S140>/Integer Delay1'
   */
  controlMCUSlugsMKII_DWork.IntegerDelay1_X_fi = controlMCUSlugsMKII_B.wp0;

  /* Integer/Tapped Delay Block: '<S180>/Integer Delay1'
   */
  controlMCUSlugsMKII_DWork.IntegerDelay1_X_i = controlMCUSlugsMKII_B.IC_e;

  /* Integer/Tapped Delay Block: '<S180>/Integer Delay2'
   */
  controlMCUSlugsMKII_DWork.IntegerDelay2_X_e[0] =
    controlMCUSlugsMKII_DWork.IntegerDelay2_X_e[1];
  controlMCUSlugsMKII_DWork.IntegerDelay2_X_e[1] = controlMCUSlugsMKII_B.IC_e;

  /* Update for UnitDelay: '<S196>/UD' */
  controlMCUSlugsMKII_DWork.UD_DSTATE = controlMCUSlugsMKII_B.Switch[0];

  /* Update for UnitDelay: '<S199>/UD' */
  controlMCUSlugsMKII_DWork.UD_DSTATE_e = controlMCUSlugsMKII_B.Switch[1];

  /* Update for UnitDelay: '<S202>/UD' */
  controlMCUSlugsMKII_DWork.UD_DSTATE_h = controlMCUSlugsMKII_B.Switch[2];

  /* Integer/Tapped Delay Block: '<S182>/Integer Delay3'
   */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X = rtb_Switch3;

  /* Integer/Tapped Delay Block: '<S137>/Integer Delay3'
   */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_n = rtb_Switch3_e;

  /* Integer/Tapped Delay Block: '<S271>/Integer Delay3'
   */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_ch = rtb_Switch3_c;

  /* S-Function "dsPIC_C_function_Call" Block: <Root>/[navSupport.c]    */
  getPidIdx(((uint8_T)8U),&controlMCUSlugsMKII_B.navSupportc_n[0]);

  /* Output and update for atomic system: '<S2>/Longitudinal Channel' */

  /* Sum: '<S91>/Add' incorporates:
   *  Constant: '<S91>/Constant from Model'
   *  Constant: '<S91>/Constant'
   *  Gain: '<S107>/Unit Conversion'
   *  Product: '<S91>/Divide'
   *  Saturate: '<S91>/[0 1000]'
   */
  controlMCUSlugsMKII_B.Add_g = 1.0F - 3.280839920E+000F * rt_SATURATE(rtb_u020,
    0.0F, 1000.0F) / 145442.0F;

  /* S-Function "dsPIC_C_function_Call" Block: <S108>/C Function Call */
  controlMCUSlugsMKII_B.CFunctionCall_ab = myPow(controlMCUSlugsMKII_B.Add_g,
    4.255876064F);

  /* Product: '<S91>/Divide1' incorporates:
   *  Constant: '<S91>/Rho_0 (Kg//m^3)'
   */
  rtb_Divide1_d = controlMCUSlugsMKII_B.CFunctionCall_ab * 1.225000024E+000F;

  /* Product: '<S93>/Divide2' incorporates:
   *  Constant: '<S93>/a'
   *  Saturate: '<S93>/[ 0.01 50000]'
   */
  rtb_Divide2 = 2.0F * controlMCUSlugsMKII_B.GetDynamicPnavSupportc /
    rt_SATURATE(rtb_Divide1_d, 9.999999776E-003F, 50000.0F);

  /* Stateflow: '<S113>/negprotect' */
  controlMCUSlugsM_negprotect(rtb_Divide2,
    &controlMCUSlugsMKII_B.sf_negprotect_c);

  /* S-Function "dsPIC_C_function_Call" Block: <S113>/C Function Call */
  controlMCUSlugsMKII_B.CFunctionCall_m4 = mySqrt
    (controlMCUSlugsMKII_B.sf_negprotect_c.zpVal);

  /* RelationalOperator: '<S99>/Relational Operator2' */
  rtb_RelationalOperator2_h = (controlMCUSlugsMKII_B.CFunctionCall_m4 ==
    controlMCUSlugsMKII_B.CFunctionCall_m4);

  /* S-Function (sfix_udelay): '<S99>/Integer Delay3'
   *
   * Regarding '<S99>/Integer Delay3':
   * Integer/Tapped Delay Block: '<S99>/Integer Delay3'
   */
  rtb_Enforcelowerlimit_c = controlMCUSlugsMKII_DWork.IntegerDelay3_X_i;

  {
    real32_T rateLimiterRate;

    /* Switch: '<S99>/Switch3' */
    if (rtb_RelationalOperator2_h > 0U) {
      rtb_Switch3_f = controlMCUSlugsMKII_B.CFunctionCall_m4;
    } else {
      rtb_Switch3_f = rtb_Enforcelowerlimit_c;
    }

    /* Embedded MATLAB: '<S88>/Embedded MATLAB Function' incorporates:
     *  Constant: '<S88>/Constant1'
     *  Constant: '<S88>/Constant'
     */
    {
      real_T eml_omega;

      /*  This block supports an embeddable subset of the MATLAB language. */
      /*  See the help menu for details.  */
      if (!controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction_m.a_not_empty) {
        /* tf = [T*omega/(2+T*omega) T*omega/(2+T*omega)],[1 (T*omega-2)/(T*omega+2)] */
        /* tf = [a a],[1 -b] */
        eml_omega = 6.2831853071795862E+000 * (0.5);
        controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction_m.a = 0.01 * eml_omega /
          (2.0 + 0.01 * eml_omega);
        controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction_m.a_not_empty = true;
        controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction_m.b = (-(0.01 *
          eml_omega - 2.0)) / (0.01 * eml_omega + 2.0);
        controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction_m.y_km1 = rtb_Switch3_f;
        controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction_m.u_km1 = rtb_Switch3_f;
      }

      rtb_y_i = (real32_T)controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction_m.a *
        (rtb_Switch3_f +
         controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction_m.u_km1) + (real32_T)
        controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction_m.b *
        controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction_m.y_km1;
      controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction_m.y_km1 = rtb_y_i;
      controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction_m.u_km1 = rtb_Switch3_f;
    }

    /* RelationalOperator: '<S102>/Compare' incorporates:
     *  Constant: '<S102>/Constant'
     */
    rtb_Compare_l = (rtb_Switch3_f <= 10.0F);

    /* Embedded MATLAB: '<S90>/Embedded MATLAB Function' incorporates:
     *  Constant: '<S90>/Constant1'
     *  Constant: '<S90>/Constant'
     */
    {
      real_T eml_omega;

      /*  This block supports an embeddable subset of the MATLAB language. */
      /*  See the help menu for details.  */
      if (!controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction_l.a_not_empty) {
        /* tf = [T*omega/(2+T*omega) T*omega/(2+T*omega)],[1 (T*omega-2)/(T*omega+2)] */
        /* tf = [a a],[1 -b] */
        eml_omega = 6.2831853071795862E+000 * (0.032);
        controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction_l.a = 0.01 * eml_omega /
          (2.0 + 0.01 * eml_omega);
        controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction_l.a_not_empty = true;
        controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction_l.b = (-(0.01 *
          eml_omega - 2.0)) / (0.01 * eml_omega + 2.0);
        controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction_l.y_km1 = rtb_Switch3_f;
        controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction_l.u_km1 = rtb_Switch3_f;
      }

      rtb_y_g = (real32_T)controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction_l.a *
        (rtb_Switch3_f +
         controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction_l.u_km1) + (real32_T)
        controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction_l.b *
        controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction_l.y_km1;
      controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction_l.y_km1 = rtb_y_g;
      controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction_l.u_km1 = rtb_Switch3_f;
    }

    /* Switch: '<S15>/Schedule LPF' */
    if (rtb_Compare_l > 0U) {
      rtb_ScheduleLPF = rtb_y_i;
    } else {
      rtb_ScheduleLPF = rtb_y_g;
    }

    /* Switch: '<S15>/Switch' incorporates:
     *  Saturate: '<S2>/[-20 20]1'
     */
    if (controlMCUSlugsMKII_B.wpFlynavSupportc > 0U) {
      rtb_Product1_ma = rt_SATURATE(controlMCUSlugsMKII_B.Reshape1[2], 170.0F,
        350.0F);
    } else {
      rtb_Product1_ma = controlMCUSlugsMKII_B.GetMidLevelCommandsnavSupportc[1];
    }

    /* RateLimiter: '<S15>/Rate Limiter' */
    rateLimiterRate = rtb_Product1_ma - controlMCUSlugsMKII_DWork.PrevY;
    if (rateLimiterRate > 7.000000030E-002F) {
      rtb_Product1_ma = controlMCUSlugsMKII_DWork.PrevY + 7.000000030E-002F;
    } else if (rateLimiterRate < -5.000000075E-002F) {
      rtb_Product1_ma = controlMCUSlugsMKII_DWork.PrevY + -5.000000075E-002F;
    }

    controlMCUSlugsMKII_DWork.PrevY = rtb_Product1_ma;

    /* Sum: '<S15>/Add2' */
    rtb_Add2 = rtb_Product1_ma - rtb_u020;
  }

  /* S-Function (sfix_udelay): '<S97>/Integer Delay3'
   *
   * Regarding '<S97>/Integer Delay3':
   * Integer/Tapped Delay Block: '<S97>/Integer Delay3'
   */
  rtb_IntegerDelay3_hu = controlMCUSlugsMKII_DWork.IntegerDelay3_X_m;

  /* Switch: '<S97>/Switch3' incorporates:
   *  RelationalOperator: '<S97>/Relational Operator2'
   */
  if (((uint8_T)(rtb_Add2 == rtb_Add2)) > 0U) {
    rtb_Switch3_c1 = rtb_Add2;
  } else {
    rtb_Switch3_c1 = rtb_IntegerDelay3_hu;
  }

  /* Product: '<S94>/Product1' */
  rtb_Product1_ma = rtb_Switch3_c1 *
    controlMCUSlugsMKII_B.GetPidaccordingtoIndex1[0];

  /* S-Function (sfix_udelay): '<S116>/Integer Delay2'
   *
   * Regarding '<S116>/Integer Delay2':
   * Integer/Tapped Delay Block: '<S116>/Integer Delay2'
   */
  rtb_IntegerDelay2_f = controlMCUSlugsMKII_DWork.IntegerDelay2_X_lq;

  /* Sum: '<S94>/Sum2' incorporates:
   *  Gain: '<S94>/Gain'
   *  Memory: '<S94>/Memory1'
   *  Product: '<S94>/Product4'
   */
  rtb_Sum2 = (9.999999776E-003F * rtb_Switch3_c1 *
              controlMCUSlugsMKII_B.GetPidaccordingtoIndex1[1] +
              controlMCUSlugsMKII_DWork.Memory1_PreviousInput) + rtb_Product1_ma;

  /* Switch: '<S94>/AntiWindup' incorporates:
   *  Constant: '<S94>/Constant5'
   *  Logic: '<S94>/Logical Operator'
   *  RelationalOperator: '<S94>/Relational Operator'
   *  RelationalOperator: '<S94>/Relational Operator1'
   */
  if ((rtb_Sum2 > controlMCUSlugsMKII_ConstB.Add4) && (rtb_Sum2 <
       controlMCUSlugsMKII_ConstB.Add3)) {
    rtb_AntiWindup = (real_T)rtb_Switch3_c1;
  } else {
    rtb_AntiWindup = 0.0;
  }

  /* S-Function (sfix_udelay): '<S118>/Integer Delay3'
   *
   * Regarding '<S118>/Integer Delay3':
   * Integer/Tapped Delay Block: '<S118>/Integer Delay3'
   */
  rtb_IntegerDelay3_k = controlMCUSlugsMKII_DWork.IntegerDelay3_X_c;

  /* Switch: '<S118>/Switch3' incorporates:
   *  RelationalOperator: '<S118>/Relational Operator2'
   */
  if (((uint8_T)(rtb_AntiWindup == rtb_AntiWindup)) > 0U) {
    rtb_Switch3_n = rtb_AntiWindup;
  } else {
    rtb_Switch3_n = rtb_IntegerDelay3_k;
  }

  /* S-Function (sfix_udelay): '<S116>/Integer Delay'
   *
   * Regarding '<S116>/Integer Delay':
   * Integer/Tapped Delay Block: '<S116>/Integer Delay'
   */
  rtb_IntegerDelay = controlMCUSlugsMKII_DWork.IntegerDelay_X;

  /* S-Function (sfix_udelay): '<S116>/Integer Delay1'
   *
   * Regarding '<S116>/Integer Delay1':
   * Integer/Tapped Delay Block: '<S116>/Integer Delay1'
   */
  rtb_IntegerDelay1 = controlMCUSlugsMKII_DWork.IntegerDelay1_X[0];

  /* Switch: '<S116>/Switch1' incorporates:
   *  Constant: '<S116>/Constant'
   *  Constant: '<S116>/Constant1'
   *  Constant: '<S116>/Constant2'
   *  Constant: '<S116>/Constant3'
   *  Constant: '<S116>/Constant5'
   *  Product: '<S116>/Product'
   *  Product: '<S116>/Product1'
   *  Product: '<S116>/Product2'
   *  Product: '<S116>/Product3'
   *  Sum: '<S116>/Subtract'
   *  Sum: '<S116>/Subtract1'
   */
  if (controlMCUSlugsMKII_B.ManualorAutonavSupportc > 0U) {
    rtb_Switch1 = 0.0F;
  } else {
    rtb_Switch1 = (((real32_T)(rtb_Switch3_n * (real_T)0.3333333433F) +
                    (real32_T)(rtb_IntegerDelay * (real_T)1.333333373F)) +
                   (real32_T)(rtb_IntegerDelay1 * 3.3333334326744080E-001)) *
      0.004999999888F + rtb_IntegerDelay2_f;
  }

  /* S-Function (sfix_udelay): '<S117>/Integer Delay3'
   *
   * Regarding '<S117>/Integer Delay3':
   * Integer/Tapped Delay Block: '<S117>/Integer Delay3'
   */
  rtb_IntegerDelay3_hu = controlMCUSlugsMKII_DWork.IntegerDelay3_X_at;

  {
    real32_T max;

    /* Switch: '<S117>/Switch3' incorporates:
     *  RelationalOperator: '<S117>/Relational Operator2'
     */
    if (((uint8_T)(rtb_Switch1 == rtb_Switch1)) > 0U) {
      rtb_Switch3_b = rtb_Switch1;
    } else {
      rtb_Switch3_b = rtb_IntegerDelay3_hu;
    }

    /* Sum: '<S94>/Add2' incorporates:
     *  Product: '<S94>/Product'
     */
    rtb_Add2_i = rtb_Switch3_b * controlMCUSlugsMKII_B.GetPidaccordingtoIndex1[1]
      + rtb_Product1_ma;

    /* MinMax: '<S115>/Enforce lower limit' */
    max = rt_MAX(controlMCUSlugsMKII_ConstB.Add4, rtb_Add2_i);

    /* MinMax: '<S115>/Enforce upper limit' */
    max = rt_MIN(max, controlMCUSlugsMKII_ConstB.Add3);

    /* Saturate: '<S15>/Theta_c Limit' */
    rtb_Theta_cLimit = rt_SATURATE(max, -3.490658402E-001F, 3.490658402E-001F);

    /* Embedded MATLAB: '<S15>/myMux Fun1' */

    /*  This block supports an embeddable subset of the MATLAB language. */
    /*  See the help menu for details.  */
    controlMCUSlugsMKII_B.y_j[0] = rtb_ScheduleLPF;
    controlMCUSlugsMKII_B.y_j[1] = rtb_Theta_cLimit;
  }

  /* S-Function "dsPIC_C_function_Call" Block: <S15>/Get XYZ [navSupport.c] */
  setNavLong(controlMCUSlugsMKII_B.y_j);

  /* RelationalOperator: '<S100>/Relational Operator2' */
  rtb_RelationalOperator2_a = (controlMCUSlugsMKII_B.y_n[0] ==
    controlMCUSlugsMKII_B.y_n[0]);

  /* S-Function (sfix_udelay): '<S100>/Integer Delay3'
   *
   * Regarding '<S100>/Integer Delay3':
   * Integer/Tapped Delay Block: '<S100>/Integer Delay3'
   */
  rtb_Add1_l = controlMCUSlugsMKII_DWork.IntegerDelay3_X_fk;

  /* Switch: '<S100>/Switch3' */
  if (rtb_RelationalOperator2_a > 0U) {
    rtb_Switch3_mx = controlMCUSlugsMKII_B.y_n[0];
  } else {
    rtb_Switch3_mx = rtb_Add1_l;
  }

  /* Embedded MATLAB: '<S89>/Embedded MATLAB Function' incorporates:
   *  Constant: '<S89>/Constant1'
   *  Constant: '<S89>/Constant'
   */
  {
    real_T eml_omega;

    /*  This block supports an embeddable subset of the MATLAB language. */
    /*  See the help menu for details.  */
    if (!controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction_j.a_not_empty) {
      /* tf = [T*omega/(2+T*omega) T*omega/(2+T*omega)],[1 (T*omega-2)/(T*omega+2)] */
      /* tf = [a a],[1 -b] */
      eml_omega = 6.2831853071795862E+000 * (0.32);
      controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction_j.a = 0.01 * eml_omega /
        (2.0 + 0.01 * eml_omega);
      controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction_j.a_not_empty = true;
      controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction_j.b = (-(0.01 * eml_omega
        - 2.0)) / (0.01 * eml_omega + 2.0);
      controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction_j.y_km1 = rtb_Switch3_mx;
      controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction_j.u_km1 = rtb_Switch3_mx;
    }

    rtb_y_o = (real32_T)controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction_j.a *
      (rtb_Switch3_mx + controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction_j.u_km1)
      + (real32_T)controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction_j.b *
      controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction_j.y_km1;
    controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction_j.y_km1 = rtb_y_o;
    controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction_j.u_km1 = rtb_Switch3_mx;
  }

  /* Sum: '<S15>/Add' */
  rtb_Add_b1 = controlMCUSlugsMKII_B.GetMidLevelCommandsnavSupportc[0] -
    rtb_ScheduleLPF;

  /* Sum: '<S92>/Add4' incorporates:
   *  Constant: '<S92>/SaturationLimit1'
   */
  rtb_Add4 = 0.0F - controlMCUSlugsMKII_B.DataTypeConversion;

  /* S-Function (sfix_udelay): '<S96>/Integer Delay3'
   *
   * Regarding '<S96>/Integer Delay3':
   * Integer/Tapped Delay Block: '<S96>/Integer Delay3'
   */
  rtb_Add1_l = controlMCUSlugsMKII_DWork.IntegerDelay3_X_e;

  /* Switch: '<S96>/Switch3' incorporates:
   *  RelationalOperator: '<S96>/Relational Operator2'
   */
  if (((uint8_T)(rtb_Add_b1 == rtb_Add_b1)) > 0U) {
    rtb_Switch3_kr = rtb_Add_b1;
  } else {
    rtb_Switch3_kr = rtb_Add1_l;
  }

  /* Product: '<S92>/Product1' */
  rtb_Product1_j = rtb_Switch3_kr * controlMCUSlugsMKII_B.GetPidaccordingtoIndex
    [0];

  /* S-Function (sfix_udelay): '<S92>/NDelays'
   *
   * Regarding '<S92>/NDelays':
   * Integer/Tapped Delay Block: '<S92>/NDelays'
   */
  rtb_NDelays = controlMCUSlugsMKII_DWork.NDelays_X[0];

  /* Sum: '<S92>/Add1' incorporates:
   *  Constant: '<S92>/delayTime'
   *  Product: '<S92>/Product2'
   *  Product: '<S92>/Product3'
   *  Sum: '<S92>/Sum'
   */
  rtb_Add1_l = (rtb_Switch3_kr - rtb_NDelays) / 5.000000075E-002F *
    controlMCUSlugsMKII_B.GetPidaccordingtoIndex[2] + rtb_Product1_j;

  /* S-Function (sfix_udelay): '<S110>/Integer Delay2'
   *
   * Regarding '<S110>/Integer Delay2':
   * Integer/Tapped Delay Block: '<S110>/Integer Delay2'
   */
  rtb_IntegerDelay2_fm = controlMCUSlugsMKII_DWork.IntegerDelay2_X_d;

  /* Sum: '<S92>/Sum2' incorporates:
   *  Gain: '<S92>/Gain'
   *  Memory: '<S92>/Memory1'
   *  Product: '<S92>/Product4'
   */
  rtb_Sum2_k = (9.999999776E-003F * rtb_Switch3_kr *
                controlMCUSlugsMKII_B.GetPidaccordingtoIndex[1] +
                controlMCUSlugsMKII_DWork.Memory1_PreviousInput_e) + rtb_Add1_l;

  /* Sum: '<S92>/Add3' incorporates:
   *  Constant: '<S92>/SaturationLimit'
   */
  rtb_Add3 = 1.0F - controlMCUSlugsMKII_B.DataTypeConversion;

  /* Switch: '<S92>/AntiWindup' incorporates:
   *  Constant: '<S92>/Constant5'
   *  Logic: '<S92>/Logical Operator'
   *  RelationalOperator: '<S92>/Relational Operator'
   *  RelationalOperator: '<S92>/Relational Operator1'
   */
  if ((rtb_Sum2_k > rtb_Add4) && (rtb_Sum2_k < rtb_Add3)) {
    rtb_AntiWindup_e = (real_T)rtb_Switch3_kr;
  } else {
    rtb_AntiWindup_e = 0.0;
  }

  /* S-Function (sfix_udelay): '<S111>/Integer Delay3'
   *
   * Regarding '<S111>/Integer Delay3':
   * Integer/Tapped Delay Block: '<S111>/Integer Delay3'
   */
  rtb_IntegerDelay3_k = controlMCUSlugsMKII_DWork.IntegerDelay3_X_l;

  /* Switch: '<S111>/Switch3' incorporates:
   *  RelationalOperator: '<S111>/Relational Operator2'
   */
  if (((uint8_T)(rtb_AntiWindup_e == rtb_AntiWindup_e)) > 0U) {
    rtb_Switch3_k = rtb_AntiWindup_e;
  } else {
    rtb_Switch3_k = rtb_IntegerDelay3_k;
  }

  /* S-Function (sfix_udelay): '<S110>/Integer Delay'
   *
   * Regarding '<S110>/Integer Delay':
   * Integer/Tapped Delay Block: '<S110>/Integer Delay'
   */
  rtb_IntegerDelay_g = controlMCUSlugsMKII_DWork.IntegerDelay_X_i;

  /* S-Function (sfix_udelay): '<S110>/Integer Delay1'
   *
   * Regarding '<S110>/Integer Delay1':
   * Integer/Tapped Delay Block: '<S110>/Integer Delay1'
   */
  rtb_IntegerDelay1_n = controlMCUSlugsMKII_DWork.IntegerDelay1_X_o[0];

  /* Switch: '<S110>/Switch1' incorporates:
   *  Constant: '<S110>/Constant'
   *  Constant: '<S110>/Constant1'
   *  Constant: '<S110>/Constant2'
   *  Constant: '<S110>/Constant3'
   *  Constant: '<S110>/Constant5'
   *  Product: '<S110>/Product'
   *  Product: '<S110>/Product1'
   *  Product: '<S110>/Product2'
   *  Product: '<S110>/Product3'
   *  Sum: '<S110>/Subtract'
   *  Sum: '<S110>/Subtract1'
   */
  if (controlMCUSlugsMKII_B.ManualorAutonavSupportc > 0U) {
    rtb_Switch1_o = 0.0F;
  } else {
    rtb_Switch1_o = (((real32_T)(rtb_Switch3_k * (real_T)0.3333333433F) +
                      (real32_T)(rtb_IntegerDelay_g * (real_T)1.333333373F)) +
                     (real32_T)(rtb_IntegerDelay1_n * 3.3333334326744080E-001)) *
      0.004999999888F + rtb_IntegerDelay2_fm;
  }

  /* S-Function (sfix_udelay): '<S112>/Integer Delay3'
   *
   * Regarding '<S112>/Integer Delay3':
   * Integer/Tapped Delay Block: '<S112>/Integer Delay3'
   */
  rtb_IntegerDelay3_hu = controlMCUSlugsMKII_DWork.IntegerDelay3_X_ex;

  {
    real32_T max;

    /* Switch: '<S112>/Switch3' incorporates:
     *  RelationalOperator: '<S112>/Relational Operator2'
     */
    if (((uint8_T)(rtb_Switch1_o == rtb_Switch1_o)) > 0U) {
      rtb_Switch3_p = rtb_Switch1_o;
    } else {
      rtb_Switch3_p = rtb_IntegerDelay3_hu;
    }

    /* Sum: '<S92>/Add2' incorporates:
     *  Product: '<S92>/Product'
     */
    rtb_Add2_d = rtb_Switch3_p * controlMCUSlugsMKII_B.GetPidaccordingtoIndex[1]
      + rtb_Add1_l;

    /* MinMax: '<S109>/Enforce lower limit' */
    max = rt_MAX(rtb_Add4, rtb_Add2_d);

    /* Sum: '<S15>/Add1' incorporates:
     *  MinMax: '<S109>/Enforce upper limit'
     *  Product: '<S15>/Product2'
     */
    rtb_Add1 = (rt_MIN(max, rtb_Add3) + controlMCUSlugsMKII_B.DataTypeConversion)
      + controlMCUSlugsMKII_B.navSupportc_n[0] * controlMCUSlugsMKII_B.y_n[1];

    /* Sum: '<S15>/Add3' */
    rtb_Add3_i = rtb_Theta_cLimit - controlMCUSlugsMKII_B.y_n[1];

    /* Sum: '<S95>/Add4' incorporates:
     *  Constant: '<S95>/SaturationLimit1'
     */
    rtb_Add4_k = -2.617993951E-001F - controlMCUSlugsMKII_B.DataTypeConversion_c;
  }

  /* S-Function (sfix_udelay): '<S98>/Integer Delay3'
   *
   * Regarding '<S98>/Integer Delay3':
   * Integer/Tapped Delay Block: '<S98>/Integer Delay3'
   */
  rtb_Add1_l = controlMCUSlugsMKII_DWork.IntegerDelay3_X_nv;

  /* Switch: '<S98>/Switch3' incorporates:
   *  RelationalOperator: '<S98>/Relational Operator2'
   */
  if (((uint8_T)(rtb_Add3_i == rtb_Add3_i)) > 0U) {
    rtb_Switch3_f3 = rtb_Add3_i;
  } else {
    rtb_Switch3_f3 = rtb_Add1_l;
  }

  /* Product: '<S95>/Product1' */
  rtb_Product1_a = rtb_Switch3_f3 *
    controlMCUSlugsMKII_B.GetPidaccordingtoIndex2[0];

  /* S-Function (sfix_udelay): '<S95>/NDelays'
   *
   * Regarding '<S95>/NDelays':
   * Integer/Tapped Delay Block: '<S95>/NDelays'
   */
  rtb_NDelays_n = controlMCUSlugsMKII_DWork.NDelays_X_c[0];

  /* Sum: '<S95>/Add1' incorporates:
   *  Constant: '<S95>/delayTime'
   *  Product: '<S95>/Product2'
   *  Product: '<S95>/Product3'
   *  Sum: '<S95>/Sum'
   */
  rtb_Add1_l = (rtb_Switch3_f3 - rtb_NDelays_n) / 5.000000075E-002F *
    controlMCUSlugsMKII_B.GetPidaccordingtoIndex2[2] + rtb_Product1_a;

  /* S-Function (sfix_udelay): '<S120>/Integer Delay2'
   *
   * Regarding '<S120>/Integer Delay2':
   * Integer/Tapped Delay Block: '<S120>/Integer Delay2'
   */
  rtb_IntegerDelay2_h = controlMCUSlugsMKII_DWork.IntegerDelay2_X_n;

  /* Sum: '<S95>/Sum2' incorporates:
   *  Gain: '<S95>/Gain'
   *  Memory: '<S95>/Memory1'
   *  Product: '<S95>/Product4'
   */
  rtb_Sum2_a = (9.999999776E-003F * rtb_Switch3_f3 *
                controlMCUSlugsMKII_B.GetPidaccordingtoIndex2[1] +
                controlMCUSlugsMKII_DWork.Memory1_PreviousInput_f) + rtb_Add1_l;

  /* Sum: '<S95>/Add3' incorporates:
   *  Constant: '<S95>/SaturationLimit'
   */
  rtb_Add3_b = 2.617993951E-001F - controlMCUSlugsMKII_B.DataTypeConversion_c;

  /* Switch: '<S95>/AntiWindup' incorporates:
   *  Constant: '<S95>/Constant5'
   *  Logic: '<S95>/Logical Operator'
   *  RelationalOperator: '<S95>/Relational Operator'
   *  RelationalOperator: '<S95>/Relational Operator1'
   */
  if ((rtb_Sum2_a > rtb_Add4_k) && (rtb_Sum2_a < rtb_Add3_b)) {
    rtb_AntiWindup_d = (real_T)rtb_Switch3_f3;
  } else {
    rtb_AntiWindup_d = 0.0;
  }

  /* S-Function (sfix_udelay): '<S121>/Integer Delay3'
   *
   * Regarding '<S121>/Integer Delay3':
   * Integer/Tapped Delay Block: '<S121>/Integer Delay3'
   */
  rtb_IntegerDelay3_k = controlMCUSlugsMKII_DWork.IntegerDelay3_X_k;

  /* Switch: '<S121>/Switch3' incorporates:
   *  RelationalOperator: '<S121>/Relational Operator2'
   */
  if (((uint8_T)(rtb_AntiWindup_d == rtb_AntiWindup_d)) > 0U) {
    rtb_Switch3_o = rtb_AntiWindup_d;
  } else {
    rtb_Switch3_o = rtb_IntegerDelay3_k;
  }

  /* S-Function (sfix_udelay): '<S120>/Integer Delay'
   *
   * Regarding '<S120>/Integer Delay':
   * Integer/Tapped Delay Block: '<S120>/Integer Delay'
   */
  rtb_IntegerDelay_i = controlMCUSlugsMKII_DWork.IntegerDelay_X_g;

  /* S-Function (sfix_udelay): '<S120>/Integer Delay1'
   *
   * Regarding '<S120>/Integer Delay1':
   * Integer/Tapped Delay Block: '<S120>/Integer Delay1'
   */
  rtb_IntegerDelay1_j = controlMCUSlugsMKII_DWork.IntegerDelay1_X_oa[0];

  /* Switch: '<S120>/Switch1' incorporates:
   *  Constant: '<S120>/Constant'
   *  Constant: '<S120>/Constant1'
   *  Constant: '<S120>/Constant2'
   *  Constant: '<S120>/Constant3'
   *  Constant: '<S120>/Constant5'
   *  Product: '<S120>/Product'
   *  Product: '<S120>/Product1'
   *  Product: '<S120>/Product2'
   *  Product: '<S120>/Product3'
   *  Sum: '<S120>/Subtract'
   *  Sum: '<S120>/Subtract1'
   */
  if (controlMCUSlugsMKII_B.ManualorAutonavSupportc > 0U) {
    rtb_Switch1_k = 0.0F;
  } else {
    rtb_Switch1_k = (((real32_T)(rtb_Switch3_o * (real_T)0.3333333433F) +
                      (real32_T)(rtb_IntegerDelay_i * (real_T)1.333333373F)) +
                     (real32_T)(rtb_IntegerDelay1_j * 3.3333334326744080E-001)) *
      0.004999999888F + rtb_IntegerDelay2_h;
  }

  /* S-Function (sfix_udelay): '<S122>/Integer Delay3'
   *
   * Regarding '<S122>/Integer Delay3':
   * Integer/Tapped Delay Block: '<S122>/Integer Delay3'
   */
  rtb_IntegerDelay3_hu = controlMCUSlugsMKII_DWork.IntegerDelay3_X_p;

  {
    real32_T max;

    /* Switch: '<S122>/Switch3' incorporates:
     *  RelationalOperator: '<S122>/Relational Operator2'
     */
    if (((uint8_T)(rtb_Switch1_k == rtb_Switch1_k)) > 0U) {
      rtb_Switch3_el = rtb_Switch1_k;
    } else {
      rtb_Switch3_el = rtb_IntegerDelay3_hu;
    }

    /* Sum: '<S95>/Add2' incorporates:
     *  Product: '<S95>/Product'
     */
    rtb_Add2_a = rtb_Switch3_el * controlMCUSlugsMKII_B.GetPidaccordingtoIndex2
      [1] + rtb_Add1_l;

    /* MinMax: '<S119>/Enforce lower limit' */
    max = rt_MAX(rtb_Add4_k, rtb_Add2_a);

    /* MinMax: '<S119>/Enforce upper limit' */
    rtb_Enforceupperlimit_m = rt_MIN(max, rtb_Add3_b);

    /* Saturate: '<S15>/[-60 60]' */
    controlMCUSlugsMKII_B.u060 = rt_SATURATE(rtb_y_o, -60.0F, 60.0F);
  }

  /* S-Function "dsPIC_C_function_Call" Block: <S101>/C Function Call1 */
  controlMCUSlugsMKII_B.CFunctionCall1_b = myCos(controlMCUSlugsMKII_B.u060);

  /* Sum: '<S15>/Add4' incorporates:
   *  Constant: '<S15>/Constant2'
   *  Constant: '<S15>/Constant4'
   *  Product: '<S15>/Product'
   *  Product: '<S15>/Product1'
   *  Sum: '<S15>/Add5'
   */
  rtb_Add4_ki = (1.0F / controlMCUSlugsMKII_B.CFunctionCall1_b - 1.0F) *
    controlMCUSlugsMKII_B.GetPidaccordingtoIndex1[2] + (rtb_Enforceupperlimit_m
    + controlMCUSlugsMKII_B.DataTypeConversion_c);

  /* Saturate: '<S15>/Elevator  Limit' */
  rtb_ElevatorLimit = rt_SATURATE(rtb_Add4_ki, -2.617993951E-001F,
    2.617993951E-001F);

  /* Saturate: '<S15>/Throttle  Limit' */
  rtb_ThrottleLimit = rt_SATURATE(rtb_Add1, 0.0F, 1.0F);

  /* Integer/Tapped Delay Block: '<S99>/Integer Delay3'
   */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_i = rtb_Switch3_f;

  /* Integer/Tapped Delay Block: '<S97>/Integer Delay3'
   */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_m = rtb_Switch3_c1;

  /* Integer/Tapped Delay Block: '<S116>/Integer Delay2'
   */
  controlMCUSlugsMKII_DWork.IntegerDelay2_X_lq = rtb_Switch3_b;

  /* Update for Memory: '<S94>/Memory1' */
  controlMCUSlugsMKII_DWork.Memory1_PreviousInput = rtb_Add2_i;

  /* Integer/Tapped Delay Block: '<S118>/Integer Delay3'
   */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_c = rtb_Switch3_n;

  /* Integer/Tapped Delay Block: '<S116>/Integer Delay'
   */
  controlMCUSlugsMKII_DWork.IntegerDelay_X = rtb_Switch3_n;

  /* Integer/Tapped Delay Block: '<S116>/Integer Delay1'
   */
  controlMCUSlugsMKII_DWork.IntegerDelay1_X[0] =
    controlMCUSlugsMKII_DWork.IntegerDelay1_X[1];
  controlMCUSlugsMKII_DWork.IntegerDelay1_X[1] = rtb_Switch3_n;

  /* Integer/Tapped Delay Block: '<S117>/Integer Delay3'
   */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_at = rtb_Switch3_b;

  /* Integer/Tapped Delay Block: '<S100>/Integer Delay3'
   */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_fk = rtb_Switch3_mx;

  /* Integer/Tapped Delay Block: '<S96>/Integer Delay3'
   */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_e = rtb_Switch3_kr;

  /* Integer/Tapped Delay Block: '<S92>/NDelays'
   */
  controlMCUSlugsMKII_DWork.NDelays_X[0] = controlMCUSlugsMKII_DWork.NDelays_X[1];
  controlMCUSlugsMKII_DWork.NDelays_X[1] = controlMCUSlugsMKII_DWork.NDelays_X[2];
  controlMCUSlugsMKII_DWork.NDelays_X[2] = controlMCUSlugsMKII_DWork.NDelays_X[3];
  controlMCUSlugsMKII_DWork.NDelays_X[3] = controlMCUSlugsMKII_DWork.NDelays_X[4];
  controlMCUSlugsMKII_DWork.NDelays_X[4] = rtb_Switch3_kr;

  /* Integer/Tapped Delay Block: '<S110>/Integer Delay2'
   */
  controlMCUSlugsMKII_DWork.IntegerDelay2_X_d = rtb_Switch3_p;

  /* Update for Memory: '<S92>/Memory1' */
  controlMCUSlugsMKII_DWork.Memory1_PreviousInput_e = rtb_Add2_d;

  /* Integer/Tapped Delay Block: '<S111>/Integer Delay3'
   */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_l = rtb_Switch3_k;

  /* Integer/Tapped Delay Block: '<S110>/Integer Delay'
   */
  controlMCUSlugsMKII_DWork.IntegerDelay_X_i = rtb_Switch3_k;

  /* Integer/Tapped Delay Block: '<S110>/Integer Delay1'
   */
  controlMCUSlugsMKII_DWork.IntegerDelay1_X_o[0] =
    controlMCUSlugsMKII_DWork.IntegerDelay1_X_o[1];
  controlMCUSlugsMKII_DWork.IntegerDelay1_X_o[1] = rtb_Switch3_k;

  /* Integer/Tapped Delay Block: '<S112>/Integer Delay3'
   */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_ex = rtb_Switch3_p;

  /* Integer/Tapped Delay Block: '<S98>/Integer Delay3'
   */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_nv = rtb_Switch3_f3;

  /* Integer/Tapped Delay Block: '<S95>/NDelays'
   */
  controlMCUSlugsMKII_DWork.NDelays_X_c[0] =
    controlMCUSlugsMKII_DWork.NDelays_X_c[1];
  controlMCUSlugsMKII_DWork.NDelays_X_c[1] =
    controlMCUSlugsMKII_DWork.NDelays_X_c[2];
  controlMCUSlugsMKII_DWork.NDelays_X_c[2] =
    controlMCUSlugsMKII_DWork.NDelays_X_c[3];
  controlMCUSlugsMKII_DWork.NDelays_X_c[3] =
    controlMCUSlugsMKII_DWork.NDelays_X_c[4];
  controlMCUSlugsMKII_DWork.NDelays_X_c[4] = rtb_Switch3_f3;

  /* Integer/Tapped Delay Block: '<S120>/Integer Delay2'
   */
  controlMCUSlugsMKII_DWork.IntegerDelay2_X_n = rtb_Switch3_el;

  /* Update for Memory: '<S95>/Memory1' */
  controlMCUSlugsMKII_DWork.Memory1_PreviousInput_f = rtb_Add2_a;

  /* Integer/Tapped Delay Block: '<S121>/Integer Delay3'
   */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_k = rtb_Switch3_o;

  /* Integer/Tapped Delay Block: '<S120>/Integer Delay'
   */
  controlMCUSlugsMKII_DWork.IntegerDelay_X_g = rtb_Switch3_o;

  /* Integer/Tapped Delay Block: '<S120>/Integer Delay1'
   */
  controlMCUSlugsMKII_DWork.IntegerDelay1_X_oa[0] =
    controlMCUSlugsMKII_DWork.IntegerDelay1_X_oa[1];
  controlMCUSlugsMKII_DWork.IntegerDelay1_X_oa[1] = rtb_Switch3_o;

  /* Integer/Tapped Delay Block: '<S122>/Integer Delay3'
   */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_p = rtb_Switch3_el;

  /* S-Function "dsPIC_C_function_Call" Block: <S3>/Get Pid according to Index3 */
  getPidIdx(((uint8_T)3U),&controlMCUSlugsMKII_B.GetPidaccordingtoIndex3[0]);

  /* S-Function "dsPIC_C_function_Call" Block: <S3>/[navSupport.c] */
  getPidIdx(((uint8_T)4U),&controlMCUSlugsMKII_B.navSupportc_k[0]);

  /* S-Function "dsPIC_C_function_Call" Block: <S20>/[apUtils.c] */
  controlMCUSlugsMKII_B.apUtilsc = myCos(controlMCUSlugsMKII_B.y_n[0]);

  /* Product: '<S12>/Product' */
  rtb_Product = controlMCUSlugsMKII_B.y_n[5] * controlMCUSlugsMKII_B.apUtilsc;

  /* S-Function "dsPIC_C_function_Call" Block: <S21>/[apUtils.c] */
  controlMCUSlugsMKII_B.apUtilsc_p = mySin(controlMCUSlugsMKII_B.y_n[0]);

  /* Sum: '<S12>/Subtract' incorporates:
   *  Product: '<S12>/Product1'
   */
  rtb_Subtract = controlMCUSlugsMKII_B.y_n[4] * controlMCUSlugsMKII_B.apUtilsc_p
    + rtb_Product;

  /* Switch: '<S19>/Switch3' incorporates:
   *  RelationalOperator: '<S19>/Relational Operator2'
   *  S-Function (sfix_udelay): '<S19>/Integer Delay3'
   */
  if (((uint8_T)(rtb_Subtract == rtb_Subtract)) > 0U) {
    rtb_Switch3_oe = rtb_Subtract;
  } else {
    rtb_Switch3_oe = (controlMCUSlugsMKII_DWork.IntegerDelay3_X_b);
  }

  /* S-Function "dsPIC_C_function_Call" Block: <Root>/[navSupport.c]  */
  getPidIdx(((uint8_T)6U),&controlMCUSlugsMKII_B.navSupportc_g[0]);
  if (controlMCUSlugsMKII_B.navSupportc_g[2] > 0.0F) {
    if (controlMCUSlugsMKII_DWork.L1OutputFeedbackControllerWithP == (int32_T)
        SUBSYS_DISABLED) {
      /* Initial conditions for enable system: '<S2>/L1 Output Feedback Controller With  Projection Operator' */

      /* InitializeConditions for UnitDelay: '<S33>/UD' */
      controlMCUSlugsMKII_DWork.UD_DSTATE_l = 0.0F;

      /* Integer/Tapped Delay Block: '<S24>/Integer Delay'
       * Initialize State
       * Initial Condition parameter uses the same data type and scaling as Output0
       */
      controlMCUSlugsMKII_DWork.IntegerDelay_X_d = (0.0F);

      /* Integer/Tapped Delay Block: '<S24>/Integer Delay1'
       * Initialize State
       * Initial Condition parameter uses the same data type and scaling as Output0
       */
      controlMCUSlugsMKII_DWork.IntegerDelay1_X_nc = (0.0F);

      /* Integer/Tapped Delay Block: '<S26>/Integer Delay3'
       * Initialize State
       * Initial Condition parameter uses the same data type and scaling as Output0
       */
      controlMCUSlugsMKII_DWork.IntegerDelay3_X_cw = (0.0F);

      /* InitializeConditions for UnitDelay: '<S42>/UD' */
      controlMCUSlugsMKII_DWork.UD_DSTATE_ld = 0.0F;

      /* Integer/Tapped Delay Block: '<S28>/Integer Delay'
       * Initialize State
       * Initial Condition parameter uses the same data type and scaling as Output0
       */
      controlMCUSlugsMKII_DWork.IntegerDelay_X_c = (0.0F);

      /* Integer/Tapped Delay Block: '<S28>/Integer Delay1'
       * Initialize State
       * Initial Condition parameter uses the same data type and scaling as Output0
       */
      controlMCUSlugsMKII_DWork.IntegerDelay1_X_a = (0.0F);

      /* Integer/Tapped Delay Block: '<S13>/Integer Delay'
       * Initialize State
       * Initial Condition parameter uses the same data type and scaling as Output0
       */
      controlMCUSlugsMKII_DWork.IntegerDelay_X_no = (0.0F);

      /* Integer/Tapped Delay Block: '<S13>/Integer Delay1'
       * Initialize State
       * Initial Condition parameter uses the same data type and scaling as Output0
       */
      controlMCUSlugsMKII_DWork.IntegerDelay1_X_b = (0.0F);

      /* InitializeConditions for Merge: '<S25>/Merge' */
      if (rtmIsFirstInitCond(controlMCUSlugsMKII_M)) {
        controlMCUSlugsMKII_B.Merge = 0.0F;
      }

      /* Integer/Tapped Delay Block: '<S27>/Integer Delay3'
       * Initialize State
       * Initial Condition parameter uses the same data type and scaling as Output0
       */
      controlMCUSlugsMKII_DWork.IntegerDelay3_X_gww = (0.0F);

      /* Integer/Tapped Delay Block: '<S29>/Integer Delay'
       * Initialize State
       * Initial Condition parameter uses the same data type and scaling as Output0
       */
      controlMCUSlugsMKII_DWork.IntegerDelay_X_f = (0.0F);

      /* Integer/Tapped Delay Block: '<S29>/Integer Delay1'
       * Initialize State
       * Initial Condition parameter uses the same data type and scaling as Output0
       */
      controlMCUSlugsMKII_DWork.IntegerDelay1_X_ny[0] = (0.0F);
      controlMCUSlugsMKII_DWork.IntegerDelay1_X_ny[1] = (0.0F);

      /* Integer/Tapped Delay Block: '<S29>/Integer Delay2'
       * Initialize State
       * Initial Condition parameter uses the same data type and scaling as Output0
       */
      controlMCUSlugsMKII_DWork.IntegerDelay2_X_m = (0.0F);

      /* Integer/Tapped Delay Block: '<S43>/Integer Delay3'
       * Initialize State
       * Initial Condition parameter uses the same data type and scaling as Output0
       */
      controlMCUSlugsMKII_DWork.IntegerDelay3_X_oe = (0.0F);

      /* Integer/Tapped Delay Block: '<S44>/Integer Delay3'
       * Initialize State
       * Initial Condition parameter uses the same data type and scaling as Output0
       */
      controlMCUSlugsMKII_DWork.IntegerDelay3_X_oe1 = (0.0F);
      controlMCUSlugsMKII_DWork.L1OutputFeedbackControllerWithP = (int32_T)
        SUBSYS_ENABLED;
    }
  } else if (controlMCUSlugsMKII_DWork.L1OutputFeedbackControllerWithP ==
             (int32_T)SUBSYS_ENABLED) {
    controlMCUSlugsMKII_DWork.L1OutputFeedbackControllerWithP = (int32_T)
      SUBSYS_DISABLED;
  }

  if (controlMCUSlugsMKII_DWork.L1OutputFeedbackControllerWithP == (int32_T)
      SUBSYS_ENABLED) {
    /* Outputs for enable system: '<S2>/L1 Output Feedback Controller With  Projection Operator' */

    /* Sum: '<S33>/Diff' incorporates:
     *  UnitDelay: '<S33>/UD'
     */
    rtb_Saturation1_pt = controlMCUSlugsMKII_B.navSupportc_g[0] -
      controlMCUSlugsMKII_DWork.UD_DSTATE_l;

    /* Abs: '<S31>/Abs1' */
    rtb_Saturation1_pt = rt_ABS(rtb_Saturation1_pt);

    /* InitialCondition: '<S24>/IC' incorporates:
     *  Saturate: '<S31>/Saturation1'
     */
    if (controlMCUSlugsMKII_DWork.IC_FirstOutputTime_g) {
      controlMCUSlugsMKII_DWork.IC_FirstOutputTime_g = 0U;
      rtb_IC_n = 1.0F;
    } else {
      rtb_IC_n = rt_SATURATE(rtb_Saturation1_pt, 0.0F, 1.0F);
    }

    if (rtb_IC_n > 0.0F) {
      /* Output and update for enable system: '<S24>/Compute Coef' */

      /* Gain: '<S30>/-T' */
      controlMCUSlugsMKII_B.T_i = -9.999999776E-003F *
        controlMCUSlugsMKII_B.navSupportc_g[0];

      /* S-Function "dsPIC_C_function_Call" Block: <S32>/C Function Call */
      controlMCUSlugsMKII_B.CFunctionCall_p = myExp(controlMCUSlugsMKII_B.T_i);

      /* Sum: '<S30>/1-c' incorporates:
       *  Constant: '<S30>/Constant'
       */
      controlMCUSlugsMKII_B.c_kt = 1.0F - controlMCUSlugsMKII_B.CFunctionCall_p;
    }

    /* Product: '<S24>/Divide' incorporates:
     *  S-Function (sfix_udelay): '<S24>/Integer Delay'
     */
    rtb_Divide_p = controlMCUSlugsMKII_B.c_kt *
      (controlMCUSlugsMKII_DWork.IntegerDelay_X_d);

    /* Sum: '<S24>/Subtract' incorporates:
     *  Product: '<S24>/Divide1'
     *  S-Function (sfix_udelay): '<S24>/Integer Delay1'
     */
    rtb_Subtract_b = controlMCUSlugsMKII_B.CFunctionCall_p *
      (controlMCUSlugsMKII_DWork.IntegerDelay1_X_nc) + rtb_Divide_p;

    /* Switch: '<S26>/Switch3' incorporates:
     *  RelationalOperator: '<S26>/Relational Operator2'
     *  S-Function (sfix_udelay): '<S26>/Integer Delay3'
     */
    if (((uint8_T)(rtb_Switch3_oe == rtb_Switch3_oe)) > 0U) {
      rtb_Switch3_cj = rtb_Switch3_oe;
    } else {
      rtb_Switch3_cj = (controlMCUSlugsMKII_DWork.IntegerDelay3_X_cw);
    }

    /* Sum: '<S42>/Diff' incorporates:
     *  UnitDelay: '<S42>/UD'
     */
    rtb_psi_ad = controlMCUSlugsMKII_B.navSupportc_g[1] -
      controlMCUSlugsMKII_DWork.UD_DSTATE_ld;

    /* Abs: '<S40>/Abs1' */
    rtb_psi_ad = rt_ABS(rtb_psi_ad);

    /* InitialCondition: '<S28>/IC' incorporates:
     *  Saturate: '<S40>/Saturation1'
     */
    if (controlMCUSlugsMKII_DWork.IC_FirstOutputTime_p) {
      controlMCUSlugsMKII_DWork.IC_FirstOutputTime_p = 0U;
      rtb_IC_j = 1.0F;
    } else {
      rtb_IC_j = rt_SATURATE(rtb_psi_ad, 0.0F, 1.0F);
    }

    if (rtb_IC_j > 0.0F) {
      /* Output and update for enable system: '<S28>/Compute Coef' */

      /* Gain: '<S39>/-T' */
      controlMCUSlugsMKII_B.T = -9.999999776E-003F *
        controlMCUSlugsMKII_B.navSupportc_g[1];

      /* S-Function "dsPIC_C_function_Call" Block: <S41>/C Function Call */
      controlMCUSlugsMKII_B.CFunctionCall_dr = myExp(controlMCUSlugsMKII_B.T);

      /* Sum: '<S39>/1-c' incorporates:
       *  Constant: '<S39>/Constant'
       */
      controlMCUSlugsMKII_B.c_i = 1.0F - controlMCUSlugsMKII_B.CFunctionCall_dr;
    }

    /* Product: '<S28>/Divide' incorporates:
     *  S-Function (sfix_udelay): '<S28>/Integer Delay'
     */
    rtb_Divide_f4 = controlMCUSlugsMKII_B.c_i *
      (controlMCUSlugsMKII_DWork.IntegerDelay_X_c);

    /* Sum: '<S28>/Subtract' incorporates:
     *  Product: '<S28>/Divide1'
     *  S-Function (sfix_udelay): '<S28>/Integer Delay1'
     */
    rtb_Subtract_c = controlMCUSlugsMKII_B.CFunctionCall_dr *
      (controlMCUSlugsMKII_DWork.IntegerDelay1_X_a) + rtb_Divide_f4;

    /* Gain: '<S13>/Gain' incorporates:
     *  Sum: '<S13>/Sum3'
     */
    rtb_Gain_ey = (rtb_Subtract_c - rtb_Switch3_cj) * -1.0F;

    /* Logic: '<S13>/Logical Operator' */
    rtb_LogicalOperator = (uint8_T)!(controlMCUSlugsMKII_B.navSupportc_g[2] !=
      0.0F);

    /* Product: '<S38>/Divide4' incorporates:
     *  Constant: '<S38>/Constant'
     *  S-Function (sfix_udelay): '<S13>/Integer Delay1'
     */
    rtb_Divide4_a = 1.0F / controlMCUSlugsMKII_ConstB.Divide2 *
      (controlMCUSlugsMKII_DWork.IntegerDelay1_X_b) * 2.0F;

    /* Product: '<S38>/Divide3' incorporates:
     *  Product: '<S38>/Divide'
     *  S-Function (sfix_udelay): '<S13>/Integer Delay1'
     *  Sum: '<S38>/Subtract'
     */
    rtb_Divide3 = ((controlMCUSlugsMKII_DWork.IntegerDelay1_X_b) *
                   (controlMCUSlugsMKII_DWork.IntegerDelay1_X_b) -
                   controlMCUSlugsMKII_ConstB.Divide1) /
      controlMCUSlugsMKII_ConstB.Divide2;

    /* Logic: '<S25>/Logical Operator2' incorporates:
     *  Product: '<S25>/Divide2'
     *  RelationalOperator: '<S34>/Compare'
     *  RelationalOperator: '<S35>/Compare'
     */
    rtb_LogicalOperator2 = ((rtb_Divide4_a * rtb_Gain_ey > 0.0F) && (rtb_Divide3
      >= 0.0F));

    /* Outputs for enable SubSystem: '<S25>/Enabled Subsystem' incorporates:
     *  Logic: '<S25>/Logical Operator'
     */
    if ((uint8_T)!(rtb_LogicalOperator2 != 0U) > 0U) {
      /* Inport: '<S36>/In1' */
      controlMCUSlugsMKII_B.Merge = rtb_Gain_ey;
    }

    /* end of Outputs for SubSystem: '<S25>/Enabled Subsystem' */

    /* Outputs for enable SubSystem: '<S25>/Enabled Subsystem1' */
    if (rtb_LogicalOperator2 > 0U) {
      /* Product: '<S37>/Divide2' incorporates:
       *  Constant: '<S37>/Constant'
       *  Product: '<S37>/Divide1'
       *  Signum: '<S37>/Sign'
       *  Sum: '<S37>/Subtract'
       */
      controlMCUSlugsMKII_B.Merge = (1.0F - rtb_Divide3 * rt_FSGN(rtb_Divide4_a))
        * rtb_Gain_ey;
    }

    /* end of Outputs for SubSystem: '<S25>/Enabled Subsystem1' */

    /* Product: '<S13>/Projection' */
    rtb_Projection = controlMCUSlugsMKII_B.navSupportc_n[1] *
      controlMCUSlugsMKII_B.Merge;

    /* Sum: '<S13>/Sum4' incorporates:
     *  S-Function (sfix_udelay): '<S13>/Integer Delay'
     */
    rtb_psi_ad = (controlMCUSlugsMKII_DWork.IntegerDelay_X_no) - rtb_Subtract_b;

    /* Saturate: '<S13>/Psi Dot  Limit' */
    controlMCUSlugsMKII_B.PsiDotLimit = rt_SATURATE(rtb_psi_ad, -1.0F, 1.0F);

    /* Sum: '<S13>/Sum2' incorporates:
     *  S-Function (sfix_udelay): '<S13>/Integer Delay1'
     */
    rtb_psi_ad = controlMCUSlugsMKII_B.PsiDotLimit +
      (controlMCUSlugsMKII_DWork.IntegerDelay1_X_b);

    /* Switch: '<S27>/Switch3' incorporates:
     *  RelationalOperator: '<S27>/Relational Operator2'
     *  S-Function (sfix_udelay): '<S27>/Integer Delay3'
     */
    if ((rtb_psi_ad == rtb_psi_ad) > 0U) {
      rtb_Switch3_ae = rtb_psi_ad;
    } else {
      rtb_Switch3_ae = (controlMCUSlugsMKII_DWork.IntegerDelay3_X_gww);
    }

    /* S-Function (sfix_udelay): '<S29>/Integer Delay1'
     *
     * Regarding '<S29>/Integer Delay1':
     * Integer/Tapped Delay Block: '<S29>/Integer Delay1'
     */
    rtb_IntegerDelay1_ov = controlMCUSlugsMKII_DWork.IntegerDelay1_X_ny[0];

    /* Switch: '<S43>/Switch3' incorporates:
     *  RelationalOperator: '<S43>/Relational Operator2'
     *  S-Function (sfix_udelay): '<S43>/Integer Delay3'
     */
    if (((uint8_T)(rtb_Projection == rtb_Projection)) > 0U) {
      rtb_Switch3_gq = rtb_Projection;
    } else {
      rtb_Switch3_gq = (controlMCUSlugsMKII_DWork.IntegerDelay3_X_oe);
    }

    /* Sum: '<S29>/Subtract1' incorporates:
     *  Constant: '<S29>/Constant'
     *  Constant: '<S29>/Constant1'
     *  Constant: '<S29>/Constant2'
     *  Constant: '<S29>/Constant3'
     *  Product: '<S29>/Product'
     *  Product: '<S29>/Product1'
     *  Product: '<S29>/Product2'
     *  Product: '<S29>/Product3'
     *  S-Function (sfix_udelay): '<S29>/Integer Delay'
     *  S-Function (sfix_udelay): '<S29>/Integer Delay2'
     *  Sum: '<S29>/Subtract'
     */
    rtb_Subtract1_d = (controlMCUSlugsMKII_DWork.IntegerDelay2_X_m) +
      (((rtb_Switch3_gq * 0.3333333433F +
         (controlMCUSlugsMKII_DWork.IntegerDelay_X_f) * 1.333333373F) +
        rtb_IntegerDelay1_ov * 0.3333333433F) * 0.004999999888F);

    /* Switch: '<S29>/Switch1' incorporates:
     *  Constant: '<S29>/Constant5'
     *  Saturate: '<S29>/[min max]'
     */
    if (rtb_LogicalOperator > 0U) {
      rtb_Subtract1_d = 0.0F;
    } else {
      rtb_Subtract1_d = rt_SATURATE(rtb_Subtract1_d, -2.0F, 2.0F);
    }

    /* Switch: '<S44>/Switch3' incorporates:
     *  RelationalOperator: '<S44>/Relational Operator2'
     *  S-Function (sfix_udelay): '<S44>/Integer Delay3'
     */
    if ((rtb_Subtract1_d == rtb_Subtract1_d) > 0U) {
      rtb_Switch3_im = rtb_Subtract1_d;
    } else {
      rtb_Switch3_im = (controlMCUSlugsMKII_DWork.IntegerDelay3_X_oe1);
    }
  }

  /* S-Function "dsPIC_C_function_Call" Block: <S9>/Get the Accelerometers [navSupport.c] */
  getAccels(&controlMCUSlugsMKII_B.GettheAccelerometersnavSupportc[0]);

  {
    static const int_T dims[3] = { 3, 3, 1 };

    rt_MatMultRR_Sgl(rtb_Product2_cp, rtb_MathFunction,
                     controlMCUSlugsMKII_B.GettheAccelerometersnavSupportc,
                     &dims[0]);
  }

  /* S-Function "dsPIC_C_function_Call" Block: <S9>/Get the Accel Bias [navSupport.c] */
  getAccBias(&controlMCUSlugsMKII_B.GettheAccelBiasnavSupportc[0]);

  {
    static const int_T dims[3] = { 3, 3, 1 };

    rt_MatMultRR_Sgl(rtb_Product3_ep, rtb_MathFunction,
                     controlMCUSlugsMKII_B.GettheAccelBiasnavSupportc, &dims[0]);
  }

  /* Sum: '<S9>/Sum' */
  rtb_Sum_l[0] = rtb_Product2_cp[0] + rtb_Product3_ep[0];
  rtb_Sum_l[1] = rtb_Product2_cp[1] + rtb_Product3_ep[1];
  rtb_Sum_l[2] = rtb_Product2_cp[2] + rtb_Product3_ep[2];

  /* Output and update for atomic system: '<S2>/Lateral Channel' */

  /* S-Function (sfix_udelay): '<S62>/Integer Delay3'
   *
   * Regarding '<S62>/Integer Delay3':
   * Integer/Tapped Delay Block: '<S62>/Integer Delay3'
   */
  rtb_IntegerDelay3_j = controlMCUSlugsMKII_DWork.IntegerDelay3_X_nc;

  /* Switch: '<S62>/Switch3' incorporates:
   *  RelationalOperator: '<S62>/Relational Operator2'
   */
  if (((uint8_T)(rtb_Switch3_c == rtb_Switch3_c)) > 0U) {
    rtb_Switch3_gn = rtb_Switch3_c;
  } else {
    rtb_Switch3_gn = rtb_IntegerDelay3_j;
  }

  /* Saturate: '<S49>/bank Limit' */
  controlMCUSlugsMKII_B.bankLimit = rt_SATURATE(rtb_Switch3_gn,
    -7.853981853E-001F, 7.853981853E-001F);

  /* S-Function "dsPIC_C_function_Call" Block: <S64>/C Function Call */
  controlMCUSlugsMKII_B.CFunctionCall_in = myTan(controlMCUSlugsMKII_B.bankLimit);

  /* S-Function (sfix_udelay): '<S63>/Integer Delay3'
   *
   * Regarding '<S63>/Integer Delay3':
   * Integer/Tapped Delay Block: '<S63>/Integer Delay3'
   */
  rtb_IntegerDelay3_j = controlMCUSlugsMKII_DWork.IntegerDelay3_X_gw;

  /* Switch: '<S63>/Switch3' incorporates:
   *  RelationalOperator: '<S63>/Relational Operator2'
   */
  if (((uint8_T)(rtb_ScheduleLPF == rtb_ScheduleLPF)) > 0U) {
    rtb_Switch3_h4 = rtb_ScheduleLPF;
  } else {
    rtb_Switch3_h4 = rtb_IntegerDelay3_j;
  }

  /* Switch: '<S14>/Switch1' incorporates:
   *  Constant: '<S49>/Constant1'
   *  Product: '<S49>/Divide'
   *  Product: '<S49>/Divide1'
   *  Saturate: '<S49>/[0 40]'
   */
  if (controlMCUSlugsMKII_B.wpFlynavSupportc > 0U) {
    rtb_IntegerDelay3_p = 1.0F / rt_SATURATE(rtb_Switch3_h4, 0.0F, 40.0F) *
      9.806650162E+000F * controlMCUSlugsMKII_B.CFunctionCall_in;
  } else {
    rtb_IntegerDelay3_p = controlMCUSlugsMKII_B.GetMidLevelCommandsnavSupportc[2];
  }

  /* Saturate: '<S14>/Psi Dot  Limit' */
  rtb_PsiDotLimit = rt_SATURATE(rtb_IntegerDelay3_p, -1.0F, 1.0F);

  /* Switch: '<S14>/Switch' */
  if (controlMCUSlugsMKII_B.navSupportc_g[2] > 3.000000119E-001F) {
    rtb_Switch = controlMCUSlugsMKII_B.PsiDotLimit;
  } else {
    rtb_Switch = rtb_PsiDotLimit;
  }

  if (controlMCUSlugsMKII_B.navSupportc_n[2] > 0.0F) {
    if (controlMCUSlugsMKII_DWork.SideslipCompensation_MODE == (int32_T)
        SUBSYS_DISABLED) {
      /* Initial conditions for enable system: '<S14>/Sideslip Compensation' */

      /* InitializeConditions for UnitDelay: '<S79>/UD' */
      controlMCUSlugsMKII_DWork.UD_DSTATE_o = 0.0F;

      /* Integer/Tapped Delay Block: '<S71>/Integer Delay'
       * Initialize State
       * Initial Condition parameter uses the same data type and scaling as Output0
       */
      controlMCUSlugsMKII_DWork.IntegerDelay_X_b = (0.0F);

      /* Integer/Tapped Delay Block: '<S71>/Integer Delay1'
       * Initialize State
       * Initial Condition parameter uses the same data type and scaling as Output0
       */
      controlMCUSlugsMKII_DWork.IntegerDelay1_X_f5 = (0.0);

      /* Integer/Tapped Delay Block: '<S72>/Integer Delay3'
       * Initialize State
       * Initial Condition parameter uses the same data type and scaling as Output0
       */
      controlMCUSlugsMKII_DWork.IntegerDelay3_X_hc = (0.0F);
      controlMCUSlugsMKII_DWork.SideslipCompensation_MODE = (int32_T)
        SUBSYS_ENABLED;
    }
  } else if (controlMCUSlugsMKII_DWork.SideslipCompensation_MODE == (int32_T)
             SUBSYS_ENABLED) {
    /* Disable for enable system: '<S14>/Sideslip Compensation' */

    /* (Virtual) Outport Block: '<S56>/bankComp' */
    controlMCUSlugsMKII_B.Subtract = 0.0;
    controlMCUSlugsMKII_DWork.SideslipCompensation_MODE = (int32_T)
      SUBSYS_DISABLED;
  }

  if (controlMCUSlugsMKII_DWork.SideslipCompensation_MODE == (int32_T)
      SUBSYS_ENABLED) {
    /* Output and update for enable system: '<S14>/Sideslip Compensation' */

    /* Stateflow: '<S70>/negprotect' */
    controlMCUSlugsM_negprotect(rtb_ScheduleLPF,
      &controlMCUSlugsMKII_B.sf_negprotect);

    /* Product: '<S70>/Divide' incorporates:
     *  Constant: '<S70>/Constant1'
     */
    rtb_Divide_l = 1.0F / controlMCUSlugsMKII_B.sf_negprotect.zpVal *
      9.806650162F;

    /* Saturate: '<S70>/bank Limit' */
    controlMCUSlugsMKII_B.bankLimit_a = rt_SATURATE(controlMCUSlugsMKII_B.y_n[0],
      -7.853981853E-001F, 7.853981853E-001F);

    /* S-Function "dsPIC_C_function_Call" Block: <S74>/C Function Call */
    controlMCUSlugsMKII_B.CFunctionCall_gd = myTan
      (controlMCUSlugsMKII_B.bankLimit_a);

    /* Product: '<S70>/Divide1' */
    rtb_Divide1_a = controlMCUSlugsMKII_B.CFunctionCall_gd * rtb_Divide_l;

    /* Sum: '<S79>/Diff' incorporates:
     *  Constant: '<S56>/Constant'
     *  UnitDelay: '<S79>/UD'
     */
    rtb_Diff = 3.000000119E-001F - controlMCUSlugsMKII_DWork.UD_DSTATE_o;

    /* Abs: '<S78>/Abs1' */
    rtb_Diff = rt_ABS(rtb_Diff);

    /* InitialCondition: '<S71>/IC' incorporates:
     *  Saturate: '<S78>/Saturation1'
     */
    if (controlMCUSlugsMKII_DWork.IC_FirstOutputTime_e) {
      controlMCUSlugsMKII_DWork.IC_FirstOutputTime_e = 0U;
      rtb_Diff = 1.0F;
    } else {
      rtb_Diff = rt_SATURATE(rtb_Diff, 0.0F, 1.0F);
    }

    /* Outputs for enable SubSystem: '<S71>/Compute Coef' */
    if (rtb_Diff > 0.0F) {
      /* Math: '<S77>/Math Function' incorporates:
       *  Constant: '<S56>/Constant'
       *  Gain: '<S77>/-T'
       */
      controlMCUSlugsMKII_B.c = (real32_T)exp(-3.000000026E-003F);

      /* Sum: '<S77>/1-c' incorporates:
       *  Constant: '<S77>/Constant'
       */
      controlMCUSlugsMKII_B.c_k = 1.0F - controlMCUSlugsMKII_B.c;
    }

    /* end of Outputs for SubSystem: '<S71>/Compute Coef' */

    /* Product: '<S71>/Divide' incorporates:
     *  S-Function (sfix_udelay): '<S71>/Integer Delay'
     */
    rtb_Divide_cm = controlMCUSlugsMKII_B.c_k *
      (controlMCUSlugsMKII_DWork.IntegerDelay_X_b);

    /* S-Function (sfix_udelay): '<S71>/Integer Delay1'
     *
     * Regarding '<S71>/Integer Delay1':
     * Integer/Tapped Delay Block: '<S71>/Integer Delay1'
     */
    rtb_IntegerDelay1_c = controlMCUSlugsMKII_DWork.IntegerDelay1_X_f5;

    /* Sum: '<S71>/Subtract' incorporates:
     *  Product: '<S71>/Divide1'
     */
    controlMCUSlugsMKII_B.Subtract = (real_T)controlMCUSlugsMKII_B.c *
      rtb_IntegerDelay1_c + (real_T)rtb_Divide_cm;

    /* Product: '<S73>/Divide' incorporates:
     *  Constant: '<S73>/Constant1'
     *  Sum: '<S56>/Subtract'
     */
    controlMCUSlugsMKII_B.Divide_a = (rtb_Divide1_a - controlMCUSlugsMKII_B.y_n
      [5]) * rtb_ScheduleLPF / 9.806650162E+000F;

    /* S-Function "dsPIC_C_function_Call" Block: <S80>/C Function Call */
    controlMCUSlugsMKII_B.CFunctionCall_id = myAtan
      (controlMCUSlugsMKII_B.Divide_a);

    /* Switch: '<S72>/Switch3' incorporates:
     *  RelationalOperator: '<S72>/Relational Operator2'
     *  S-Function (sfix_udelay): '<S72>/Integer Delay3'
     */
    if ((controlMCUSlugsMKII_B.CFunctionCall_id ==
         controlMCUSlugsMKII_B.CFunctionCall_id) > 0U) {
      rtb_Switch3_pq = controlMCUSlugsMKII_B.CFunctionCall_id;
    } else {
      rtb_Switch3_pq = (controlMCUSlugsMKII_DWork.IntegerDelay3_X_hc);
    }

    /* Update for UnitDelay: '<S79>/UD' incorporates:
     *  Constant: '<S56>/Constant'
     */
    controlMCUSlugsMKII_DWork.UD_DSTATE_o = 3.000000119E-001F;

    /* Integer/Tapped Delay Block: '<S71>/Integer Delay'
     */
    controlMCUSlugsMKII_DWork.IntegerDelay_X_b = rtb_Switch3_pq;

    /* Integer/Tapped Delay Block: '<S71>/Integer Delay1'
     */
    controlMCUSlugsMKII_DWork.IntegerDelay1_X_f5 =
      controlMCUSlugsMKII_B.Subtract;

    /* Integer/Tapped Delay Block: '<S72>/Integer Delay3'
     */
    controlMCUSlugsMKII_DWork.IntegerDelay3_X_hc = rtb_Switch3_pq;
  }

  /* Product: '<S60>/Divide' incorporates:
   *  Constant: '<S60>/Constant1'
   */
  controlMCUSlugsMKII_B.Divide_m = rtb_Switch * rtb_ScheduleLPF /
    9.806650162E+000F;

  /* S-Function "dsPIC_C_function_Call" Block: <S86>/C Function Call */
  controlMCUSlugsMKII_B.CFunctionCall_i4 = myAtan(controlMCUSlugsMKII_B.Divide_m);

  /* Sum: '<S14>/Add2' */
  rtb_IntegerDelay3_p = (real32_T)controlMCUSlugsMKII_B.Subtract +
    controlMCUSlugsMKII_B.CFunctionCall_i4;

  /* Saturate: '<S14>/Bank  Limit Command' */
  rtb_BankLimitCommand = rt_SATURATE(rtb_IntegerDelay3_p, -7.853981853E-001F,
    7.853981853E-001F);

  /* S-Function (sfix_udelay): '<S53>/Integer Delay3'
   *
   * Regarding '<S53>/Integer Delay3':
   * Integer/Tapped Delay Block: '<S53>/Integer Delay3'
   */
  rtb_IntegerDelay3_p = controlMCUSlugsMKII_DWork.IntegerDelay3_X_h;

  /* Switch: '<S53>/Switch3' incorporates:
   *  RelationalOperator: '<S53>/Relational Operator2'
   */
  if (((uint8_T)(rtb_Sum_l[1] == rtb_Sum_l[1])) > 0U) {
    rtb_Switch3_pa = rtb_Sum_l[1];
  } else {
    rtb_Switch3_pa = rtb_IntegerDelay3_p;
  }

  /* Saturate: '<S14>/[-20 20]' */
  rtb_u020_g = rt_SATURATE(rtb_Switch3_pa, -20.0F, 20.0F);

  /* Embedded MATLAB: '<S45>/Embedded MATLAB Function' incorporates:
   *  Constant: '<S45>/Constant1'
   *  Constant: '<S45>/Constant'
   */
  {
    real_T eml_omega;

    /*  This block supports an embeddable subset of the MATLAB language. */
    /*  See the help menu for details.  */
    if (!controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction.a_not_empty) {
      /* tf = [T*omega/(2+T*omega) T*omega/(2+T*omega)],[1 (T*omega-2)/(T*omega+2)] */
      /* tf = [a a],[1 -b] */
      eml_omega = 6.2831853071795862E+000 * (0.3183);
      controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction.a = 0.01 * eml_omega /
        (2.0 + 0.01 * eml_omega);
      controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction.a_not_empty = true;
      controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction.b = (-(0.01 * eml_omega -
        2.0)) / (0.01 * eml_omega + 2.0);
      controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction.y_km1 = rtb_u020_g;
      controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction.u_km1 = rtb_u020_g;
    }

    rtb_y_m = (real32_T)controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction.a *
      (rtb_u020_g + controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction.u_km1) +
      (real32_T)controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction.b *
      controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction.y_km1;
    controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction.y_km1 = rtb_y_m;
    controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction.u_km1 = rtb_u020_g;
  }

  /* S-Function "dsPIC_C_function_Call" Block: <S14>/[navSupport.c]    */
  getPidIdx(((uint8_T)9U),&controlMCUSlugsMKII_B.navSupportc_l[0]);

  /* RelationalOperator: '<S54>/Relational Operator2' */
  rtb_RelationalOperator2_j4 = (controlMCUSlugsMKII_B.y_n[5] ==
    controlMCUSlugsMKII_B.y_n[5]);

  /* S-Function (sfix_udelay): '<S54>/Integer Delay3'
   *
   * Regarding '<S54>/Integer Delay3':
   * Integer/Tapped Delay Block: '<S54>/Integer Delay3'
   */
  rtb_IntegerDelay3_p = controlMCUSlugsMKII_DWork.IntegerDelay3_X_ae;

  /* Switch: '<S54>/Switch3' */
  if (rtb_RelationalOperator2_j4 > 0U) {
    rtb_Switch3_fx = controlMCUSlugsMKII_B.y_n[5];
  } else {
    rtb_Switch3_fx = rtb_IntegerDelay3_p;
  }

  /* Saturate: '<S14>/[-2 2]' */
  rtb_u2 = rt_SATURATE(rtb_Switch3_fx, -2.0F, 2.0F);

  /* Output and update for atomic system: '<S14>/High Pass (Washout) Filter' */

  /* S-Function (sfix_udelay): '<S50>/Integer Delay'
   *
   * Regarding '<S50>/Integer Delay':
   * Integer/Tapped Delay Block: '<S50>/Integer Delay'
   */
  rtb_IntegerDelay_k = controlMCUSlugsMKII_DWork.IntegerDelay_X_nm;

  /* S-Function (sfix_udelay): '<S50>/Integer Delay1'
   *
   * Regarding '<S50>/Integer Delay1':
   * Integer/Tapped Delay Block: '<S50>/Integer Delay1'
   */
  rtb_IntegerDelay1_a = controlMCUSlugsMKII_DWork.IntegerDelay1_X_l;

  /* Sum: '<S50>/Subtract' incorporates:
   *  Constant: '<S50>/Constant1'
   *  Constant: '<S50>/Constant2'
   *  Constant: '<S50>/Constant3'
   *  Product: '<S50>/Product'
   *  Product: '<S50>/Product1'
   *  Product: '<S50>/Product2'
   */
  rtb_Subtract_a = (0.9991999865F * rtb_u2 - rtb_IntegerDelay_k * 0.9991999865F)
    + rtb_IntegerDelay1_a * 0.9983000159F;

  /* Saturate: '<S50>/[-2 2]' */
  rtb_u2_o = rt_SATURATE(rtb_Subtract_a, -2.0F, 2.0F);

  /* Integer/Tapped Delay Block: '<S50>/Integer Delay'
   */
  controlMCUSlugsMKII_DWork.IntegerDelay_X_nm = rtb_u2;

  /* Integer/Tapped Delay Block: '<S50>/Integer Delay1'
   */
  controlMCUSlugsMKII_DWork.IntegerDelay1_X_l = rtb_u2_o;

  /* Switch: '<S14>/Switch2' incorporates:
   *  Gain: '<S14>/Neg Feedback '
   *  Gain: '<S14>/Neg Feedback'
   */
  if (controlMCUSlugsMKII_B.navSupportc_l[0] > 3.000000119E-001F) {
    rtb_Switch2 = -1.0F * rtb_y_m;
  } else {
    rtb_Switch2 = -1.0F * rtb_u2_o;
  }

  /* S-Function (sfix_udelay): '<S52>/Integer Delay3'
   *
   * Regarding '<S52>/Integer Delay3':
   * Integer/Tapped Delay Block: '<S52>/Integer Delay3'
   */
  rtb_IntegerDelay3_p = controlMCUSlugsMKII_DWork.IntegerDelay3_X_b5;

  /* Switch: '<S52>/Switch3' incorporates:
   *  RelationalOperator: '<S52>/Relational Operator2'
   */
  if (((uint8_T)(rtb_Switch2 == rtb_Switch2)) > 0U) {
    rtb_Switch3_my = rtb_Switch2;
  } else {
    rtb_Switch3_my = rtb_IntegerDelay3_p;
  }

  /* Stateflow: '<S14>/myMux Fun1' */
  controlMCUSlugsMK_myMuxFun1(rtb_Switch, rtb_BankLimitCommand, rtb_Switch3_my,
    &controlMCUSlugsMKII_B.sf_myMuxFun1_h);

  /* S-Function "dsPIC_C_function_Call" Block: <S14>/Get XYZ [navSupport.c] */
  setNavLat(controlMCUSlugsMKII_B.sf_myMuxFun1_h.y);

  /* Sum: '<S57>/Add4' incorporates:
   *  Constant: '<S57>/SaturationLimit1'
   */
  rtb_Add4_m = -1.745329201E-001F - controlMCUSlugsMKII_B.DataTypeConversion_b;

  /* Product: '<S57>/Product1' */
  rtb_Product1_p = rtb_Switch3_my *
    controlMCUSlugsMKII_B.GetPidaccordingtoIndex3[0];

  /* S-Function (sfix_udelay): '<S57>/NDelays'
   *
   * Regarding '<S57>/NDelays':
   * Integer/Tapped Delay Block: '<S57>/NDelays'
   */
  rtb_NDelays_no = controlMCUSlugsMKII_DWork.NDelays_X_e[0];

  /* Sum: '<S57>/Add1' incorporates:
   *  Constant: '<S57>/delayTime'
   *  Product: '<S57>/Product2'
   *  Product: '<S57>/Product3'
   *  Sum: '<S57>/Sum'
   */
  rtb_IntegerDelay3_p = (rtb_Switch3_my - rtb_NDelays_no) / 5.000000075E-002F *
    controlMCUSlugsMKII_B.GetPidaccordingtoIndex3[2] + rtb_Product1_p;

  /* S-Function (sfix_udelay): '<S83>/Integer Delay2'
   *
   * Regarding '<S83>/Integer Delay2':
   * Integer/Tapped Delay Block: '<S83>/Integer Delay2'
   */
  rtb_IntegerDelay2_ih = controlMCUSlugsMKII_DWork.IntegerDelay2_X_g;

  /* Sum: '<S57>/Sum2' incorporates:
   *  Gain: '<S57>/Gain'
   *  Memory: '<S57>/Memory1'
   *  Product: '<S57>/Product4'
   */
  rtb_Sum2_c = (9.999999776E-003F * rtb_Switch3_my *
                controlMCUSlugsMKII_B.GetPidaccordingtoIndex3[1] +
                controlMCUSlugsMKII_DWork.Memory1_PreviousInput_a) +
    rtb_IntegerDelay3_p;

  /* Sum: '<S57>/Add3' incorporates:
   *  Constant: '<S57>/SaturationLimit'
   */
  rtb_Add3_k = 1.745329201E-001F - controlMCUSlugsMKII_B.DataTypeConversion_b;

  /* Switch: '<S57>/AntiWindup' incorporates:
   *  Constant: '<S57>/Constant5'
   *  Logic: '<S57>/Logical Operator'
   *  RelationalOperator: '<S57>/Relational Operator'
   *  RelationalOperator: '<S57>/Relational Operator1'
   */
  if ((rtb_Sum2_c > rtb_Add4_m) && (rtb_Sum2_c < rtb_Add3_k)) {
    rtb_AntiWindup_k = (real_T)rtb_Switch3_my;
  } else {
    rtb_AntiWindup_k = 0.0;
  }

  /* S-Function (sfix_udelay): '<S84>/Integer Delay3'
   *
   * Regarding '<S84>/Integer Delay3':
   * Integer/Tapped Delay Block: '<S84>/Integer Delay3'
   */
  rtb_IntegerDelay3_l = controlMCUSlugsMKII_DWork.IntegerDelay3_X_o;

  /* Switch: '<S84>/Switch3' incorporates:
   *  RelationalOperator: '<S84>/Relational Operator2'
   */
  if (((uint8_T)(rtb_AntiWindup_k == rtb_AntiWindup_k)) > 0U) {
    rtb_Switch3_g = rtb_AntiWindup_k;
  } else {
    rtb_Switch3_g = rtb_IntegerDelay3_l;
  }

  /* S-Function (sfix_udelay): '<S83>/Integer Delay'
   *
   * Regarding '<S83>/Integer Delay':
   * Integer/Tapped Delay Block: '<S83>/Integer Delay'
   */
  rtb_IntegerDelay_b = controlMCUSlugsMKII_DWork.IntegerDelay_X_i0;

  /* S-Function (sfix_udelay): '<S83>/Integer Delay1'
   *
   * Regarding '<S83>/Integer Delay1':
   * Integer/Tapped Delay Block: '<S83>/Integer Delay1'
   */
  rtb_IntegerDelay1_o = controlMCUSlugsMKII_DWork.IntegerDelay1_X_f[0];

  /* Switch: '<S83>/Switch1' incorporates:
   *  Constant: '<S83>/Constant'
   *  Constant: '<S83>/Constant1'
   *  Constant: '<S83>/Constant2'
   *  Constant: '<S83>/Constant3'
   *  Constant: '<S83>/Constant5'
   *  Product: '<S83>/Product'
   *  Product: '<S83>/Product1'
   *  Product: '<S83>/Product2'
   *  Product: '<S83>/Product3'
   *  Sum: '<S83>/Subtract'
   *  Sum: '<S83>/Subtract1'
   */
  if (controlMCUSlugsMKII_B.ManualorAutonavSupportc > 0U) {
    rtb_Switch1_i = 0.0F;
  } else {
    rtb_Switch1_i = (((real32_T)(rtb_Switch3_g * (real_T)0.3333333433F) +
                      (real32_T)(rtb_IntegerDelay_b * (real_T)1.333333373F)) +
                     (real32_T)(rtb_IntegerDelay1_o * 3.3333334326744080E-001)) *
      0.004999999888F + rtb_IntegerDelay2_ih;
  }

  /* RelationalOperator: '<S85>/Relational Operator2' */
  rtb_RelationalOperator2_m3 = (rtb_Switch1_i == rtb_Switch1_i);

  /* S-Function (sfix_udelay): '<S85>/Integer Delay3'
   *
   * Regarding '<S85>/Integer Delay3':
   * Integer/Tapped Delay Block: '<S85>/Integer Delay3'
   */
  rtb_IntegerDelay3_j = controlMCUSlugsMKII_DWork.IntegerDelay3_X_cn;

  {
    real_T tmp;

    /* Switch: '<S85>/Switch3' incorporates:
     *  RelationalOperator: '<S85>/Relational Operator2'
     */
    if (rtb_RelationalOperator2_m3 > 0U) {
      rtb_Switch3_pf = rtb_Switch1_i;
    } else {
      rtb_Switch3_pf = rtb_IntegerDelay3_j;
    }

    /* Sum: '<S57>/Add2' incorporates:
     *  Product: '<S57>/Product'
     */
    rtb_Add2_af = rtb_Switch3_pf * controlMCUSlugsMKII_B.GetPidaccordingtoIndex3
      [1] + rtb_IntegerDelay3_p;

    /* Switch: '<S14>/Switch3' incorporates:
     *  Gain: '<S46>/Unit Conversion'
     *  MinMax: '<S82>/Enforce upper limit'
     *  Sum: '<S14>/Add'
     */
    if (controlMCUSlugsMKII_B.navSupportc_l[1] > 3.000000119E-001F) {
      rtb_Add1_b = 1.745329238E-002F * controlMCUSlugsMKII_B.navSupportc_l[2];
    } else {
      /* MinMax: '<S82>/Enforce lower limit' */
      rtb_Add1_b = rt_MAX(rtb_Add4_m, rtb_Add2_af);
      rtb_Add1_b = rt_MIN(rtb_Add1_b, rtb_Add3_k) +
        controlMCUSlugsMKII_B.DataTypeConversion_b;
    }

    /* Saturate: '<S14>/Rudder Limit' */
    rtb_RudderLimit = rt_SATURATE(rtb_Add1_b, -1.745329201E-001F,
      1.745329201E-001F);

    /* Gain: '<S48>/Unit Conversion' */
    rtb_UnitConversion_a = 5.729578018E+001F * rtb_RudderLimit;

    /* Gain: '<S47>/Unit Conversion' */
    rtb_UnitConversion = 5.7295779513082323E+001 *
      controlMCUSlugsMKII_B.Subtract;

    /* Embedded MATLAB: '<S14>/myMux Fun3' */

    /*  This block supports an embeddable subset of the MATLAB language. */
    /*  See the help menu for details.  */
    rtb_y_om[0] = rtb_UnitConversion_a;
    rtb_y_om[1] = controlMCUSlugsMKII_B.navSupportc_l[1];
    rtb_y_om[2] = (real32_T)rtb_UnitConversion;

    /* DataTypeConversion: '<S14>/Data Type Conversion2' incorporates:
     *  Gain: '<S14>/Gain3'
     */
    tmp = fmod(floor((real_T)(100.0F * rtb_y_om[0])), 65536.0);
    if (tmp < -32768.0) {
      tmp += 65536.0;
    } else if (tmp >= 32768.0) {
      tmp -= 65536.0;
    }

    controlMCUSlugsMKII_B.DataTypeConversion2[0] = (int16_T)tmp;
    tmp = fmod(floor((real_T)(100.0F * rtb_y_om[1])), 65536.0);
    if (tmp < -32768.0) {
      tmp += 65536.0;
    } else if (tmp >= 32768.0) {
      tmp -= 65536.0;
    }

    controlMCUSlugsMKII_B.DataTypeConversion2[1] = (int16_T)tmp;
    tmp = fmod(floor((real_T)(100.0F * rtb_y_om[2])), 65536.0);
    if (tmp < -32768.0) {
      tmp += 65536.0;
    } else if (tmp >= 32768.0) {
      tmp -= 65536.0;
    }

    controlMCUSlugsMKII_B.DataTypeConversion2[2] = (int16_T)tmp;
  }

  /* S-Function "dsPIC_C_function_Call" Block: <S14>/Get XYZ [navSupport.c]2 */
  setDiagnosticShort(controlMCUSlugsMKII_B.DataTypeConversion2);

  /* Sum: '<S14>/Add1' */
  rtb_Add1_j = rtb_BankLimitCommand - controlMCUSlugsMKII_B.y_n[0];

  /* Sum: '<S55>/Add4' incorporates:
   *  Constant: '<S55>/SaturationLimit1'
   */
  rtb_Add4_p = -2.792526782E-001F - controlMCUSlugsMKII_B.DataTypeConversion_f;

  /* S-Function (sfix_udelay): '<S51>/Integer Delay3'
   *
   * Regarding '<S51>/Integer Delay3':
   * Integer/Tapped Delay Block: '<S51>/Integer Delay3'
   */
  rtb_Add1_b = controlMCUSlugsMKII_DWork.IntegerDelay3_X_mk;

  /* Switch: '<S51>/Switch3' incorporates:
   *  RelationalOperator: '<S51>/Relational Operator2'
   */
  if (((uint8_T)(rtb_Add1_j == rtb_Add1_j)) > 0U) {
    rtb_Switch3_i = rtb_Add1_j;
  } else {
    rtb_Switch3_i = rtb_Add1_b;
  }

  /* Product: '<S55>/Product1' */
  rtb_Product1_mf = rtb_Switch3_i * controlMCUSlugsMKII_B.navSupportc_k[0];

  /* S-Function (sfix_udelay): '<S55>/NDelays'
   *
   * Regarding '<S55>/NDelays':
   * Integer/Tapped Delay Block: '<S55>/NDelays'
   */
  rtb_NDelays_m = controlMCUSlugsMKII_DWork.NDelays_X_m[0];

  /* Sum: '<S55>/Add1' incorporates:
   *  Constant: '<S55>/delayTime'
   *  Product: '<S55>/Product2'
   *  Product: '<S55>/Product3'
   *  Sum: '<S55>/Sum'
   */
  rtb_Add1_b = (rtb_Switch3_i - rtb_NDelays_m) / 5.000000075E-002F *
    controlMCUSlugsMKII_B.navSupportc_k[2] + rtb_Product1_mf;

  /* S-Function (sfix_udelay): '<S67>/Integer Delay2'
   *
   * Regarding '<S67>/Integer Delay2':
   * Integer/Tapped Delay Block: '<S67>/Integer Delay2'
   */
  rtb_IntegerDelay2_k = controlMCUSlugsMKII_DWork.IntegerDelay2_X_j;

  /* Sum: '<S55>/Sum2' incorporates:
   *  Gain: '<S55>/Gain'
   *  Memory: '<S55>/Memory1'
   *  Product: '<S55>/Product4'
   */
  rtb_Sum2_b = (9.999999776E-003F * rtb_Switch3_i *
                controlMCUSlugsMKII_B.navSupportc_k[1] +
                controlMCUSlugsMKII_DWork.Memory1_PreviousInput_l) + rtb_Add1_b;

  /* Sum: '<S55>/Add3' incorporates:
   *  Constant: '<S55>/SaturationLimit'
   */
  rtb_Add3_o = 2.792526782E-001F - controlMCUSlugsMKII_B.DataTypeConversion_f;

  /* Switch: '<S55>/AntiWindup' incorporates:
   *  Constant: '<S55>/Constant5'
   *  Logic: '<S55>/Logical Operator'
   *  RelationalOperator: '<S55>/Relational Operator'
   *  RelationalOperator: '<S55>/Relational Operator1'
   */
  if ((rtb_Sum2_b > rtb_Add4_p) && (rtb_Sum2_b < rtb_Add3_o)) {
    rtb_AntiWindup_m = (real_T)rtb_Switch3_i;
  } else {
    rtb_AntiWindup_m = 0.0;
  }

  /* S-Function (sfix_udelay): '<S68>/Integer Delay3'
   *
   * Regarding '<S68>/Integer Delay3':
   * Integer/Tapped Delay Block: '<S68>/Integer Delay3'
   */
  rtb_IntegerDelay3_l = controlMCUSlugsMKII_DWork.IntegerDelay3_X_j;

  /* Switch: '<S68>/Switch3' incorporates:
   *  RelationalOperator: '<S68>/Relational Operator2'
   */
  if (((uint8_T)(rtb_AntiWindup_m == rtb_AntiWindup_m)) > 0U) {
    rtb_Switch3_na = rtb_AntiWindup_m;
  } else {
    rtb_Switch3_na = rtb_IntegerDelay3_l;
  }

  /* S-Function (sfix_udelay): '<S67>/Integer Delay'
   *
   * Regarding '<S67>/Integer Delay':
   * Integer/Tapped Delay Block: '<S67>/Integer Delay'
   */
  rtb_IntegerDelay_c = controlMCUSlugsMKII_DWork.IntegerDelay_X_n;

  /* S-Function (sfix_udelay): '<S67>/Integer Delay1'
   *
   * Regarding '<S67>/Integer Delay1':
   * Integer/Tapped Delay Block: '<S67>/Integer Delay1'
   */
  rtb_IntegerDelay1_d = controlMCUSlugsMKII_DWork.IntegerDelay1_X_n[0];

  /* Switch: '<S67>/Switch1' incorporates:
   *  Constant: '<S67>/Constant'
   *  Constant: '<S67>/Constant1'
   *  Constant: '<S67>/Constant2'
   *  Constant: '<S67>/Constant3'
   *  Constant: '<S67>/Constant5'
   *  Product: '<S67>/Product'
   *  Product: '<S67>/Product1'
   *  Product: '<S67>/Product2'
   *  Product: '<S67>/Product3'
   *  Sum: '<S67>/Subtract'
   *  Sum: '<S67>/Subtract1'
   */
  if (controlMCUSlugsMKII_B.ManualorAutonavSupportc > 0U) {
    rtb_Switch1_g = 0.0F;
  } else {
    rtb_Switch1_g = (((real32_T)(rtb_Switch3_na * (real_T)0.3333333433F) +
                      (real32_T)(rtb_IntegerDelay_c * (real_T)1.333333373F)) +
                     (real32_T)(rtb_IntegerDelay1_d * 3.3333334326744080E-001)) *
      0.004999999888F + rtb_IntegerDelay2_k;
  }

  /* S-Function (sfix_udelay): '<S69>/Integer Delay3'
   *
   * Regarding '<S69>/Integer Delay3':
   * Integer/Tapped Delay Block: '<S69>/Integer Delay3'
   */
  rtb_IntegerDelay3_p = controlMCUSlugsMKII_DWork.IntegerDelay3_X_hp;

  {
    real32_T max;

    /* Switch: '<S69>/Switch3' incorporates:
     *  RelationalOperator: '<S69>/Relational Operator2'
     */
    if (((uint8_T)(rtb_Switch1_g == rtb_Switch1_g)) > 0U) {
      rtb_Switch3_cv = rtb_Switch1_g;
    } else {
      rtb_Switch3_cv = rtb_IntegerDelay3_p;
    }

    /* Sum: '<S55>/Add2' incorporates:
     *  Product: '<S55>/Product'
     */
    rtb_Add2_n = rtb_Switch3_cv * controlMCUSlugsMKII_B.navSupportc_k[1] +
      rtb_Add1_b;

    /* MinMax: '<S66>/Enforce lower limit' */
    max = rt_MAX(rtb_Add4_p, rtb_Add2_n);

    /* Sum: '<S14>/Add3' incorporates:
     *  MinMax: '<S66>/Enforce upper limit'
     */
    max = rt_MIN(max, rtb_Add3_o) + controlMCUSlugsMKII_B.DataTypeConversion_f;

    /* Saturate: '<S14>/Aileron Limit' */
    rtb_AileronLimit = rt_SATURATE(max, -2.792526782E-001F, 2.792526782E-001F);
  }

  /* Integer/Tapped Delay Block: '<S62>/Integer Delay3'
   */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_nc = rtb_Switch3_gn;

  /* Integer/Tapped Delay Block: '<S63>/Integer Delay3'
   */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_gw = rtb_Switch3_h4;

  /* Integer/Tapped Delay Block: '<S53>/Integer Delay3'
   */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_h = rtb_Switch3_pa;

  /* Integer/Tapped Delay Block: '<S54>/Integer Delay3'
   */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_ae = rtb_Switch3_fx;

  /* Integer/Tapped Delay Block: '<S52>/Integer Delay3'
   */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_b5 = rtb_Switch3_my;

  /* Integer/Tapped Delay Block: '<S57>/NDelays'
   */
  controlMCUSlugsMKII_DWork.NDelays_X_e[0] =
    controlMCUSlugsMKII_DWork.NDelays_X_e[1];
  controlMCUSlugsMKII_DWork.NDelays_X_e[1] =
    controlMCUSlugsMKII_DWork.NDelays_X_e[2];
  controlMCUSlugsMKII_DWork.NDelays_X_e[2] =
    controlMCUSlugsMKII_DWork.NDelays_X_e[3];
  controlMCUSlugsMKII_DWork.NDelays_X_e[3] =
    controlMCUSlugsMKII_DWork.NDelays_X_e[4];
  controlMCUSlugsMKII_DWork.NDelays_X_e[4] = rtb_Switch3_my;

  /* Integer/Tapped Delay Block: '<S83>/Integer Delay2'
   */
  controlMCUSlugsMKII_DWork.IntegerDelay2_X_g = rtb_Switch3_pf;

  /* Update for Memory: '<S57>/Memory1' */
  controlMCUSlugsMKII_DWork.Memory1_PreviousInput_a = rtb_Add2_af;

  /* Integer/Tapped Delay Block: '<S84>/Integer Delay3'
   */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_o = rtb_Switch3_g;

  /* Integer/Tapped Delay Block: '<S83>/Integer Delay'
   */
  controlMCUSlugsMKII_DWork.IntegerDelay_X_i0 = rtb_Switch3_g;

  /* Integer/Tapped Delay Block: '<S83>/Integer Delay1'
   */
  controlMCUSlugsMKII_DWork.IntegerDelay1_X_f[0] =
    controlMCUSlugsMKII_DWork.IntegerDelay1_X_f[1];
  controlMCUSlugsMKII_DWork.IntegerDelay1_X_f[1] = rtb_Switch3_g;

  /* Integer/Tapped Delay Block: '<S85>/Integer Delay3'
   */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_cn = rtb_Switch3_pf;

  /* Integer/Tapped Delay Block: '<S51>/Integer Delay3'
   */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_mk = rtb_Switch3_i;

  /* Integer/Tapped Delay Block: '<S55>/NDelays'
   */
  controlMCUSlugsMKII_DWork.NDelays_X_m[0] =
    controlMCUSlugsMKII_DWork.NDelays_X_m[1];
  controlMCUSlugsMKII_DWork.NDelays_X_m[1] =
    controlMCUSlugsMKII_DWork.NDelays_X_m[2];
  controlMCUSlugsMKII_DWork.NDelays_X_m[2] =
    controlMCUSlugsMKII_DWork.NDelays_X_m[3];
  controlMCUSlugsMKII_DWork.NDelays_X_m[3] =
    controlMCUSlugsMKII_DWork.NDelays_X_m[4];
  controlMCUSlugsMKII_DWork.NDelays_X_m[4] = rtb_Switch3_i;

  /* Integer/Tapped Delay Block: '<S67>/Integer Delay2'
   */
  controlMCUSlugsMKII_DWork.IntegerDelay2_X_j = rtb_Switch3_cv;

  /* Update for Memory: '<S55>/Memory1' */
  controlMCUSlugsMKII_DWork.Memory1_PreviousInput_l = rtb_Add2_n;

  /* Integer/Tapped Delay Block: '<S68>/Integer Delay3'
   */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_j = rtb_Switch3_na;

  /* Integer/Tapped Delay Block: '<S67>/Integer Delay'
   */
  controlMCUSlugsMKII_DWork.IntegerDelay_X_n = rtb_Switch3_na;

  /* Integer/Tapped Delay Block: '<S67>/Integer Delay1'
   */
  controlMCUSlugsMKII_DWork.IntegerDelay1_X_n[0] =
    controlMCUSlugsMKII_DWork.IntegerDelay1_X_n[1];
  controlMCUSlugsMKII_DWork.IntegerDelay1_X_n[1] = rtb_Switch3_na;

  /* Integer/Tapped Delay Block: '<S69>/Integer Delay3'
   */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_hp = rtb_Switch3_cv;

  /* Embedded MATLAB: '<Root>/myMux Fun1' */

  /*  This block supports an embeddable subset of the MATLAB language. */
  /*  See the help menu for details.  */
  rtb_y[0] = rtb_ThrottleLimit;
  rtb_y[1] = rtb_AileronLimit;
  rtb_y[2] = rtb_RudderLimit;
  rtb_y[3] = rtb_ElevatorLimit;

  /* If: '<S291>/If' */
  if (controlMCUSlugsMKII_B.GetControlTypenavSupportc == 1U) {
    /* Output and update for action system: '<S291>/If  Control Type Is Manual' */

    /* Gain: '<S293>/Gain' */
    rtb_Gain_fi = rtb_y_n[0] >> 1;

    /* Gain: '<S293>/Gain1' */
    rtb_Gain1_cp = rtb_y_n[1] >> 1;

    /* Gain: '<S293>/Gain2' */
    rtb_Gain2_fp = rtb_y_n[3] >> 1;

    /* Gain: '<S293>/Gain3' */
    rtb_Gain3_j = rtb_y_n[2] >> 1;

    /* Stateflow: '<S293>/myMux Fun1' */
    controlMCUSlugs_myMuxFun1_a(rtb_Gain_fi, rtb_Gain1_cp, rtb_Gain2_fp,
      rtb_Gain3_j, controlMCUSlugsMKII_B.Merge_n);
  } else if ((controlMCUSlugsMKII_B.GetControlTypenavSupportc == 2U) ||
             (controlMCUSlugsMKII_B.GetControlTypenavSupportc == 3U)) {
    /* Output and update for action system: '<S291>/If  Control Type Is Wp Follow  or Inner Cmds' */
    {
      real_T tmp;

      /* DataTypeConversion: '<S304>/Data Type Conversion' incorporates:
       *  Constant: '<S304>/Constant1'
       *  Constant: '<S304>/Constant2'
       *  Product: '<S304>/Divide'
       *  Sum: '<S304>/Add'
       */
      tmp = fmod(floor((real_T)rtb_y[3] * 3.9411311193641618E+003 +
                       3.7764285714285725E+003), 65536.0);
      if (tmp < 0.0) {
        tmp += 65536.0;
      }

      rtb_DataTypeConversion_k = (uint16_T)tmp;

      /* DataTypeConversion: '<S305>/Data Type Conversion' incorporates:
       *  Constant: '<S305>/Constant1'
       *  Constant: '<S305>/Constant2'
       *  Product: '<S305>/Divide'
       *  Sum: '<S305>/Add'
       */
      tmp = fmod(floor((real_T)rtb_y[0] * 1274.0 + 3176.0), 65536.0);
      if (tmp < 0.0) {
        tmp += 65536.0;
      }

      rtb_DataTypeConversion_o = (uint16_T)tmp;

      /* DataTypeConversion: '<S306>/Data Type Conversion' incorporates:
       *  Constant: '<S306>/Constant1'
       *  Constant: '<S306>/Constant2'
       *  Product: '<S306>/Divide'
       *  Sum: '<S306>/Add'
       */
      tmp = fmod(floor((real_T)rtb_y[1] * 3.4254691037464213E+003 +
                       3.6921428571428564E+003), 65536.0);
      if (tmp < 0.0) {
        tmp += 65536.0;
      }

      rtb_DataTypeConversion_o5 = (uint16_T)tmp;

      /* DataTypeConversion: '<S307>/Data Type Conversion' incorporates:
       *  Constant: '<S307>/Constant1'
       *  Constant: '<S307>/Constant2'
       *  Product: '<S307>/Divide'
       *  Sum: '<S307>/Add'
       */
      tmp = fmod(floor((real_T)rtb_y[2] * 2.8579680495216048E+003 +
                       3.7214285714285706E+003), 65536.0);
      if (tmp < 0.0) {
        tmp += 65536.0;
      }

      rtb_DataTypeConversion_j = (uint16_T)tmp;
    }

    /* Stateflow: '<S296>/myMux Fun1' */
    controlMCUSlugs_myMuxFun1_a(rtb_DataTypeConversion_o,
      rtb_DataTypeConversion_o5, rtb_DataTypeConversion_j,
      rtb_DataTypeConversion_k, controlMCUSlugsMKII_B.Merge_n);
  } else if (controlMCUSlugsMKII_B.GetControlTypenavSupportc == 4U) {
    /* Output and update for action system: '<S291>/If  Control Type Is Passthrough' */

    /* Gain: '<S294>/Gain' */
    rtb_Gain_pn = rtb_y_n[0] >> 1;

    /* Gain: '<S294>/Gain1' */
    rtb_Gain1_c = rtb_y_n[1] >> 1;

    /* Gain: '<S294>/Gain2' */
    rtb_Gain2_d = rtb_y_n[3] >> 1;

    /* Gain: '<S294>/Gain3' */
    rtb_Gain3_p = rtb_y_n[2] >> 1;

    /* Stateflow: '<S294>/myMux Fun1' */
    controlMCUSlugs_myMuxFun1_a(rtb_Gain_pn, rtb_Gain1_c, rtb_Gain2_d,
      rtb_Gain3_p, controlMCUSlugsMKII_B.Merge_n);
  } else if (controlMCUSlugsMKII_B.GetControlTypenavSupportc == 5U) {
    /* Output and update for action system: '<S291>/If  Control Type Is Selective Passthrough' */

    /* S-Function "dsPIC_C_function_Call" Block: <S295>/Get Pass Switches [navSupport.c] */
    getPassValues(&controlMCUSlugsMKII_B.GetPassSwitchesnavSupportc[0]);

    {
      real_T tmp;

      /* Switch: '<S295>/Switch' incorporates:
       *  Constant: '<S300>/Constant1'
       *  Constant: '<S300>/Constant2'
       *  DataTypeConversion: '<S300>/Data Type Conversion'
       *  Gain: '<S295>/Gain'
       *  Product: '<S300>/Divide'
       *  Sum: '<S300>/Add'
       */
      if (controlMCUSlugsMKII_B.GetPassSwitchesnavSupportc[3] >= 1U) {
        rtb_Switch_k = rtb_y_n[0] >> 1;
      } else {
        tmp = fmod(floor((real_T)rtb_y[0] * 1274.0 + 3176.0), 65536.0);
        if (tmp < 0.0) {
          tmp += 65536.0;
        }

        rtb_Switch_k = (uint16_T)tmp;
      }

      /* Switch: '<S295>/Switch1' incorporates:
       *  Constant: '<S301>/Constant1'
       *  Constant: '<S301>/Constant2'
       *  DataTypeConversion: '<S301>/Data Type Conversion'
       *  Gain: '<S295>/Gain1'
       *  Product: '<S301>/Divide'
       *  Sum: '<S301>/Add'
       */
      if (controlMCUSlugsMKII_B.GetPassSwitchesnavSupportc[2] >= 1U) {
        rtb_Switch1_bs = rtb_y_n[1] >> 1;
      } else {
        tmp = fmod(floor((real_T)rtb_y[1] * 3.4254691037464213E+003 +
                         3.6921428571428564E+003), 65536.0);
        if (tmp < 0.0) {
          tmp += 65536.0;
        }

        rtb_Switch1_bs = (uint16_T)tmp;
      }

      /* Switch: '<S295>/Switch2' incorporates:
       *  Constant: '<S302>/Constant1'
       *  Constant: '<S302>/Constant2'
       *  DataTypeConversion: '<S302>/Data Type Conversion'
       *  Gain: '<S295>/Gain2'
       *  Product: '<S302>/Divide'
       *  Sum: '<S302>/Add'
       */
      if (controlMCUSlugsMKII_B.GetPassSwitchesnavSupportc[1] >= 1U) {
        rtb_Switch2_l = rtb_y_n[3] >> 1;
      } else {
        tmp = fmod(floor((real_T)rtb_y[2] * 2.8579680495216048E+003 +
                         3.7214285714285706E+003), 65536.0);
        if (tmp < 0.0) {
          tmp += 65536.0;
        }

        rtb_Switch2_l = (uint16_T)tmp;
      }

      /* Switch: '<S295>/Switch3' incorporates:
       *  Constant: '<S299>/Constant1'
       *  Constant: '<S299>/Constant2'
       *  DataTypeConversion: '<S299>/Data Type Conversion'
       *  Gain: '<S295>/Gain3'
       *  Product: '<S299>/Divide'
       *  Sum: '<S299>/Add'
       */
      if (controlMCUSlugsMKII_B.GetPassSwitchesnavSupportc[0] >= 1U) {
        rtb_Switch3_c5 = rtb_y_n[2] >> 1;
      } else {
        tmp = fmod(floor((real_T)rtb_y[3] * 3.9411311193641618E+003 +
                         3.7764285714285725E+003), 65536.0);
        if (tmp < 0.0) {
          tmp += 65536.0;
        }

        rtb_Switch3_c5 = (uint16_T)tmp;
      }
    }

    /* Stateflow: '<S295>/myMux Fun1' */
    controlMCUSlugs_myMuxFun1_a(rtb_Switch_k, rtb_Switch1_bs, rtb_Switch2_l,
      rtb_Switch3_c5, controlMCUSlugsMKII_B.Merge_n);
  }

  /* S-Function "dsPIC_PWM_motor" Block: <S8>/PWM Servo Output */
  PDC1 = controlMCUSlugsMKII_B.Merge_n[2] ;
  PDC2 = controlMCUSlugsMKII_B.Merge_n[3] ;
  PDC3 = controlMCUSlugsMKII_B.Merge_n[1] ;
  PDC4 = controlMCUSlugsMKII_B.Merge_n[0] ;

  /* SignalConversion: '<S292>/TmpHiddenBufferAt SFunction Inport1' */
  rtb_TmpHiddenBufferAtSFunctionI[0] = controlMCUSlugsMKII_B.Merge_n[0];
  rtb_TmpHiddenBufferAtSFunctionI[1] = controlMCUSlugsMKII_B.Merge_n[1];
  rtb_TmpHiddenBufferAtSFunctionI[2] = controlMCUSlugsMKII_B.Merge_n[3];
  rtb_TmpHiddenBufferAtSFunctionI[3] = controlMCUSlugsMKII_B.Merge_n[2];

  /* Embedded MATLAB: '<S8>/myMux Fun1' */
  {
    int16_T eml_i0;

    /*  This block supports an embeddable subset of the MATLAB language. */
    /*  See the help menu for details.  */
    for (eml_i0 = 0; eml_i0 < 4; eml_i0++) {
      controlMCUSlugsMKII_B.y_d[eml_i0] = rtb_TmpHiddenBufferAtSFunctionI[eml_i0];
    }

    controlMCUSlugsMKII_B.y_d[4] = rtb_y_n[4];
  }

  /* S-Function "dsPIC_C_function_Call" Block: <S8>/Update PWM  Commands [groundStationDriver.c] */
  updatePWM(controlMCUSlugsMKII_B.y_d);

  /* S-Function "dsPIC_C_function_Call" Block: <S8>/Update the Euler Angles [groundStationDriver.c]  */
  updateEuler(controlMCUSlugsMKII_B.sf_myMuxFun1_e.y_i);

  /* S-Function "dsPIC_C_function_Call" Block: <S8>/Update PQR [groundStationDriver.c]  */
  updatePQR(controlMCUSlugsMKII_B.Product1);

  /* S-Function "dsPIC_C_function_Call" Block: <S8>/Create Telemetry  Sentence [groundStationDriver.c] */
  prepareTelemetry(&controlMCUSlugsMKII_B.CreateTelemetrySentencegroundSt[0]);

  /* S-Function "dsPIC_C_function_Call" Block: <S8>/Send Data to Radio Modem [groundStationDriver.c] */
  send2GS(controlMCUSlugsMKII_B.CreateTelemetrySentencegroundSt);

  /* Stateflow: '<S2>/myMux Fun2' */
  controlMCUSlugsMK_myMuxFun1(rtb_Switch3_oe, rtb_PsiDotLimit,
    controlMCUSlugsMKII_B.PsiDotLimit, &controlMCUSlugsMKII_B.sf_myMuxFun2_l);

  /* S-Function "dsPIC_C_function_Call" Block: <S2>/Diagnostics [navSupport.c] */
  setDiagnosticFloat(controlMCUSlugsMKII_B.sf_myMuxFun2_l.y);

  /* DataTypeConversion: '<S290>/Data Type Conversion4' */
  controlMCUSlugsMKII_B.DataTypeConversion4 = (uint16_T)
    (controlMCUSlugsMKII_ConstB.Gain4 <= 65535.0 ?
     controlMCUSlugsMKII_ConstB.Gain4 >= 0.0 ? controlMCUSlugsMKII_ConstB.Gain4 :
     0.0 : 65535.0);

  /* S-Function "dsPIC_C_function_Call" Block: <S290>/Update PWM  Commands4 */
  updatePWM2(controlMCUSlugsMKII_B.DataTypeConversion4,((uint8_T)4U));

  {
    real_T tmp;

    /* Gain: '<S6>/Gain4' */
    rtb_Abs2 = 100.0F * controlMCUSlugsMKII_B.DataTypeConversion;

    /* DataTypeConversion: '<S280>/Data Type Conversion2' incorporates:
     *  Abs: '<S6>/Abs4'
     */
    tmp = fmod(floor((real_T)rt_ABS(rtb_Abs2)), 65536.0);
    if (tmp < 0.0) {
      tmp += 65536.0;
    }

    controlMCUSlugsMKII_B.DataTypeConversion2_e = (uint16_T)tmp;
  }

  /* S-Function "dsPIC_C_function_Call" Block: <S280>/Update PWM  Commands1 */
  updatePWM2(controlMCUSlugsMKII_B.DataTypeConversion2_e,((uint8_T)0U));

  {
    real_T tmp;

    /* Gain: '<S6>/Gain1' */
    rtb_Gain2_f = 5729.578125F * controlMCUSlugsMKII_B.DataTypeConversion_f;

    /* DataTypeConversion: '<S280>/Data Type Conversion3' incorporates:
     *  Abs: '<S6>/Abs'
     */
    tmp = fmod(floor((real_T)rt_ABS(rtb_Gain2_f)), 65536.0);
    if (tmp < 0.0) {
      tmp += 65536.0;
    }

    controlMCUSlugsMKII_B.DataTypeConversion3 = (uint16_T)tmp;
  }

  /* S-Function "dsPIC_C_function_Call" Block: <S280>/Update PWM  Commands2 */
  updatePWM2(controlMCUSlugsMKII_B.DataTypeConversion3,((uint8_T)1U));

  {
    real_T tmp;

    /* Gain: '<S6>/Gain3' */
    rtb_Gain2_f = 5729.578125F * controlMCUSlugsMKII_B.DataTypeConversion_c;

    /* DataTypeConversion: '<S280>/Data Type Conversion1' incorporates:
     *  Abs: '<S6>/Abs1'
     */
    tmp = fmod(floor((real_T)rt_ABS(rtb_Gain2_f)), 65536.0);
    if (tmp < 0.0) {
      tmp += 65536.0;
    }

    controlMCUSlugsMKII_B.DataTypeConversion1 = (uint16_T)tmp;
  }

  /* S-Function "dsPIC_C_function_Call" Block: <S280>/Update PWM  Commands3 */
  updatePWM2(controlMCUSlugsMKII_B.DataTypeConversion1,((uint8_T)2U));

  {
    real_T tmp;

    /* Gain: '<S6>/Gain2' */
    rtb_Gain2_f = 5729.578125F * controlMCUSlugsMKII_B.DataTypeConversion_b;

    /* DataTypeConversion: '<S280>/Data Type Conversion4' incorporates:
     *  Abs: '<S6>/Abs2'
     */
    tmp = fmod(floor((real_T)rt_ABS(rtb_Gain2_f)), 65536.0);
    if (tmp < 0.0) {
      tmp += 65536.0;
    }

    controlMCUSlugsMKII_B.DataTypeConversion4_p = (uint16_T)tmp;
  }

  /* S-Function "dsPIC_C_function_Call" Block: <S280>/Update PWM  Commands4 */
  updatePWM2(controlMCUSlugsMKII_B.DataTypeConversion4_p,((uint8_T)3U));

  /* S-Function "dsPIC_C_function_Call" Block: <S5>/GetFilterOnOff */
  controlMCUSlugsMKII_B.GetFilterOnOff = getFilterOnOff();

  /* DataTypeConversion: '<S5>/Data Type Conversion1' */
  controlMCUSlugsMKII_B.DataTypeConversion1_e =
    (controlMCUSlugsMKII_B.GetFilterOnOff != 0U);

  /* S-Function "dsPIC_Digital_OutputWrite" Block: <S5>/HIL Attitude  On//Off Switch */
  LATBbits.LATB6 = controlMCUSlugsMKII_B.DataTypeConversion1_e;

  /* S-Function "dsPIC_Digital_OutputWrite" Block: <S5>/HIL On//Off Switch */
  LATEbits.LATE9 = controlMCUSlugsMKII_B.DataTypeConversion1_e;

  /* Integer/Tapped Delay Block: '<S6>/Integer Delay'
   */
  controlMCUSlugsMKII_DWork.IntegerDelay_X_p = rtb_ScheduleLPF;

  /* Integer/Tapped Delay Block: '<S278>/Integer Delay2'
   */
  controlMCUSlugsMKII_DWork.IntegerDelay2_X_k = controlMCUSlugsMKII_B.IC_c;

  /* Integer/Tapped Delay Block: '<S17>/Integer Delay3'
   */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_j5 = rtb_Switch3_ov;

  /* Integer/Tapped Delay Block: '<S19>/Integer Delay3'
   */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_b = rtb_Switch3_oe;
  if (controlMCUSlugsMKII_DWork.L1OutputFeedbackControllerWithP == (int32_T)
      SUBSYS_ENABLED) {
    /* Update for enable system: '<S2>/L1 Output Feedback Controller With  Projection Operator' */

    /* Update for UnitDelay: '<S33>/UD' */
    controlMCUSlugsMKII_DWork.UD_DSTATE_l = controlMCUSlugsMKII_B.navSupportc_g
      [0];

    /* Integer/Tapped Delay Block: '<S24>/Integer Delay'
     */
    controlMCUSlugsMKII_DWork.IntegerDelay_X_d = rtb_Switch3_im;

    /* Integer/Tapped Delay Block: '<S24>/Integer Delay1'
     */
    controlMCUSlugsMKII_DWork.IntegerDelay1_X_nc = rtb_Subtract_b;

    /* Integer/Tapped Delay Block: '<S26>/Integer Delay3'
     */
    controlMCUSlugsMKII_DWork.IntegerDelay3_X_cw = rtb_Switch3_cj;

    /* Update for UnitDelay: '<S42>/UD' */
    controlMCUSlugsMKII_DWork.UD_DSTATE_ld = controlMCUSlugsMKII_B.navSupportc_g
      [1];

    /* Integer/Tapped Delay Block: '<S28>/Integer Delay'
     */
    controlMCUSlugsMKII_DWork.IntegerDelay_X_c = rtb_Switch3_ae;

    /* Integer/Tapped Delay Block: '<S28>/Integer Delay1'
     */
    controlMCUSlugsMKII_DWork.IntegerDelay1_X_a = rtb_Subtract_c;

    /* Integer/Tapped Delay Block: '<S13>/Integer Delay'
     */
    controlMCUSlugsMKII_DWork.IntegerDelay_X_no = rtb_PsiDotLimit;

    /* Integer/Tapped Delay Block: '<S13>/Integer Delay1'
     */
    controlMCUSlugsMKII_DWork.IntegerDelay1_X_b = rtb_Switch3_im;

    /* Integer/Tapped Delay Block: '<S27>/Integer Delay3'
     */
    controlMCUSlugsMKII_DWork.IntegerDelay3_X_gww = rtb_Switch3_ae;

    /* Integer/Tapped Delay Block: '<S29>/Integer Delay'
     */
    controlMCUSlugsMKII_DWork.IntegerDelay_X_f = rtb_Switch3_gq;

    /* Integer/Tapped Delay Block: '<S29>/Integer Delay1'
     */
    controlMCUSlugsMKII_DWork.IntegerDelay1_X_ny[0] =
      controlMCUSlugsMKII_DWork.IntegerDelay1_X_ny[1];
    controlMCUSlugsMKII_DWork.IntegerDelay1_X_ny[1] = rtb_Switch3_gq;

    /* Integer/Tapped Delay Block: '<S29>/Integer Delay2'
     */
    controlMCUSlugsMKII_DWork.IntegerDelay2_X_m = rtb_Switch3_im;

    /* Integer/Tapped Delay Block: '<S43>/Integer Delay3'
     */
    controlMCUSlugsMKII_DWork.IntegerDelay3_X_oe = rtb_Switch3_gq;

    /* Integer/Tapped Delay Block: '<S44>/Integer Delay3'
     */
    controlMCUSlugsMKII_DWork.IntegerDelay3_X_oe1 = rtb_Switch3_im;
  }

  /* Update absolute time */
  controlMCUSlugsMKII_M->Timing.clockTick0++;
}

/* Model step function for TID1 */
void controlMCUSlugsMKII_step1(void)   /* Sample time: [1.0s, 0.0s] */
{
  /* (no output/update code required) */
}

void controlMCUSlugsMKII_step(int_T tid)
{
  switch (tid) {
   case 0 :
    controlMCUSlugsMKII_step0();
    break;

   case 1 :
    controlMCUSlugsMKII_step1();
    break;

   default :
    break;
  }
}

/* Model initialize function */
void controlMCUSlugsMKII_initialize(boolean_T firstTime)
{
  (void)firstTime;

  /* Registration code */
  /* initialize real-time model */
  (void) memset((char_T *)controlMCUSlugsMKII_M,0,
                sizeof(RT_MODEL_controlMCUSlugsMKII));

  /* block I/O */
  (void) memset(((void *) &controlMCUSlugsMKII_B),0,
                sizeof(BlockIO_controlMCUSlugsMKII));

  {
    int_T i;
    void *pVoidBlockIORegion;
    pVoidBlockIORegion = (void *)(&controlMCUSlugsMKII_B.IC);
    for (i = 0; i < 2; i++) {
      ((real_T*)pVoidBlockIORegion)[i] = 0.0;
    }

    pVoidBlockIORegion = (void *)
      (&controlMCUSlugsMKII_B.GetMidLevelCommandsnavSupportc[0]);
    for (i = 0; i < 83; i++) {
      ((real32_T*)pVoidBlockIORegion)[i] = 0.0F;
    }

    pVoidBlockIORegion = (void *)(&controlMCUSlugsMKII_B.y_n[0]);
    for (i = 0; i < 113; i++) {
      ((real32_T*)pVoidBlockIORegion)[i] = 0.0F;
    }

    pVoidBlockIORegion = (void *)(&controlMCUSlugsMKII_B.sf_myMuxFun1_e.y_i[0]);
    for (i = 0; i < 3; i++) {
      ((real32_T*)pVoidBlockIORegion)[i] = 0.0F;
    }

    pVoidBlockIORegion = (void *)(&controlMCUSlugsMKII_B.sf_myMuxFun2_c.y_i[0]);
    for (i = 0; i < 3; i++) {
      ((real32_T*)pVoidBlockIORegion)[i] = 0.0F;
    }

    pVoidBlockIORegion = (void *)(&controlMCUSlugsMKII_B.sf_myMuxFun1_a.y_i[0]);
    for (i = 0; i < 3; i++) {
      ((real32_T*)pVoidBlockIORegion)[i] = 0.0F;
    }

    pVoidBlockIORegion = (void *)(&controlMCUSlugsMKII_B.sf_myMuxFun1_m.y_l[0]);
    for (i = 0; i < 9; i++) {
      ((real32_T*)pVoidBlockIORegion)[i] = 0.0F;
    }

    pVoidBlockIORegion = (void *)(&controlMCUSlugsMKII_B.sf_myMuxFun2.y_i[0]);
    for (i = 0; i < 3; i++) {
      ((real32_T*)pVoidBlockIORegion)[i] = 0.0F;
    }

    pVoidBlockIORegion = (void *)(&controlMCUSlugsMKII_B.sf_myMuxFun1.y_i[0]);
    for (i = 0; i < 3; i++) {
      ((real32_T*)pVoidBlockIORegion)[i] = 0.0F;
    }

    pVoidBlockIORegion = (void *)(&controlMCUSlugsMKII_B.sf_myMuxFun1_n.y_l[0]);
    for (i = 0; i < 9; i++) {
      ((real32_T*)pVoidBlockIORegion)[i] = 0.0F;
    }

    pVoidBlockIORegion = (void *)(&controlMCUSlugsMKII_B.sf_myMuxFun2_l.y[0]);
    for (i = 0; i < 3; i++) {
      ((real32_T*)pVoidBlockIORegion)[i] = 0.0F;
    }

    pVoidBlockIORegion = (void *)(&controlMCUSlugsMKII_B.sf_myMuxFun1_o.y[0]);
    for (i = 0; i < 3; i++) {
      ((real32_T*)pVoidBlockIORegion)[i] = 0.0F;
    }

    pVoidBlockIORegion = (void *)(&controlMCUSlugsMKII_B.sf_myMuxFun1_h.y[0]);
    for (i = 0; i < 3; i++) {
      ((real32_T*)pVoidBlockIORegion)[i] = 0.0F;
    }

    ((real32_T*)&controlMCUSlugsMKII_B.sf_negprotect1.zpVal)[0] = 0.0F;
    ((real32_T*)&controlMCUSlugsMKII_B.sf_negprotect_h.zpVal_k)[0] = 0.0F;
    ((real32_T*)&controlMCUSlugsMKII_B.sf_negprotect_f.zpVal_k)[0] = 0.0F;
    ((real32_T*)&controlMCUSlugsMKII_B.sf_negprotect_fm.zpVal)[0] = 0.0F;
    ((real32_T*)&controlMCUSlugsMKII_B.sf_EmbeddedMATLABFunction_d.xDoty_j)[0] =
      0.0F;
    ((real32_T*)&controlMCUSlugsMKII_B.sf_negprotect_b.zpVal_k)[0] = 0.0F;
    ((real32_T*)&controlMCUSlugsMKII_B.sf_EmbeddedMATLABFunction_or.xDoty_j)[0] =
      0.0F;
    ((real32_T*)&controlMCUSlugsMKII_B.sf_negprotect_bp.zpVal_k)[0] = 0.0F;
    ((real32_T*)&controlMCUSlugsMKII_B.sf_EmbeddedMATLABFunction_hk.xDoty_j)[0] =
      0.0F;
    ((real32_T*)&controlMCUSlugsMKII_B.sf_negprotect_g.zpVal_k)[0] = 0.0F;
    ((real32_T*)&controlMCUSlugsMKII_B.sf_EmbeddedMATLABFunction_mg.xDoty_g)[0] =
      0.0F;
    ((real32_T*)&controlMCUSlugsMKII_B.sf_negprotect_l.zpVal_k)[0] = 0.0F;
    ((real32_T*)&controlMCUSlugsMKII_B.sf_EmbeddedMATLABFunction_n.xDoty)[0] =
      0.0F;
    ((real32_T*)&controlMCUSlugsMKII_B.sf_EmbeddedMATLABFunction_a.xDoty_g)[0] =
      0.0F;
    ((real32_T*)&controlMCUSlugsMKII_B.sf_negprotect_e.zpVal_k)[0] = 0.0F;
    ((real32_T*)&controlMCUSlugsMKII_B.sf_EmbeddedMATLABFunction_m.xDoty)[0] =
      0.0F;
    ((real32_T*)&controlMCUSlugsMKII_B.sf_negprotect_c.zpVal)[0] = 0.0F;
    ((real32_T*)&controlMCUSlugsMKII_B.sf_negprotect.zpVal)[0] = 0.0F;
  }

  /* states (dwork) */
  (void) memset((char_T *) &controlMCUSlugsMKII_DWork,0,
                sizeof(D_Work_controlMCUSlugsMKII));

  {
    int_T i;
    real_T *dwork_ptr = (real_T *) &controlMCUSlugsMKII_DWork.IntegerDelay2_X;
    for (i = 0; i < 24; i++) {
      dwork_ptr[i] = 0.0;
    }
  }

  {
    int_T i;
    real32_T *dwork_ptr = (real32_T *)
      &controlMCUSlugsMKII_DWork.IntegerDelay_X_p;
    for (i = 0; i < 91; i++) {
      dwork_ptr[i] = 0.0F;
    }
  }

  /* S-Function "dsPIC_MASTER" initialization Block: <Root>/Master */
  /* 1 testfcy 	*/
  /*  4.0E+007	*/
  /* CONFIG TIMER 1 for scheduling steps 	*/
  ConfigIntTimer1(T1_INT_PRIOR_0 & T1_INT_OFF);
  T1CON = 0x8010 ;                     /* T1_PS_1_8	*/
  PR1 = 49999;

  /* Configuration TIMER 2 */
  ConfigIntTimer2(T2_INT_PRIOR_0 & T2_INT_OFF);
  OpenTimer2(T2_ON & T2_GATE_OFF &
             T2_PS_1_8 & T2_SOURCE_INT , 65535);

  /* Configuration TRIS */
  TRISB = 65471;
  TRISE = 65023;

  /* Configuration ADCHS */
  AD1PCFGL = (68);
  AD2PCFGL = (68);
  AD1PCFGH = ((2097220 >> 16) & 65535);

  /* S-Function "dsPIC_PWM_IC" initialization Block: <S277>/Input Capture */
  /* Initialise Input Capture */
  /* config capture */
  OpenCapture2(IC_IDLE_CON & IC_TIMER2_SRC & IC_INT_1CAPTURE &
               IC_EVERY_RISE_EDGE);
  ConfigIntCapture2(IC_INT_ON & IC_INT_PRIOR_6);

  /* config capture */
  OpenCapture3(IC_IDLE_CON & IC_TIMER2_SRC & IC_INT_1CAPTURE &
               IC_EVERY_RISE_EDGE);
  ConfigIntCapture3(IC_INT_ON & IC_INT_PRIOR_6);

  /* config capture */
  OpenCapture4(IC_IDLE_CON & IC_TIMER2_SRC & IC_INT_1CAPTURE &
               IC_EVERY_RISE_EDGE);
  ConfigIntCapture4(IC_INT_ON & IC_INT_PRIOR_6);

  /* config capture */
  OpenCapture5(IC_IDLE_CON & IC_TIMER2_SRC & IC_INT_1CAPTURE &
               IC_EVERY_RISE_EDGE);
  ConfigIntCapture5(IC_INT_ON & IC_INT_PRIOR_6);

  /* config capture */
  OpenCapture8(IC_IDLE_CON & IC_TIMER2_SRC & IC_INT_1CAPTURE &
               IC_EVERY_RISE_EDGE);
  ConfigIntCapture8(IC_INT_ON & IC_INT_PRIOR_6);

  /* Start for InitialCondition: '<S278>/IC' */
  controlMCUSlugsMKII_B.IC_c = 1U;
  controlMCUSlugsMKII_DWork.IC_FirstOutputTime = 1U;

  /* Start for atomic system: '<S2>/Navigation' */

  /* Start for InitialCondition: '<S124>/IC1' */
  controlMCUSlugsMKII_DWork.IC1_FirstOutputTime = 1U;

  /* Start for InitialCondition: '<S139>/IC' */
  controlMCUSlugsMKII_B.IC = 1.0;
  controlMCUSlugsMKII_DWork.IC_FirstOutputTime_i = 1U;

  /* Start for InitialCondition: '<S180>/IC' */
  controlMCUSlugsMKII_B.IC_e = 1.0F;
  controlMCUSlugsMKII_DWork.IC_FirstOutputTime_b = 1U;

  /* Start for InitialCondition: '<S140>/IC' */
  controlMCUSlugsMKII_DWork.IC_FirstOutputTime_d = 1U;

  /* Start for enable system: '<S140>/Compute Total Run' */

  /* virtual outports code */

  /* (Virtual) Outport Block: '<S179>/Tot Run' */
  controlMCUSlugsMKII_B.Switch3 = 150.0F;

  /* Start for enable system: '<S124>/Compute P' */

  /* Start for InitialCondition: '<S133>/IC' */
  controlMCUSlugsMKII_DWork.IC_FirstOutputTime_k = 1U;

  /* virtual outports code */

  /* (Virtual) Outport Block: '<S133>/P' */
  controlMCUSlugsMKII_B.IC_l = 50.0F;

  /* Start for enable system: '<S2>/L1 Output Feedback Controller With  Projection Operator' */

  /* Start for InitialCondition: '<S24>/IC' */
  controlMCUSlugsMKII_DWork.IC_FirstOutputTime_g = 1U;

  /* Start for InitialCondition: '<S28>/IC' */
  controlMCUSlugsMKII_DWork.IC_FirstOutputTime_p = 1U;

  /* Initial conditions for enable system: '<S2>/L1 Output Feedback Controller With  Projection Operator' */

  /* InitializeConditions for UnitDelay: '<S33>/UD' */
  controlMCUSlugsMKII_DWork.UD_DSTATE_l = 0.0F;

  /* Integer/Tapped Delay Block: '<S24>/Integer Delay'
   * Initialize State
   * Initial Condition parameter uses the same data type and scaling as Output0
   */
  controlMCUSlugsMKII_DWork.IntegerDelay_X_d = (0.0F);

  /* Integer/Tapped Delay Block: '<S24>/Integer Delay1'
   * Initialize State
   * Initial Condition parameter uses the same data type and scaling as Output0
   */
  controlMCUSlugsMKII_DWork.IntegerDelay1_X_nc = (0.0F);

  /* Integer/Tapped Delay Block: '<S26>/Integer Delay3'
   * Initialize State
   * Initial Condition parameter uses the same data type and scaling as Output0
   */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_cw = (0.0F);

  /* InitializeConditions for UnitDelay: '<S42>/UD' */
  controlMCUSlugsMKII_DWork.UD_DSTATE_ld = 0.0F;

  /* Integer/Tapped Delay Block: '<S28>/Integer Delay'
   * Initialize State
   * Initial Condition parameter uses the same data type and scaling as Output0
   */
  controlMCUSlugsMKII_DWork.IntegerDelay_X_c = (0.0F);

  /* Integer/Tapped Delay Block: '<S28>/Integer Delay1'
   * Initialize State
   * Initial Condition parameter uses the same data type and scaling as Output0
   */
  controlMCUSlugsMKII_DWork.IntegerDelay1_X_a = (0.0F);

  /* Integer/Tapped Delay Block: '<S13>/Integer Delay'
   * Initialize State
   * Initial Condition parameter uses the same data type and scaling as Output0
   */
  controlMCUSlugsMKII_DWork.IntegerDelay_X_no = (0.0F);

  /* Integer/Tapped Delay Block: '<S13>/Integer Delay1'
   * Initialize State
   * Initial Condition parameter uses the same data type and scaling as Output0
   */
  controlMCUSlugsMKII_DWork.IntegerDelay1_X_b = (0.0F);

  /* InitializeConditions for Merge: '<S25>/Merge' */
  if (rtmIsFirstInitCond(controlMCUSlugsMKII_M)) {
    controlMCUSlugsMKII_B.Merge = 0.0F;
  }

  /* Integer/Tapped Delay Block: '<S27>/Integer Delay3'
   * Initialize State
   * Initial Condition parameter uses the same data type and scaling as Output0
   */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_gww = (0.0F);

  /* Integer/Tapped Delay Block: '<S29>/Integer Delay'
   * Initialize State
   * Initial Condition parameter uses the same data type and scaling as Output0
   */
  controlMCUSlugsMKII_DWork.IntegerDelay_X_f = (0.0F);

  /* Integer/Tapped Delay Block: '<S29>/Integer Delay1'
   * Initialize State
   * Initial Condition parameter uses the same data type and scaling as Output0
   */
  controlMCUSlugsMKII_DWork.IntegerDelay1_X_ny[0] = (0.0F);
  controlMCUSlugsMKII_DWork.IntegerDelay1_X_ny[1] = (0.0F);

  /* Integer/Tapped Delay Block: '<S29>/Integer Delay2'
   * Initialize State
   * Initial Condition parameter uses the same data type and scaling as Output0
   */
  controlMCUSlugsMKII_DWork.IntegerDelay2_X_m = (0.0F);

  /* Integer/Tapped Delay Block: '<S43>/Integer Delay3'
   * Initialize State
   * Initial Condition parameter uses the same data type and scaling as Output0
   */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_oe = (0.0F);

  /* Integer/Tapped Delay Block: '<S44>/Integer Delay3'
   * Initialize State
   * Initial Condition parameter uses the same data type and scaling as Output0
   */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_oe1 = (0.0F);

  /* Start for atomic system: '<S2>/Lateral Channel' */

  /* Start for enable system: '<S14>/Sideslip Compensation' */

  /* Start for InitialCondition: '<S71>/IC' */
  controlMCUSlugsMKII_DWork.IC_FirstOutputTime_e = 1U;

  /* Initial conditions for enable system: '<S14>/Sideslip Compensation' */

  /* InitializeConditions for UnitDelay: '<S79>/UD' */
  controlMCUSlugsMKII_DWork.UD_DSTATE_o = 0.0F;

  /* Integer/Tapped Delay Block: '<S71>/Integer Delay'
   * Initialize State
   * Initial Condition parameter uses the same data type and scaling as Output0
   */
  controlMCUSlugsMKII_DWork.IntegerDelay_X_b = (0.0F);

  /* Integer/Tapped Delay Block: '<S71>/Integer Delay1'
   * Initialize State
   * Initial Condition parameter uses the same data type and scaling as Output0
   */
  controlMCUSlugsMKII_DWork.IntegerDelay1_X_f5 = (0.0);

  /* Integer/Tapped Delay Block: '<S72>/Integer Delay3'
   * Initialize State
   * Initial Condition parameter uses the same data type and scaling as Output0
   */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_hc = (0.0F);

  /* S-Function "dsPIC_PWM_motor" initialization Block: <S8>/PWM Servo Output */
  /* Initialise Output Capture */
  SetDCMCPWM(1,0,0);
  SetDCMCPWM(2,0,0);
  SetDCMCPWM(3,0,0);
  SetDCMCPWM(4,0,0);

#define config2                        (0xffff &PWM_PEN1L & PWM_MOD1_IND & PWM_PDIS1H &PWM_PEN2L & PWM_MOD2_IND & PWM_PDIS2H &PWM_PEN3L & PWM_MOD3_IND & PWM_PDIS3H &PWM_PEN4L & PWM_MOD4_IND & PWM_PDIS4H)
#define config                         (PWM_INT_DIS & PWM_FLTA_DIS_INT & PWM_INT_PR1 & PWM_FLTA_INT_PR0)

  ConfigIntMCPWM( config );

#define config1                        (PWM_EN & 0xDFFF & PWM_OP_SCALE1 & PWM_IPCLK_SCALE16 & PWM_MOD_UPDN)
#define config3                        (PWM_SEVOPS1 & PWM_OSYNC_TCY & PWM_UEN)

  OpenMCPWM(25000,0,config1,config2,config3);

  /* blocks with infinite sample periods */

  /* S-Function "dsPIC_C_function_Call" Block: <Root>/Initialize the MCU [groundStationDriver.c] */
  controlMCUInit();
  controlMCUSlugsM_PrevZCSigState.HitCrossing_ZCE = UNINITIALIZED_ZCSIG;
  controlMCUSlugsM_PrevZCSigState.HitCrossing1_ZCE = UNINITIALIZED_ZCSIG;

  /* Initialize code for chart: '<S276>/Buffer IC Channel' */
  {
    int16_T eml_i0;
    for (eml_i0 = 0; eml_i0 < 7; eml_i0++) {
      controlMCUSlugsMKII_DWork.BufferICChannel.oldValues[eml_i0] = 0U;
    }
  }

  /* Initialize code for chart: '<S276>/Buffer IC Channel1' */
  {
    int16_T eml_i0;
    for (eml_i0 = 0; eml_i0 < 7; eml_i0++) {
      controlMCUSlugsMKII_DWork.BufferICChannel1.oldValues[eml_i0] = 0U;
    }
  }

  /* Initialize code for chart: '<S276>/Buffer IC Channel2' */
  {
    int16_T eml_i0;
    for (eml_i0 = 0; eml_i0 < 7; eml_i0++) {
      controlMCUSlugsMKII_DWork.BufferICChannel2.oldValues[eml_i0] = 0U;
    }
  }

  /* Initialize code for chart: '<S276>/Buffer IC Channel3' */
  {
    int16_T eml_i0;
    for (eml_i0 = 0; eml_i0 < 7; eml_i0++) {
      controlMCUSlugsMKII_DWork.BufferICChannel3.oldValues[eml_i0] = 0U;
    }
  }

  /* Initial conditions for atomic system: '<S2>/Navigation' */

  /* Integer/Tapped Delay Block: '<S124>/Integer Delay2'
   * Initialize State
   * Initial Condition parameter uses the same data type and scaling as Output0
   */
  controlMCUSlugsMKII_DWork.IntegerDelay2_X = (1.0);

  /* Initialize code for chart: '<S124>/Embedded MATLAB Function' */
  controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction_g.fromWP_not_empty = false;

  /* Integer/Tapped Delay Block: '<S124>/Integer Delay3'
   * Initialize State
   * Initial Condition parameter uses the same data type and scaling as Output0
   */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_a = (50.0F);

  /* Integer/Tapped Delay Block: '<S180>/Integer Delay1'
   * Initialize State
   * Initial Condition parameter uses the same data type and scaling as Output0
   */
  controlMCUSlugsMKII_DWork.IntegerDelay1_X_i = (1.0F);

  /* Integer/Tapped Delay Block: '<S180>/Integer Delay2'
   * Initialize State
   * Initial Condition parameter uses the same data type and scaling as Output0
   */
  controlMCUSlugsMKII_DWork.IntegerDelay2_X_e[0] = (1.0F);
  controlMCUSlugsMKII_DWork.IntegerDelay2_X_e[1] = (1.0F);

  /* Initialize code for chart: '<S124>/Embedded MATLAB Function1' */
  controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction1.internalTimer = 0U;
  controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction1.oldSw = 0U;

  /* Initial conditions for atomic system: '<S2>/Longitudinal Channel' */

  /* Initialize code for chart: '<S88>/Embedded MATLAB Function' */
  controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction_m.a_not_empty = false;

  /* Initialize code for chart: '<S90>/Embedded MATLAB Function' */
  controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction_l.a_not_empty = false;

  /* InitializeConditions for RateLimiter: '<S15>/Rate Limiter' */
  controlMCUSlugsMKII_DWork.PrevY = 180.0F;

  /* InitializeConditions for Memory: '<S94>/Memory1' */
  controlMCUSlugsMKII_DWork.Memory1_PreviousInput = 0.0F;

  /* Initialize code for chart: '<S89>/Embedded MATLAB Function' */
  controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction_j.a_not_empty = false;

  /* InitializeConditions for Memory: '<S92>/Memory1' */
  controlMCUSlugsMKII_DWork.Memory1_PreviousInput_e = 0.0F;

  /* InitializeConditions for Memory: '<S95>/Memory1' */
  controlMCUSlugsMKII_DWork.Memory1_PreviousInput_f = 0.0F;

  /* Initial conditions for atomic system: '<S2>/Lateral Channel' */

  /* Initialize code for chart: '<S45>/Embedded MATLAB Function' */
  controlMCUSlugsMKII_DWork.EmbeddedMATLABFunction.a_not_empty = false;

  /* InitializeConditions for Memory: '<S57>/Memory1' */
  controlMCUSlugsMKII_DWork.Memory1_PreviousInput_a = 0.0F;

  /* InitializeConditions for Memory: '<S55>/Memory1' */
  controlMCUSlugsMKII_DWork.Memory1_PreviousInput_l = 0.0F;
}

/* File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
