/*
 * File: controlMCUSlugsMKII_types.h
 *
 * Real-Time Workshop code generated for Simulink model controlMCUSlugsMKII.
 *
 * Model version                        : 1.716
 * Real-Time Workshop file version      : 6.6  (R2007a)  01-Feb-2007
 * Real-Time Workshop file generated on : Sat Nov 27 11:43:56 2010
 * TLC version                          : 6.6 (Jan 16 2007)
 * C source code generated on           : Sat Nov 27 11:43:58 2010
 *--------------------------------------------------------------
 *   Embedded Coder for Microchip dsPIC family.                 |
 *   Generate .c and .h files from your Matlab/simulink model   |
 *   and compile the diagram to .hex and .coff file that can be |
 *   downloaded directly into the microcontroller               |
 *                                                              |
 * Licence Accorded to Mariano I. Lizarraga                     |
 *                     University of California Santa Cruz (UCSC)|
 *                                                              |
 *   Written by Lubin KERHUEL -  http://www.kerhuel.eu          |
 *  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - |
 *   Version 0.99b+                            17-Mar-2009      |
 *   For Matlab 7.4             R2007a                          |
 *--------------------------------------------------------------
 */

#ifndef _RTW_HEADER_controlMCUSlugsMKII_types_h_
#define _RTW_HEADER_controlMCUSlugsMKII_types_h_
#ifndef _CSC37_CONTROLMCUSLUGSMKII_CHART_
#define _CSC37_CONTROLMCUSLUGSMKII_CHART_

typedef struct {
  real_T a;
  real_T b;
  real32_T u_km1;
  real32_T y_km1;
  boolean_T a_not_empty;
} CSc37_controlMCUSlugsMKII_Chart;

#endif                                 /* _CSC37_CONTROLMCUSLUGSMKII_CHART_ */

#ifndef _CSC49_CONTROLMCUSLUGSMKII_CHART_
#define _CSC49_CONTROLMCUSLUGSMKII_CHART_

typedef struct {
  real_T a;
  real_T b;
  real32_T u_km1;
  real32_T y_km1;
  boolean_T a_not_empty;
} CSc49_controlMCUSlugsMKII_Chart;

#endif                                 /* _CSC49_CONTROLMCUSLUGSMKII_CHART_ */

#ifndef _CSC14_CONTROLMCUSLUGSMKII_CHART_
#define _CSC14_CONTROLMCUSLUGSMKII_CHART_

typedef struct {
  real_T a;
  real_T b;
  real32_T u_km1;
  real32_T y_km1;
  boolean_T a_not_empty;
} CSc14_controlMCUSlugsMKII_Chart;

#endif                                 /* _CSC14_CONTROLMCUSLUGSMKII_CHART_ */

#ifndef _CSC48_CONTROLMCUSLUGSMKII_CHART_
#define _CSC48_CONTROLMCUSLUGSMKII_CHART_

typedef struct {
  real_T a;
  real_T b;
  real32_T u_km1;
  real32_T y_km1;
  boolean_T a_not_empty;
} CSc48_controlMCUSlugsMKII_Chart;

#endif                                 /* _CSC48_CONTROLMCUSLUGSMKII_CHART_ */

#ifndef _CSC10_CONTROLMCUSLUGSMKII_CHART_
#define _CSC10_CONTROLMCUSLUGSMKII_CHART_

typedef struct {
  boolean_T fromWP_not_empty;
  uint8_T fromWP;
  uint8_T toWP;
  uint8_T totoWP;
} CSc10_controlMCUSlugsMKII_Chart;

#endif                                 /* _CSC10_CONTROLMCUSLUGSMKII_CHART_ */

#ifndef _CSC11_CONTROLMCUSLUGSMKII_CHART_
#define _CSC11_CONTROLMCUSLUGSMKII_CHART_

typedef struct {
  uint16_T internalTimer;
  uint8_T oldSw;
} CSc11_controlMCUSlugsMKII_Chart;

#endif                                 /* _CSC11_CONTROLMCUSLUGSMKII_CHART_ */

#ifndef _CSC4_CONTROLMCUSLUGSMKII_CHARTS_
#define _CSC4_CONTROLMCUSLUGSMKII_CHARTS_

typedef struct {
  uint16_T oldValues[7];
} CSc4_controlMCUSlugsMKII_ChartS;

#endif                                 /* _CSC4_CONTROLMCUSLUGSMKII_CHARTS_ */

#ifndef _CSC6_CONTROLMCUSLUGSMKII_CHARTS_
#define _CSC6_CONTROLMCUSLUGSMKII_CHARTS_

typedef struct {
  uint16_T oldValues[7];
} CSc6_controlMCUSlugsMKII_ChartS;

#endif                                 /* _CSC6_CONTROLMCUSLUGSMKII_CHARTS_ */

#ifndef _CSC25_CONTROLMCUSLUGSMKII_CHART_
#define _CSC25_CONTROLMCUSLUGSMKII_CHART_

typedef struct {
  uint16_T oldValues[7];
} CSc25_controlMCUSlugsMKII_Chart;

#endif                                 /* _CSC25_CONTROLMCUSLUGSMKII_CHART_ */

#ifndef _CSC26_CONTROLMCUSLUGSMKII_CHART_
#define _CSC26_CONTROLMCUSLUGSMKII_CHART_

typedef struct {
  uint16_T oldValues[7];
} CSc26_controlMCUSlugsMKII_Chart;

#endif                                 /* _CSC26_CONTROLMCUSLUGSMKII_CHART_ */

/* Forward declaration for rtModel */
typedef struct RT_MODEL_controlMCUSlugsMKII RT_MODEL_controlMCUSlugsMKII;

#endif                                 /* _RTW_HEADER_controlMCUSlugsMKII_types_h_ */

/* File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
