/*
 * File: controlMCUSlugsMKII_main.c
 *
 * Real-Time Workshop code generated for Simulink model controlMCUSlugsMKII.
 *
 * Model version                        : 1.716
 * Real-Time Workshop file version      : 6.6  (R2007a)  01-Feb-2007
 * Real-Time Workshop file generated on : Sat Nov 27 11:43:56 2010
 * TLC version                          : 6.6 (Jan 16 2007)
 * C source code generated on           : Sat Nov 27 11:43:58 2010
 *--------------------------------------------------------------
 *   Embedded Coder for Microchip dsPIC family.                 |
 *   Generate .c and .h files from your Matlab/simulink model   |
 *   and compile the diagram to .hex and .coff file that can be |
 *   downloaded directly into the microcontroller               |
 *                                                              |
 * Licence Accorded to Mariano I. Lizarraga                     |
 *                     University of California Santa Cruz (UCSC)|
 *                                                              |
 *   Written by Lubin KERHUEL -  http://www.kerhuel.eu          |
 *  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - |
 *   Version 0.99b+                            17-Mar-2009      |
 *   For Matlab 7.4             R2007a                          |
 *--------------------------------------------------------------
 */

#include "controlMCUSlugsMKII.h"
#include "controlMCUSlugsMKII_private.h"

_FSS( RSS_NO_RAM & SSS_NO_FLASH & SWRP_WRPROTECT_OFF )
  _FGS( GCP_OFF & GSS_OFF & GWRP_OFF )
  _FOSCSEL( FNOSC_PRIPLL & IESO_OFF & 0xFFFF )
  _FOSC( FCKSM_CSDCMD & OSCIOFNC_OFF & POSCMD_EC)
  _FPOR( FPWRT_PWR64 )
  _FWDT( FWDTEN_OFF )
  unsigned int CalculusTimeStep;
void rt_OneStep()
{
  boolean_T eventFlags[2];
  int_T i;

  /* Disable interrupts here */
  /* Save FPU context here (if necessary) */
  /* Re-enable timer or interrupt here */
  controlMCUSlugsMKII_SetEventsForThisBaseStep(eventFlags);
  controlMCUSlugsMKII_step(0);
  for (i = 1; i < 2; i++) {
    if (eventFlags[i]) {
      controlMCUSlugsMKII_step(i);
    }
  }

  /* Disable interrupts here */
  /* Restore FPU context here (if necessary) */
  /* Enable interrupts here */
}

int main(void)
{
  PLLFBD = 38;                         /* configure clock speed */
  CLKDIV = 1;

  /* Initialize model */
  controlMCUSlugsMKII_initialize(1);

  /* Associate rt_OneStep() with a timer that executes at the base rate of the model */
  for (;;) {
    /* Associate rt_OneStep() with a timer that executes at the base rate of the model */
    while (!_T1IF) ;
    _T1IF = 0;
    rt_OneStep();
    if (_T1IF)
      CalculusTimeStep = PR1;          /* Overload */
    else
      CalculusTimeStep = TMR1;
  }
}

/* File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
