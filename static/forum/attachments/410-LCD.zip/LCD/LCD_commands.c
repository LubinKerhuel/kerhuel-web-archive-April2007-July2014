#include <p30fxxxx.h>
#include "LCD_Defines.h"

void LcdWrite(unsigned char dc,unsigned char data){
  char dump;
  PIN_DC  = (dc & 0x01);
  PIN_SCE = 0;
  dump = TXRX_SPI(data);
  PIN_SCE = 1;
}

void gotoXY(unsigned char x, unsigned char y){
  LcdWrite( LCD_C, (0x80 | x));  // Column.
  LcdWrite( LCD_C, (0x40 | y));  // Row.  ?
}

void LcdBmp(const unsigned char *my_array){
    int index =0;
  while (index < 504)
  {
    LcdWrite(LCD_D, *my_array++);
    index++;
  }
}

void LcdCharacter(char character){
  LcdWrite(LCD_D, 0x00);
  int index =0;
  character= (character - 20);
  while (index < 5)
  {
    LcdWrite(LCD_D, ASCII[character][index]);
    index++;
  }
  LcdWrite(LCD_D, 0x00);
}

void LcdBattery(char u1, char u2, char u3){
  gotoXY(u1,u2);
  int index =0;
  while (index < 25)
  {
    LcdWrite(LCD_D, Battery[u3][index]);
    index++;
  }
}

void LcdString(char *characters){
  while (*characters)
  {
    LcdCharacter(*characters++);
  }
}

void settobattxy(void){
  gotoXY(0,1);
}


void LcdClear(void){
  gotoXY(0x00, 0x00);
  int index =0;
  while (index < (LCD_X * LCD_Y / 8))
  {
    LcdWrite(LCD_D, 0x00);
    index++;
  }
}

void LcdInitialise(void){
  PIN_RESET = 0;
  PIN_RESET = 1;
  LcdWrite( LCD_C, 0x20);
  LcdWrite( LCD_C, 0x0C);
  LcdWrite( LCD_C, 0x21 ); // LCD Extended Commands.
  LcdWrite( LCD_C, 0xBf ); // Set LCD Vop (Contrast). //B1
  LcdWrite( LCD_C, 0x04 ); // Set Temp coefficent. //0x04
  LcdWrite( LCD_C, 0x14 ); // LCD bias mode 1:48. //0x13
  LcdWrite( LCD_C, 0x20 ); // Set normal instructions
  LcdWrite( LCD_C, 0x0C ); // LCD in normal mode. 0x0d for inverse
}


void EECS_Logos(void){
      LcdBmp(EECS);
}

void Intros(void){
      LcdBmp(Intro);
}

void Screen_Samples(void){
      LcdBmp(Sample);
}

void Screen_Defss(void){
      LcdBmp(Screen_Defs);
}
