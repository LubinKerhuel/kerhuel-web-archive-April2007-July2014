#include <p30fxxxx.h>

char TXRX_SPI(unsigned char u1){
    char y1;
    //Clear SPIROV error just in case
    SPI2STAT = SPI2STAT & 0xFFBF; 
    
    //Transmitt input
    SPI1BUF = u1;
    
    //Recieve Buffer
    y1 = SPI1BUF;
    return y1;
    
}
