#ifndef __c23_controlMCUSlugsMKII_h__
#define __c23_controlMCUSlugsMKII_h__

/* Include files */
#include "sfc_sf.h"
#include "sfc_mex.h"
#include "rtwtypes.h"

/* Type Definitions */
typedef struct {
  SimStruct *S;
  uint32_T chartNumber;
  uint32_T instanceNumber;
  boolean_T c23_doneDoubleBufferReInit;
  boolean_T c23_isStable;
  uint8_T c23_is_active_c23_controlMCUSlugsMKII;
  ChartInfoStruct chartInfo;
} SFc23_controlMCUSlugsMKIIInstanceStruct;

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */

/* Function Declarations */
extern const mxArray *sf_c23_controlMCUSlugsMKII_get_eml_resolved_functions_info
  (void);

/* Function Definitions */
extern void sf_c23_controlMCUSlugsMKII_get_check_sum(mxArray *plhs[]);
extern void c23_controlMCUSlugsMKII_method_dispatcher(SimStruct *S, int_T method,
  void *data);

#endif
