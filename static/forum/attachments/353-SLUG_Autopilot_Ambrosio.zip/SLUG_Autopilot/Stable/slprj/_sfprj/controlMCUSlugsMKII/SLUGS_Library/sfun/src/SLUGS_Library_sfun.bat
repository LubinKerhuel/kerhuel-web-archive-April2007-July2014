"c:\program files\matlab\r2010a\sys\lcc\bin\lccmake" -f SLUGS_Library_sfun.lmk
