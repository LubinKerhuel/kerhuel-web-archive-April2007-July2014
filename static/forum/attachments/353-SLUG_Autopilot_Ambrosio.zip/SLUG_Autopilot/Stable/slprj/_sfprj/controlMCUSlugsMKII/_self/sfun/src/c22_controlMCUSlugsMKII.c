/* Include files */

#include "blascompat32.h"
#include "controlMCUSlugsMKII_sfun.h"
#include "c22_controlMCUSlugsMKII.h"
#define CHARTINSTANCE_CHARTNUMBER      (chartInstance->chartNumber)
#define CHARTINSTANCE_INSTANCENUMBER   (chartInstance->instanceNumber)
#include "controlMCUSlugsMKII_sfun_debug_macros.h"

/* Type Definitions */

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */
static const char *c22_debug_family_names[7] = { "nargin", "nargout", "u1", "u2",
  "u3", "u4", "y" };

/* Function Declarations */
static void initialize_c22_controlMCUSlugsMKII
  (SFc22_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void initialize_params_c22_controlMCUSlugsMKII
  (SFc22_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void enable_c22_controlMCUSlugsMKII
  (SFc22_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void disable_c22_controlMCUSlugsMKII
  (SFc22_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void c22_update_debugger_state_c22_controlMCUSlugsMKII
  (SFc22_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static const mxArray *get_sim_state_c22_controlMCUSlugsMKII
  (SFc22_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void set_sim_state_c22_controlMCUSlugsMKII
  (SFc22_controlMCUSlugsMKIIInstanceStruct *chartInstance, const mxArray *c22_st);
static void finalize_c22_controlMCUSlugsMKII
  (SFc22_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void sf_c22_controlMCUSlugsMKII(SFc22_controlMCUSlugsMKIIInstanceStruct
  *chartInstance);
static void init_script_number_translation(uint32_T c22_machineNumber, uint32_T
  c22_chartNumber);
static const mxArray *c22_sf_marshall(void *chartInstanceVoid, void *c22_u);
static const mxArray *c22_b_sf_marshall(void *chartInstanceVoid, void *c22_u);
static const mxArray *c22_c_sf_marshall(void *chartInstanceVoid, void *c22_u);
static const mxArray *c22_d_sf_marshall(void *chartInstanceVoid, void *c22_u);
static void c22_emlrt_marshallIn(SFc22_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c22_y, const char_T *c22_name, uint16_T
  c22_b_y[4]);
static uint8_T c22_b_emlrt_marshallIn(SFc22_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c22_b_is_active_c22_controlMCUSlugsMKII, const
  char_T *c22_name);
static void init_dsm_address_info(SFc22_controlMCUSlugsMKIIInstanceStruct
  *chartInstance);

/* Function Definitions */
static void initialize_c22_controlMCUSlugsMKII
  (SFc22_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
  chartInstance->c22_is_active_c22_controlMCUSlugsMKII = 0U;
}

static void initialize_params_c22_controlMCUSlugsMKII
  (SFc22_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
}

static void enable_c22_controlMCUSlugsMKII
  (SFc22_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
}

static void disable_c22_controlMCUSlugsMKII
  (SFc22_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
}

static void c22_update_debugger_state_c22_controlMCUSlugsMKII
  (SFc22_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
}

static const mxArray *get_sim_state_c22_controlMCUSlugsMKII
  (SFc22_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
  const mxArray *c22_st = NULL;
  const mxArray *c22_y = NULL;
  int32_T c22_i0;
  uint16_T c22_hoistedGlobal[4];
  int32_T c22_i1;
  uint16_T c22_u[4];
  const mxArray *c22_b_y = NULL;
  uint8_T c22_b_hoistedGlobal;
  uint8_T c22_b_u;
  const mxArray *c22_c_y = NULL;
  uint16_T (*c22_d_y)[4];
  c22_d_y = (uint16_T (*)[4])ssGetOutputPortSignal(chartInstance->S, 1);
  c22_st = NULL;
  c22_y = NULL;
  sf_mex_assign(&c22_y, sf_mex_createcellarray(2));
  for (c22_i0 = 0; c22_i0 < 4; c22_i0 = c22_i0 + 1) {
    c22_hoistedGlobal[c22_i0] = (*c22_d_y)[c22_i0];
  }

  for (c22_i1 = 0; c22_i1 < 4; c22_i1 = c22_i1 + 1) {
    c22_u[c22_i1] = c22_hoistedGlobal[c22_i1];
  }

  c22_b_y = NULL;
  sf_mex_assign(&c22_b_y, sf_mex_create("y", &c22_u, 5, 0U, 1U, 0U, 1, 4));
  sf_mex_setcell(c22_y, 0, c22_b_y);
  c22_b_hoistedGlobal = chartInstance->c22_is_active_c22_controlMCUSlugsMKII;
  c22_b_u = c22_b_hoistedGlobal;
  c22_c_y = NULL;
  sf_mex_assign(&c22_c_y, sf_mex_create("y", &c22_b_u, 3, 0U, 0U, 0U, 0));
  sf_mex_setcell(c22_y, 1, c22_c_y);
  sf_mex_assign(&c22_st, c22_y);
  return c22_st;
}

static void set_sim_state_c22_controlMCUSlugsMKII
  (SFc22_controlMCUSlugsMKIIInstanceStruct *chartInstance, const mxArray *c22_st)
{
  const mxArray *c22_u;
  uint16_T c22_uv0[4];
  int32_T c22_i2;
  uint16_T (*c22_y)[4];
  c22_y = (uint16_T (*)[4])ssGetOutputPortSignal(chartInstance->S, 1);
  chartInstance->c22_doneDoubleBufferReInit = TRUE;
  c22_u = sf_mex_dup(c22_st);
  c22_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(c22_u, 0)), "y",
                       c22_uv0);
  for (c22_i2 = 0; c22_i2 < 4; c22_i2 = c22_i2 + 1) {
    (*c22_y)[c22_i2] = c22_uv0[c22_i2];
  }

  chartInstance->c22_is_active_c22_controlMCUSlugsMKII = c22_b_emlrt_marshallIn
    (chartInstance, sf_mex_dup(sf_mex_getcell(c22_u, 1)),
     "is_active_c22_controlMCUSlugsMKII");
  sf_mex_destroy(&c22_u);
  c22_update_debugger_state_c22_controlMCUSlugsMKII(chartInstance);
  sf_mex_destroy(&c22_st);
}

static void finalize_c22_controlMCUSlugsMKII
  (SFc22_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
}

static void sf_c22_controlMCUSlugsMKII(SFc22_controlMCUSlugsMKIIInstanceStruct
  *chartInstance)
{
  int32_T c22_i3;
  int32_T c22_previousEvent;
  uint16_T c22_hoistedGlobal;
  uint16_T c22_b_hoistedGlobal;
  uint16_T c22_c_hoistedGlobal;
  uint16_T c22_d_hoistedGlobal;
  uint16_T c22_u1;
  uint16_T c22_u2;
  uint16_T c22_u3;
  uint16_T c22_u4;
  uint32_T c22_debug_family_var_map[7];
  real_T c22_nargin = 4.0;
  real_T c22_nargout = 1.0;
  uint16_T c22_y[4];
  int32_T c22_i4;
  uint16_T *c22_b_u1;
  uint16_T *c22_b_u2;
  uint16_T *c22_b_u3;
  uint16_T *c22_b_u4;
  uint16_T (*c22_b_y)[4];
  c22_b_u4 = (uint16_T *)ssGetInputPortSignal(chartInstance->S, 3);
  c22_b_u3 = (uint16_T *)ssGetInputPortSignal(chartInstance->S, 2);
  c22_b_u2 = (uint16_T *)ssGetInputPortSignal(chartInstance->S, 1);
  c22_b_y = (uint16_T (*)[4])ssGetOutputPortSignal(chartInstance->S, 1);
  c22_b_u1 = (uint16_T *)ssGetInputPortSignal(chartInstance->S, 0);
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
  _SFD_CC_CALL(CHART_ENTER_SFUNCTION_TAG,21);
  _SFD_DATA_RANGE_CHECK((real_T)*c22_b_u1, 0U);
  for (c22_i3 = 0; c22_i3 < 4; c22_i3 = c22_i3 + 1) {
    _SFD_DATA_RANGE_CHECK((real_T)(*c22_b_y)[c22_i3], 1U);
  }

  _SFD_DATA_RANGE_CHECK((real_T)*c22_b_u2, 2U);
  _SFD_DATA_RANGE_CHECK((real_T)*c22_b_u3, 3U);
  _SFD_DATA_RANGE_CHECK((real_T)*c22_b_u4, 4U);
  c22_previousEvent = _sfEvent_;
  _sfEvent_ = CALL_EVENT;
  _SFD_CC_CALL(CHART_ENTER_DURING_FUNCTION_TAG,21);
  c22_hoistedGlobal = *c22_b_u1;
  c22_b_hoistedGlobal = *c22_b_u2;
  c22_c_hoistedGlobal = *c22_b_u3;
  c22_d_hoistedGlobal = *c22_b_u4;
  c22_u1 = c22_hoistedGlobal;
  c22_u2 = c22_b_hoistedGlobal;
  c22_u3 = c22_c_hoistedGlobal;
  c22_u4 = c22_d_hoistedGlobal;
  sf_debug_symbol_scope_push_eml(0U, 7U, 7U, c22_debug_family_names,
    c22_debug_family_var_map);
  sf_debug_symbol_scope_add_eml(&c22_nargin, c22_c_sf_marshall, 0U);
  sf_debug_symbol_scope_add_eml(&c22_nargout, c22_c_sf_marshall, 1U);
  sf_debug_symbol_scope_add_eml(&c22_u1, c22_b_sf_marshall, 2U);
  sf_debug_symbol_scope_add_eml(&c22_u2, c22_b_sf_marshall, 3U);
  sf_debug_symbol_scope_add_eml(&c22_u3, c22_b_sf_marshall, 4U);
  sf_debug_symbol_scope_add_eml(&c22_u4, c22_b_sf_marshall, 5U);
  sf_debug_symbol_scope_add_eml(&c22_y, c22_sf_marshall, 6U);
  CV_EML_FCN(0, 0);

  /*  This block supports an embeddable subset of the MATLAB language. */
  /*  See the help menu for details.  */
  _SFD_EML_CALL(0,5);
  c22_y[0] = c22_u1;
  c22_y[1] = c22_u2;
  c22_y[2] = c22_u3;
  c22_y[3] = c22_u4;
  _SFD_EML_CALL(0,-5);
  sf_debug_symbol_scope_pop();
  for (c22_i4 = 0; c22_i4 < 4; c22_i4 = c22_i4 + 1) {
    (*c22_b_y)[c22_i4] = c22_y[c22_i4];
  }

  _SFD_CC_CALL(EXIT_OUT_OF_FUNCTION_TAG,21);
  _sfEvent_ = c22_previousEvent;
  sf_debug_check_for_state_inconsistency(_controlMCUSlugsMKIIMachineNumber_,
    chartInstance->chartNumber, chartInstance->instanceNumber
    );
}

static void init_script_number_translation(uint32_T c22_machineNumber, uint32_T
  c22_chartNumber)
{
}

static const mxArray *c22_sf_marshall(void *chartInstanceVoid, void *c22_u)
{
  const mxArray *c22_y = NULL;
  int32_T c22_i5;
  uint16_T c22_b_u[4];
  const mxArray *c22_b_y = NULL;
  SFc22_controlMCUSlugsMKIIInstanceStruct *chartInstance;
  chartInstance = (SFc22_controlMCUSlugsMKIIInstanceStruct *)chartInstanceVoid;
  c22_y = NULL;
  for (c22_i5 = 0; c22_i5 < 4; c22_i5 = c22_i5 + 1) {
    c22_b_u[c22_i5] = (*((uint16_T (*)[4])c22_u))[c22_i5];
  }

  c22_b_y = NULL;
  sf_mex_assign(&c22_b_y, sf_mex_create("y", &c22_b_u, 5, 0U, 1U, 0U, 1, 4));
  sf_mex_assign(&c22_y, c22_b_y);
  return c22_y;
}

static const mxArray *c22_b_sf_marshall(void *chartInstanceVoid, void *c22_u)
{
  const mxArray *c22_y = NULL;
  uint16_T c22_b_u;
  const mxArray *c22_b_y = NULL;
  SFc22_controlMCUSlugsMKIIInstanceStruct *chartInstance;
  chartInstance = (SFc22_controlMCUSlugsMKIIInstanceStruct *)chartInstanceVoid;
  c22_y = NULL;
  c22_b_u = *((uint16_T *)c22_u);
  c22_b_y = NULL;
  sf_mex_assign(&c22_b_y, sf_mex_create("y", &c22_b_u, 5, 0U, 0U, 0U, 0));
  sf_mex_assign(&c22_y, c22_b_y);
  return c22_y;
}

static const mxArray *c22_c_sf_marshall(void *chartInstanceVoid, void *c22_u)
{
  const mxArray *c22_y = NULL;
  real_T c22_b_u;
  const mxArray *c22_b_y = NULL;
  SFc22_controlMCUSlugsMKIIInstanceStruct *chartInstance;
  chartInstance = (SFc22_controlMCUSlugsMKIIInstanceStruct *)chartInstanceVoid;
  c22_y = NULL;
  c22_b_u = *((real_T *)c22_u);
  c22_b_y = NULL;
  sf_mex_assign(&c22_b_y, sf_mex_create("y", &c22_b_u, 0, 0U, 0U, 0U, 0));
  sf_mex_assign(&c22_y, c22_b_y);
  return c22_y;
}

const mxArray *sf_c22_controlMCUSlugsMKII_get_eml_resolved_functions_info(void)
{
  const mxArray *c22_nameCaptureInfo = NULL;
  c22_nameCaptureInfo = NULL;
  sf_mex_assign(&c22_nameCaptureInfo, sf_mex_create("nameCaptureInfo", NULL, 0,
    0U, 1U, 0U, 2, 0, 1));
  return c22_nameCaptureInfo;
}

static const mxArray *c22_d_sf_marshall(void *chartInstanceVoid, void *c22_u)
{
  const mxArray *c22_y = NULL;
  boolean_T c22_b_u;
  const mxArray *c22_b_y = NULL;
  SFc22_controlMCUSlugsMKIIInstanceStruct *chartInstance;
  chartInstance = (SFc22_controlMCUSlugsMKIIInstanceStruct *)chartInstanceVoid;
  c22_y = NULL;
  c22_b_u = *((boolean_T *)c22_u);
  c22_b_y = NULL;
  sf_mex_assign(&c22_b_y, sf_mex_create("y", &c22_b_u, 11, 0U, 0U, 0U, 0));
  sf_mex_assign(&c22_y, c22_b_y);
  return c22_y;
}

static void c22_emlrt_marshallIn(SFc22_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c22_y, const char_T *
  c22_name, uint16_T c22_b_y[4])
{
  uint16_T c22_uv1[4];
  int32_T c22_i6;
  sf_mex_import(c22_name, sf_mex_dup(c22_y), &c22_uv1, 1, 5, 0U, 1, 0U, 1, 4);
  for (c22_i6 = 0; c22_i6 < 4; c22_i6 = c22_i6 + 1) {
    c22_b_y[c22_i6] = c22_uv1[c22_i6];
  }

  sf_mex_destroy(&c22_y);
}

static uint8_T c22_b_emlrt_marshallIn(SFc22_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *
  c22_b_is_active_c22_controlMCUSlugsMKII, const char_T *c22_name)
{
  uint8_T c22_y;
  uint8_T c22_u0;
  sf_mex_import(c22_name, sf_mex_dup(c22_b_is_active_c22_controlMCUSlugsMKII),
                &c22_u0, 1, 3, 0U, 0, 0U, 0);
  c22_y = c22_u0;
  sf_mex_destroy(&c22_b_is_active_c22_controlMCUSlugsMKII);
  return c22_y;
}

static void init_dsm_address_info(SFc22_controlMCUSlugsMKIIInstanceStruct
  *chartInstance)
{
}

/* SFunction Glue Code */
void sf_c22_controlMCUSlugsMKII_get_check_sum(mxArray *plhs[])
{
  ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(807721770U);
  ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(1331490828U);
  ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(968177574U);
  ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(875596107U);
}

mxArray *sf_c22_controlMCUSlugsMKII_get_autoinheritance_info(void)
{
  const char *autoinheritanceFields[] = { "checksum", "inputs", "parameters",
    "outputs" };

  mxArray *mxAutoinheritanceInfo = mxCreateStructMatrix(1,1,4,
    autoinheritanceFields);

  {
    mxArray *mxChecksum = mxCreateDoubleMatrix(4,1,mxREAL);
    double *pr = mxGetPr(mxChecksum);
    pr[0] = (double)(2330567122U);
    pr[1] = (double)(2549457914U);
    pr[2] = (double)(2103466949U);
    pr[3] = (double)(731398919U);
    mxSetField(mxAutoinheritanceInfo,0,"checksum",mxChecksum);
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,4,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(5));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,1,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(5));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,1,"type",mxType);
    }

    mxSetField(mxData,1,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,2,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(5));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,2,"type",mxType);
    }

    mxSetField(mxData,2,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,3,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(5));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,3,"type",mxType);
    }

    mxSetField(mxData,3,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"inputs",mxData);
  }

  {
    mxSetField(mxAutoinheritanceInfo,0,"parameters",mxCreateDoubleMatrix(0,0,
                mxREAL));
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,1,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(4);
      pr[1] = (double)(1);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(5));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"outputs",mxData);
  }

  return(mxAutoinheritanceInfo);
}

static mxArray *sf_get_sim_state_info_c22_controlMCUSlugsMKII(void)
{
  const char *infoFields[] = { "chartChecksum", "varInfo" };

  mxArray *mxInfo = mxCreateStructMatrix(1, 1, 2, infoFields);
  const char *infoEncStr[] = {
    "100 S1x2'type','srcId','name','auxInfo'{{M[1],M[5],T\"y\",},{M[8],M[0],T\"is_active_c22_controlMCUSlugsMKII\",}}"
  };

  mxArray *mxVarInfo = sf_mex_decode_encoded_mx_struct_array(infoEncStr, 2, 10);
  mxArray *mxChecksum = mxCreateDoubleMatrix(1, 4, mxREAL);
  sf_c22_controlMCUSlugsMKII_get_check_sum(&mxChecksum);
  mxSetField(mxInfo, 0, infoFields[0], mxChecksum);
  mxSetField(mxInfo, 0, infoFields[1], mxVarInfo);
  return mxInfo;
}

static void chart_debug_initialization(SimStruct *S, unsigned int
  fullDebuggerInitialization)
{
  if (!sim_mode_is_rtw_gen(S)) {
    SFc22_controlMCUSlugsMKIIInstanceStruct *chartInstance;
    chartInstance = (SFc22_controlMCUSlugsMKIIInstanceStruct *)
      ((ChartInfoStruct *)(ssGetUserData(S)))->chartInstance;
    if (ssIsFirstInitCond(S) && fullDebuggerInitialization==1) {
      /* do this only if simulation is starting */
      {
        unsigned int chartAlreadyPresent;
        chartAlreadyPresent = sf_debug_initialize_chart
          (_controlMCUSlugsMKIIMachineNumber_,
           22,
           1,
           1,
           5,
           0,
           0,
           0,
           0,
           0,
           &(chartInstance->chartNumber),
           &(chartInstance->instanceNumber),
           ssGetPath(S),
           (void *)S);
        if (chartAlreadyPresent==0) {
          /* this is the first instance */
          init_script_number_translation(_controlMCUSlugsMKIIMachineNumber_,
            chartInstance->chartNumber);
          sf_debug_set_chart_disable_implicit_casting
            (_controlMCUSlugsMKIIMachineNumber_,chartInstance->chartNumber,1);
          sf_debug_set_chart_event_thresholds(_controlMCUSlugsMKIIMachineNumber_,
            chartInstance->chartNumber,
            0,
            0,
            0);
          _SFD_SET_DATA_PROPS(0,1,1,0,SF_UINT16,0,NULL,0,0,0,0.0,1.0,0,"u1",0,
                              (MexFcnForType)c22_b_sf_marshall);

          {
            unsigned int dimVector[1];
            dimVector[0]= 4;
            _SFD_SET_DATA_PROPS(1,2,0,1,SF_UINT16,1,&(dimVector[0]),0,0,0,0.0,
                                1.0,0,"y",0,(MexFcnForType)c22_sf_marshall);
          }

          _SFD_SET_DATA_PROPS(2,1,1,0,SF_UINT16,0,NULL,0,0,0,0.0,1.0,0,"u2",0,
                              (MexFcnForType)c22_b_sf_marshall);
          _SFD_SET_DATA_PROPS(3,1,1,0,SF_UINT16,0,NULL,0,0,0,0.0,1.0,0,"u3",0,
                              (MexFcnForType)c22_b_sf_marshall);
          _SFD_SET_DATA_PROPS(4,1,1,0,SF_UINT16,0,NULL,0,0,0,0.0,1.0,0,"u4",0,
                              (MexFcnForType)c22_b_sf_marshall);
          _SFD_STATE_INFO(0,0,2);
          _SFD_CH_SUBSTATE_COUNT(0);
          _SFD_CH_SUBSTATE_DECOMP(0);
        }

        _SFD_CV_INIT_CHART(0,0,0,0);

        {
          _SFD_CV_INIT_STATE(0,0,0,0,0,0,NULL,NULL);
        }

        _SFD_CV_INIT_TRANS(0,0,NULL,NULL,0,NULL);

        /* Initialization of EML Model Coverage */
        _SFD_CV_INIT_EML(0,1,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML_FCN(0,0,"eML_blk_kernel",0,-1,171);
        _SFD_TRANS_COV_WTS(0,0,0,1,0);
        if (chartAlreadyPresent==0) {
          _SFD_TRANS_COV_MAPS(0,
                              0,NULL,NULL,
                              0,NULL,NULL,
                              1,NULL,NULL,
                              0,NULL,NULL);
        }

        {
          uint16_T *c22_u1;
          uint16_T (*c22_y)[4];
          uint16_T *c22_u2;
          uint16_T *c22_u3;
          uint16_T *c22_u4;
          c22_u4 = (uint16_T *)ssGetInputPortSignal(chartInstance->S, 3);
          c22_u3 = (uint16_T *)ssGetInputPortSignal(chartInstance->S, 2);
          c22_u2 = (uint16_T *)ssGetInputPortSignal(chartInstance->S, 1);
          c22_y = (uint16_T (*)[4])ssGetOutputPortSignal(chartInstance->S, 1);
          c22_u1 = (uint16_T *)ssGetInputPortSignal(chartInstance->S, 0);
          _SFD_SET_DATA_VALUE_PTR(0U, c22_u1);
          _SFD_SET_DATA_VALUE_PTR(1U, c22_y);
          _SFD_SET_DATA_VALUE_PTR(2U, c22_u2);
          _SFD_SET_DATA_VALUE_PTR(3U, c22_u3);
          _SFD_SET_DATA_VALUE_PTR(4U, c22_u4);
        }
      }
    } else {
      sf_debug_reset_current_state_configuration
        (_controlMCUSlugsMKIIMachineNumber_,chartInstance->chartNumber,
         chartInstance->instanceNumber);
    }
  }
}

static void sf_opaque_initialize_c22_controlMCUSlugsMKII(void *chartInstanceVar)
{
  chart_debug_initialization(((SFc22_controlMCUSlugsMKIIInstanceStruct*)
    chartInstanceVar)->S,0);
  initialize_params_c22_controlMCUSlugsMKII
    ((SFc22_controlMCUSlugsMKIIInstanceStruct*) chartInstanceVar);
  initialize_c22_controlMCUSlugsMKII((SFc22_controlMCUSlugsMKIIInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_enable_c22_controlMCUSlugsMKII(void *chartInstanceVar)
{
  enable_c22_controlMCUSlugsMKII((SFc22_controlMCUSlugsMKIIInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_disable_c22_controlMCUSlugsMKII(void *chartInstanceVar)
{
  disable_c22_controlMCUSlugsMKII((SFc22_controlMCUSlugsMKIIInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_gateway_c22_controlMCUSlugsMKII(void *chartInstanceVar)
{
  sf_c22_controlMCUSlugsMKII((SFc22_controlMCUSlugsMKIIInstanceStruct*)
    chartInstanceVar);
}

static mxArray* sf_internal_get_sim_state_c22_controlMCUSlugsMKII(SimStruct* S)
{
  ChartInfoStruct *chartInfo = (ChartInfoStruct*) ssGetUserData(S);
  mxArray *plhs[1] = { NULL };

  mxArray *prhs[4];
  int mxError = 0;
  prhs[0] = mxCreateString("chart_simctx_raw2high");
  prhs[1] = mxCreateDoubleScalar(ssGetSFuncBlockHandle(S));
  prhs[2] = (mxArray*) get_sim_state_c22_controlMCUSlugsMKII
    ((SFc22_controlMCUSlugsMKIIInstanceStruct*)chartInfo->chartInstance);/* raw sim ctx */
  prhs[3] = sf_get_sim_state_info_c22_controlMCUSlugsMKII();/* state var info */
  mxError = sf_mex_call_matlab(1, plhs, 4, prhs, "sfprivate");
  mxDestroyArray(prhs[0]);
  mxDestroyArray(prhs[1]);
  mxDestroyArray(prhs[2]);
  mxDestroyArray(prhs[3]);
  if (mxError || plhs[0] == NULL) {
    sf_mex_error_message("Stateflow Internal Error: \nError calling 'chart_simctx_raw2high'.\n");
  }

  return plhs[0];
}

static void sf_internal_set_sim_state_c22_controlMCUSlugsMKII(SimStruct* S,
  const mxArray *st)
{
  ChartInfoStruct *chartInfo = (ChartInfoStruct*) ssGetUserData(S);
  mxArray *plhs[1] = { NULL };

  mxArray *prhs[4];
  int mxError = 0;
  prhs[0] = mxCreateString("chart_simctx_high2raw");
  prhs[1] = mxCreateDoubleScalar(ssGetSFuncBlockHandle(S));
  prhs[2] = mxDuplicateArray(st);      /* high level simctx */
  prhs[3] = (mxArray*) sf_get_sim_state_info_c22_controlMCUSlugsMKII();/* state var info */
  mxError = sf_mex_call_matlab(1, plhs, 4, prhs, "sfprivate");
  mxDestroyArray(prhs[0]);
  mxDestroyArray(prhs[1]);
  mxDestroyArray(prhs[2]);
  mxDestroyArray(prhs[3]);
  if (mxError || plhs[0] == NULL) {
    sf_mex_error_message("Stateflow Internal Error: \nError calling 'chart_simctx_high2raw'.\n");
  }

  set_sim_state_c22_controlMCUSlugsMKII((SFc22_controlMCUSlugsMKIIInstanceStruct*)
    chartInfo->chartInstance, mxDuplicateArray(plhs[0]));
  mxDestroyArray(plhs[0]);
}

static mxArray* sf_opaque_get_sim_state_c22_controlMCUSlugsMKII(SimStruct* S)
{
  return sf_internal_get_sim_state_c22_controlMCUSlugsMKII(S);
}

static void sf_opaque_set_sim_state_c22_controlMCUSlugsMKII(SimStruct* S, const
  mxArray *st)
{
  sf_internal_set_sim_state_c22_controlMCUSlugsMKII(S, st);
}

static void sf_opaque_terminate_c22_controlMCUSlugsMKII(void *chartInstanceVar)
{
  if (chartInstanceVar!=NULL) {
    SimStruct *S = ((SFc22_controlMCUSlugsMKIIInstanceStruct*) chartInstanceVar
      )->S;
    if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
      sf_clear_rtw_identifier(S);
    }

    finalize_c22_controlMCUSlugsMKII((SFc22_controlMCUSlugsMKIIInstanceStruct*)
      chartInstanceVar);
    free((void *)chartInstanceVar);
    ssSetUserData(S,NULL);
  }
}

extern unsigned int sf_machine_global_initializer_called(void);
static void mdlProcessParameters_c22_controlMCUSlugsMKII(SimStruct *S)
{
  int i;
  for (i=0;i<ssGetNumRunTimeParams(S);i++) {
    if (ssGetSFcnParamTunable(S,i)) {
      ssUpdateDlgParamAsRunTimeParam(S,i);
    }
  }

  if (sf_machine_global_initializer_called()) {
    initialize_params_c22_controlMCUSlugsMKII
      ((SFc22_controlMCUSlugsMKIIInstanceStruct*)(((ChartInfoStruct *)
         ssGetUserData(S))->chartInstance));
  }
}

static void mdlSetWorkWidths_c22_controlMCUSlugsMKII(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
    int_T chartIsInlinable =
      (int_T)sf_is_chart_inlinable("controlMCUSlugsMKII","controlMCUSlugsMKII",
      22);
    ssSetStateflowIsInlinable(S,chartIsInlinable);
    ssSetRTWCG(S,sf_rtw_info_uint_prop("controlMCUSlugsMKII",
                "controlMCUSlugsMKII",22,"RTWCG"));
    ssSetEnableFcnIsTrivial(S,1);
    ssSetDisableFcnIsTrivial(S,1);
    ssSetNotMultipleInlinable(S,sf_rtw_info_uint_prop("controlMCUSlugsMKII",
      "controlMCUSlugsMKII",22,"gatewayCannotBeInlinedMultipleTimes"));
    if (chartIsInlinable) {
      ssSetInputPortOptimOpts(S, 0, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 1, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 2, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 3, SS_REUSABLE_AND_LOCAL);
      sf_mark_chart_expressionable_inputs(S,"controlMCUSlugsMKII",
        "controlMCUSlugsMKII",22,4);
      sf_mark_chart_reusable_outputs(S,"controlMCUSlugsMKII",
        "controlMCUSlugsMKII",22,1);
    }

    sf_set_rtw_dwork_info(S,"controlMCUSlugsMKII","controlMCUSlugsMKII",22);
    ssSetHasSubFunctions(S,!(chartIsInlinable));
    ssSetOptions(S,ssGetOptions(S)|SS_OPTION_WORKS_WITH_CODE_REUSE);
  }

  ssSetChecksum0(S,(2215375743U));
  ssSetChecksum1(S,(4216114592U));
  ssSetChecksum2(S,(2724518855U));
  ssSetChecksum3(S,(1940166138U));
  ssSetmdlDerivatives(S, NULL);
  ssSetExplicitFCSSCtrl(S,1);
}

static void mdlRTW_c22_controlMCUSlugsMKII(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S)) {
    sf_write_symbol_mapping(S, "controlMCUSlugsMKII", "controlMCUSlugsMKII",22);
    ssWriteRTWStrParam(S, "StateflowChartType", "Embedded MATLAB");
  }
}

static void mdlStart_c22_controlMCUSlugsMKII(SimStruct *S)
{
  SFc22_controlMCUSlugsMKIIInstanceStruct *chartInstance;
  chartInstance = (SFc22_controlMCUSlugsMKIIInstanceStruct *)malloc(sizeof
    (SFc22_controlMCUSlugsMKIIInstanceStruct));
  memset(chartInstance, 0, sizeof(SFc22_controlMCUSlugsMKIIInstanceStruct));
  if (chartInstance==NULL) {
    sf_mex_error_message("Could not allocate memory for chart instance.");
  }

  chartInstance->chartInfo.chartInstance = chartInstance;
  chartInstance->chartInfo.isEMLChart = 1;
  chartInstance->chartInfo.chartInitialized = 0;
  chartInstance->chartInfo.sFunctionGateway =
    sf_opaque_gateway_c22_controlMCUSlugsMKII;
  chartInstance->chartInfo.initializeChart =
    sf_opaque_initialize_c22_controlMCUSlugsMKII;
  chartInstance->chartInfo.terminateChart =
    sf_opaque_terminate_c22_controlMCUSlugsMKII;
  chartInstance->chartInfo.enableChart =
    sf_opaque_enable_c22_controlMCUSlugsMKII;
  chartInstance->chartInfo.disableChart =
    sf_opaque_disable_c22_controlMCUSlugsMKII;
  chartInstance->chartInfo.getSimState =
    sf_opaque_get_sim_state_c22_controlMCUSlugsMKII;
  chartInstance->chartInfo.setSimState =
    sf_opaque_set_sim_state_c22_controlMCUSlugsMKII;
  chartInstance->chartInfo.getSimStateInfo =
    sf_get_sim_state_info_c22_controlMCUSlugsMKII;
  chartInstance->chartInfo.zeroCrossings = NULL;
  chartInstance->chartInfo.outputs = NULL;
  chartInstance->chartInfo.derivatives = NULL;
  chartInstance->chartInfo.mdlRTW = mdlRTW_c22_controlMCUSlugsMKII;
  chartInstance->chartInfo.mdlStart = mdlStart_c22_controlMCUSlugsMKII;
  chartInstance->chartInfo.mdlSetWorkWidths =
    mdlSetWorkWidths_c22_controlMCUSlugsMKII;
  chartInstance->chartInfo.extModeExec = NULL;
  chartInstance->chartInfo.restoreLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.restoreBeforeLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.storeCurrentConfiguration = NULL;
  chartInstance->S = S;
  ssSetUserData(S,(void *)(&(chartInstance->chartInfo)));/* register the chart instance with simstruct */
  if (!sim_mode_is_rtw_gen(S)) {
    init_dsm_address_info(chartInstance);
  }

  chart_debug_initialization(S,1);
}

void c22_controlMCUSlugsMKII_method_dispatcher(SimStruct *S, int_T method, void *
  data)
{
  switch (method) {
   case SS_CALL_MDL_START:
    mdlStart_c22_controlMCUSlugsMKII(S);
    break;

   case SS_CALL_MDL_SET_WORK_WIDTHS:
    mdlSetWorkWidths_c22_controlMCUSlugsMKII(S);
    break;

   case SS_CALL_MDL_PROCESS_PARAMETERS:
    mdlProcessParameters_c22_controlMCUSlugsMKII(S);
    break;

   default:
    /* Unhandled method */
    sf_mex_error_message("Stateflow Internal Error:\n"
                         "Error calling c22_controlMCUSlugsMKII_method_dispatcher.\n"
                         "Can't handle method %d.\n", method);
    break;
  }
}
