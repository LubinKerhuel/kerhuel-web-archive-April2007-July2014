"c:\program files\matlab\r2010a\sys\lcc\bin\lccmake" -f controlMCUSlugsMKII_sfun.lmk
