/* Include files */

#include "blascompat32.h"
#include "controlMCUSlugsMKII_sfun.h"
#include "c10_controlMCUSlugsMKII.h"

/* Type Definitions */

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */

/* Function Declarations */
static void initialize_c10_controlMCUSlugsMKII
  (SFc10_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void initialize_params_c10_controlMCUSlugsMKII
  (SFc10_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void enable_c10_controlMCUSlugsMKII
  (SFc10_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void disable_c10_controlMCUSlugsMKII
  (SFc10_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static const mxArray *get_sim_state_c10_controlMCUSlugsMKII
  (SFc10_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void set_sim_state_c10_controlMCUSlugsMKII
  (SFc10_controlMCUSlugsMKIIInstanceStruct *chartInstance, const mxArray *c10_st);
static void finalize_c10_controlMCUSlugsMKII
  (SFc10_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void sf_c10_controlMCUSlugsMKII(SFc10_controlMCUSlugsMKIIInstanceStruct
  *chartInstance);
static void init_script_number_translation(uint32_T c10_machineNumber, uint32_T
  c10_chartNumber);
static uint8_T c10_emlrt_marshallIn(SFc10_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c10_wp0, const char_T *c10_name);
static uint8_T c10_b_emlrt_marshallIn(SFc10_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c10_b_fromWP, const char_T *c10_name);
static uint8_T c10_c_emlrt_marshallIn(SFc10_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c10_b_toWP, const char_T *c10_name);
static uint8_T c10_d_emlrt_marshallIn(SFc10_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c10_b_totoWP, const char_T *c10_name);
static void init_dsm_address_info(SFc10_controlMCUSlugsMKIIInstanceStruct
  *chartInstance);

/* Function Definitions */
static void initialize_c10_controlMCUSlugsMKII
  (SFc10_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
  chartInstance->c10_fromWP_not_empty = FALSE;
  chartInstance->c10_toWP_not_empty = FALSE;
  chartInstance->c10_totoWP_not_empty = FALSE;
  chartInstance->c10_is_active_c10_controlMCUSlugsMKII = 0U;
}

static void initialize_params_c10_controlMCUSlugsMKII
  (SFc10_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
}

static void enable_c10_controlMCUSlugsMKII
  (SFc10_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
}

static void disable_c10_controlMCUSlugsMKII
  (SFc10_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
}

static const mxArray *get_sim_state_c10_controlMCUSlugsMKII
  (SFc10_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
  const mxArray *c10_st;
  const mxArray *c10_y = NULL;
  uint8_T c10_u;
  const mxArray *c10_b_y = NULL;
  uint8_T c10_b_u;
  const mxArray *c10_c_y = NULL;
  uint8_T c10_c_u;
  const mxArray *c10_d_y = NULL;
  uint8_T c10_d_u;
  const mxArray *c10_e_y = NULL;
  uint8_T c10_e_u;
  const mxArray *c10_f_y = NULL;
  uint8_T c10_f_u;
  const mxArray *c10_g_y = NULL;
  uint8_T c10_g_u;
  const mxArray *c10_h_y = NULL;
  uint8_T *c10_wp0;
  uint8_T *c10_wp1;
  uint8_T *c10_wp2;
  c10_wp2 = (uint8_T *)ssGetOutputPortSignal(chartInstance->S, 3);
  c10_wp1 = (uint8_T *)ssGetOutputPortSignal(chartInstance->S, 2);
  c10_wp0 = (uint8_T *)ssGetOutputPortSignal(chartInstance->S, 1);
  c10_st = NULL;
  c10_st = NULL;
  c10_y = NULL;
  sf_mex_assign(&c10_y, sf_mex_createcellarray(7));
  c10_u = *c10_wp0;
  c10_b_y = NULL;
  sf_mex_assign(&c10_b_y, sf_mex_create("y", &c10_u, 3, 0U, 0U, 0U, 0));
  sf_mex_setcell(c10_y, 0, c10_b_y);
  c10_b_u = *c10_wp1;
  c10_c_y = NULL;
  sf_mex_assign(&c10_c_y, sf_mex_create("y", &c10_b_u, 3, 0U, 0U, 0U, 0));
  sf_mex_setcell(c10_y, 1, c10_c_y);
  c10_c_u = *c10_wp2;
  c10_d_y = NULL;
  sf_mex_assign(&c10_d_y, sf_mex_create("y", &c10_c_u, 3, 0U, 0U, 0U, 0));
  sf_mex_setcell(c10_y, 2, c10_d_y);
  c10_d_u = chartInstance->c10_fromWP;
  c10_e_y = NULL;
  if (!chartInstance->c10_fromWP_not_empty) {
    sf_mex_assign(&c10_e_y, sf_mex_create("y", NULL, 0, 0U, 1U, 0U, 2, 0, 0));
  } else {
    sf_mex_assign(&c10_e_y, sf_mex_create("y", &c10_d_u, 3, 0U, 0U, 0U, 0));
  }

  sf_mex_setcell(c10_y, 3, c10_e_y);
  c10_e_u = chartInstance->c10_toWP;
  c10_f_y = NULL;
  if (!chartInstance->c10_toWP_not_empty) {
    sf_mex_assign(&c10_f_y, sf_mex_create("y", NULL, 0, 0U, 1U, 0U, 2, 0, 0));
  } else {
    sf_mex_assign(&c10_f_y, sf_mex_create("y", &c10_e_u, 3, 0U, 0U, 0U, 0));
  }

  sf_mex_setcell(c10_y, 4, c10_f_y);
  c10_f_u = chartInstance->c10_totoWP;
  c10_g_y = NULL;
  if (!chartInstance->c10_totoWP_not_empty) {
    sf_mex_assign(&c10_g_y, sf_mex_create("y", NULL, 0, 0U, 1U, 0U, 2, 0, 0));
  } else {
    sf_mex_assign(&c10_g_y, sf_mex_create("y", &c10_f_u, 3, 0U, 0U, 0U, 0));
  }

  sf_mex_setcell(c10_y, 5, c10_g_y);
  c10_g_u = chartInstance->c10_is_active_c10_controlMCUSlugsMKII;
  c10_h_y = NULL;
  sf_mex_assign(&c10_h_y, sf_mex_create("y", &c10_g_u, 3, 0U, 0U, 0U, 0));
  sf_mex_setcell(c10_y, 6, c10_h_y);
  sf_mex_assign(&c10_st, c10_y);
  return c10_st;
}

static void set_sim_state_c10_controlMCUSlugsMKII
  (SFc10_controlMCUSlugsMKIIInstanceStruct *chartInstance, const mxArray *c10_st)
{
  const mxArray *c10_u;
  uint8_T *c10_wp0;
  uint8_T *c10_wp1;
  uint8_T *c10_wp2;
  c10_wp2 = (uint8_T *)ssGetOutputPortSignal(chartInstance->S, 3);
  c10_wp1 = (uint8_T *)ssGetOutputPortSignal(chartInstance->S, 2);
  c10_wp0 = (uint8_T *)ssGetOutputPortSignal(chartInstance->S, 1);
  c10_u = sf_mex_dup(c10_st);
  *c10_wp0 = c10_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(c10_u,
    0)), "wp0");
  *c10_wp1 = c10_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(c10_u,
    1)), "wp1");
  *c10_wp2 = c10_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(c10_u,
    2)), "wp2");
  chartInstance->c10_fromWP = c10_b_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getcell(c10_u, 3)), "fromWP");
  chartInstance->c10_toWP = c10_c_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getcell(c10_u, 4)), "toWP");
  chartInstance->c10_totoWP = c10_d_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getcell(c10_u, 5)), "totoWP");
  chartInstance->c10_is_active_c10_controlMCUSlugsMKII = c10_emlrt_marshallIn
    (chartInstance, sf_mex_dup(sf_mex_getcell(c10_u, 6)),
     "is_active_c10_controlMCUSlugsMKII");
  sf_mex_destroy(&c10_u);
  sf_mex_destroy(&c10_st);
}

static void finalize_c10_controlMCUSlugsMKII
  (SFc10_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
}

static void sf_c10_controlMCUSlugsMKII(SFc10_controlMCUSlugsMKIIInstanceStruct
  *chartInstance)
{
  int32_T c10_previousEvent;
  int32_T c10_i0;
  uint8_T c10_u0;
  uint8_T *c10_wp0;
  uint8_T *c10_wp1;
  uint8_T *c10_wp2;
  uint8_T *c10_wpStart;
  uint8_T *c10_wpCount;
  uint8_T *c10_wpEnabl;
  real_T *c10_swIncrement;
  c10_wpEnabl = (uint8_T *)ssGetInputPortSignal(chartInstance->S, 3);
  c10_wp2 = (uint8_T *)ssGetOutputPortSignal(chartInstance->S, 3);
  c10_wp1 = (uint8_T *)ssGetOutputPortSignal(chartInstance->S, 2);
  c10_swIncrement = (real_T *)ssGetInputPortSignal(chartInstance->S, 2);
  c10_wp0 = (uint8_T *)ssGetOutputPortSignal(chartInstance->S, 1);
  c10_wpCount = (uint8_T *)ssGetInputPortSignal(chartInstance->S, 1);
  c10_wpStart = (uint8_T *)ssGetInputPortSignal(chartInstance->S, 0);
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
  c10_previousEvent = _sfEvent_;
  _sfEvent_ = CALL_EVENT;

  /*  Declare static variables */
  /* initialize the static variables */
  if (!chartInstance->c10_fromWP_not_empty) {
    chartInstance->c10_fromWP = *c10_wpStart;
    chartInstance->c10_fromWP_not_empty = TRUE;
    c10_i0 = chartInstance->c10_fromWP + 1;
    if ((uint32_T)c10_i0 > 255U) {
      chartInstance->c10_toWP = MAX_uint8_T;
    } else {
      chartInstance->c10_toWP = (uint8_T)c10_i0;
    }

    chartInstance->c10_toWP_not_empty = TRUE;

    /*  check if there are more than 2 WPs */
    c10_i0 = chartInstance->c10_toWP + 1;
    if ((uint32_T)c10_i0 > 255U) {
      c10_u0 = MAX_uint8_T;
    } else {
      c10_u0 = (uint8_T)c10_i0;
    }

    if (*c10_wpCount > c10_u0) {
      c10_i0 = chartInstance->c10_toWP + 1;
      if ((uint32_T)c10_i0 > 255U) {
        chartInstance->c10_totoWP = MAX_uint8_T;
      } else {
        chartInstance->c10_totoWP = (uint8_T)c10_i0;
      }

      chartInstance->c10_totoWP_not_empty = TRUE;
    } else {
      chartInstance->c10_totoWP = chartInstance->c10_fromWP;
      chartInstance->c10_totoWP_not_empty = TRUE;
    }
  }

  /* if WP Nav was just enabled */
  if (*c10_wpEnabl == 1) {
    chartInstance->c10_fromWP = 0U;
    chartInstance->c10_toWP = 1U;
    chartInstance->c10_totoWP = 2U;
  }

  /*  if there is a change of wp */
  if (*c10_swIncrement == 1.0) {
    chartInstance->c10_fromWP = chartInstance->c10_toWP;
    chartInstance->c10_toWP = chartInstance->c10_totoWP;
    c10_i0 = chartInstance->c10_totoWP + 1;
    if ((uint32_T)c10_i0 > 255U) {
      chartInstance->c10_totoWP = MAX_uint8_T;
    } else {
      chartInstance->c10_totoWP = (uint8_T)c10_i0;
    }

    if (chartInstance->c10_totoWP > *c10_wpCount) {
      chartInstance->c10_totoWP = *c10_wpStart;
    }
  }

  *c10_wp0 = chartInstance->c10_fromWP;
  *c10_wp1 = chartInstance->c10_toWP;
  *c10_wp2 = chartInstance->c10_totoWP;
  _sfEvent_ = c10_previousEvent;
}

static void init_script_number_translation(uint32_T c10_machineNumber, uint32_T
  c10_chartNumber)
{
}

const mxArray *sf_c10_controlMCUSlugsMKII_get_eml_resolved_functions_info(void)
{
  const mxArray *c10_nameCaptureInfo;
  c10_ResolvedFunctionInfo c10_info[4];
  c10_ResolvedFunctionInfo (*c10_b_info)[4];
  const mxArray *c10_m0 = NULL;
  int32_T c10_i1;
  c10_ResolvedFunctionInfo *c10_r0;
  c10_nameCaptureInfo = NULL;
  c10_nameCaptureInfo = NULL;
  c10_b_info = (c10_ResolvedFunctionInfo (*)[4])c10_info;
  (*c10_b_info)[0].context = "";
  (*c10_b_info)[0].name = "uint8";
  (*c10_b_info)[0].dominantType = "uint8";
  (*c10_b_info)[0].resolved = "[B]uint8";
  (*c10_b_info)[0].fileLength = 0U;
  (*c10_b_info)[0].fileTime1 = 0U;
  (*c10_b_info)[0].fileTime2 = 0U;
  (*c10_b_info)[1].context = "";
  (*c10_b_info)[1].name = "plus";
  (*c10_b_info)[1].dominantType = "uint8";
  (*c10_b_info)[1].resolved = "[B]plus";
  (*c10_b_info)[1].fileLength = 0U;
  (*c10_b_info)[1].fileTime1 = 0U;
  (*c10_b_info)[1].fileTime2 = 0U;
  (*c10_b_info)[2].context = "";
  (*c10_b_info)[2].name = "gt";
  (*c10_b_info)[2].dominantType = "uint8";
  (*c10_b_info)[2].resolved = "[B]gt";
  (*c10_b_info)[2].fileLength = 0U;
  (*c10_b_info)[2].fileTime1 = 0U;
  (*c10_b_info)[2].fileTime2 = 0U;
  (*c10_b_info)[3].context = "";
  (*c10_b_info)[3].name = "eq";
  (*c10_b_info)[3].dominantType = "uint8";
  (*c10_b_info)[3].resolved = "[B]eq";
  (*c10_b_info)[3].fileLength = 0U;
  (*c10_b_info)[3].fileTime1 = 0U;
  (*c10_b_info)[3].fileTime2 = 0U;
  sf_mex_assign(&c10_m0, sf_mex_createstruct("nameCaptureInfo", 1, 4));
  for (c10_i1 = 0; c10_i1 < 4; c10_i1 = c10_i1 + 1) {
    c10_r0 = &c10_info[c10_i1];
    sf_mex_addfield(c10_m0, sf_mex_create("nameCaptureInfo", (const char *)
      c10_r0->context, 15, 0U, 0U, 0U, 2, 1, strlen((const char *)
      c10_r0->context)), "context", "nameCaptureInfo", c10_i1);
    sf_mex_addfield(c10_m0, sf_mex_create("nameCaptureInfo", (const char *)
      c10_r0->name, 15, 0U, 0U, 0U, 2, 1, strlen((const char *)
      c10_r0->name)), "name", "nameCaptureInfo", c10_i1);
    sf_mex_addfield(c10_m0, sf_mex_create("nameCaptureInfo", (const char *)
      c10_r0->dominantType, 15, 0U, 0U, 0U, 2, 1, strlen((const
      char *)c10_r0->dominantType)), "dominantType", "nameCaptureInfo", c10_i1);
    sf_mex_addfield(c10_m0, sf_mex_create("nameCaptureInfo", (const char *)
      c10_r0->resolved, 15, 0U, 0U, 0U, 2, 1, strlen((const char *)
      c10_r0->resolved)), "resolved", "nameCaptureInfo", c10_i1);
    sf_mex_addfield(c10_m0, sf_mex_create("nameCaptureInfo", &c10_r0->fileLength,
      7, 0U, 0U, 0U, 0), "fileLength", "nameCaptureInfo",
                    c10_i1);
    sf_mex_addfield(c10_m0, sf_mex_create("nameCaptureInfo", &c10_r0->fileTime1,
      7, 0U, 0U, 0U, 0), "fileTime1", "nameCaptureInfo",
                    c10_i1);
    sf_mex_addfield(c10_m0, sf_mex_create("nameCaptureInfo", &c10_r0->fileTime2,
      7, 0U, 0U, 0U, 0), "fileTime2", "nameCaptureInfo",
                    c10_i1);
  }

  sf_mex_assign(&c10_nameCaptureInfo, c10_m0);
  return c10_nameCaptureInfo;
}

static uint8_T c10_emlrt_marshallIn(SFc10_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c10_wp0, const char_T *
  c10_name)
{
  uint8_T c10_y;
  uint8_T c10_u1;
  sf_mex_import(c10_name, sf_mex_dup(c10_wp0), &c10_u1, 1, 3, 0U, 0, 0U, 0);
  c10_y = c10_u1;
  sf_mex_destroy(&c10_wp0);
  return c10_y;
}

static uint8_T c10_b_emlrt_marshallIn(SFc10_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c10_b_fromWP, const
  char_T *c10_name)
{
  uint8_T c10_y;
  uint8_T c10_u2;
  if (mxIsEmpty(c10_b_fromWP)) {
    chartInstance->c10_fromWP_not_empty = FALSE;
  } else {
    chartInstance->c10_fromWP_not_empty = TRUE;
    sf_mex_import(c10_name, sf_mex_dup(c10_b_fromWP), &c10_u2, 1, 3, 0U, 0, 0U,
                  0);
    c10_y = c10_u2;
  }

  sf_mex_destroy(&c10_b_fromWP);
  return c10_y;
}

static uint8_T c10_c_emlrt_marshallIn(SFc10_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c10_b_toWP, const
  char_T *c10_name)
{
  uint8_T c10_y;
  uint8_T c10_u3;
  if (mxIsEmpty(c10_b_toWP)) {
    chartInstance->c10_toWP_not_empty = FALSE;
  } else {
    chartInstance->c10_toWP_not_empty = TRUE;
    sf_mex_import(c10_name, sf_mex_dup(c10_b_toWP), &c10_u3, 1, 3, 0U, 0, 0U, 0);
    c10_y = c10_u3;
  }

  sf_mex_destroy(&c10_b_toWP);
  return c10_y;
}

static uint8_T c10_d_emlrt_marshallIn(SFc10_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c10_b_totoWP, const
  char_T *c10_name)
{
  uint8_T c10_y;
  uint8_T c10_u4;
  if (mxIsEmpty(c10_b_totoWP)) {
    chartInstance->c10_totoWP_not_empty = FALSE;
  } else {
    chartInstance->c10_totoWP_not_empty = TRUE;
    sf_mex_import(c10_name, sf_mex_dup(c10_b_totoWP), &c10_u4, 1, 3, 0U, 0, 0U,
                  0);
    c10_y = c10_u4;
  }

  sf_mex_destroy(&c10_b_totoWP);
  return c10_y;
}

static void init_dsm_address_info(SFc10_controlMCUSlugsMKIIInstanceStruct
  *chartInstance)
{
}

/* SFunction Glue Code */
void sf_c10_controlMCUSlugsMKII_get_check_sum(mxArray *plhs[])
{
  ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(706851033U);
  ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(1440137588U);
  ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(4236571564U);
  ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(2980323189U);
}

mxArray *sf_c10_controlMCUSlugsMKII_get_autoinheritance_info(void)
{
  const char *autoinheritanceFields[] = { "checksum", "inputs", "parameters",
    "outputs" };

  mxArray *mxAutoinheritanceInfo = mxCreateStructMatrix(1,1,4,
    autoinheritanceFields);

  {
    mxArray *mxChecksum = mxCreateDoubleMatrix(4,1,mxREAL);
    double *pr = mxGetPr(mxChecksum);
    pr[0] = (double)(3352855546U);
    pr[1] = (double)(4000459348U);
    pr[2] = (double)(1193756145U);
    pr[3] = (double)(1819567189U);
    mxSetField(mxAutoinheritanceInfo,0,"checksum",mxChecksum);
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,4,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(3));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,1,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(3));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,1,"type",mxType);
    }

    mxSetField(mxData,1,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,2,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,2,"type",mxType);
    }

    mxSetField(mxData,2,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,3,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(3));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,3,"type",mxType);
    }

    mxSetField(mxData,3,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"inputs",mxData);
  }

  {
    mxSetField(mxAutoinheritanceInfo,0,"parameters",mxCreateDoubleMatrix(0,0,
                mxREAL));
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,3,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(3));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,1,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(3));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,1,"type",mxType);
    }

    mxSetField(mxData,1,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,2,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(3));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,2,"type",mxType);
    }

    mxSetField(mxData,2,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"outputs",mxData);
  }

  return(mxAutoinheritanceInfo);
}

static mxArray *sf_get_sim_state_info_c10_controlMCUSlugsMKII(void)
{
  const char *infoFields[] = { "chartChecksum", "varInfo" };

  mxArray *mxInfo = mxCreateStructMatrix(1, 1, 2, infoFields);
  const char *infoEncStr[] = {
    "100 S1x7'type','srcId','name','auxInfo'{{M[1],M[6],T\"wp0\",},{M[1],M[8],T\"wp1\",},{M[1],M[9],T\"wp2\",},{M[4],M[0],T\"fromWP\",S'l','i','p'{{M1x2[115 121],M[0],}}},{M[4],M[0],T\"toWP\",S'l','i','p'{{M1x2[134 138],M[0],}}},{M[4],M[0],T\"totoWP\",S'l','i','p'{{M1x2[151 157],M[0],}}},{M[8],M[0],T\"is_active_c10_controlMCUSlugsMKII\",}}"
  };

  mxArray *mxVarInfo = sf_mex_decode_encoded_mx_struct_array(infoEncStr, 7, 10);
  mxArray *mxChecksum = mxCreateDoubleMatrix(1, 4, mxREAL);
  sf_c10_controlMCUSlugsMKII_get_check_sum(&mxChecksum);
  mxSetField(mxInfo, 0, infoFields[0], mxChecksum);
  mxSetField(mxInfo, 0, infoFields[1], mxVarInfo);
  return mxInfo;
}

static void sf_opaque_initialize_c10_controlMCUSlugsMKII(void *chartInstanceVar)
{
  initialize_params_c10_controlMCUSlugsMKII
    ((SFc10_controlMCUSlugsMKIIInstanceStruct*) chartInstanceVar);
  initialize_c10_controlMCUSlugsMKII((SFc10_controlMCUSlugsMKIIInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_enable_c10_controlMCUSlugsMKII(void *chartInstanceVar)
{
  enable_c10_controlMCUSlugsMKII((SFc10_controlMCUSlugsMKIIInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_disable_c10_controlMCUSlugsMKII(void *chartInstanceVar)
{
  disable_c10_controlMCUSlugsMKII((SFc10_controlMCUSlugsMKIIInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_gateway_c10_controlMCUSlugsMKII(void *chartInstanceVar)
{
  sf_c10_controlMCUSlugsMKII((SFc10_controlMCUSlugsMKIIInstanceStruct*)
    chartInstanceVar);
}

static mxArray* sf_internal_get_sim_state_c10_controlMCUSlugsMKII(SimStruct* S)
{
  ChartInfoStruct *chartInfo = (ChartInfoStruct*) ssGetUserData(S);
  mxArray *plhs[1] = { NULL };

  mxArray *prhs[4];
  int mxError = 0;
  prhs[0] = mxCreateString("chart_simctx_raw2high");
  prhs[1] = mxCreateDoubleScalar(ssGetSFuncBlockHandle(S));
  prhs[2] = (mxArray*) get_sim_state_c10_controlMCUSlugsMKII
    ((SFc10_controlMCUSlugsMKIIInstanceStruct*)chartInfo->chartInstance);/* raw sim ctx */
  prhs[3] = sf_get_sim_state_info_c10_controlMCUSlugsMKII();/* state var info */
  mxError = sf_mex_call_matlab(1, plhs, 4, prhs, "sfprivate");
  mxDestroyArray(prhs[0]);
  mxDestroyArray(prhs[1]);
  mxDestroyArray(prhs[2]);
  mxDestroyArray(prhs[3]);
  if (mxError || plhs[0] == NULL) {
    sf_mex_error_message("Stateflow Internal Error: \nError calling 'chart_simctx_raw2high'.\n");
  }

  return plhs[0];
}

static void sf_internal_set_sim_state_c10_controlMCUSlugsMKII(SimStruct* S,
  const mxArray *st)
{
  ChartInfoStruct *chartInfo = (ChartInfoStruct*) ssGetUserData(S);
  mxArray *plhs[1] = { NULL };

  mxArray *prhs[4];
  int mxError = 0;
  prhs[0] = mxCreateString("chart_simctx_high2raw");
  prhs[1] = mxCreateDoubleScalar(ssGetSFuncBlockHandle(S));
  prhs[2] = mxDuplicateArray(st);      /* high level simctx */
  prhs[3] = (mxArray*) sf_get_sim_state_info_c10_controlMCUSlugsMKII();/* state var info */
  mxError = sf_mex_call_matlab(1, plhs, 4, prhs, "sfprivate");
  mxDestroyArray(prhs[0]);
  mxDestroyArray(prhs[1]);
  mxDestroyArray(prhs[2]);
  mxDestroyArray(prhs[3]);
  if (mxError || plhs[0] == NULL) {
    sf_mex_error_message("Stateflow Internal Error: \nError calling 'chart_simctx_high2raw'.\n");
  }

  set_sim_state_c10_controlMCUSlugsMKII((SFc10_controlMCUSlugsMKIIInstanceStruct*)
    chartInfo->chartInstance, mxDuplicateArray(plhs[0]));
  mxDestroyArray(plhs[0]);
}

static mxArray* sf_opaque_get_sim_state_c10_controlMCUSlugsMKII(SimStruct* S)
{
  return sf_internal_get_sim_state_c10_controlMCUSlugsMKII(S);
}

static void sf_opaque_set_sim_state_c10_controlMCUSlugsMKII(SimStruct* S, const
  mxArray *st)
{
  sf_internal_set_sim_state_c10_controlMCUSlugsMKII(S, st);
}

static void sf_opaque_terminate_c10_controlMCUSlugsMKII(void *chartInstanceVar)
{
  if (chartInstanceVar!=NULL) {
    SimStruct *S = ((SFc10_controlMCUSlugsMKIIInstanceStruct*) chartInstanceVar
      )->S;
    if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
      sf_clear_rtw_identifier(S);
    }

    finalize_c10_controlMCUSlugsMKII((SFc10_controlMCUSlugsMKIIInstanceStruct*)
      chartInstanceVar);
    free((void *)chartInstanceVar);
    ssSetUserData(S,NULL);
  }
}

extern unsigned int sf_machine_global_initializer_called(void);
static void mdlProcessParameters_c10_controlMCUSlugsMKII(SimStruct *S)
{
  int i;
  for (i=0;i<ssGetNumRunTimeParams(S);i++) {
    if (ssGetSFcnParamTunable(S,i)) {
      ssUpdateDlgParamAsRunTimeParam(S,i);
    }
  }

  if (sf_machine_global_initializer_called()) {
    initialize_params_c10_controlMCUSlugsMKII
      ((SFc10_controlMCUSlugsMKIIInstanceStruct*)(((ChartInfoStruct *)
         ssGetUserData(S))->chartInstance));
  }
}

static void mdlSetWorkWidths_c10_controlMCUSlugsMKII(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
    int_T chartIsInlinable =
      (int_T)sf_is_chart_inlinable("controlMCUSlugsMKII","controlMCUSlugsMKII",
      10);
    ssSetStateflowIsInlinable(S,chartIsInlinable);
    ssSetRTWCG(S,sf_rtw_info_uint_prop("controlMCUSlugsMKII",
                "controlMCUSlugsMKII",10,"RTWCG"));
    ssSetEnableFcnIsTrivial(S,1);
    ssSetDisableFcnIsTrivial(S,1);
    ssSetNotMultipleInlinable(S,sf_rtw_info_uint_prop("controlMCUSlugsMKII",
      "controlMCUSlugsMKII",10,"gatewayCannotBeInlinedMultipleTimes"));
    if (chartIsInlinable) {
      ssSetInputPortOptimOpts(S, 0, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 1, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 2, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 3, SS_REUSABLE_AND_LOCAL);
      sf_mark_chart_expressionable_inputs(S,"controlMCUSlugsMKII",
        "controlMCUSlugsMKII",10,4);
      sf_mark_chart_reusable_outputs(S,"controlMCUSlugsMKII",
        "controlMCUSlugsMKII",10,3);
    }

    sf_set_rtw_dwork_info(S,"controlMCUSlugsMKII","controlMCUSlugsMKII",10);
    ssSetHasSubFunctions(S,!(chartIsInlinable));
    ssSetOptions(S,ssGetOptions(S)|SS_OPTION_WORKS_WITH_CODE_REUSE);
  }

  ssSetChecksum0(S,(3684397460U));
  ssSetChecksum1(S,(685533707U));
  ssSetChecksum2(S,(1117012234U));
  ssSetChecksum3(S,(737460593U));
  ssSetmdlDerivatives(S, NULL);
  ssSetExplicitFCSSCtrl(S,1);
}

static void mdlRTW_c10_controlMCUSlugsMKII(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S)) {
    sf_write_symbol_mapping(S, "controlMCUSlugsMKII", "controlMCUSlugsMKII",10);
    ssWriteRTWStrParam(S, "StateflowChartType", "Embedded MATLAB");
  }
}

static void mdlStart_c10_controlMCUSlugsMKII(SimStruct *S)
{
  SFc10_controlMCUSlugsMKIIInstanceStruct *chartInstance;
  chartInstance = (SFc10_controlMCUSlugsMKIIInstanceStruct *)malloc(sizeof
    (SFc10_controlMCUSlugsMKIIInstanceStruct));
  memset(chartInstance, 0, sizeof(SFc10_controlMCUSlugsMKIIInstanceStruct));
  if (chartInstance==NULL) {
    sf_mex_error_message("Could not allocate memory for chart instance.");
  }

  chartInstance->chartInfo.chartInstance = chartInstance;
  chartInstance->chartInfo.isEMLChart = 1;
  chartInstance->chartInfo.chartInitialized = 0;
  chartInstance->chartInfo.sFunctionGateway =
    sf_opaque_gateway_c10_controlMCUSlugsMKII;
  chartInstance->chartInfo.initializeChart =
    sf_opaque_initialize_c10_controlMCUSlugsMKII;
  chartInstance->chartInfo.terminateChart =
    sf_opaque_terminate_c10_controlMCUSlugsMKII;
  chartInstance->chartInfo.enableChart =
    sf_opaque_enable_c10_controlMCUSlugsMKII;
  chartInstance->chartInfo.disableChart =
    sf_opaque_disable_c10_controlMCUSlugsMKII;
  chartInstance->chartInfo.getSimState =
    sf_opaque_get_sim_state_c10_controlMCUSlugsMKII;
  chartInstance->chartInfo.setSimState =
    sf_opaque_set_sim_state_c10_controlMCUSlugsMKII;
  chartInstance->chartInfo.getSimStateInfo =
    sf_get_sim_state_info_c10_controlMCUSlugsMKII;
  chartInstance->chartInfo.zeroCrossings = NULL;
  chartInstance->chartInfo.outputs = NULL;
  chartInstance->chartInfo.derivatives = NULL;
  chartInstance->chartInfo.mdlRTW = mdlRTW_c10_controlMCUSlugsMKII;
  chartInstance->chartInfo.mdlStart = mdlStart_c10_controlMCUSlugsMKII;
  chartInstance->chartInfo.mdlSetWorkWidths =
    mdlSetWorkWidths_c10_controlMCUSlugsMKII;
  chartInstance->chartInfo.extModeExec = NULL;
  chartInstance->chartInfo.restoreLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.restoreBeforeLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.storeCurrentConfiguration = NULL;
  chartInstance->S = S;
  ssSetUserData(S,(void *)(&(chartInstance->chartInfo)));/* register the chart instance with simstruct */
  if (!sim_mode_is_rtw_gen(S)) {
    init_dsm_address_info(chartInstance);
  }
}

void c10_controlMCUSlugsMKII_method_dispatcher(SimStruct *S, int_T method, void *
  data)
{
  switch (method) {
   case SS_CALL_MDL_START:
    mdlStart_c10_controlMCUSlugsMKII(S);
    break;

   case SS_CALL_MDL_SET_WORK_WIDTHS:
    mdlSetWorkWidths_c10_controlMCUSlugsMKII(S);
    break;

   case SS_CALL_MDL_PROCESS_PARAMETERS:
    mdlProcessParameters_c10_controlMCUSlugsMKII(S);
    break;

   default:
    /* Unhandled method */
    sf_mex_error_message("Stateflow Internal Error:\n"
                         "Error calling c10_controlMCUSlugsMKII_method_dispatcher.\n"
                         "Can't handle method %d.\n", method);
    break;
  }
}
