/* Include files */

#include "blascompat32.h"
#include "controlMCUSlugsMKII_sfun.h"
#include "c8_controlMCUSlugsMKII.h"
#define CHARTINSTANCE_CHARTNUMBER      (chartInstance->chartNumber)
#define CHARTINSTANCE_INSTANCENUMBER   (chartInstance->instanceNumber)
#include "controlMCUSlugsMKII_sfun_debug_macros.h"

/* Type Definitions */

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */
static const char *c8_debug_family_names[14] = { "r_vec", "M", "nargin",
  "nargout", "sd", "cd", "WP1", "R", "T1", "T2", "O", "P", "Pch", "PchB" };

static const char *c8_b_debug_family_names[4] = { "nargin", "nargout", "x",
  "absVal" };

/* Function Declarations */
static void initialize_c8_controlMCUSlugsMKII
  (SFc8_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void initialize_params_c8_controlMCUSlugsMKII
  (SFc8_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void enable_c8_controlMCUSlugsMKII(SFc8_controlMCUSlugsMKIIInstanceStruct
  *chartInstance);
static void disable_c8_controlMCUSlugsMKII
  (SFc8_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void c8_update_debugger_state_c8_controlMCUSlugsMKII
  (SFc8_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static const mxArray *get_sim_state_c8_controlMCUSlugsMKII
  (SFc8_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void set_sim_state_c8_controlMCUSlugsMKII
  (SFc8_controlMCUSlugsMKIIInstanceStruct *chartInstance, const mxArray *c8_st);
static void finalize_c8_controlMCUSlugsMKII
  (SFc8_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void sf_c8_controlMCUSlugsMKII(SFc8_controlMCUSlugsMKIIInstanceStruct
  *chartInstance);
static void init_script_number_translation(uint32_T c8_machineNumber, uint32_T
  c8_chartNumber);
static real32_T c8_localAbs(SFc8_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, real32_T c8_x);
static const mxArray *c8_sf_marshall(void *chartInstanceVoid, void *c8_u);
static const mxArray *c8_b_sf_marshall(void *chartInstanceVoid, void *c8_u);
static const mxArray *c8_c_sf_marshall(void *chartInstanceVoid, void *c8_u);
static const mxArray *c8_d_sf_marshall(void *chartInstanceVoid, void *c8_u);
static void c8_info_helper(c8_ResolvedFunctionInfo c8_info[23]);
static const mxArray *c8_e_sf_marshall(void *chartInstanceVoid, void *c8_u);
static void c8_emlrt_marshallIn(SFc8_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c8_O, const char_T *c8_name, real32_T c8_y[3]);
static real32_T c8_b_emlrt_marshallIn(SFc8_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c8_P, const char_T *c8_name);
static uint8_T c8_c_emlrt_marshallIn(SFc8_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c8_b_is_active_c8_controlMCUSlugsMKII, const
  char_T *c8_name);
static void init_dsm_address_info(SFc8_controlMCUSlugsMKIIInstanceStruct
  *chartInstance);

/* Function Definitions */
static void initialize_c8_controlMCUSlugsMKII
  (SFc8_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
  chartInstance->c8_is_active_c8_controlMCUSlugsMKII = 0U;
}

static void initialize_params_c8_controlMCUSlugsMKII
  (SFc8_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
}

static void enable_c8_controlMCUSlugsMKII(SFc8_controlMCUSlugsMKIIInstanceStruct
  *chartInstance)
{
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
}

static void disable_c8_controlMCUSlugsMKII
  (SFc8_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
}

static void c8_update_debugger_state_c8_controlMCUSlugsMKII
  (SFc8_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
}

static const mxArray *get_sim_state_c8_controlMCUSlugsMKII
  (SFc8_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
  const mxArray *c8_st = NULL;
  const mxArray *c8_y = NULL;
  int32_T c8_i0;
  real32_T c8_hoistedGlobal[3];
  int32_T c8_i1;
  real32_T c8_u[3];
  const mxArray *c8_b_y = NULL;
  real32_T c8_b_hoistedGlobal;
  real32_T c8_b_u;
  const mxArray *c8_c_y = NULL;
  int32_T c8_i2;
  real32_T c8_c_hoistedGlobal[3];
  int32_T c8_i3;
  real32_T c8_c_u[3];
  const mxArray *c8_d_y = NULL;
  int32_T c8_i4;
  real32_T c8_d_hoistedGlobal[3];
  int32_T c8_i5;
  real32_T c8_d_u[3];
  const mxArray *c8_e_y = NULL;
  uint8_T c8_e_hoistedGlobal;
  uint8_T c8_e_u;
  const mxArray *c8_f_y = NULL;
  real32_T *c8_P;
  real32_T (*c8_PchB)[3];
  real32_T (*c8_Pch)[3];
  real32_T (*c8_O)[3];
  c8_PchB = (real32_T (*)[3])ssGetOutputPortSignal(chartInstance->S, 4);
  c8_Pch = (real32_T (*)[3])ssGetOutputPortSignal(chartInstance->S, 3);
  c8_P = (real32_T *)ssGetOutputPortSignal(chartInstance->S, 2);
  c8_O = (real32_T (*)[3])ssGetOutputPortSignal(chartInstance->S, 1);
  c8_st = NULL;
  c8_y = NULL;
  sf_mex_assign(&c8_y, sf_mex_createcellarray(5));
  for (c8_i0 = 0; c8_i0 < 3; c8_i0 = c8_i0 + 1) {
    c8_hoistedGlobal[c8_i0] = (*c8_O)[c8_i0];
  }

  for (c8_i1 = 0; c8_i1 < 3; c8_i1 = c8_i1 + 1) {
    c8_u[c8_i1] = c8_hoistedGlobal[c8_i1];
  }

  c8_b_y = NULL;
  sf_mex_assign(&c8_b_y, sf_mex_create("y", &c8_u, 1, 0U, 1U, 0U, 1, 3));
  sf_mex_setcell(c8_y, 0, c8_b_y);
  c8_b_hoistedGlobal = *c8_P;
  c8_b_u = c8_b_hoistedGlobal;
  c8_c_y = NULL;
  sf_mex_assign(&c8_c_y, sf_mex_create("y", &c8_b_u, 1, 0U, 0U, 0U, 0));
  sf_mex_setcell(c8_y, 1, c8_c_y);
  for (c8_i2 = 0; c8_i2 < 3; c8_i2 = c8_i2 + 1) {
    c8_c_hoistedGlobal[c8_i2] = (*c8_Pch)[c8_i2];
  }

  for (c8_i3 = 0; c8_i3 < 3; c8_i3 = c8_i3 + 1) {
    c8_c_u[c8_i3] = c8_c_hoistedGlobal[c8_i3];
  }

  c8_d_y = NULL;
  sf_mex_assign(&c8_d_y, sf_mex_create("y", &c8_c_u, 1, 0U, 1U, 0U, 1, 3));
  sf_mex_setcell(c8_y, 2, c8_d_y);
  for (c8_i4 = 0; c8_i4 < 3; c8_i4 = c8_i4 + 1) {
    c8_d_hoistedGlobal[c8_i4] = (*c8_PchB)[c8_i4];
  }

  for (c8_i5 = 0; c8_i5 < 3; c8_i5 = c8_i5 + 1) {
    c8_d_u[c8_i5] = c8_d_hoistedGlobal[c8_i5];
  }

  c8_e_y = NULL;
  sf_mex_assign(&c8_e_y, sf_mex_create("y", &c8_d_u, 1, 0U, 1U, 0U, 1, 3));
  sf_mex_setcell(c8_y, 3, c8_e_y);
  c8_e_hoistedGlobal = chartInstance->c8_is_active_c8_controlMCUSlugsMKII;
  c8_e_u = c8_e_hoistedGlobal;
  c8_f_y = NULL;
  sf_mex_assign(&c8_f_y, sf_mex_create("y", &c8_e_u, 3, 0U, 0U, 0U, 0));
  sf_mex_setcell(c8_y, 4, c8_f_y);
  sf_mex_assign(&c8_st, c8_y);
  return c8_st;
}

static void set_sim_state_c8_controlMCUSlugsMKII
  (SFc8_controlMCUSlugsMKIIInstanceStruct *chartInstance, const mxArray *c8_st)
{
  const mxArray *c8_u;
  real32_T c8_fv0[3];
  int32_T c8_i6;
  real32_T c8_fv1[3];
  int32_T c8_i7;
  real32_T c8_fv2[3];
  int32_T c8_i8;
  real32_T *c8_P;
  real32_T (*c8_O)[3];
  real32_T (*c8_Pch)[3];
  real32_T (*c8_PchB)[3];
  c8_PchB = (real32_T (*)[3])ssGetOutputPortSignal(chartInstance->S, 4);
  c8_Pch = (real32_T (*)[3])ssGetOutputPortSignal(chartInstance->S, 3);
  c8_P = (real32_T *)ssGetOutputPortSignal(chartInstance->S, 2);
  c8_O = (real32_T (*)[3])ssGetOutputPortSignal(chartInstance->S, 1);
  chartInstance->c8_doneDoubleBufferReInit = TRUE;
  c8_u = sf_mex_dup(c8_st);
  c8_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(c8_u, 0)), "O",
                      c8_fv0);
  for (c8_i6 = 0; c8_i6 < 3; c8_i6 = c8_i6 + 1) {
    (*c8_O)[c8_i6] = c8_fv0[c8_i6];
  }

  *c8_P = c8_b_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(c8_u, 1)),
    "P");
  c8_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(c8_u, 2)), "Pch",
                      c8_fv1);
  for (c8_i7 = 0; c8_i7 < 3; c8_i7 = c8_i7 + 1) {
    (*c8_Pch)[c8_i7] = c8_fv1[c8_i7];
  }

  c8_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(c8_u, 3)), "PchB",
                      c8_fv2);
  for (c8_i8 = 0; c8_i8 < 3; c8_i8 = c8_i8 + 1) {
    (*c8_PchB)[c8_i8] = c8_fv2[c8_i8];
  }

  chartInstance->c8_is_active_c8_controlMCUSlugsMKII = c8_c_emlrt_marshallIn
    (chartInstance, sf_mex_dup(sf_mex_getcell(c8_u, 4)),
     "is_active_c8_controlMCUSlugsMKII");
  sf_mex_destroy(&c8_u);
  c8_update_debugger_state_c8_controlMCUSlugsMKII(chartInstance);
  sf_mex_destroy(&c8_st);
}

static void finalize_c8_controlMCUSlugsMKII
  (SFc8_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
}

static void sf_c8_controlMCUSlugsMKII(SFc8_controlMCUSlugsMKIIInstanceStruct
  *chartInstance)
{
  int32_T c8_i9;
  int32_T c8_i10;
  int32_T c8_i11;
  int32_T c8_i12;
  int32_T c8_i13;
  int32_T c8_i14;
  int32_T c8_previousEvent;
  real32_T c8_hoistedGlobal;
  real32_T c8_b_hoistedGlobal;
  int32_T c8_i15;
  real32_T c8_c_hoistedGlobal[3];
  real32_T c8_d_hoistedGlobal;
  int32_T c8_i16;
  real32_T c8_e_hoistedGlobal[3];
  int32_T c8_i17;
  real32_T c8_f_hoistedGlobal[3];
  real32_T c8_sd;
  real32_T c8_cd;
  int32_T c8_i18;
  real32_T c8_WP1[3];
  real32_T c8_R;
  int32_T c8_i19;
  real32_T c8_T1[3];
  int32_T c8_i20;
  real32_T c8_T2[3];
  uint32_T c8_debug_family_var_map[14];
  static const char *c8_sv0[14] = { "r_vec", "M", "nargin", "nargout", "sd",
    "cd", "WP1", "R", "T1", "T2", "O", "P", "Pch", "PchB" };

  real_T c8_r_vec[3];
  real32_T c8_M;
  real_T c8_nargin = 6.0;
  real_T c8_nargout = 4.0;
  real32_T c8_O[3];
  real32_T c8_P;
  real32_T c8_Pch[3];
  real32_T c8_PchB[3];
  int32_T c8_i21;
  real32_T c8_a;
  real32_T c8_b;
  real32_T c8_y;
  real32_T c8_b_a;
  real32_T c8_b_b;
  real32_T c8_b_y;
  real32_T c8_c_a;
  real32_T c8_c_b;
  real32_T c8_c_y;
  real32_T c8_d_a;
  real32_T c8_d_b;
  real32_T c8_d_y;
  real32_T c8_A;
  real32_T c8_B;
  real32_T c8_x;
  real32_T c8_e_y;
  real32_T c8_b_x;
  real32_T c8_f_y;
  real32_T c8_c_x;
  real32_T c8_g_y;
  real32_T c8_h_y;
  real32_T c8_e_a;
  real32_T c8_e_b;
  int32_T c8_i22;
  int32_T c8_i23;
  real32_T c8_f_a[3];
  real32_T c8_f_b;
  int32_T c8_i24;
  real32_T c8_i_y[3];
  int32_T c8_i25;
  int32_T c8_i26;
  real32_T c8_g_a[3];
  real32_T c8_g_b;
  int32_T c8_i27;
  real32_T c8_j_y[3];
  int32_T c8_i28;
  int32_T c8_i29;
  int32_T c8_i30;
  int32_T c8_i31;
  real32_T *c8_b_sd;
  real32_T *c8_b_cd;
  real32_T *c8_b_R;
  real32_T *c8_b_P;
  real32_T (*c8_b_O)[3];
  real32_T (*c8_b_Pch)[3];
  real32_T (*c8_b_PchB)[3];
  real32_T (*c8_b_T2)[3];
  real32_T (*c8_b_T1)[3];
  real32_T (*c8_b_WP1)[3];
  c8_b_PchB = (real32_T (*)[3])ssGetOutputPortSignal(chartInstance->S, 4);
  c8_b_T2 = (real32_T (*)[3])ssGetInputPortSignal(chartInstance->S, 5);
  c8_b_Pch = (real32_T (*)[3])ssGetOutputPortSignal(chartInstance->S, 3);
  c8_b_P = (real32_T *)ssGetOutputPortSignal(chartInstance->S, 2);
  c8_b_T1 = (real32_T (*)[3])ssGetInputPortSignal(chartInstance->S, 4);
  c8_b_R = (real32_T *)ssGetInputPortSignal(chartInstance->S, 3);
  c8_b_WP1 = (real32_T (*)[3])ssGetInputPortSignal(chartInstance->S, 2);
  c8_b_cd = (real32_T *)ssGetInputPortSignal(chartInstance->S, 1);
  c8_b_O = (real32_T (*)[3])ssGetOutputPortSignal(chartInstance->S, 1);
  c8_b_sd = (real32_T *)ssGetInputPortSignal(chartInstance->S, 0);
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
  _SFD_CC_CALL(CHART_ENTER_SFUNCTION_TAG,7);
  _SFD_DATA_RANGE_CHECK((real_T)*c8_b_sd, 0U);
  for (c8_i9 = 0; c8_i9 < 3; c8_i9 = c8_i9 + 1) {
    _SFD_DATA_RANGE_CHECK((real_T)(*c8_b_O)[c8_i9], 1U);
  }

  _SFD_DATA_RANGE_CHECK((real_T)*c8_b_cd, 2U);
  for (c8_i10 = 0; c8_i10 < 3; c8_i10 = c8_i10 + 1) {
    _SFD_DATA_RANGE_CHECK((real_T)(*c8_b_WP1)[c8_i10], 3U);
  }

  _SFD_DATA_RANGE_CHECK((real_T)*c8_b_R, 4U);
  for (c8_i11 = 0; c8_i11 < 3; c8_i11 = c8_i11 + 1) {
    _SFD_DATA_RANGE_CHECK((real_T)(*c8_b_T1)[c8_i11], 5U);
  }

  _SFD_DATA_RANGE_CHECK((real_T)*c8_b_P, 6U);
  for (c8_i12 = 0; c8_i12 < 3; c8_i12 = c8_i12 + 1) {
    _SFD_DATA_RANGE_CHECK((real_T)(*c8_b_Pch)[c8_i12], 7U);
  }

  for (c8_i13 = 0; c8_i13 < 3; c8_i13 = c8_i13 + 1) {
    _SFD_DATA_RANGE_CHECK((real_T)(*c8_b_T2)[c8_i13], 8U);
  }

  for (c8_i14 = 0; c8_i14 < 3; c8_i14 = c8_i14 + 1) {
    _SFD_DATA_RANGE_CHECK((real_T)(*c8_b_PchB)[c8_i14], 9U);
  }

  c8_previousEvent = _sfEvent_;
  _sfEvent_ = CALL_EVENT;
  _SFD_CC_CALL(CHART_ENTER_DURING_FUNCTION_TAG,7);
  c8_hoistedGlobal = *c8_b_sd;
  c8_b_hoistedGlobal = *c8_b_cd;
  for (c8_i15 = 0; c8_i15 < 3; c8_i15 = c8_i15 + 1) {
    c8_c_hoistedGlobal[c8_i15] = (*c8_b_WP1)[c8_i15];
  }

  c8_d_hoistedGlobal = *c8_b_R;
  for (c8_i16 = 0; c8_i16 < 3; c8_i16 = c8_i16 + 1) {
    c8_e_hoistedGlobal[c8_i16] = (*c8_b_T1)[c8_i16];
  }

  for (c8_i17 = 0; c8_i17 < 3; c8_i17 = c8_i17 + 1) {
    c8_f_hoistedGlobal[c8_i17] = (*c8_b_T2)[c8_i17];
  }

  c8_sd = c8_hoistedGlobal;
  c8_cd = c8_b_hoistedGlobal;
  for (c8_i18 = 0; c8_i18 < 3; c8_i18 = c8_i18 + 1) {
    c8_WP1[c8_i18] = c8_c_hoistedGlobal[c8_i18];
  }

  c8_R = c8_d_hoistedGlobal;
  for (c8_i19 = 0; c8_i19 < 3; c8_i19 = c8_i19 + 1) {
    c8_T1[c8_i19] = c8_e_hoistedGlobal[c8_i19];
  }

  for (c8_i20 = 0; c8_i20 < 3; c8_i20 = c8_i20 + 1) {
    c8_T2[c8_i20] = c8_f_hoistedGlobal[c8_i20];
  }

  sf_debug_symbol_scope_push_eml(0U, 14U, 14U, c8_sv0, c8_debug_family_var_map);
  sf_debug_symbol_scope_add_eml(&c8_r_vec, c8_d_sf_marshall, 0U);
  sf_debug_symbol_scope_add_eml(&c8_M, c8_b_sf_marshall, 1U);
  sf_debug_symbol_scope_add_eml(&c8_nargin, c8_c_sf_marshall, 2U);
  sf_debug_symbol_scope_add_eml(&c8_nargout, c8_c_sf_marshall, 3U);
  sf_debug_symbol_scope_add_eml(&c8_sd, c8_b_sf_marshall, 4U);
  sf_debug_symbol_scope_add_eml(&c8_cd, c8_b_sf_marshall, 5U);
  sf_debug_symbol_scope_add_eml(&c8_WP1, c8_sf_marshall, 6U);
  sf_debug_symbol_scope_add_eml(&c8_R, c8_b_sf_marshall, 7U);
  sf_debug_symbol_scope_add_eml(&c8_T1, c8_sf_marshall, 8U);
  sf_debug_symbol_scope_add_eml(&c8_T2, c8_sf_marshall, 9U);
  sf_debug_symbol_scope_add_eml(&c8_O, c8_sf_marshall, 10U);
  sf_debug_symbol_scope_add_eml(&c8_P, c8_b_sf_marshall, 11U);
  sf_debug_symbol_scope_add_eml(&c8_Pch, c8_sf_marshall, 12U);
  sf_debug_symbol_scope_add_eml(&c8_PchB, c8_sf_marshall, 13U);
  CV_EML_FCN(0, 0);

  /*  This block supports an embeddable subset of the MATLAB language. */
  /*  See the help menu for details. */
  /*  rotate the vector delta degrees */
  _SFD_EML_CALL(0,6);
  for (c8_i21 = 0; c8_i21 < 3; c8_i21 = c8_i21 + 1) {
    c8_r_vec[c8_i21] = 0.0;
  }

  _SFD_EML_CALL(0,7);
  c8_a = -c8_T1[0];
  c8_b = c8_cd;
  c8_y = c8_a * c8_b;
  c8_b_a = c8_T1[1];
  c8_b_b = c8_sd;
  c8_b_y = c8_b_a * c8_b_b;
  c8_r_vec[0] = (real_T)(c8_y - c8_b_y);
  _SFD_EML_CALL(0,8);
  c8_c_a = c8_T1[0];
  c8_c_b = c8_sd;
  c8_c_y = c8_c_a * c8_c_b;
  c8_d_a = c8_T1[1];
  c8_d_b = c8_cd;
  c8_d_y = c8_d_a * c8_d_b;
  c8_r_vec[1] = (real_T)(c8_c_y - c8_d_y);

  /* compute M */
  _SFD_EML_CALL(0,11);
  if (CV_EML_IF(0, 0, (real_T)c8_localAbs(chartInstance, c8_sd) > 0.01)) {
    _SFD_EML_CALL(0,12);
    c8_A = c8_R;
    c8_B = c8_sd;
    c8_x = c8_A;
    c8_e_y = c8_B;
    c8_b_x = c8_x;
    c8_f_y = c8_e_y;
    c8_c_x = c8_b_x;
    c8_g_y = c8_f_y;
    c8_h_y = c8_c_x / c8_g_y;
    c8_M = c8_localAbs(chartInstance, c8_h_y);
  } else {
    _SFD_EML_CALL(0,14);
    c8_M = 0.0F;
  }

  /* find the distance from WP */
  _SFD_EML_CALL(0,18);
  c8_e_a = c8_M;
  c8_e_b = c8_cd;
  c8_P = c8_e_a * c8_e_b;

  /*  find the center of the circle */
  _SFD_EML_CALL(0,21);
  for (c8_i22 = 0; c8_i22 < 3; c8_i22 = c8_i22 + 1) {
    c8_O[c8_i22] = c8_WP1[c8_i22] + (real32_T)c8_r_vec[c8_i22] * c8_M;
  }

  /*  find the tangent points */
  _SFD_EML_CALL(0,24);
  for (c8_i23 = 0; c8_i23 < 3; c8_i23 = c8_i23 + 1) {
    c8_f_a[c8_i23] = c8_T1[c8_i23];
  }

  c8_f_b = c8_P;
  for (c8_i24 = 0; c8_i24 < 3; c8_i24 = c8_i24 + 1) {
    c8_i_y[c8_i24] = c8_f_a[c8_i24] * c8_f_b;
  }

  for (c8_i25 = 0; c8_i25 < 3; c8_i25 = c8_i25 + 1) {
    c8_Pch[c8_i25] = c8_WP1[c8_i25] - c8_i_y[c8_i25];
  }

  _SFD_EML_CALL(0,25);
  for (c8_i26 = 0; c8_i26 < 3; c8_i26 = c8_i26 + 1) {
    c8_g_a[c8_i26] = c8_T2[c8_i26];
  }

  c8_g_b = c8_P;
  for (c8_i27 = 0; c8_i27 < 3; c8_i27 = c8_i27 + 1) {
    c8_j_y[c8_i27] = c8_g_a[c8_i27] * c8_g_b;
  }

  for (c8_i28 = 0; c8_i28 < 3; c8_i28 = c8_i28 + 1) {
    c8_PchB[c8_i28] = c8_WP1[c8_i28] + c8_j_y[c8_i28];
  }

  _SFD_EML_CALL(0,-25);
  sf_debug_symbol_scope_pop();
  for (c8_i29 = 0; c8_i29 < 3; c8_i29 = c8_i29 + 1) {
    (*c8_b_O)[c8_i29] = c8_O[c8_i29];
  }

  *c8_b_P = c8_P;
  for (c8_i30 = 0; c8_i30 < 3; c8_i30 = c8_i30 + 1) {
    (*c8_b_Pch)[c8_i30] = c8_Pch[c8_i30];
  }

  for (c8_i31 = 0; c8_i31 < 3; c8_i31 = c8_i31 + 1) {
    (*c8_b_PchB)[c8_i31] = c8_PchB[c8_i31];
  }

  _SFD_CC_CALL(EXIT_OUT_OF_FUNCTION_TAG,7);
  _sfEvent_ = c8_previousEvent;
  sf_debug_check_for_state_inconsistency(_controlMCUSlugsMKIIMachineNumber_,
    chartInstance->chartNumber, chartInstance->instanceNumber
    );
}

static void init_script_number_translation(uint32_T c8_machineNumber, uint32_T
  c8_chartNumber)
{
}

static real32_T c8_localAbs(SFc8_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, real32_T c8_x)
{
  real32_T c8_absVal;
  uint32_T c8_debug_family_var_map[4];
  real_T c8_nargin = 1.0;
  real_T c8_nargout = 1.0;
  real32_T c8_b;
  sf_debug_symbol_scope_push_eml(0U, 4U, 4U, c8_b_debug_family_names,
    c8_debug_family_var_map);
  sf_debug_symbol_scope_add_eml(&c8_nargin, c8_c_sf_marshall, 0U);
  sf_debug_symbol_scope_add_eml(&c8_nargout, c8_c_sf_marshall, 1U);
  sf_debug_symbol_scope_add_eml(&c8_x, c8_b_sf_marshall, 2U);
  sf_debug_symbol_scope_add_eml(&c8_absVal, c8_b_sf_marshall, 3U);
  CV_EML_FCN(0, 1);
  _SFD_EML_CALL(0,29);
  if (CV_EML_IF(0, 1, (real_T)c8_x < 0.0)) {
    _SFD_EML_CALL(0,30);
    c8_b = c8_x;
    c8_absVal = -1.0F * c8_b;
  } else {
    _SFD_EML_CALL(0,32);
    c8_absVal = c8_x;
  }

  _SFD_EML_CALL(0,-32);
  sf_debug_symbol_scope_pop();
  return c8_absVal;
}

static const mxArray *c8_sf_marshall(void *chartInstanceVoid, void *c8_u)
{
  const mxArray *c8_y = NULL;
  int32_T c8_i32;
  real32_T c8_b_u[3];
  const mxArray *c8_b_y = NULL;
  SFc8_controlMCUSlugsMKIIInstanceStruct *chartInstance;
  chartInstance = (SFc8_controlMCUSlugsMKIIInstanceStruct *)chartInstanceVoid;
  c8_y = NULL;
  for (c8_i32 = 0; c8_i32 < 3; c8_i32 = c8_i32 + 1) {
    c8_b_u[c8_i32] = (*((real32_T (*)[3])c8_u))[c8_i32];
  }

  c8_b_y = NULL;
  sf_mex_assign(&c8_b_y, sf_mex_create("y", &c8_b_u, 1, 0U, 1U, 0U, 1, 3));
  sf_mex_assign(&c8_y, c8_b_y);
  return c8_y;
}

static const mxArray *c8_b_sf_marshall(void *chartInstanceVoid, void *c8_u)
{
  const mxArray *c8_y = NULL;
  real32_T c8_b_u;
  const mxArray *c8_b_y = NULL;
  SFc8_controlMCUSlugsMKIIInstanceStruct *chartInstance;
  chartInstance = (SFc8_controlMCUSlugsMKIIInstanceStruct *)chartInstanceVoid;
  c8_y = NULL;
  c8_b_u = *((real32_T *)c8_u);
  c8_b_y = NULL;
  sf_mex_assign(&c8_b_y, sf_mex_create("y", &c8_b_u, 1, 0U, 0U, 0U, 0));
  sf_mex_assign(&c8_y, c8_b_y);
  return c8_y;
}

static const mxArray *c8_c_sf_marshall(void *chartInstanceVoid, void *c8_u)
{
  const mxArray *c8_y = NULL;
  real_T c8_b_u;
  const mxArray *c8_b_y = NULL;
  SFc8_controlMCUSlugsMKIIInstanceStruct *chartInstance;
  chartInstance = (SFc8_controlMCUSlugsMKIIInstanceStruct *)chartInstanceVoid;
  c8_y = NULL;
  c8_b_u = *((real_T *)c8_u);
  c8_b_y = NULL;
  sf_mex_assign(&c8_b_y, sf_mex_create("y", &c8_b_u, 0, 0U, 0U, 0U, 0));
  sf_mex_assign(&c8_y, c8_b_y);
  return c8_y;
}

static const mxArray *c8_d_sf_marshall(void *chartInstanceVoid, void *c8_u)
{
  const mxArray *c8_y = NULL;
  int32_T c8_i33;
  real_T c8_b_u[3];
  const mxArray *c8_b_y = NULL;
  SFc8_controlMCUSlugsMKIIInstanceStruct *chartInstance;
  chartInstance = (SFc8_controlMCUSlugsMKIIInstanceStruct *)chartInstanceVoid;
  c8_y = NULL;
  for (c8_i33 = 0; c8_i33 < 3; c8_i33 = c8_i33 + 1) {
    c8_b_u[c8_i33] = (*((real_T (*)[3])c8_u))[c8_i33];
  }

  c8_b_y = NULL;
  sf_mex_assign(&c8_b_y, sf_mex_create("y", &c8_b_u, 0, 0U, 1U, 0U, 1, 3));
  sf_mex_assign(&c8_y, c8_b_y);
  return c8_y;
}

const mxArray *sf_c8_controlMCUSlugsMKII_get_eml_resolved_functions_info(void)
{
  const mxArray *c8_nameCaptureInfo = NULL;
  c8_ResolvedFunctionInfo c8_info[23];
  const mxArray *c8_m0 = NULL;
  int32_T c8_i34;
  c8_ResolvedFunctionInfo *c8_r0;
  c8_nameCaptureInfo = NULL;
  c8_info_helper(c8_info);
  sf_mex_assign(&c8_m0, sf_mex_createstruct("nameCaptureInfo", 1, 23));
  for (c8_i34 = 0; c8_i34 < 23; c8_i34 = c8_i34 + 1) {
    c8_r0 = &c8_info[c8_i34];
    sf_mex_addfield(c8_m0, sf_mex_create("nameCaptureInfo", c8_r0->context, 15,
      0U, 0U, 0U, 2, 1, strlen(c8_r0->context)), "context",
                    "nameCaptureInfo", c8_i34);
    sf_mex_addfield(c8_m0, sf_mex_create("nameCaptureInfo", c8_r0->name, 15, 0U,
      0U, 0U, 2, 1, strlen(c8_r0->name)), "name",
                    "nameCaptureInfo", c8_i34);
    sf_mex_addfield(c8_m0, sf_mex_create("nameCaptureInfo", c8_r0->dominantType,
      15, 0U, 0U, 0U, 2, 1, strlen(c8_r0->dominantType)),
                    "dominantType", "nameCaptureInfo", c8_i34);
    sf_mex_addfield(c8_m0, sf_mex_create("nameCaptureInfo", c8_r0->resolved, 15,
      0U, 0U, 0U, 2, 1, strlen(c8_r0->resolved)), "resolved"
                    , "nameCaptureInfo", c8_i34);
    sf_mex_addfield(c8_m0, sf_mex_create("nameCaptureInfo", &c8_r0->fileLength,
      7, 0U, 0U, 0U, 0), "fileLength", "nameCaptureInfo",
                    c8_i34);
    sf_mex_addfield(c8_m0, sf_mex_create("nameCaptureInfo", &c8_r0->fileTime1, 7,
      0U, 0U, 0U, 0), "fileTime1", "nameCaptureInfo", c8_i34
                    );
    sf_mex_addfield(c8_m0, sf_mex_create("nameCaptureInfo", &c8_r0->fileTime2, 7,
      0U, 0U, 0U, 0), "fileTime2", "nameCaptureInfo", c8_i34
                    );
  }

  sf_mex_assign(&c8_nameCaptureInfo, c8_m0);
  return c8_nameCaptureInfo;
}

static void c8_info_helper(c8_ResolvedFunctionInfo c8_info[23])
{
  c8_info[0].context = "";
  c8_info[0].name = "zeros";
  c8_info[0].dominantType = "double";
  c8_info[0].resolved = "[B]zeros";
  c8_info[0].fileLength = 0U;
  c8_info[0].fileTime1 = 0U;
  c8_info[0].fileTime2 = 0U;
  c8_info[1].context = "";
  c8_info[1].name = "uminus";
  c8_info[1].dominantType = "single";
  c8_info[1].resolved = "[B]uminus";
  c8_info[1].fileLength = 0U;
  c8_info[1].fileTime1 = 0U;
  c8_info[1].fileTime2 = 0U;
  c8_info[2].context = "";
  c8_info[2].name = "mtimes";
  c8_info[2].dominantType = "single";
  c8_info[2].resolved = "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  c8_info[2].fileLength = 3425U;
  c8_info[2].fileTime1 = 1250701566U;
  c8_info[2].fileTime2 = 0U;
  c8_info[3].context = "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  c8_info[3].name = "nargin";
  c8_info[3].dominantType = "";
  c8_info[3].resolved = "[B]nargin";
  c8_info[3].fileLength = 0U;
  c8_info[3].fileTime1 = 0U;
  c8_info[3].fileTime2 = 0U;
  c8_info[4].context = "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  c8_info[4].name = "gt";
  c8_info[4].dominantType = "double";
  c8_info[4].resolved = "[B]gt";
  c8_info[4].fileLength = 0U;
  c8_info[4].fileTime1 = 0U;
  c8_info[4].fileTime2 = 0U;
  c8_info[5].context = "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  c8_info[5].name = "isa";
  c8_info[5].dominantType = "single";
  c8_info[5].resolved = "[B]isa";
  c8_info[5].fileLength = 0U;
  c8_info[5].fileTime1 = 0U;
  c8_info[5].fileTime2 = 0U;
  c8_info[6].context = "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  c8_info[6].name = "isinteger";
  c8_info[6].dominantType = "single";
  c8_info[6].resolved = "[B]isinteger";
  c8_info[6].fileLength = 0U;
  c8_info[6].fileTime1 = 0U;
  c8_info[6].fileTime2 = 0U;
  c8_info[7].context = "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  c8_info[7].name = "isscalar";
  c8_info[7].dominantType = "single";
  c8_info[7].resolved = "[B]isscalar";
  c8_info[7].fileLength = 0U;
  c8_info[7].fileTime1 = 0U;
  c8_info[7].fileTime2 = 0U;
  c8_info[8].context = "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  c8_info[8].name = "strcmp";
  c8_info[8].dominantType = "char";
  c8_info[8].resolved = "[B]strcmp";
  c8_info[8].fileLength = 0U;
  c8_info[8].fileTime1 = 0U;
  c8_info[8].fileTime2 = 0U;
  c8_info[9].context = "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  c8_info[9].name = "size";
  c8_info[9].dominantType = "single";
  c8_info[9].resolved = "[B]size";
  c8_info[9].fileLength = 0U;
  c8_info[9].fileTime1 = 0U;
  c8_info[9].fileTime2 = 0U;
  c8_info[10].context = "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  c8_info[10].name = "eq";
  c8_info[10].dominantType = "double";
  c8_info[10].resolved = "[B]eq";
  c8_info[10].fileLength = 0U;
  c8_info[10].fileTime1 = 0U;
  c8_info[10].fileTime2 = 0U;
  c8_info[11].context = "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  c8_info[11].name = "class";
  c8_info[11].dominantType = "single";
  c8_info[11].resolved = "[B]class";
  c8_info[11].fileLength = 0U;
  c8_info[11].fileTime1 = 0U;
  c8_info[11].fileTime2 = 0U;
  c8_info[12].context = "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  c8_info[12].name = "not";
  c8_info[12].dominantType = "logical";
  c8_info[12].resolved = "[B]not";
  c8_info[12].fileLength = 0U;
  c8_info[12].fileTime1 = 0U;
  c8_info[12].fileTime2 = 0U;
  c8_info[13].context = "";
  c8_info[13].name = "minus";
  c8_info[13].dominantType = "single";
  c8_info[13].resolved = "[B]minus";
  c8_info[13].fileLength = 0U;
  c8_info[13].fileTime1 = 0U;
  c8_info[13].fileTime2 = 0U;
  c8_info[14].context = "";
  c8_info[14].name = "lt";
  c8_info[14].dominantType = "single";
  c8_info[14].resolved = "[B]lt";
  c8_info[14].fileLength = 0U;
  c8_info[14].fileTime1 = 0U;
  c8_info[14].fileTime2 = 0U;
  c8_info[15].context = "";
  c8_info[15].name = "single";
  c8_info[15].dominantType = "single";
  c8_info[15].resolved = "[B]single";
  c8_info[15].fileLength = 0U;
  c8_info[15].fileTime1 = 0U;
  c8_info[15].fileTime2 = 0U;
  c8_info[16].context = "";
  c8_info[16].name = "mrdivide";
  c8_info[16].dominantType = "single";
  c8_info[16].resolved =
    "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mrdivide.m";
  c8_info[16].fileLength = 800U;
  c8_info[16].fileTime1 = 1238463090U;
  c8_info[16].fileTime2 = 0U;
  c8_info[17].context =
    "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mrdivide.m";
  c8_info[17].name = "ge";
  c8_info[17].dominantType = "double";
  c8_info[17].resolved = "[B]ge";
  c8_info[17].fileLength = 0U;
  c8_info[17].fileTime1 = 0U;
  c8_info[17].fileTime2 = 0U;
  c8_info[18].context =
    "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mrdivide.m";
  c8_info[18].name = "rdivide";
  c8_info[18].dominantType = "single";
  c8_info[18].resolved =
    "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/rdivide.m";
  c8_info[18].fileLength = 403U;
  c8_info[18].fileTime1 = 1244764352U;
  c8_info[18].fileTime2 = 0U;
  c8_info[19].context = "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/rdivide.m";
  c8_info[19].name = "eml_div";
  c8_info[19].dominantType = "single";
  c8_info[19].resolved =
    "[ILX]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_div.m";
  c8_info[19].fileLength = 4269U;
  c8_info[19].fileTime1 = 1228122626U;
  c8_info[19].fileTime2 = 0U;
  c8_info[20].context =
    "[ILX]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_div.m/eml_fldiv";
  c8_info[20].name = "isreal";
  c8_info[20].dominantType = "single";
  c8_info[20].resolved = "[B]isreal";
  c8_info[20].fileLength = 0U;
  c8_info[20].fileTime1 = 0U;
  c8_info[20].fileTime2 = 0U;
  c8_info[21].context = "";
  c8_info[21].name = "times";
  c8_info[21].dominantType = "single";
  c8_info[21].resolved = "[B]times";
  c8_info[21].fileLength = 0U;
  c8_info[21].fileTime1 = 0U;
  c8_info[21].fileTime2 = 0U;
  c8_info[22].context = "";
  c8_info[22].name = "plus";
  c8_info[22].dominantType = "single";
  c8_info[22].resolved = "[B]plus";
  c8_info[22].fileLength = 0U;
  c8_info[22].fileTime1 = 0U;
  c8_info[22].fileTime2 = 0U;
}

static const mxArray *c8_e_sf_marshall(void *chartInstanceVoid, void *c8_u)
{
  const mxArray *c8_y = NULL;
  boolean_T c8_b_u;
  const mxArray *c8_b_y = NULL;
  SFc8_controlMCUSlugsMKIIInstanceStruct *chartInstance;
  chartInstance = (SFc8_controlMCUSlugsMKIIInstanceStruct *)chartInstanceVoid;
  c8_y = NULL;
  c8_b_u = *((boolean_T *)c8_u);
  c8_b_y = NULL;
  sf_mex_assign(&c8_b_y, sf_mex_create("y", &c8_b_u, 11, 0U, 0U, 0U, 0));
  sf_mex_assign(&c8_y, c8_b_y);
  return c8_y;
}

static void c8_emlrt_marshallIn(SFc8_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c8_O, const char_T *c8_name,
  real32_T c8_y[3])
{
  real32_T c8_fv3[3];
  int32_T c8_i35;
  sf_mex_import(c8_name, sf_mex_dup(c8_O), &c8_fv3, 1, 1, 0U, 1, 0U, 1, 3);
  for (c8_i35 = 0; c8_i35 < 3; c8_i35 = c8_i35 + 1) {
    c8_y[c8_i35] = c8_fv3[c8_i35];
  }

  sf_mex_destroy(&c8_O);
}

static real32_T c8_b_emlrt_marshallIn(SFc8_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c8_P, const char_T *
  c8_name)
{
  real32_T c8_y;
  real32_T c8_f0;
  sf_mex_import(c8_name, sf_mex_dup(c8_P), &c8_f0, 1, 1, 0U, 0, 0U, 0);
  c8_y = c8_f0;
  sf_mex_destroy(&c8_P);
  return c8_y;
}

static uint8_T c8_c_emlrt_marshallIn(SFc8_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *
  c8_b_is_active_c8_controlMCUSlugsMKII, const char_T *c8_name)
{
  uint8_T c8_y;
  uint8_T c8_u0;
  sf_mex_import(c8_name, sf_mex_dup(c8_b_is_active_c8_controlMCUSlugsMKII),
                &c8_u0, 1, 3, 0U, 0, 0U, 0);
  c8_y = c8_u0;
  sf_mex_destroy(&c8_b_is_active_c8_controlMCUSlugsMKII);
  return c8_y;
}

static void init_dsm_address_info(SFc8_controlMCUSlugsMKIIInstanceStruct
  *chartInstance)
{
}

/* SFunction Glue Code */
void sf_c8_controlMCUSlugsMKII_get_check_sum(mxArray *plhs[])
{
  ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(3639249756U);
  ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(2089251395U);
  ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(1983025534U);
  ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(3751555114U);
}

mxArray *sf_c8_controlMCUSlugsMKII_get_autoinheritance_info(void)
{
  const char *autoinheritanceFields[] = { "checksum", "inputs", "parameters",
    "outputs" };

  mxArray *mxAutoinheritanceInfo = mxCreateStructMatrix(1,1,4,
    autoinheritanceFields);

  {
    mxArray *mxChecksum = mxCreateDoubleMatrix(4,1,mxREAL);
    double *pr = mxGetPr(mxChecksum);
    pr[0] = (double)(191846970U);
    pr[1] = (double)(1990348773U);
    pr[2] = (double)(1139211062U);
    pr[3] = (double)(2394056119U);
    mxSetField(mxAutoinheritanceInfo,0,"checksum",mxChecksum);
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,6,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(9));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,1,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(9));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,1,"type",mxType);
    }

    mxSetField(mxData,1,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(3);
      pr[1] = (double)(1);
      mxSetField(mxData,2,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(9));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,2,"type",mxType);
    }

    mxSetField(mxData,2,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,3,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(9));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,3,"type",mxType);
    }

    mxSetField(mxData,3,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(3);
      pr[1] = (double)(1);
      mxSetField(mxData,4,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(9));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,4,"type",mxType);
    }

    mxSetField(mxData,4,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(3);
      pr[1] = (double)(1);
      mxSetField(mxData,5,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(9));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,5,"type",mxType);
    }

    mxSetField(mxData,5,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"inputs",mxData);
  }

  {
    mxSetField(mxAutoinheritanceInfo,0,"parameters",mxCreateDoubleMatrix(0,0,
                mxREAL));
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,4,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(3);
      pr[1] = (double)(1);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(9));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,1,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(9));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,1,"type",mxType);
    }

    mxSetField(mxData,1,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(3);
      pr[1] = (double)(1);
      mxSetField(mxData,2,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(9));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,2,"type",mxType);
    }

    mxSetField(mxData,2,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(3);
      pr[1] = (double)(1);
      mxSetField(mxData,3,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(9));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,3,"type",mxType);
    }

    mxSetField(mxData,3,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"outputs",mxData);
  }

  return(mxAutoinheritanceInfo);
}

static mxArray *sf_get_sim_state_info_c8_controlMCUSlugsMKII(void)
{
  const char *infoFields[] = { "chartChecksum", "varInfo" };

  mxArray *mxInfo = mxCreateStructMatrix(1, 1, 2, infoFields);
  const char *infoEncStr[] = {
    "100 S1x5'type','srcId','name','auxInfo'{{M[1],M[5],T\"O\",},{M[1],M[10],T\"P\",},{M[1],M[11],T\"Pch\",},{M[1],M[13],T\"PchB\",},{M[8],M[0],T\"is_active_c8_controlMCUSlugsMKII\",}}"
  };

  mxArray *mxVarInfo = sf_mex_decode_encoded_mx_struct_array(infoEncStr, 5, 10);
  mxArray *mxChecksum = mxCreateDoubleMatrix(1, 4, mxREAL);
  sf_c8_controlMCUSlugsMKII_get_check_sum(&mxChecksum);
  mxSetField(mxInfo, 0, infoFields[0], mxChecksum);
  mxSetField(mxInfo, 0, infoFields[1], mxVarInfo);
  return mxInfo;
}

static void chart_debug_initialization(SimStruct *S, unsigned int
  fullDebuggerInitialization)
{
  if (!sim_mode_is_rtw_gen(S)) {
    SFc8_controlMCUSlugsMKIIInstanceStruct *chartInstance;
    chartInstance = (SFc8_controlMCUSlugsMKIIInstanceStruct *) ((ChartInfoStruct
      *)(ssGetUserData(S)))->chartInstance;
    if (ssIsFirstInitCond(S) && fullDebuggerInitialization==1) {
      /* do this only if simulation is starting */
      {
        unsigned int chartAlreadyPresent;
        chartAlreadyPresent = sf_debug_initialize_chart
          (_controlMCUSlugsMKIIMachineNumber_,
           8,
           1,
           1,
           10,
           0,
           0,
           0,
           0,
           0,
           &(chartInstance->chartNumber),
           &(chartInstance->instanceNumber),
           ssGetPath(S),
           (void *)S);
        if (chartAlreadyPresent==0) {
          /* this is the first instance */
          init_script_number_translation(_controlMCUSlugsMKIIMachineNumber_,
            chartInstance->chartNumber);
          sf_debug_set_chart_disable_implicit_casting
            (_controlMCUSlugsMKIIMachineNumber_,chartInstance->chartNumber,1);
          sf_debug_set_chart_event_thresholds(_controlMCUSlugsMKIIMachineNumber_,
            chartInstance->chartNumber,
            0,
            0,
            0);
          _SFD_SET_DATA_PROPS(0,1,1,0,SF_SINGLE,0,NULL,0,0,0,0.0,1.0,0,"sd",0,
                              (MexFcnForType)c8_b_sf_marshall);

          {
            unsigned int dimVector[1];
            dimVector[0]= 3;
            _SFD_SET_DATA_PROPS(1,2,0,1,SF_SINGLE,1,&(dimVector[0]),0,0,0,0.0,
                                1.0,0,"O",0,(MexFcnForType)c8_sf_marshall);
          }

          _SFD_SET_DATA_PROPS(2,1,1,0,SF_SINGLE,0,NULL,0,0,0,0.0,1.0,0,"cd",0,
                              (MexFcnForType)c8_b_sf_marshall);

          {
            unsigned int dimVector[1];
            dimVector[0]= 3;
            _SFD_SET_DATA_PROPS(3,1,1,0,SF_SINGLE,1,&(dimVector[0]),0,0,0,0.0,
                                1.0,0,"WP1",0,(MexFcnForType)c8_sf_marshall);
          }

          _SFD_SET_DATA_PROPS(4,1,1,0,SF_SINGLE,0,NULL,0,0,0,0.0,1.0,0,"R",0,
                              (MexFcnForType)c8_b_sf_marshall);

          {
            unsigned int dimVector[1];
            dimVector[0]= 3;
            _SFD_SET_DATA_PROPS(5,1,1,0,SF_SINGLE,1,&(dimVector[0]),0,0,0,0.0,
                                1.0,0,"T1",0,(MexFcnForType)c8_sf_marshall);
          }

          _SFD_SET_DATA_PROPS(6,2,0,1,SF_SINGLE,0,NULL,0,0,0,0.0,1.0,0,"P",0,
                              (MexFcnForType)c8_b_sf_marshall);

          {
            unsigned int dimVector[1];
            dimVector[0]= 3;
            _SFD_SET_DATA_PROPS(7,2,0,1,SF_SINGLE,1,&(dimVector[0]),0,0,0,0.0,
                                1.0,0,"Pch",0,(MexFcnForType)c8_sf_marshall);
          }

          {
            unsigned int dimVector[1];
            dimVector[0]= 3;
            _SFD_SET_DATA_PROPS(8,1,1,0,SF_SINGLE,1,&(dimVector[0]),0,0,0,0.0,
                                1.0,0,"T2",0,(MexFcnForType)c8_sf_marshall);
          }

          {
            unsigned int dimVector[1];
            dimVector[0]= 3;
            _SFD_SET_DATA_PROPS(9,2,0,1,SF_SINGLE,1,&(dimVector[0]),0,0,0,0.0,
                                1.0,0,"PchB",0,(MexFcnForType)c8_sf_marshall);
          }

          _SFD_STATE_INFO(0,0,2);
          _SFD_CH_SUBSTATE_COUNT(0);
          _SFD_CH_SUBSTATE_DECOMP(0);
        }

        _SFD_CV_INIT_CHART(0,0,0,0);

        {
          _SFD_CV_INIT_STATE(0,0,0,0,0,0,NULL,NULL);
        }

        _SFD_CV_INIT_TRANS(0,0,NULL,NULL,0,NULL);

        /* Initialization of EML Model Coverage */
        _SFD_CV_INIT_EML(0,2,2,0,0,0,0,0,0);
        _SFD_CV_INIT_EML_FCN(0,0,"eML_blk_kernel",0,-1,591);
        _SFD_CV_INIT_EML_FCN(0,1,"localAbs",593,-1,715);
        _SFD_CV_INIT_EML_IF(0,0,318,338,371,406);
        _SFD_CV_INIT_EML_IF(0,1,627,635,671,711);
        _SFD_TRANS_COV_WTS(0,0,0,1,0);
        if (chartAlreadyPresent==0) {
          _SFD_TRANS_COV_MAPS(0,
                              0,NULL,NULL,
                              0,NULL,NULL,
                              1,NULL,NULL,
                              0,NULL,NULL);
        }

        {
          real32_T *c8_sd;
          real32_T (*c8_O)[3];
          real32_T *c8_cd;
          real32_T (*c8_WP1)[3];
          real32_T *c8_R;
          real32_T (*c8_T1)[3];
          real32_T *c8_P;
          real32_T (*c8_Pch)[3];
          real32_T (*c8_T2)[3];
          real32_T (*c8_PchB)[3];
          c8_PchB = (real32_T (*)[3])ssGetOutputPortSignal(chartInstance->S, 4);
          c8_T2 = (real32_T (*)[3])ssGetInputPortSignal(chartInstance->S, 5);
          c8_Pch = (real32_T (*)[3])ssGetOutputPortSignal(chartInstance->S, 3);
          c8_P = (real32_T *)ssGetOutputPortSignal(chartInstance->S, 2);
          c8_T1 = (real32_T (*)[3])ssGetInputPortSignal(chartInstance->S, 4);
          c8_R = (real32_T *)ssGetInputPortSignal(chartInstance->S, 3);
          c8_WP1 = (real32_T (*)[3])ssGetInputPortSignal(chartInstance->S, 2);
          c8_cd = (real32_T *)ssGetInputPortSignal(chartInstance->S, 1);
          c8_O = (real32_T (*)[3])ssGetOutputPortSignal(chartInstance->S, 1);
          c8_sd = (real32_T *)ssGetInputPortSignal(chartInstance->S, 0);
          _SFD_SET_DATA_VALUE_PTR(0U, c8_sd);
          _SFD_SET_DATA_VALUE_PTR(1U, c8_O);
          _SFD_SET_DATA_VALUE_PTR(2U, c8_cd);
          _SFD_SET_DATA_VALUE_PTR(3U, c8_WP1);
          _SFD_SET_DATA_VALUE_PTR(4U, c8_R);
          _SFD_SET_DATA_VALUE_PTR(5U, c8_T1);
          _SFD_SET_DATA_VALUE_PTR(6U, c8_P);
          _SFD_SET_DATA_VALUE_PTR(7U, c8_Pch);
          _SFD_SET_DATA_VALUE_PTR(8U, c8_T2);
          _SFD_SET_DATA_VALUE_PTR(9U, c8_PchB);
        }
      }
    } else {
      sf_debug_reset_current_state_configuration
        (_controlMCUSlugsMKIIMachineNumber_,chartInstance->chartNumber,
         chartInstance->instanceNumber);
    }
  }
}

static void sf_opaque_initialize_c8_controlMCUSlugsMKII(void *chartInstanceVar)
{
  chart_debug_initialization(((SFc8_controlMCUSlugsMKIIInstanceStruct*)
    chartInstanceVar)->S,0);
  initialize_params_c8_controlMCUSlugsMKII
    ((SFc8_controlMCUSlugsMKIIInstanceStruct*) chartInstanceVar);
  initialize_c8_controlMCUSlugsMKII((SFc8_controlMCUSlugsMKIIInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_enable_c8_controlMCUSlugsMKII(void *chartInstanceVar)
{
  enable_c8_controlMCUSlugsMKII((SFc8_controlMCUSlugsMKIIInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_disable_c8_controlMCUSlugsMKII(void *chartInstanceVar)
{
  disable_c8_controlMCUSlugsMKII((SFc8_controlMCUSlugsMKIIInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_gateway_c8_controlMCUSlugsMKII(void *chartInstanceVar)
{
  sf_c8_controlMCUSlugsMKII((SFc8_controlMCUSlugsMKIIInstanceStruct*)
    chartInstanceVar);
}

static mxArray* sf_internal_get_sim_state_c8_controlMCUSlugsMKII(SimStruct* S)
{
  ChartInfoStruct *chartInfo = (ChartInfoStruct*) ssGetUserData(S);
  mxArray *plhs[1] = { NULL };

  mxArray *prhs[4];
  int mxError = 0;
  prhs[0] = mxCreateString("chart_simctx_raw2high");
  prhs[1] = mxCreateDoubleScalar(ssGetSFuncBlockHandle(S));
  prhs[2] = (mxArray*) get_sim_state_c8_controlMCUSlugsMKII
    ((SFc8_controlMCUSlugsMKIIInstanceStruct*)chartInfo->chartInstance);/* raw sim ctx */
  prhs[3] = sf_get_sim_state_info_c8_controlMCUSlugsMKII();/* state var info */
  mxError = sf_mex_call_matlab(1, plhs, 4, prhs, "sfprivate");
  mxDestroyArray(prhs[0]);
  mxDestroyArray(prhs[1]);
  mxDestroyArray(prhs[2]);
  mxDestroyArray(prhs[3]);
  if (mxError || plhs[0] == NULL) {
    sf_mex_error_message("Stateflow Internal Error: \nError calling 'chart_simctx_raw2high'.\n");
  }

  return plhs[0];
}

static void sf_internal_set_sim_state_c8_controlMCUSlugsMKII(SimStruct* S, const
  mxArray *st)
{
  ChartInfoStruct *chartInfo = (ChartInfoStruct*) ssGetUserData(S);
  mxArray *plhs[1] = { NULL };

  mxArray *prhs[4];
  int mxError = 0;
  prhs[0] = mxCreateString("chart_simctx_high2raw");
  prhs[1] = mxCreateDoubleScalar(ssGetSFuncBlockHandle(S));
  prhs[2] = mxDuplicateArray(st);      /* high level simctx */
  prhs[3] = (mxArray*) sf_get_sim_state_info_c8_controlMCUSlugsMKII();/* state var info */
  mxError = sf_mex_call_matlab(1, plhs, 4, prhs, "sfprivate");
  mxDestroyArray(prhs[0]);
  mxDestroyArray(prhs[1]);
  mxDestroyArray(prhs[2]);
  mxDestroyArray(prhs[3]);
  if (mxError || plhs[0] == NULL) {
    sf_mex_error_message("Stateflow Internal Error: \nError calling 'chart_simctx_high2raw'.\n");
  }

  set_sim_state_c8_controlMCUSlugsMKII((SFc8_controlMCUSlugsMKIIInstanceStruct*)
    chartInfo->chartInstance, mxDuplicateArray(plhs[0]));
  mxDestroyArray(plhs[0]);
}

static mxArray* sf_opaque_get_sim_state_c8_controlMCUSlugsMKII(SimStruct* S)
{
  return sf_internal_get_sim_state_c8_controlMCUSlugsMKII(S);
}

static void sf_opaque_set_sim_state_c8_controlMCUSlugsMKII(SimStruct* S, const
  mxArray *st)
{
  sf_internal_set_sim_state_c8_controlMCUSlugsMKII(S, st);
}

static void sf_opaque_terminate_c8_controlMCUSlugsMKII(void *chartInstanceVar)
{
  if (chartInstanceVar!=NULL) {
    SimStruct *S = ((SFc8_controlMCUSlugsMKIIInstanceStruct*) chartInstanceVar
      )->S;
    if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
      sf_clear_rtw_identifier(S);
    }

    finalize_c8_controlMCUSlugsMKII((SFc8_controlMCUSlugsMKIIInstanceStruct*)
      chartInstanceVar);
    free((void *)chartInstanceVar);
    ssSetUserData(S,NULL);
  }
}

extern unsigned int sf_machine_global_initializer_called(void);
static void mdlProcessParameters_c8_controlMCUSlugsMKII(SimStruct *S)
{
  int i;
  for (i=0;i<ssGetNumRunTimeParams(S);i++) {
    if (ssGetSFcnParamTunable(S,i)) {
      ssUpdateDlgParamAsRunTimeParam(S,i);
    }
  }

  if (sf_machine_global_initializer_called()) {
    initialize_params_c8_controlMCUSlugsMKII
      ((SFc8_controlMCUSlugsMKIIInstanceStruct*)(((ChartInfoStruct *)
         ssGetUserData(S))->chartInstance));
  }
}

static void mdlSetWorkWidths_c8_controlMCUSlugsMKII(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
    int_T chartIsInlinable =
      (int_T)sf_is_chart_inlinable("controlMCUSlugsMKII","controlMCUSlugsMKII",8);
    ssSetStateflowIsInlinable(S,chartIsInlinable);
    ssSetRTWCG(S,sf_rtw_info_uint_prop("controlMCUSlugsMKII",
                "controlMCUSlugsMKII",8,"RTWCG"));
    ssSetEnableFcnIsTrivial(S,1);
    ssSetDisableFcnIsTrivial(S,1);
    ssSetNotMultipleInlinable(S,sf_rtw_info_uint_prop("controlMCUSlugsMKII",
      "controlMCUSlugsMKII",8,"gatewayCannotBeInlinedMultipleTimes"));
    if (chartIsInlinable) {
      ssSetInputPortOptimOpts(S, 0, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 1, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 2, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 3, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 4, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 5, SS_REUSABLE_AND_LOCAL);
      sf_mark_chart_expressionable_inputs(S,"controlMCUSlugsMKII",
        "controlMCUSlugsMKII",8,6);
      sf_mark_chart_reusable_outputs(S,"controlMCUSlugsMKII",
        "controlMCUSlugsMKII",8,4);
    }

    sf_set_rtw_dwork_info(S,"controlMCUSlugsMKII","controlMCUSlugsMKII",8);
    ssSetHasSubFunctions(S,!(chartIsInlinable));
    ssSetOptions(S,ssGetOptions(S)|SS_OPTION_WORKS_WITH_CODE_REUSE);
  }

  ssSetChecksum0(S,(231377053U));
  ssSetChecksum1(S,(1035107510U));
  ssSetChecksum2(S,(2894637025U));
  ssSetChecksum3(S,(2971987001U));
  ssSetmdlDerivatives(S, NULL);
  ssSetExplicitFCSSCtrl(S,1);
}

static void mdlRTW_c8_controlMCUSlugsMKII(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S)) {
    sf_write_symbol_mapping(S, "controlMCUSlugsMKII", "controlMCUSlugsMKII",8);
    ssWriteRTWStrParam(S, "StateflowChartType", "Embedded MATLAB");
  }
}

static void mdlStart_c8_controlMCUSlugsMKII(SimStruct *S)
{
  SFc8_controlMCUSlugsMKIIInstanceStruct *chartInstance;
  chartInstance = (SFc8_controlMCUSlugsMKIIInstanceStruct *)malloc(sizeof
    (SFc8_controlMCUSlugsMKIIInstanceStruct));
  memset(chartInstance, 0, sizeof(SFc8_controlMCUSlugsMKIIInstanceStruct));
  if (chartInstance==NULL) {
    sf_mex_error_message("Could not allocate memory for chart instance.");
  }

  chartInstance->chartInfo.chartInstance = chartInstance;
  chartInstance->chartInfo.isEMLChart = 1;
  chartInstance->chartInfo.chartInitialized = 0;
  chartInstance->chartInfo.sFunctionGateway =
    sf_opaque_gateway_c8_controlMCUSlugsMKII;
  chartInstance->chartInfo.initializeChart =
    sf_opaque_initialize_c8_controlMCUSlugsMKII;
  chartInstance->chartInfo.terminateChart =
    sf_opaque_terminate_c8_controlMCUSlugsMKII;
  chartInstance->chartInfo.enableChart = sf_opaque_enable_c8_controlMCUSlugsMKII;
  chartInstance->chartInfo.disableChart =
    sf_opaque_disable_c8_controlMCUSlugsMKII;
  chartInstance->chartInfo.getSimState =
    sf_opaque_get_sim_state_c8_controlMCUSlugsMKII;
  chartInstance->chartInfo.setSimState =
    sf_opaque_set_sim_state_c8_controlMCUSlugsMKII;
  chartInstance->chartInfo.getSimStateInfo =
    sf_get_sim_state_info_c8_controlMCUSlugsMKII;
  chartInstance->chartInfo.zeroCrossings = NULL;
  chartInstance->chartInfo.outputs = NULL;
  chartInstance->chartInfo.derivatives = NULL;
  chartInstance->chartInfo.mdlRTW = mdlRTW_c8_controlMCUSlugsMKII;
  chartInstance->chartInfo.mdlStart = mdlStart_c8_controlMCUSlugsMKII;
  chartInstance->chartInfo.mdlSetWorkWidths =
    mdlSetWorkWidths_c8_controlMCUSlugsMKII;
  chartInstance->chartInfo.extModeExec = NULL;
  chartInstance->chartInfo.restoreLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.restoreBeforeLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.storeCurrentConfiguration = NULL;
  chartInstance->S = S;
  ssSetUserData(S,(void *)(&(chartInstance->chartInfo)));/* register the chart instance with simstruct */
  if (!sim_mode_is_rtw_gen(S)) {
    init_dsm_address_info(chartInstance);
  }

  chart_debug_initialization(S,1);
}

void c8_controlMCUSlugsMKII_method_dispatcher(SimStruct *S, int_T method, void
  *data)
{
  switch (method) {
   case SS_CALL_MDL_START:
    mdlStart_c8_controlMCUSlugsMKII(S);
    break;

   case SS_CALL_MDL_SET_WORK_WIDTHS:
    mdlSetWorkWidths_c8_controlMCUSlugsMKII(S);
    break;

   case SS_CALL_MDL_PROCESS_PARAMETERS:
    mdlProcessParameters_c8_controlMCUSlugsMKII(S);
    break;

   default:
    /* Unhandled method */
    sf_mex_error_message("Stateflow Internal Error:\n"
                         "Error calling c8_controlMCUSlugsMKII_method_dispatcher.\n"
                         "Can't handle method %d.\n", method);
    break;
  }
}
