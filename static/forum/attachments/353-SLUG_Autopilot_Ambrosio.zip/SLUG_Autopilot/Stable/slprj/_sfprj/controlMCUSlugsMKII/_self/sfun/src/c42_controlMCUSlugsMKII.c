/* Include files */

#include "blascompat32.h"
#include "controlMCUSlugsMKII_sfun.h"
#include "c42_controlMCUSlugsMKII.h"
#define CHARTINSTANCE_CHARTNUMBER      (chartInstance->chartNumber)
#define CHARTINSTANCE_INSTANCENUMBER   (chartInstance->instanceNumber)
#include "controlMCUSlugsMKII_sfun_debug_macros.h"

/* Type Definitions */

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */
static const char *c42_debug_family_names[5] = { "nargin", "nargout", "x", "y",
  "xDoty" };

/* Function Declarations */
static void initialize_c42_controlMCUSlugsMKII
  (SFc42_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void initialize_params_c42_controlMCUSlugsMKII
  (SFc42_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void enable_c42_controlMCUSlugsMKII
  (SFc42_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void disable_c42_controlMCUSlugsMKII
  (SFc42_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void c42_update_debugger_state_c42_controlMCUSlugsMKII
  (SFc42_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static const mxArray *get_sim_state_c42_controlMCUSlugsMKII
  (SFc42_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void set_sim_state_c42_controlMCUSlugsMKII
  (SFc42_controlMCUSlugsMKIIInstanceStruct *chartInstance, const mxArray *c42_st);
static void finalize_c42_controlMCUSlugsMKII
  (SFc42_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void sf_c42_controlMCUSlugsMKII(SFc42_controlMCUSlugsMKIIInstanceStruct
  *chartInstance);
static void init_script_number_translation(uint32_T c42_machineNumber, uint32_T
  c42_chartNumber);
static const mxArray *c42_sf_marshall(void *chartInstanceVoid, void *c42_u);
static const mxArray *c42_b_sf_marshall(void *chartInstanceVoid, void *c42_u);
static const mxArray *c42_c_sf_marshall(void *chartInstanceVoid, void *c42_u);
static const mxArray *c42_d_sf_marshall(void *chartInstanceVoid, void *c42_u);
static real32_T c42_emlrt_marshallIn(SFc42_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c42_xDoty, const char_T *c42_name);
static uint8_T c42_b_emlrt_marshallIn(SFc42_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c42_b_is_active_c42_controlMCUSlugsMKII, const
  char_T *c42_name);
static void init_dsm_address_info(SFc42_controlMCUSlugsMKIIInstanceStruct
  *chartInstance);

/* Function Definitions */
static void initialize_c42_controlMCUSlugsMKII
  (SFc42_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
  chartInstance->c42_is_active_c42_controlMCUSlugsMKII = 0U;
}

static void initialize_params_c42_controlMCUSlugsMKII
  (SFc42_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
}

static void enable_c42_controlMCUSlugsMKII
  (SFc42_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
}

static void disable_c42_controlMCUSlugsMKII
  (SFc42_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
}

static void c42_update_debugger_state_c42_controlMCUSlugsMKII
  (SFc42_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
}

static const mxArray *get_sim_state_c42_controlMCUSlugsMKII
  (SFc42_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
  const mxArray *c42_st = NULL;
  const mxArray *c42_y = NULL;
  real32_T c42_hoistedGlobal;
  real32_T c42_u;
  const mxArray *c42_b_y = NULL;
  uint8_T c42_b_hoistedGlobal;
  uint8_T c42_b_u;
  const mxArray *c42_c_y = NULL;
  real32_T *c42_xDoty;
  c42_xDoty = (real32_T *)ssGetOutputPortSignal(chartInstance->S, 1);
  c42_st = NULL;
  c42_y = NULL;
  sf_mex_assign(&c42_y, sf_mex_createcellarray(2));
  c42_hoistedGlobal = *c42_xDoty;
  c42_u = c42_hoistedGlobal;
  c42_b_y = NULL;
  sf_mex_assign(&c42_b_y, sf_mex_create("y", &c42_u, 1, 0U, 0U, 0U, 0));
  sf_mex_setcell(c42_y, 0, c42_b_y);
  c42_b_hoistedGlobal = chartInstance->c42_is_active_c42_controlMCUSlugsMKII;
  c42_b_u = c42_b_hoistedGlobal;
  c42_c_y = NULL;
  sf_mex_assign(&c42_c_y, sf_mex_create("y", &c42_b_u, 3, 0U, 0U, 0U, 0));
  sf_mex_setcell(c42_y, 1, c42_c_y);
  sf_mex_assign(&c42_st, c42_y);
  return c42_st;
}

static void set_sim_state_c42_controlMCUSlugsMKII
  (SFc42_controlMCUSlugsMKIIInstanceStruct *chartInstance, const mxArray *c42_st)
{
  const mxArray *c42_u;
  real32_T *c42_xDoty;
  c42_xDoty = (real32_T *)ssGetOutputPortSignal(chartInstance->S, 1);
  chartInstance->c42_doneDoubleBufferReInit = TRUE;
  c42_u = sf_mex_dup(c42_st);
  *c42_xDoty = c42_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell
    (c42_u, 0)), "xDoty");
  chartInstance->c42_is_active_c42_controlMCUSlugsMKII = c42_b_emlrt_marshallIn
    (chartInstance, sf_mex_dup(sf_mex_getcell(c42_u, 1)),
     "is_active_c42_controlMCUSlugsMKII");
  sf_mex_destroy(&c42_u);
  c42_update_debugger_state_c42_controlMCUSlugsMKII(chartInstance);
  sf_mex_destroy(&c42_st);
}

static void finalize_c42_controlMCUSlugsMKII
  (SFc42_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
}

static void sf_c42_controlMCUSlugsMKII(SFc42_controlMCUSlugsMKIIInstanceStruct
  *chartInstance)
{
  int32_T c42_i0;
  int32_T c42_i1;
  int32_T c42_previousEvent;
  int32_T c42_i2;
  real32_T c42_hoistedGlobal[3];
  int32_T c42_i3;
  real32_T c42_b_hoistedGlobal[3];
  int32_T c42_i4;
  real32_T c42_x[3];
  int32_T c42_i5;
  real32_T c42_y[3];
  uint32_T c42_debug_family_var_map[5];
  real_T c42_nargin = 2.0;
  real_T c42_nargout = 1.0;
  real32_T c42_xDoty;
  real32_T c42_a;
  real32_T c42_b;
  real32_T c42_b_y;
  real32_T c42_b_a;
  real32_T c42_b_b;
  real32_T c42_c_y;
  real32_T c42_c_a;
  real32_T c42_c_b;
  real32_T c42_d_y;
  real32_T *c42_b_xDoty;
  real32_T (*c42_e_y)[3];
  real32_T (*c42_b_x)[3];
  c42_b_xDoty = (real32_T *)ssGetOutputPortSignal(chartInstance->S, 1);
  c42_e_y = (real32_T (*)[3])ssGetInputPortSignal(chartInstance->S, 1);
  c42_b_x = (real32_T (*)[3])ssGetInputPortSignal(chartInstance->S, 0);
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
  _SFD_CC_CALL(CHART_ENTER_SFUNCTION_TAG,40);
  for (c42_i0 = 0; c42_i0 < 3; c42_i0 = c42_i0 + 1) {
    _SFD_DATA_RANGE_CHECK((real_T)(*c42_b_x)[c42_i0], 0U);
  }

  for (c42_i1 = 0; c42_i1 < 3; c42_i1 = c42_i1 + 1) {
    _SFD_DATA_RANGE_CHECK((real_T)(*c42_e_y)[c42_i1], 1U);
  }

  _SFD_DATA_RANGE_CHECK((real_T)*c42_b_xDoty, 2U);
  c42_previousEvent = _sfEvent_;
  _sfEvent_ = CALL_EVENT;
  _SFD_CC_CALL(CHART_ENTER_DURING_FUNCTION_TAG,40);
  for (c42_i2 = 0; c42_i2 < 3; c42_i2 = c42_i2 + 1) {
    c42_hoistedGlobal[c42_i2] = (*c42_b_x)[c42_i2];
  }

  for (c42_i3 = 0; c42_i3 < 3; c42_i3 = c42_i3 + 1) {
    c42_b_hoistedGlobal[c42_i3] = (*c42_e_y)[c42_i3];
  }

  for (c42_i4 = 0; c42_i4 < 3; c42_i4 = c42_i4 + 1) {
    c42_x[c42_i4] = c42_hoistedGlobal[c42_i4];
  }

  for (c42_i5 = 0; c42_i5 < 3; c42_i5 = c42_i5 + 1) {
    c42_y[c42_i5] = c42_b_hoistedGlobal[c42_i5];
  }

  sf_debug_symbol_scope_push_eml(0U, 5U, 5U, c42_debug_family_names,
    c42_debug_family_var_map);
  sf_debug_symbol_scope_add_eml(&c42_nargin, c42_c_sf_marshall, 0U);
  sf_debug_symbol_scope_add_eml(&c42_nargout, c42_c_sf_marshall, 1U);
  sf_debug_symbol_scope_add_eml(&c42_x, c42_b_sf_marshall, 2U);
  sf_debug_symbol_scope_add_eml(&c42_y, c42_b_sf_marshall, 3U);
  sf_debug_symbol_scope_add_eml(&c42_xDoty, c42_sf_marshall, 4U);
  CV_EML_FCN(0, 0);

  /*  This block supports an embeddable subset of the MATLAB language. */
  /*  See the help menu for details.  */
  _SFD_EML_CALL(0,5);
  c42_a = c42_x[0];
  c42_b = c42_y[0];
  c42_b_y = c42_a * c42_b;
  c42_b_a = c42_x[1];
  c42_b_b = c42_y[1];
  c42_c_y = c42_b_a * c42_b_b;
  c42_c_a = c42_x[2];
  c42_c_b = c42_y[2];
  c42_d_y = c42_c_a * c42_c_b;
  c42_xDoty = (c42_b_y + c42_c_y) + c42_d_y;
  _SFD_EML_CALL(0,-5);
  sf_debug_symbol_scope_pop();
  *c42_b_xDoty = c42_xDoty;
  _SFD_CC_CALL(EXIT_OUT_OF_FUNCTION_TAG,40);
  _sfEvent_ = c42_previousEvent;
  sf_debug_check_for_state_inconsistency(_controlMCUSlugsMKIIMachineNumber_,
    chartInstance->chartNumber, chartInstance->instanceNumber
    );
}

static void init_script_number_translation(uint32_T c42_machineNumber, uint32_T
  c42_chartNumber)
{
}

static const mxArray *c42_sf_marshall(void *chartInstanceVoid, void *c42_u)
{
  const mxArray *c42_y = NULL;
  real32_T c42_b_u;
  const mxArray *c42_b_y = NULL;
  SFc42_controlMCUSlugsMKIIInstanceStruct *chartInstance;
  chartInstance = (SFc42_controlMCUSlugsMKIIInstanceStruct *)chartInstanceVoid;
  c42_y = NULL;
  c42_b_u = *((real32_T *)c42_u);
  c42_b_y = NULL;
  sf_mex_assign(&c42_b_y, sf_mex_create("y", &c42_b_u, 1, 0U, 0U, 0U, 0));
  sf_mex_assign(&c42_y, c42_b_y);
  return c42_y;
}

static const mxArray *c42_b_sf_marshall(void *chartInstanceVoid, void *c42_u)
{
  const mxArray *c42_y = NULL;
  int32_T c42_i6;
  real32_T c42_b_u[3];
  const mxArray *c42_b_y = NULL;
  SFc42_controlMCUSlugsMKIIInstanceStruct *chartInstance;
  chartInstance = (SFc42_controlMCUSlugsMKIIInstanceStruct *)chartInstanceVoid;
  c42_y = NULL;
  for (c42_i6 = 0; c42_i6 < 3; c42_i6 = c42_i6 + 1) {
    c42_b_u[c42_i6] = (*((real32_T (*)[3])c42_u))[c42_i6];
  }

  c42_b_y = NULL;
  sf_mex_assign(&c42_b_y, sf_mex_create("y", &c42_b_u, 1, 0U, 1U, 0U, 1, 3));
  sf_mex_assign(&c42_y, c42_b_y);
  return c42_y;
}

static const mxArray *c42_c_sf_marshall(void *chartInstanceVoid, void *c42_u)
{
  const mxArray *c42_y = NULL;
  real_T c42_b_u;
  const mxArray *c42_b_y = NULL;
  SFc42_controlMCUSlugsMKIIInstanceStruct *chartInstance;
  chartInstance = (SFc42_controlMCUSlugsMKIIInstanceStruct *)chartInstanceVoid;
  c42_y = NULL;
  c42_b_u = *((real_T *)c42_u);
  c42_b_y = NULL;
  sf_mex_assign(&c42_b_y, sf_mex_create("y", &c42_b_u, 0, 0U, 0U, 0U, 0));
  sf_mex_assign(&c42_y, c42_b_y);
  return c42_y;
}

const mxArray *sf_c42_controlMCUSlugsMKII_get_eml_resolved_functions_info(void)
{
  const mxArray *c42_nameCaptureInfo = NULL;
  c42_ResolvedFunctionInfo c42_info[12];
  c42_ResolvedFunctionInfo (*c42_b_info)[12];
  const mxArray *c42_m0 = NULL;
  int32_T c42_i7;
  c42_ResolvedFunctionInfo *c42_r0;
  c42_nameCaptureInfo = NULL;
  c42_b_info = (c42_ResolvedFunctionInfo (*)[12])c42_info;
  (*c42_b_info)[0].context = "";
  (*c42_b_info)[0].name = "mtimes";
  (*c42_b_info)[0].dominantType = "single";
  (*c42_b_info)[0].resolved =
    "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  (*c42_b_info)[0].fileLength = 3425U;
  (*c42_b_info)[0].fileTime1 = 1250701566U;
  (*c42_b_info)[0].fileTime2 = 0U;
  (*c42_b_info)[1].context =
    "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  (*c42_b_info)[1].name = "nargin";
  (*c42_b_info)[1].dominantType = "";
  (*c42_b_info)[1].resolved = "[B]nargin";
  (*c42_b_info)[1].fileLength = 0U;
  (*c42_b_info)[1].fileTime1 = 0U;
  (*c42_b_info)[1].fileTime2 = 0U;
  (*c42_b_info)[2].context =
    "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  (*c42_b_info)[2].name = "gt";
  (*c42_b_info)[2].dominantType = "double";
  (*c42_b_info)[2].resolved = "[B]gt";
  (*c42_b_info)[2].fileLength = 0U;
  (*c42_b_info)[2].fileTime1 = 0U;
  (*c42_b_info)[2].fileTime2 = 0U;
  (*c42_b_info)[3].context =
    "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  (*c42_b_info)[3].name = "isa";
  (*c42_b_info)[3].dominantType = "single";
  (*c42_b_info)[3].resolved = "[B]isa";
  (*c42_b_info)[3].fileLength = 0U;
  (*c42_b_info)[3].fileTime1 = 0U;
  (*c42_b_info)[3].fileTime2 = 0U;
  (*c42_b_info)[4].context =
    "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  (*c42_b_info)[4].name = "isinteger";
  (*c42_b_info)[4].dominantType = "single";
  (*c42_b_info)[4].resolved = "[B]isinteger";
  (*c42_b_info)[4].fileLength = 0U;
  (*c42_b_info)[4].fileTime1 = 0U;
  (*c42_b_info)[4].fileTime2 = 0U;
  (*c42_b_info)[5].context =
    "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  (*c42_b_info)[5].name = "isscalar";
  (*c42_b_info)[5].dominantType = "single";
  (*c42_b_info)[5].resolved = "[B]isscalar";
  (*c42_b_info)[5].fileLength = 0U;
  (*c42_b_info)[5].fileTime1 = 0U;
  (*c42_b_info)[5].fileTime2 = 0U;
  (*c42_b_info)[6].context =
    "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  (*c42_b_info)[6].name = "strcmp";
  (*c42_b_info)[6].dominantType = "char";
  (*c42_b_info)[6].resolved = "[B]strcmp";
  (*c42_b_info)[6].fileLength = 0U;
  (*c42_b_info)[6].fileTime1 = 0U;
  (*c42_b_info)[6].fileTime2 = 0U;
  (*c42_b_info)[7].context =
    "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  (*c42_b_info)[7].name = "size";
  (*c42_b_info)[7].dominantType = "single";
  (*c42_b_info)[7].resolved = "[B]size";
  (*c42_b_info)[7].fileLength = 0U;
  (*c42_b_info)[7].fileTime1 = 0U;
  (*c42_b_info)[7].fileTime2 = 0U;
  (*c42_b_info)[8].context =
    "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  (*c42_b_info)[8].name = "eq";
  (*c42_b_info)[8].dominantType = "double";
  (*c42_b_info)[8].resolved = "[B]eq";
  (*c42_b_info)[8].fileLength = 0U;
  (*c42_b_info)[8].fileTime1 = 0U;
  (*c42_b_info)[8].fileTime2 = 0U;
  (*c42_b_info)[9].context =
    "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  (*c42_b_info)[9].name = "class";
  (*c42_b_info)[9].dominantType = "single";
  (*c42_b_info)[9].resolved = "[B]class";
  (*c42_b_info)[9].fileLength = 0U;
  (*c42_b_info)[9].fileTime1 = 0U;
  (*c42_b_info)[9].fileTime2 = 0U;
  (*c42_b_info)[10].context =
    "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  (*c42_b_info)[10].name = "not";
  (*c42_b_info)[10].dominantType = "logical";
  (*c42_b_info)[10].resolved = "[B]not";
  (*c42_b_info)[10].fileLength = 0U;
  (*c42_b_info)[10].fileTime1 = 0U;
  (*c42_b_info)[10].fileTime2 = 0U;
  (*c42_b_info)[11].context = "";
  (*c42_b_info)[11].name = "plus";
  (*c42_b_info)[11].dominantType = "single";
  (*c42_b_info)[11].resolved = "[B]plus";
  (*c42_b_info)[11].fileLength = 0U;
  (*c42_b_info)[11].fileTime1 = 0U;
  (*c42_b_info)[11].fileTime2 = 0U;
  sf_mex_assign(&c42_m0, sf_mex_createstruct("nameCaptureInfo", 1, 12));
  for (c42_i7 = 0; c42_i7 < 12; c42_i7 = c42_i7 + 1) {
    c42_r0 = &c42_info[c42_i7];
    sf_mex_addfield(c42_m0, sf_mex_create("nameCaptureInfo", c42_r0->context, 15,
      0U, 0U, 0U, 2, 1, strlen(c42_r0->context)), "context"
                    , "nameCaptureInfo", c42_i7);
    sf_mex_addfield(c42_m0, sf_mex_create("nameCaptureInfo", c42_r0->name, 15,
      0U, 0U, 0U, 2, 1, strlen(c42_r0->name)), "name",
                    "nameCaptureInfo", c42_i7);
    sf_mex_addfield(c42_m0, sf_mex_create("nameCaptureInfo",
      c42_r0->dominantType, 15, 0U, 0U, 0U, 2, 1, strlen(c42_r0->dominantType)),
                    "dominantType", "nameCaptureInfo", c42_i7);
    sf_mex_addfield(c42_m0, sf_mex_create("nameCaptureInfo", c42_r0->resolved,
      15, 0U, 0U, 0U, 2, 1, strlen(c42_r0->resolved)),
                    "resolved", "nameCaptureInfo", c42_i7);
    sf_mex_addfield(c42_m0, sf_mex_create("nameCaptureInfo", &c42_r0->fileLength,
      7, 0U, 0U, 0U, 0), "fileLength", "nameCaptureInfo",
                    c42_i7);
    sf_mex_addfield(c42_m0, sf_mex_create("nameCaptureInfo", &c42_r0->fileTime1,
      7, 0U, 0U, 0U, 0), "fileTime1", "nameCaptureInfo",
                    c42_i7);
    sf_mex_addfield(c42_m0, sf_mex_create("nameCaptureInfo", &c42_r0->fileTime2,
      7, 0U, 0U, 0U, 0), "fileTime2", "nameCaptureInfo",
                    c42_i7);
  }

  sf_mex_assign(&c42_nameCaptureInfo, c42_m0);
  return c42_nameCaptureInfo;
}

static const mxArray *c42_d_sf_marshall(void *chartInstanceVoid, void *c42_u)
{
  const mxArray *c42_y = NULL;
  boolean_T c42_b_u;
  const mxArray *c42_b_y = NULL;
  SFc42_controlMCUSlugsMKIIInstanceStruct *chartInstance;
  chartInstance = (SFc42_controlMCUSlugsMKIIInstanceStruct *)chartInstanceVoid;
  c42_y = NULL;
  c42_b_u = *((boolean_T *)c42_u);
  c42_b_y = NULL;
  sf_mex_assign(&c42_b_y, sf_mex_create("y", &c42_b_u, 11, 0U, 0U, 0U, 0));
  sf_mex_assign(&c42_y, c42_b_y);
  return c42_y;
}

static real32_T c42_emlrt_marshallIn(SFc42_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c42_xDoty, const char_T
  *c42_name)
{
  real32_T c42_y;
  real32_T c42_f0;
  sf_mex_import(c42_name, sf_mex_dup(c42_xDoty), &c42_f0, 1, 1, 0U, 0, 0U, 0);
  c42_y = c42_f0;
  sf_mex_destroy(&c42_xDoty);
  return c42_y;
}

static uint8_T c42_b_emlrt_marshallIn(SFc42_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *
  c42_b_is_active_c42_controlMCUSlugsMKII, const char_T *c42_name)
{
  uint8_T c42_y;
  uint8_T c42_u0;
  sf_mex_import(c42_name, sf_mex_dup(c42_b_is_active_c42_controlMCUSlugsMKII),
                &c42_u0, 1, 3, 0U, 0, 0U, 0);
  c42_y = c42_u0;
  sf_mex_destroy(&c42_b_is_active_c42_controlMCUSlugsMKII);
  return c42_y;
}

static void init_dsm_address_info(SFc42_controlMCUSlugsMKIIInstanceStruct
  *chartInstance)
{
}

/* SFunction Glue Code */
void sf_c42_controlMCUSlugsMKII_get_check_sum(mxArray *plhs[])
{
  ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(2580876852U);
  ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(373553290U);
  ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(81881223U);
  ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(1560984384U);
}

mxArray *sf_c42_controlMCUSlugsMKII_get_autoinheritance_info(void)
{
  const char *autoinheritanceFields[] = { "checksum", "inputs", "parameters",
    "outputs" };

  mxArray *mxAutoinheritanceInfo = mxCreateStructMatrix(1,1,4,
    autoinheritanceFields);

  {
    mxArray *mxChecksum = mxCreateDoubleMatrix(4,1,mxREAL);
    double *pr = mxGetPr(mxChecksum);
    pr[0] = (double)(3940687668U);
    pr[1] = (double)(4042831294U);
    pr[2] = (double)(2531203934U);
    pr[3] = (double)(266890788U);
    mxSetField(mxAutoinheritanceInfo,0,"checksum",mxChecksum);
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,2,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(3);
      pr[1] = (double)(1);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(9));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(3);
      pr[1] = (double)(1);
      mxSetField(mxData,1,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(9));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,1,"type",mxType);
    }

    mxSetField(mxData,1,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"inputs",mxData);
  }

  {
    mxSetField(mxAutoinheritanceInfo,0,"parameters",mxCreateDoubleMatrix(0,0,
                mxREAL));
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,1,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(9));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"outputs",mxData);
  }

  return(mxAutoinheritanceInfo);
}

static mxArray *sf_get_sim_state_info_c42_controlMCUSlugsMKII(void)
{
  const char *infoFields[] = { "chartChecksum", "varInfo" };

  mxArray *mxInfo = mxCreateStructMatrix(1, 1, 2, infoFields);
  const char *infoEncStr[] = {
    "100 S1x2'type','srcId','name','auxInfo'{{M[1],M[6],T\"xDoty\",},{M[8],M[0],T\"is_active_c42_controlMCUSlugsMKII\",}}"
  };

  mxArray *mxVarInfo = sf_mex_decode_encoded_mx_struct_array(infoEncStr, 2, 10);
  mxArray *mxChecksum = mxCreateDoubleMatrix(1, 4, mxREAL);
  sf_c42_controlMCUSlugsMKII_get_check_sum(&mxChecksum);
  mxSetField(mxInfo, 0, infoFields[0], mxChecksum);
  mxSetField(mxInfo, 0, infoFields[1], mxVarInfo);
  return mxInfo;
}

static void chart_debug_initialization(SimStruct *S, unsigned int
  fullDebuggerInitialization)
{
  if (!sim_mode_is_rtw_gen(S)) {
    SFc42_controlMCUSlugsMKIIInstanceStruct *chartInstance;
    chartInstance = (SFc42_controlMCUSlugsMKIIInstanceStruct *)
      ((ChartInfoStruct *)(ssGetUserData(S)))->chartInstance;
    if (ssIsFirstInitCond(S) && fullDebuggerInitialization==1) {
      /* do this only if simulation is starting */
      {
        unsigned int chartAlreadyPresent;
        chartAlreadyPresent = sf_debug_initialize_chart
          (_controlMCUSlugsMKIIMachineNumber_,
           42,
           1,
           1,
           3,
           0,
           0,
           0,
           0,
           0,
           &(chartInstance->chartNumber),
           &(chartInstance->instanceNumber),
           ssGetPath(S),
           (void *)S);
        if (chartAlreadyPresent==0) {
          /* this is the first instance */
          init_script_number_translation(_controlMCUSlugsMKIIMachineNumber_,
            chartInstance->chartNumber);
          sf_debug_set_chart_disable_implicit_casting
            (_controlMCUSlugsMKIIMachineNumber_,chartInstance->chartNumber,1);
          sf_debug_set_chart_event_thresholds(_controlMCUSlugsMKIIMachineNumber_,
            chartInstance->chartNumber,
            0,
            0,
            0);

          {
            unsigned int dimVector[1];
            dimVector[0]= 3;
            _SFD_SET_DATA_PROPS(0,1,1,0,SF_SINGLE,1,&(dimVector[0]),0,0,0,0.0,
                                1.0,0,"x",0,(MexFcnForType)c42_b_sf_marshall);
          }

          {
            unsigned int dimVector[1];
            dimVector[0]= 3;
            _SFD_SET_DATA_PROPS(1,1,1,0,SF_SINGLE,1,&(dimVector[0]),0,0,0,0.0,
                                1.0,0,"y",0,(MexFcnForType)c42_b_sf_marshall);
          }

          _SFD_SET_DATA_PROPS(2,2,0,1,SF_SINGLE,0,NULL,0,0,0,0.0,1.0,0,"xDoty",0,
                              (MexFcnForType)c42_sf_marshall);
          _SFD_STATE_INFO(0,0,2);
          _SFD_CH_SUBSTATE_COUNT(0);
          _SFD_CH_SUBSTATE_DECOMP(0);
        }

        _SFD_CV_INIT_CHART(0,0,0,0);

        {
          _SFD_CV_INIT_STATE(0,0,0,0,0,0,NULL,NULL);
        }

        _SFD_CV_INIT_TRANS(0,0,NULL,NULL,0,NULL);

        /* Initialization of EML Model Coverage */
        _SFD_CV_INIT_EML(0,1,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML_FCN(0,0,"eML_blk_kernel",0,-1,172);
        _SFD_TRANS_COV_WTS(0,0,0,1,0);
        if (chartAlreadyPresent==0) {
          _SFD_TRANS_COV_MAPS(0,
                              0,NULL,NULL,
                              0,NULL,NULL,
                              1,NULL,NULL,
                              0,NULL,NULL);
        }

        {
          real32_T (*c42_x)[3];
          real32_T (*c42_y)[3];
          real32_T *c42_xDoty;
          c42_xDoty = (real32_T *)ssGetOutputPortSignal(chartInstance->S, 1);
          c42_y = (real32_T (*)[3])ssGetInputPortSignal(chartInstance->S, 1);
          c42_x = (real32_T (*)[3])ssGetInputPortSignal(chartInstance->S, 0);
          _SFD_SET_DATA_VALUE_PTR(0U, c42_x);
          _SFD_SET_DATA_VALUE_PTR(1U, c42_y);
          _SFD_SET_DATA_VALUE_PTR(2U, c42_xDoty);
        }
      }
    } else {
      sf_debug_reset_current_state_configuration
        (_controlMCUSlugsMKIIMachineNumber_,chartInstance->chartNumber,
         chartInstance->instanceNumber);
    }
  }
}

static void sf_opaque_initialize_c42_controlMCUSlugsMKII(void *chartInstanceVar)
{
  chart_debug_initialization(((SFc42_controlMCUSlugsMKIIInstanceStruct*)
    chartInstanceVar)->S,0);
  initialize_params_c42_controlMCUSlugsMKII
    ((SFc42_controlMCUSlugsMKIIInstanceStruct*) chartInstanceVar);
  initialize_c42_controlMCUSlugsMKII((SFc42_controlMCUSlugsMKIIInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_enable_c42_controlMCUSlugsMKII(void *chartInstanceVar)
{
  enable_c42_controlMCUSlugsMKII((SFc42_controlMCUSlugsMKIIInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_disable_c42_controlMCUSlugsMKII(void *chartInstanceVar)
{
  disable_c42_controlMCUSlugsMKII((SFc42_controlMCUSlugsMKIIInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_gateway_c42_controlMCUSlugsMKII(void *chartInstanceVar)
{
  sf_c42_controlMCUSlugsMKII((SFc42_controlMCUSlugsMKIIInstanceStruct*)
    chartInstanceVar);
}

static mxArray* sf_internal_get_sim_state_c42_controlMCUSlugsMKII(SimStruct* S)
{
  ChartInfoStruct *chartInfo = (ChartInfoStruct*) ssGetUserData(S);
  mxArray *plhs[1] = { NULL };

  mxArray *prhs[4];
  int mxError = 0;
  prhs[0] = mxCreateString("chart_simctx_raw2high");
  prhs[1] = mxCreateDoubleScalar(ssGetSFuncBlockHandle(S));
  prhs[2] = (mxArray*) get_sim_state_c42_controlMCUSlugsMKII
    ((SFc42_controlMCUSlugsMKIIInstanceStruct*)chartInfo->chartInstance);/* raw sim ctx */
  prhs[3] = sf_get_sim_state_info_c42_controlMCUSlugsMKII();/* state var info */
  mxError = sf_mex_call_matlab(1, plhs, 4, prhs, "sfprivate");
  mxDestroyArray(prhs[0]);
  mxDestroyArray(prhs[1]);
  mxDestroyArray(prhs[2]);
  mxDestroyArray(prhs[3]);
  if (mxError || plhs[0] == NULL) {
    sf_mex_error_message("Stateflow Internal Error: \nError calling 'chart_simctx_raw2high'.\n");
  }

  return plhs[0];
}

static void sf_internal_set_sim_state_c42_controlMCUSlugsMKII(SimStruct* S,
  const mxArray *st)
{
  ChartInfoStruct *chartInfo = (ChartInfoStruct*) ssGetUserData(S);
  mxArray *plhs[1] = { NULL };

  mxArray *prhs[4];
  int mxError = 0;
  prhs[0] = mxCreateString("chart_simctx_high2raw");
  prhs[1] = mxCreateDoubleScalar(ssGetSFuncBlockHandle(S));
  prhs[2] = mxDuplicateArray(st);      /* high level simctx */
  prhs[3] = (mxArray*) sf_get_sim_state_info_c42_controlMCUSlugsMKII();/* state var info */
  mxError = sf_mex_call_matlab(1, plhs, 4, prhs, "sfprivate");
  mxDestroyArray(prhs[0]);
  mxDestroyArray(prhs[1]);
  mxDestroyArray(prhs[2]);
  mxDestroyArray(prhs[3]);
  if (mxError || plhs[0] == NULL) {
    sf_mex_error_message("Stateflow Internal Error: \nError calling 'chart_simctx_high2raw'.\n");
  }

  set_sim_state_c42_controlMCUSlugsMKII((SFc42_controlMCUSlugsMKIIInstanceStruct*)
    chartInfo->chartInstance, mxDuplicateArray(plhs[0]));
  mxDestroyArray(plhs[0]);
}

static mxArray* sf_opaque_get_sim_state_c42_controlMCUSlugsMKII(SimStruct* S)
{
  return sf_internal_get_sim_state_c42_controlMCUSlugsMKII(S);
}

static void sf_opaque_set_sim_state_c42_controlMCUSlugsMKII(SimStruct* S, const
  mxArray *st)
{
  sf_internal_set_sim_state_c42_controlMCUSlugsMKII(S, st);
}

static void sf_opaque_terminate_c42_controlMCUSlugsMKII(void *chartInstanceVar)
{
  if (chartInstanceVar!=NULL) {
    SimStruct *S = ((SFc42_controlMCUSlugsMKIIInstanceStruct*) chartInstanceVar
      )->S;
    if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
      sf_clear_rtw_identifier(S);
    }

    finalize_c42_controlMCUSlugsMKII((SFc42_controlMCUSlugsMKIIInstanceStruct*)
      chartInstanceVar);
    free((void *)chartInstanceVar);
    ssSetUserData(S,NULL);
  }
}

extern unsigned int sf_machine_global_initializer_called(void);
static void mdlProcessParameters_c42_controlMCUSlugsMKII(SimStruct *S)
{
  int i;
  for (i=0;i<ssGetNumRunTimeParams(S);i++) {
    if (ssGetSFcnParamTunable(S,i)) {
      ssUpdateDlgParamAsRunTimeParam(S,i);
    }
  }

  if (sf_machine_global_initializer_called()) {
    initialize_params_c42_controlMCUSlugsMKII
      ((SFc42_controlMCUSlugsMKIIInstanceStruct*)(((ChartInfoStruct *)
         ssGetUserData(S))->chartInstance));
  }
}

static void mdlSetWorkWidths_c42_controlMCUSlugsMKII(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
    int_T chartIsInlinable =
      (int_T)sf_is_chart_inlinable("controlMCUSlugsMKII","controlMCUSlugsMKII",
      42);
    ssSetStateflowIsInlinable(S,chartIsInlinable);
    ssSetRTWCG(S,sf_rtw_info_uint_prop("controlMCUSlugsMKII",
                "controlMCUSlugsMKII",42,"RTWCG"));
    ssSetEnableFcnIsTrivial(S,1);
    ssSetDisableFcnIsTrivial(S,1);
    ssSetNotMultipleInlinable(S,sf_rtw_info_uint_prop("controlMCUSlugsMKII",
      "controlMCUSlugsMKII",42,"gatewayCannotBeInlinedMultipleTimes"));
    if (chartIsInlinable) {
      ssSetInputPortOptimOpts(S, 0, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 1, SS_REUSABLE_AND_LOCAL);
      sf_mark_chart_expressionable_inputs(S,"controlMCUSlugsMKII",
        "controlMCUSlugsMKII",42,2);
      sf_mark_chart_reusable_outputs(S,"controlMCUSlugsMKII",
        "controlMCUSlugsMKII",42,1);
    }

    sf_set_rtw_dwork_info(S,"controlMCUSlugsMKII","controlMCUSlugsMKII",42);
    ssSetHasSubFunctions(S,!(chartIsInlinable));
    ssSetOptions(S,ssGetOptions(S)|SS_OPTION_WORKS_WITH_CODE_REUSE);
  }

  ssSetChecksum0(S,(239954016U));
  ssSetChecksum1(S,(3132800559U));
  ssSetChecksum2(S,(1221111897U));
  ssSetChecksum3(S,(179205883U));
  ssSetmdlDerivatives(S, NULL);
  ssSetExplicitFCSSCtrl(S,1);
}

static void mdlRTW_c42_controlMCUSlugsMKII(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S)) {
    sf_write_symbol_mapping(S, "controlMCUSlugsMKII", "controlMCUSlugsMKII",42);
    ssWriteRTWStrParam(S, "StateflowChartType", "Embedded MATLAB");
  }
}

static void mdlStart_c42_controlMCUSlugsMKII(SimStruct *S)
{
  SFc42_controlMCUSlugsMKIIInstanceStruct *chartInstance;
  chartInstance = (SFc42_controlMCUSlugsMKIIInstanceStruct *)malloc(sizeof
    (SFc42_controlMCUSlugsMKIIInstanceStruct));
  memset(chartInstance, 0, sizeof(SFc42_controlMCUSlugsMKIIInstanceStruct));
  if (chartInstance==NULL) {
    sf_mex_error_message("Could not allocate memory for chart instance.");
  }

  chartInstance->chartInfo.chartInstance = chartInstance;
  chartInstance->chartInfo.isEMLChart = 1;
  chartInstance->chartInfo.chartInitialized = 0;
  chartInstance->chartInfo.sFunctionGateway =
    sf_opaque_gateway_c42_controlMCUSlugsMKII;
  chartInstance->chartInfo.initializeChart =
    sf_opaque_initialize_c42_controlMCUSlugsMKII;
  chartInstance->chartInfo.terminateChart =
    sf_opaque_terminate_c42_controlMCUSlugsMKII;
  chartInstance->chartInfo.enableChart =
    sf_opaque_enable_c42_controlMCUSlugsMKII;
  chartInstance->chartInfo.disableChart =
    sf_opaque_disable_c42_controlMCUSlugsMKII;
  chartInstance->chartInfo.getSimState =
    sf_opaque_get_sim_state_c42_controlMCUSlugsMKII;
  chartInstance->chartInfo.setSimState =
    sf_opaque_set_sim_state_c42_controlMCUSlugsMKII;
  chartInstance->chartInfo.getSimStateInfo =
    sf_get_sim_state_info_c42_controlMCUSlugsMKII;
  chartInstance->chartInfo.zeroCrossings = NULL;
  chartInstance->chartInfo.outputs = NULL;
  chartInstance->chartInfo.derivatives = NULL;
  chartInstance->chartInfo.mdlRTW = mdlRTW_c42_controlMCUSlugsMKII;
  chartInstance->chartInfo.mdlStart = mdlStart_c42_controlMCUSlugsMKII;
  chartInstance->chartInfo.mdlSetWorkWidths =
    mdlSetWorkWidths_c42_controlMCUSlugsMKII;
  chartInstance->chartInfo.extModeExec = NULL;
  chartInstance->chartInfo.restoreLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.restoreBeforeLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.storeCurrentConfiguration = NULL;
  chartInstance->S = S;
  ssSetUserData(S,(void *)(&(chartInstance->chartInfo)));/* register the chart instance with simstruct */
  if (!sim_mode_is_rtw_gen(S)) {
    init_dsm_address_info(chartInstance);
  }

  chart_debug_initialization(S,1);
}

void c42_controlMCUSlugsMKII_method_dispatcher(SimStruct *S, int_T method, void *
  data)
{
  switch (method) {
   case SS_CALL_MDL_START:
    mdlStart_c42_controlMCUSlugsMKII(S);
    break;

   case SS_CALL_MDL_SET_WORK_WIDTHS:
    mdlSetWorkWidths_c42_controlMCUSlugsMKII(S);
    break;

   case SS_CALL_MDL_PROCESS_PARAMETERS:
    mdlProcessParameters_c42_controlMCUSlugsMKII(S);
    break;

   default:
    /* Unhandled method */
    sf_mex_error_message("Stateflow Internal Error:\n"
                         "Error calling c42_controlMCUSlugsMKII_method_dispatcher.\n"
                         "Can't handle method %d.\n", method);
    break;
  }
}
