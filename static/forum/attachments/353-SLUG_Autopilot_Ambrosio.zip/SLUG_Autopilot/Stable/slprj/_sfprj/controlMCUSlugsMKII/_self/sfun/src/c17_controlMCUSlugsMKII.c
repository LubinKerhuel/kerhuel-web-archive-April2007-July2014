/* Include files */

#include "blascompat32.h"
#include "controlMCUSlugsMKII_sfun.h"
#include "c17_controlMCUSlugsMKII.h"
#define CHARTINSTANCE_CHARTNUMBER      (chartInstance->chartNumber)
#define CHARTINSTANCE_INSTANCENUMBER   (chartInstance->instanceNumber)
#include "controlMCUSlugsMKII_sfun_debug_macros.h"

/* Type Definitions */

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */
static const char *c17_debug_family_names[5] = { "nargin", "nargout", "x", "y",
  "xDoty" };

/* Function Declarations */
static void initialize_c17_controlMCUSlugsMKII
  (SFc17_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void initialize_params_c17_controlMCUSlugsMKII
  (SFc17_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void enable_c17_controlMCUSlugsMKII
  (SFc17_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void disable_c17_controlMCUSlugsMKII
  (SFc17_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void c17_update_debugger_state_c17_controlMCUSlugsMKII
  (SFc17_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static const mxArray *get_sim_state_c17_controlMCUSlugsMKII
  (SFc17_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void set_sim_state_c17_controlMCUSlugsMKII
  (SFc17_controlMCUSlugsMKIIInstanceStruct *chartInstance, const mxArray *c17_st);
static void finalize_c17_controlMCUSlugsMKII
  (SFc17_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void sf_c17_controlMCUSlugsMKII(SFc17_controlMCUSlugsMKIIInstanceStruct
  *chartInstance);
static void init_script_number_translation(uint32_T c17_machineNumber, uint32_T
  c17_chartNumber);
static const mxArray *c17_sf_marshall(void *chartInstanceVoid, void *c17_u);
static const mxArray *c17_b_sf_marshall(void *chartInstanceVoid, void *c17_u);
static const mxArray *c17_c_sf_marshall(void *chartInstanceVoid, void *c17_u);
static const mxArray *c17_d_sf_marshall(void *chartInstanceVoid, void *c17_u);
static real32_T c17_emlrt_marshallIn(SFc17_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c17_xDoty, const char_T *c17_name);
static uint8_T c17_b_emlrt_marshallIn(SFc17_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c17_b_is_active_c17_controlMCUSlugsMKII, const
  char_T *c17_name);
static void init_dsm_address_info(SFc17_controlMCUSlugsMKIIInstanceStruct
  *chartInstance);

/* Function Definitions */
static void initialize_c17_controlMCUSlugsMKII
  (SFc17_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
  chartInstance->c17_is_active_c17_controlMCUSlugsMKII = 0U;
}

static void initialize_params_c17_controlMCUSlugsMKII
  (SFc17_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
}

static void enable_c17_controlMCUSlugsMKII
  (SFc17_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
}

static void disable_c17_controlMCUSlugsMKII
  (SFc17_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
}

static void c17_update_debugger_state_c17_controlMCUSlugsMKII
  (SFc17_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
}

static const mxArray *get_sim_state_c17_controlMCUSlugsMKII
  (SFc17_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
  const mxArray *c17_st = NULL;
  const mxArray *c17_y = NULL;
  real32_T c17_hoistedGlobal;
  real32_T c17_u;
  const mxArray *c17_b_y = NULL;
  uint8_T c17_b_hoistedGlobal;
  uint8_T c17_b_u;
  const mxArray *c17_c_y = NULL;
  real32_T *c17_xDoty;
  c17_xDoty = (real32_T *)ssGetOutputPortSignal(chartInstance->S, 1);
  c17_st = NULL;
  c17_y = NULL;
  sf_mex_assign(&c17_y, sf_mex_createcellarray(2));
  c17_hoistedGlobal = *c17_xDoty;
  c17_u = c17_hoistedGlobal;
  c17_b_y = NULL;
  sf_mex_assign(&c17_b_y, sf_mex_create("y", &c17_u, 1, 0U, 0U, 0U, 0));
  sf_mex_setcell(c17_y, 0, c17_b_y);
  c17_b_hoistedGlobal = chartInstance->c17_is_active_c17_controlMCUSlugsMKII;
  c17_b_u = c17_b_hoistedGlobal;
  c17_c_y = NULL;
  sf_mex_assign(&c17_c_y, sf_mex_create("y", &c17_b_u, 3, 0U, 0U, 0U, 0));
  sf_mex_setcell(c17_y, 1, c17_c_y);
  sf_mex_assign(&c17_st, c17_y);
  return c17_st;
}

static void set_sim_state_c17_controlMCUSlugsMKII
  (SFc17_controlMCUSlugsMKIIInstanceStruct *chartInstance, const mxArray *c17_st)
{
  const mxArray *c17_u;
  real32_T *c17_xDoty;
  c17_xDoty = (real32_T *)ssGetOutputPortSignal(chartInstance->S, 1);
  chartInstance->c17_doneDoubleBufferReInit = TRUE;
  c17_u = sf_mex_dup(c17_st);
  *c17_xDoty = c17_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell
    (c17_u, 0)), "xDoty");
  chartInstance->c17_is_active_c17_controlMCUSlugsMKII = c17_b_emlrt_marshallIn
    (chartInstance, sf_mex_dup(sf_mex_getcell(c17_u, 1)),
     "is_active_c17_controlMCUSlugsMKII");
  sf_mex_destroy(&c17_u);
  c17_update_debugger_state_c17_controlMCUSlugsMKII(chartInstance);
  sf_mex_destroy(&c17_st);
}

static void finalize_c17_controlMCUSlugsMKII
  (SFc17_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
}

static void sf_c17_controlMCUSlugsMKII(SFc17_controlMCUSlugsMKIIInstanceStruct
  *chartInstance)
{
  int32_T c17_i0;
  int32_T c17_i1;
  int32_T c17_previousEvent;
  int32_T c17_i2;
  real32_T c17_hoistedGlobal[3];
  int32_T c17_i3;
  real32_T c17_b_hoistedGlobal[3];
  int32_T c17_i4;
  real32_T c17_x[3];
  int32_T c17_i5;
  real32_T c17_y[3];
  uint32_T c17_debug_family_var_map[5];
  real_T c17_nargin = 2.0;
  real_T c17_nargout = 1.0;
  real32_T c17_xDoty;
  real32_T c17_a;
  real32_T c17_b;
  real32_T c17_b_y;
  real32_T c17_b_a;
  real32_T c17_b_b;
  real32_T c17_c_y;
  real32_T *c17_b_xDoty;
  real32_T (*c17_d_y)[3];
  real32_T (*c17_b_x)[3];
  c17_b_xDoty = (real32_T *)ssGetOutputPortSignal(chartInstance->S, 1);
  c17_d_y = (real32_T (*)[3])ssGetInputPortSignal(chartInstance->S, 1);
  c17_b_x = (real32_T (*)[3])ssGetInputPortSignal(chartInstance->S, 0);
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
  _SFD_CC_CALL(CHART_ENTER_SFUNCTION_TAG,16);
  for (c17_i0 = 0; c17_i0 < 3; c17_i0 = c17_i0 + 1) {
    _SFD_DATA_RANGE_CHECK((real_T)(*c17_b_x)[c17_i0], 0U);
  }

  for (c17_i1 = 0; c17_i1 < 3; c17_i1 = c17_i1 + 1) {
    _SFD_DATA_RANGE_CHECK((real_T)(*c17_d_y)[c17_i1], 1U);
  }

  _SFD_DATA_RANGE_CHECK((real_T)*c17_b_xDoty, 2U);
  c17_previousEvent = _sfEvent_;
  _sfEvent_ = CALL_EVENT;
  _SFD_CC_CALL(CHART_ENTER_DURING_FUNCTION_TAG,16);
  for (c17_i2 = 0; c17_i2 < 3; c17_i2 = c17_i2 + 1) {
    c17_hoistedGlobal[c17_i2] = (*c17_b_x)[c17_i2];
  }

  for (c17_i3 = 0; c17_i3 < 3; c17_i3 = c17_i3 + 1) {
    c17_b_hoistedGlobal[c17_i3] = (*c17_d_y)[c17_i3];
  }

  for (c17_i4 = 0; c17_i4 < 3; c17_i4 = c17_i4 + 1) {
    c17_x[c17_i4] = c17_hoistedGlobal[c17_i4];
  }

  for (c17_i5 = 0; c17_i5 < 3; c17_i5 = c17_i5 + 1) {
    c17_y[c17_i5] = c17_b_hoistedGlobal[c17_i5];
  }

  sf_debug_symbol_scope_push_eml(0U, 5U, 5U, c17_debug_family_names,
    c17_debug_family_var_map);
  sf_debug_symbol_scope_add_eml(&c17_nargin, c17_c_sf_marshall, 0U);
  sf_debug_symbol_scope_add_eml(&c17_nargout, c17_c_sf_marshall, 1U);
  sf_debug_symbol_scope_add_eml(&c17_x, c17_b_sf_marshall, 2U);
  sf_debug_symbol_scope_add_eml(&c17_y, c17_b_sf_marshall, 3U);
  sf_debug_symbol_scope_add_eml(&c17_xDoty, c17_sf_marshall, 4U);
  CV_EML_FCN(0, 0);

  /*  This block supports an embeddable subset of the MATLAB language. */
  /*  See the help menu for details.  */
  _SFD_EML_CALL(0,5);
  c17_a = c17_x[0];
  c17_b = c17_y[0];
  c17_b_y = c17_a * c17_b;
  c17_b_a = c17_x[1];
  c17_b_b = c17_y[1];
  c17_c_y = c17_b_a * c17_b_b;
  c17_xDoty = c17_b_y + c17_c_y;
  _SFD_EML_CALL(0,-5);
  sf_debug_symbol_scope_pop();
  *c17_b_xDoty = c17_xDoty;
  _SFD_CC_CALL(EXIT_OUT_OF_FUNCTION_TAG,16);
  _sfEvent_ = c17_previousEvent;
  sf_debug_check_for_state_inconsistency(_controlMCUSlugsMKIIMachineNumber_,
    chartInstance->chartNumber, chartInstance->instanceNumber
    );
}

static void init_script_number_translation(uint32_T c17_machineNumber, uint32_T
  c17_chartNumber)
{
}

static const mxArray *c17_sf_marshall(void *chartInstanceVoid, void *c17_u)
{
  const mxArray *c17_y = NULL;
  real32_T c17_b_u;
  const mxArray *c17_b_y = NULL;
  SFc17_controlMCUSlugsMKIIInstanceStruct *chartInstance;
  chartInstance = (SFc17_controlMCUSlugsMKIIInstanceStruct *)chartInstanceVoid;
  c17_y = NULL;
  c17_b_u = *((real32_T *)c17_u);
  c17_b_y = NULL;
  sf_mex_assign(&c17_b_y, sf_mex_create("y", &c17_b_u, 1, 0U, 0U, 0U, 0));
  sf_mex_assign(&c17_y, c17_b_y);
  return c17_y;
}

static const mxArray *c17_b_sf_marshall(void *chartInstanceVoid, void *c17_u)
{
  const mxArray *c17_y = NULL;
  int32_T c17_i6;
  real32_T c17_b_u[3];
  const mxArray *c17_b_y = NULL;
  SFc17_controlMCUSlugsMKIIInstanceStruct *chartInstance;
  chartInstance = (SFc17_controlMCUSlugsMKIIInstanceStruct *)chartInstanceVoid;
  c17_y = NULL;
  for (c17_i6 = 0; c17_i6 < 3; c17_i6 = c17_i6 + 1) {
    c17_b_u[c17_i6] = (*((real32_T (*)[3])c17_u))[c17_i6];
  }

  c17_b_y = NULL;
  sf_mex_assign(&c17_b_y, sf_mex_create("y", &c17_b_u, 1, 0U, 1U, 0U, 1, 3));
  sf_mex_assign(&c17_y, c17_b_y);
  return c17_y;
}

static const mxArray *c17_c_sf_marshall(void *chartInstanceVoid, void *c17_u)
{
  const mxArray *c17_y = NULL;
  real_T c17_b_u;
  const mxArray *c17_b_y = NULL;
  SFc17_controlMCUSlugsMKIIInstanceStruct *chartInstance;
  chartInstance = (SFc17_controlMCUSlugsMKIIInstanceStruct *)chartInstanceVoid;
  c17_y = NULL;
  c17_b_u = *((real_T *)c17_u);
  c17_b_y = NULL;
  sf_mex_assign(&c17_b_y, sf_mex_create("y", &c17_b_u, 0, 0U, 0U, 0U, 0));
  sf_mex_assign(&c17_y, c17_b_y);
  return c17_y;
}

const mxArray *sf_c17_controlMCUSlugsMKII_get_eml_resolved_functions_info(void)
{
  const mxArray *c17_nameCaptureInfo = NULL;
  c17_ResolvedFunctionInfo c17_info[12];
  c17_ResolvedFunctionInfo (*c17_b_info)[12];
  const mxArray *c17_m0 = NULL;
  int32_T c17_i7;
  c17_ResolvedFunctionInfo *c17_r0;
  c17_nameCaptureInfo = NULL;
  c17_b_info = (c17_ResolvedFunctionInfo (*)[12])c17_info;
  (*c17_b_info)[0].context = "";
  (*c17_b_info)[0].name = "mtimes";
  (*c17_b_info)[0].dominantType = "single";
  (*c17_b_info)[0].resolved =
    "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  (*c17_b_info)[0].fileLength = 3425U;
  (*c17_b_info)[0].fileTime1 = 1250701566U;
  (*c17_b_info)[0].fileTime2 = 0U;
  (*c17_b_info)[1].context =
    "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  (*c17_b_info)[1].name = "nargin";
  (*c17_b_info)[1].dominantType = "";
  (*c17_b_info)[1].resolved = "[B]nargin";
  (*c17_b_info)[1].fileLength = 0U;
  (*c17_b_info)[1].fileTime1 = 0U;
  (*c17_b_info)[1].fileTime2 = 0U;
  (*c17_b_info)[2].context =
    "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  (*c17_b_info)[2].name = "gt";
  (*c17_b_info)[2].dominantType = "double";
  (*c17_b_info)[2].resolved = "[B]gt";
  (*c17_b_info)[2].fileLength = 0U;
  (*c17_b_info)[2].fileTime1 = 0U;
  (*c17_b_info)[2].fileTime2 = 0U;
  (*c17_b_info)[3].context =
    "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  (*c17_b_info)[3].name = "isa";
  (*c17_b_info)[3].dominantType = "single";
  (*c17_b_info)[3].resolved = "[B]isa";
  (*c17_b_info)[3].fileLength = 0U;
  (*c17_b_info)[3].fileTime1 = 0U;
  (*c17_b_info)[3].fileTime2 = 0U;
  (*c17_b_info)[4].context =
    "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  (*c17_b_info)[4].name = "isinteger";
  (*c17_b_info)[4].dominantType = "single";
  (*c17_b_info)[4].resolved = "[B]isinteger";
  (*c17_b_info)[4].fileLength = 0U;
  (*c17_b_info)[4].fileTime1 = 0U;
  (*c17_b_info)[4].fileTime2 = 0U;
  (*c17_b_info)[5].context =
    "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  (*c17_b_info)[5].name = "isscalar";
  (*c17_b_info)[5].dominantType = "single";
  (*c17_b_info)[5].resolved = "[B]isscalar";
  (*c17_b_info)[5].fileLength = 0U;
  (*c17_b_info)[5].fileTime1 = 0U;
  (*c17_b_info)[5].fileTime2 = 0U;
  (*c17_b_info)[6].context =
    "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  (*c17_b_info)[6].name = "strcmp";
  (*c17_b_info)[6].dominantType = "char";
  (*c17_b_info)[6].resolved = "[B]strcmp";
  (*c17_b_info)[6].fileLength = 0U;
  (*c17_b_info)[6].fileTime1 = 0U;
  (*c17_b_info)[6].fileTime2 = 0U;
  (*c17_b_info)[7].context =
    "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  (*c17_b_info)[7].name = "size";
  (*c17_b_info)[7].dominantType = "single";
  (*c17_b_info)[7].resolved = "[B]size";
  (*c17_b_info)[7].fileLength = 0U;
  (*c17_b_info)[7].fileTime1 = 0U;
  (*c17_b_info)[7].fileTime2 = 0U;
  (*c17_b_info)[8].context =
    "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  (*c17_b_info)[8].name = "eq";
  (*c17_b_info)[8].dominantType = "double";
  (*c17_b_info)[8].resolved = "[B]eq";
  (*c17_b_info)[8].fileLength = 0U;
  (*c17_b_info)[8].fileTime1 = 0U;
  (*c17_b_info)[8].fileTime2 = 0U;
  (*c17_b_info)[9].context =
    "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  (*c17_b_info)[9].name = "class";
  (*c17_b_info)[9].dominantType = "single";
  (*c17_b_info)[9].resolved = "[B]class";
  (*c17_b_info)[9].fileLength = 0U;
  (*c17_b_info)[9].fileTime1 = 0U;
  (*c17_b_info)[9].fileTime2 = 0U;
  (*c17_b_info)[10].context =
    "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  (*c17_b_info)[10].name = "not";
  (*c17_b_info)[10].dominantType = "logical";
  (*c17_b_info)[10].resolved = "[B]not";
  (*c17_b_info)[10].fileLength = 0U;
  (*c17_b_info)[10].fileTime1 = 0U;
  (*c17_b_info)[10].fileTime2 = 0U;
  (*c17_b_info)[11].context = "";
  (*c17_b_info)[11].name = "plus";
  (*c17_b_info)[11].dominantType = "single";
  (*c17_b_info)[11].resolved = "[B]plus";
  (*c17_b_info)[11].fileLength = 0U;
  (*c17_b_info)[11].fileTime1 = 0U;
  (*c17_b_info)[11].fileTime2 = 0U;
  sf_mex_assign(&c17_m0, sf_mex_createstruct("nameCaptureInfo", 1, 12));
  for (c17_i7 = 0; c17_i7 < 12; c17_i7 = c17_i7 + 1) {
    c17_r0 = &c17_info[c17_i7];
    sf_mex_addfield(c17_m0, sf_mex_create("nameCaptureInfo", c17_r0->context, 15,
      0U, 0U, 0U, 2, 1, strlen(c17_r0->context)), "context"
                    , "nameCaptureInfo", c17_i7);
    sf_mex_addfield(c17_m0, sf_mex_create("nameCaptureInfo", c17_r0->name, 15,
      0U, 0U, 0U, 2, 1, strlen(c17_r0->name)), "name",
                    "nameCaptureInfo", c17_i7);
    sf_mex_addfield(c17_m0, sf_mex_create("nameCaptureInfo",
      c17_r0->dominantType, 15, 0U, 0U, 0U, 2, 1, strlen(c17_r0->dominantType)),
                    "dominantType", "nameCaptureInfo", c17_i7);
    sf_mex_addfield(c17_m0, sf_mex_create("nameCaptureInfo", c17_r0->resolved,
      15, 0U, 0U, 0U, 2, 1, strlen(c17_r0->resolved)),
                    "resolved", "nameCaptureInfo", c17_i7);
    sf_mex_addfield(c17_m0, sf_mex_create("nameCaptureInfo", &c17_r0->fileLength,
      7, 0U, 0U, 0U, 0), "fileLength", "nameCaptureInfo",
                    c17_i7);
    sf_mex_addfield(c17_m0, sf_mex_create("nameCaptureInfo", &c17_r0->fileTime1,
      7, 0U, 0U, 0U, 0), "fileTime1", "nameCaptureInfo",
                    c17_i7);
    sf_mex_addfield(c17_m0, sf_mex_create("nameCaptureInfo", &c17_r0->fileTime2,
      7, 0U, 0U, 0U, 0), "fileTime2", "nameCaptureInfo",
                    c17_i7);
  }

  sf_mex_assign(&c17_nameCaptureInfo, c17_m0);
  return c17_nameCaptureInfo;
}

static const mxArray *c17_d_sf_marshall(void *chartInstanceVoid, void *c17_u)
{
  const mxArray *c17_y = NULL;
  boolean_T c17_b_u;
  const mxArray *c17_b_y = NULL;
  SFc17_controlMCUSlugsMKIIInstanceStruct *chartInstance;
  chartInstance = (SFc17_controlMCUSlugsMKIIInstanceStruct *)chartInstanceVoid;
  c17_y = NULL;
  c17_b_u = *((boolean_T *)c17_u);
  c17_b_y = NULL;
  sf_mex_assign(&c17_b_y, sf_mex_create("y", &c17_b_u, 11, 0U, 0U, 0U, 0));
  sf_mex_assign(&c17_y, c17_b_y);
  return c17_y;
}

static real32_T c17_emlrt_marshallIn(SFc17_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c17_xDoty, const char_T
  *c17_name)
{
  real32_T c17_y;
  real32_T c17_f0;
  sf_mex_import(c17_name, sf_mex_dup(c17_xDoty), &c17_f0, 1, 1, 0U, 0, 0U, 0);
  c17_y = c17_f0;
  sf_mex_destroy(&c17_xDoty);
  return c17_y;
}

static uint8_T c17_b_emlrt_marshallIn(SFc17_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *
  c17_b_is_active_c17_controlMCUSlugsMKII, const char_T *c17_name)
{
  uint8_T c17_y;
  uint8_T c17_u0;
  sf_mex_import(c17_name, sf_mex_dup(c17_b_is_active_c17_controlMCUSlugsMKII),
                &c17_u0, 1, 3, 0U, 0, 0U, 0);
  c17_y = c17_u0;
  sf_mex_destroy(&c17_b_is_active_c17_controlMCUSlugsMKII);
  return c17_y;
}

static void init_dsm_address_info(SFc17_controlMCUSlugsMKIIInstanceStruct
  *chartInstance)
{
}

/* SFunction Glue Code */
void sf_c17_controlMCUSlugsMKII_get_check_sum(mxArray *plhs[])
{
  ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(2874907964U);
  ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(1209002739U);
  ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(939189434U);
  ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(3687023051U);
}

mxArray *sf_c17_controlMCUSlugsMKII_get_autoinheritance_info(void)
{
  const char *autoinheritanceFields[] = { "checksum", "inputs", "parameters",
    "outputs" };

  mxArray *mxAutoinheritanceInfo = mxCreateStructMatrix(1,1,4,
    autoinheritanceFields);

  {
    mxArray *mxChecksum = mxCreateDoubleMatrix(4,1,mxREAL);
    double *pr = mxGetPr(mxChecksum);
    pr[0] = (double)(2681072502U);
    pr[1] = (double)(789764362U);
    pr[2] = (double)(3466689179U);
    pr[3] = (double)(3007275501U);
    mxSetField(mxAutoinheritanceInfo,0,"checksum",mxChecksum);
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,2,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(3);
      pr[1] = (double)(1);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(9));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(3);
      pr[1] = (double)(1);
      mxSetField(mxData,1,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(9));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,1,"type",mxType);
    }

    mxSetField(mxData,1,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"inputs",mxData);
  }

  {
    mxSetField(mxAutoinheritanceInfo,0,"parameters",mxCreateDoubleMatrix(0,0,
                mxREAL));
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,1,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(9));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"outputs",mxData);
  }

  return(mxAutoinheritanceInfo);
}

static mxArray *sf_get_sim_state_info_c17_controlMCUSlugsMKII(void)
{
  const char *infoFields[] = { "chartChecksum", "varInfo" };

  mxArray *mxInfo = mxCreateStructMatrix(1, 1, 2, infoFields);
  const char *infoEncStr[] = {
    "100 S1x2'type','srcId','name','auxInfo'{{M[1],M[6],T\"xDoty\",},{M[8],M[0],T\"is_active_c17_controlMCUSlugsMKII\",}}"
  };

  mxArray *mxVarInfo = sf_mex_decode_encoded_mx_struct_array(infoEncStr, 2, 10);
  mxArray *mxChecksum = mxCreateDoubleMatrix(1, 4, mxREAL);
  sf_c17_controlMCUSlugsMKII_get_check_sum(&mxChecksum);
  mxSetField(mxInfo, 0, infoFields[0], mxChecksum);
  mxSetField(mxInfo, 0, infoFields[1], mxVarInfo);
  return mxInfo;
}

static void chart_debug_initialization(SimStruct *S, unsigned int
  fullDebuggerInitialization)
{
  if (!sim_mode_is_rtw_gen(S)) {
    SFc17_controlMCUSlugsMKIIInstanceStruct *chartInstance;
    chartInstance = (SFc17_controlMCUSlugsMKIIInstanceStruct *)
      ((ChartInfoStruct *)(ssGetUserData(S)))->chartInstance;
    if (ssIsFirstInitCond(S) && fullDebuggerInitialization==1) {
      /* do this only if simulation is starting */
      {
        unsigned int chartAlreadyPresent;
        chartAlreadyPresent = sf_debug_initialize_chart
          (_controlMCUSlugsMKIIMachineNumber_,
           17,
           1,
           1,
           3,
           0,
           0,
           0,
           0,
           0,
           &(chartInstance->chartNumber),
           &(chartInstance->instanceNumber),
           ssGetPath(S),
           (void *)S);
        if (chartAlreadyPresent==0) {
          /* this is the first instance */
          init_script_number_translation(_controlMCUSlugsMKIIMachineNumber_,
            chartInstance->chartNumber);
          sf_debug_set_chart_disable_implicit_casting
            (_controlMCUSlugsMKIIMachineNumber_,chartInstance->chartNumber,1);
          sf_debug_set_chart_event_thresholds(_controlMCUSlugsMKIIMachineNumber_,
            chartInstance->chartNumber,
            0,
            0,
            0);

          {
            unsigned int dimVector[1];
            dimVector[0]= 3;
            _SFD_SET_DATA_PROPS(0,1,1,0,SF_SINGLE,1,&(dimVector[0]),0,0,0,0.0,
                                1.0,0,"x",0,(MexFcnForType)c17_b_sf_marshall);
          }

          {
            unsigned int dimVector[1];
            dimVector[0]= 3;
            _SFD_SET_DATA_PROPS(1,1,1,0,SF_SINGLE,1,&(dimVector[0]),0,0,0,0.0,
                                1.0,0,"y",0,(MexFcnForType)c17_b_sf_marshall);
          }

          _SFD_SET_DATA_PROPS(2,2,0,1,SF_SINGLE,0,NULL,0,0,0,0.0,1.0,0,"xDoty",0,
                              (MexFcnForType)c17_sf_marshall);
          _SFD_STATE_INFO(0,0,2);
          _SFD_CH_SUBSTATE_COUNT(0);
          _SFD_CH_SUBSTATE_DECOMP(0);
        }

        _SFD_CV_INIT_CHART(0,0,0,0);

        {
          _SFD_CV_INIT_STATE(0,0,0,0,0,0,NULL,NULL);
        }

        _SFD_CV_INIT_TRANS(0,0,NULL,NULL,0,NULL);

        /* Initialization of EML Model Coverage */
        _SFD_CV_INIT_EML(0,1,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML_FCN(0,0,"eML_blk_kernel",0,-1,160);
        _SFD_TRANS_COV_WTS(0,0,0,1,0);
        if (chartAlreadyPresent==0) {
          _SFD_TRANS_COV_MAPS(0,
                              0,NULL,NULL,
                              0,NULL,NULL,
                              1,NULL,NULL,
                              0,NULL,NULL);
        }

        {
          real32_T (*c17_x)[3];
          real32_T (*c17_y)[3];
          real32_T *c17_xDoty;
          c17_xDoty = (real32_T *)ssGetOutputPortSignal(chartInstance->S, 1);
          c17_y = (real32_T (*)[3])ssGetInputPortSignal(chartInstance->S, 1);
          c17_x = (real32_T (*)[3])ssGetInputPortSignal(chartInstance->S, 0);
          _SFD_SET_DATA_VALUE_PTR(0U, c17_x);
          _SFD_SET_DATA_VALUE_PTR(1U, c17_y);
          _SFD_SET_DATA_VALUE_PTR(2U, c17_xDoty);
        }
      }
    } else {
      sf_debug_reset_current_state_configuration
        (_controlMCUSlugsMKIIMachineNumber_,chartInstance->chartNumber,
         chartInstance->instanceNumber);
    }
  }
}

static void sf_opaque_initialize_c17_controlMCUSlugsMKII(void *chartInstanceVar)
{
  chart_debug_initialization(((SFc17_controlMCUSlugsMKIIInstanceStruct*)
    chartInstanceVar)->S,0);
  initialize_params_c17_controlMCUSlugsMKII
    ((SFc17_controlMCUSlugsMKIIInstanceStruct*) chartInstanceVar);
  initialize_c17_controlMCUSlugsMKII((SFc17_controlMCUSlugsMKIIInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_enable_c17_controlMCUSlugsMKII(void *chartInstanceVar)
{
  enable_c17_controlMCUSlugsMKII((SFc17_controlMCUSlugsMKIIInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_disable_c17_controlMCUSlugsMKII(void *chartInstanceVar)
{
  disable_c17_controlMCUSlugsMKII((SFc17_controlMCUSlugsMKIIInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_gateway_c17_controlMCUSlugsMKII(void *chartInstanceVar)
{
  sf_c17_controlMCUSlugsMKII((SFc17_controlMCUSlugsMKIIInstanceStruct*)
    chartInstanceVar);
}

static mxArray* sf_internal_get_sim_state_c17_controlMCUSlugsMKII(SimStruct* S)
{
  ChartInfoStruct *chartInfo = (ChartInfoStruct*) ssGetUserData(S);
  mxArray *plhs[1] = { NULL };

  mxArray *prhs[4];
  int mxError = 0;
  prhs[0] = mxCreateString("chart_simctx_raw2high");
  prhs[1] = mxCreateDoubleScalar(ssGetSFuncBlockHandle(S));
  prhs[2] = (mxArray*) get_sim_state_c17_controlMCUSlugsMKII
    ((SFc17_controlMCUSlugsMKIIInstanceStruct*)chartInfo->chartInstance);/* raw sim ctx */
  prhs[3] = sf_get_sim_state_info_c17_controlMCUSlugsMKII();/* state var info */
  mxError = sf_mex_call_matlab(1, plhs, 4, prhs, "sfprivate");
  mxDestroyArray(prhs[0]);
  mxDestroyArray(prhs[1]);
  mxDestroyArray(prhs[2]);
  mxDestroyArray(prhs[3]);
  if (mxError || plhs[0] == NULL) {
    sf_mex_error_message("Stateflow Internal Error: \nError calling 'chart_simctx_raw2high'.\n");
  }

  return plhs[0];
}

static void sf_internal_set_sim_state_c17_controlMCUSlugsMKII(SimStruct* S,
  const mxArray *st)
{
  ChartInfoStruct *chartInfo = (ChartInfoStruct*) ssGetUserData(S);
  mxArray *plhs[1] = { NULL };

  mxArray *prhs[4];
  int mxError = 0;
  prhs[0] = mxCreateString("chart_simctx_high2raw");
  prhs[1] = mxCreateDoubleScalar(ssGetSFuncBlockHandle(S));
  prhs[2] = mxDuplicateArray(st);      /* high level simctx */
  prhs[3] = (mxArray*) sf_get_sim_state_info_c17_controlMCUSlugsMKII();/* state var info */
  mxError = sf_mex_call_matlab(1, plhs, 4, prhs, "sfprivate");
  mxDestroyArray(prhs[0]);
  mxDestroyArray(prhs[1]);
  mxDestroyArray(prhs[2]);
  mxDestroyArray(prhs[3]);
  if (mxError || plhs[0] == NULL) {
    sf_mex_error_message("Stateflow Internal Error: \nError calling 'chart_simctx_high2raw'.\n");
  }

  set_sim_state_c17_controlMCUSlugsMKII((SFc17_controlMCUSlugsMKIIInstanceStruct*)
    chartInfo->chartInstance, mxDuplicateArray(plhs[0]));
  mxDestroyArray(plhs[0]);
}

static mxArray* sf_opaque_get_sim_state_c17_controlMCUSlugsMKII(SimStruct* S)
{
  return sf_internal_get_sim_state_c17_controlMCUSlugsMKII(S);
}

static void sf_opaque_set_sim_state_c17_controlMCUSlugsMKII(SimStruct* S, const
  mxArray *st)
{
  sf_internal_set_sim_state_c17_controlMCUSlugsMKII(S, st);
}

static void sf_opaque_terminate_c17_controlMCUSlugsMKII(void *chartInstanceVar)
{
  if (chartInstanceVar!=NULL) {
    SimStruct *S = ((SFc17_controlMCUSlugsMKIIInstanceStruct*) chartInstanceVar
      )->S;
    if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
      sf_clear_rtw_identifier(S);
    }

    finalize_c17_controlMCUSlugsMKII((SFc17_controlMCUSlugsMKIIInstanceStruct*)
      chartInstanceVar);
    free((void *)chartInstanceVar);
    ssSetUserData(S,NULL);
  }
}

extern unsigned int sf_machine_global_initializer_called(void);
static void mdlProcessParameters_c17_controlMCUSlugsMKII(SimStruct *S)
{
  int i;
  for (i=0;i<ssGetNumRunTimeParams(S);i++) {
    if (ssGetSFcnParamTunable(S,i)) {
      ssUpdateDlgParamAsRunTimeParam(S,i);
    }
  }

  if (sf_machine_global_initializer_called()) {
    initialize_params_c17_controlMCUSlugsMKII
      ((SFc17_controlMCUSlugsMKIIInstanceStruct*)(((ChartInfoStruct *)
         ssGetUserData(S))->chartInstance));
  }
}

static void mdlSetWorkWidths_c17_controlMCUSlugsMKII(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
    int_T chartIsInlinable =
      (int_T)sf_is_chart_inlinable("controlMCUSlugsMKII","controlMCUSlugsMKII",
      17);
    ssSetStateflowIsInlinable(S,chartIsInlinable);
    ssSetRTWCG(S,sf_rtw_info_uint_prop("controlMCUSlugsMKII",
                "controlMCUSlugsMKII",17,"RTWCG"));
    ssSetEnableFcnIsTrivial(S,1);
    ssSetDisableFcnIsTrivial(S,1);
    ssSetNotMultipleInlinable(S,sf_rtw_info_uint_prop("controlMCUSlugsMKII",
      "controlMCUSlugsMKII",17,"gatewayCannotBeInlinedMultipleTimes"));
    if (chartIsInlinable) {
      ssSetInputPortOptimOpts(S, 0, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 1, SS_REUSABLE_AND_LOCAL);
      sf_mark_chart_expressionable_inputs(S,"controlMCUSlugsMKII",
        "controlMCUSlugsMKII",17,2);
      sf_mark_chart_reusable_outputs(S,"controlMCUSlugsMKII",
        "controlMCUSlugsMKII",17,1);
    }

    sf_set_rtw_dwork_info(S,"controlMCUSlugsMKII","controlMCUSlugsMKII",17);
    ssSetHasSubFunctions(S,!(chartIsInlinable));
    ssSetOptions(S,ssGetOptions(S)|SS_OPTION_WORKS_WITH_CODE_REUSE);
  }

  ssSetChecksum0(S,(1992249247U));
  ssSetChecksum1(S,(1511112110U));
  ssSetChecksum2(S,(424958409U));
  ssSetChecksum3(S,(3975631328U));
  ssSetmdlDerivatives(S, NULL);
  ssSetExplicitFCSSCtrl(S,1);
}

static void mdlRTW_c17_controlMCUSlugsMKII(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S)) {
    sf_write_symbol_mapping(S, "controlMCUSlugsMKII", "controlMCUSlugsMKII",17);
    ssWriteRTWStrParam(S, "StateflowChartType", "Embedded MATLAB");
  }
}

static void mdlStart_c17_controlMCUSlugsMKII(SimStruct *S)
{
  SFc17_controlMCUSlugsMKIIInstanceStruct *chartInstance;
  chartInstance = (SFc17_controlMCUSlugsMKIIInstanceStruct *)malloc(sizeof
    (SFc17_controlMCUSlugsMKIIInstanceStruct));
  memset(chartInstance, 0, sizeof(SFc17_controlMCUSlugsMKIIInstanceStruct));
  if (chartInstance==NULL) {
    sf_mex_error_message("Could not allocate memory for chart instance.");
  }

  chartInstance->chartInfo.chartInstance = chartInstance;
  chartInstance->chartInfo.isEMLChart = 1;
  chartInstance->chartInfo.chartInitialized = 0;
  chartInstance->chartInfo.sFunctionGateway =
    sf_opaque_gateway_c17_controlMCUSlugsMKII;
  chartInstance->chartInfo.initializeChart =
    sf_opaque_initialize_c17_controlMCUSlugsMKII;
  chartInstance->chartInfo.terminateChart =
    sf_opaque_terminate_c17_controlMCUSlugsMKII;
  chartInstance->chartInfo.enableChart =
    sf_opaque_enable_c17_controlMCUSlugsMKII;
  chartInstance->chartInfo.disableChart =
    sf_opaque_disable_c17_controlMCUSlugsMKII;
  chartInstance->chartInfo.getSimState =
    sf_opaque_get_sim_state_c17_controlMCUSlugsMKII;
  chartInstance->chartInfo.setSimState =
    sf_opaque_set_sim_state_c17_controlMCUSlugsMKII;
  chartInstance->chartInfo.getSimStateInfo =
    sf_get_sim_state_info_c17_controlMCUSlugsMKII;
  chartInstance->chartInfo.zeroCrossings = NULL;
  chartInstance->chartInfo.outputs = NULL;
  chartInstance->chartInfo.derivatives = NULL;
  chartInstance->chartInfo.mdlRTW = mdlRTW_c17_controlMCUSlugsMKII;
  chartInstance->chartInfo.mdlStart = mdlStart_c17_controlMCUSlugsMKII;
  chartInstance->chartInfo.mdlSetWorkWidths =
    mdlSetWorkWidths_c17_controlMCUSlugsMKII;
  chartInstance->chartInfo.extModeExec = NULL;
  chartInstance->chartInfo.restoreLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.restoreBeforeLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.storeCurrentConfiguration = NULL;
  chartInstance->S = S;
  ssSetUserData(S,(void *)(&(chartInstance->chartInfo)));/* register the chart instance with simstruct */
  if (!sim_mode_is_rtw_gen(S)) {
    init_dsm_address_info(chartInstance);
  }

  chart_debug_initialization(S,1);
}

void c17_controlMCUSlugsMKII_method_dispatcher(SimStruct *S, int_T method, void *
  data)
{
  switch (method) {
   case SS_CALL_MDL_START:
    mdlStart_c17_controlMCUSlugsMKII(S);
    break;

   case SS_CALL_MDL_SET_WORK_WIDTHS:
    mdlSetWorkWidths_c17_controlMCUSlugsMKII(S);
    break;

   case SS_CALL_MDL_PROCESS_PARAMETERS:
    mdlProcessParameters_c17_controlMCUSlugsMKII(S);
    break;

   default:
    /* Unhandled method */
    sf_mex_error_message("Stateflow Internal Error:\n"
                         "Error calling c17_controlMCUSlugsMKII_method_dispatcher.\n"
                         "Can't handle method %d.\n", method);
    break;
  }
}
