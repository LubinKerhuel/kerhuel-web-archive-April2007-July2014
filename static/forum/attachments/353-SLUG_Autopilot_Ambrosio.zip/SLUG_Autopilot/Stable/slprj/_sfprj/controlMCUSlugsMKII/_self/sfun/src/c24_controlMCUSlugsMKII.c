/* Include files */

#include "blascompat32.h"
#include "controlMCUSlugsMKII_sfun.h"
#include "c24_controlMCUSlugsMKII.h"
#define CHARTINSTANCE_CHARTNUMBER      (chartInstance->chartNumber)
#define CHARTINSTANCE_INSTANCENUMBER   (chartInstance->instanceNumber)
#include "controlMCUSlugsMKII_sfun_debug_macros.h"

/* Type Definitions */

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */
static const char *c24_debug_family_names[4] = { "nargin", "nargout", "u", "y" };

/* Function Declarations */
static void initialize_c24_controlMCUSlugsMKII
  (SFc24_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void initialize_params_c24_controlMCUSlugsMKII
  (SFc24_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void enable_c24_controlMCUSlugsMKII
  (SFc24_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void disable_c24_controlMCUSlugsMKII
  (SFc24_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void c24_update_debugger_state_c24_controlMCUSlugsMKII
  (SFc24_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static const mxArray *get_sim_state_c24_controlMCUSlugsMKII
  (SFc24_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void set_sim_state_c24_controlMCUSlugsMKII
  (SFc24_controlMCUSlugsMKIIInstanceStruct *chartInstance, const mxArray *c24_st);
static void finalize_c24_controlMCUSlugsMKII
  (SFc24_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void sf_c24_controlMCUSlugsMKII(SFc24_controlMCUSlugsMKIIInstanceStruct
  *chartInstance);
static void init_script_number_translation(uint32_T c24_machineNumber, uint32_T
  c24_chartNumber);
static const mxArray *c24_sf_marshall(void *chartInstanceVoid, void *c24_u);
static const mxArray *c24_b_sf_marshall(void *chartInstanceVoid, void *c24_u);
static const mxArray *c24_c_sf_marshall(void *chartInstanceVoid, void *c24_u);
static real32_T c24_emlrt_marshallIn(SFc24_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c24_y, const char_T *c24_name);
static uint8_T c24_b_emlrt_marshallIn(SFc24_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c24_b_is_active_c24_controlMCUSlugsMKII, const
  char_T *c24_name);
static void init_dsm_address_info(SFc24_controlMCUSlugsMKIIInstanceStruct
  *chartInstance);

/* Function Definitions */
static void initialize_c24_controlMCUSlugsMKII
  (SFc24_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
  chartInstance->c24_is_active_c24_controlMCUSlugsMKII = 0U;
}

static void initialize_params_c24_controlMCUSlugsMKII
  (SFc24_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
}

static void enable_c24_controlMCUSlugsMKII
  (SFc24_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
}

static void disable_c24_controlMCUSlugsMKII
  (SFc24_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
}

static void c24_update_debugger_state_c24_controlMCUSlugsMKII
  (SFc24_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
}

static const mxArray *get_sim_state_c24_controlMCUSlugsMKII
  (SFc24_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
  const mxArray *c24_st = NULL;
  const mxArray *c24_y = NULL;
  real32_T c24_hoistedGlobal;
  real32_T c24_u;
  const mxArray *c24_b_y = NULL;
  uint8_T c24_b_hoistedGlobal;
  uint8_T c24_b_u;
  const mxArray *c24_c_y = NULL;
  real32_T *c24_d_y;
  c24_d_y = (real32_T *)ssGetOutputPortSignal(chartInstance->S, 1);
  c24_st = NULL;
  c24_y = NULL;
  sf_mex_assign(&c24_y, sf_mex_createcellarray(2));
  c24_hoistedGlobal = *c24_d_y;
  c24_u = c24_hoistedGlobal;
  c24_b_y = NULL;
  sf_mex_assign(&c24_b_y, sf_mex_create("y", &c24_u, 1, 0U, 0U, 0U, 0));
  sf_mex_setcell(c24_y, 0, c24_b_y);
  c24_b_hoistedGlobal = chartInstance->c24_is_active_c24_controlMCUSlugsMKII;
  c24_b_u = c24_b_hoistedGlobal;
  c24_c_y = NULL;
  sf_mex_assign(&c24_c_y, sf_mex_create("y", &c24_b_u, 3, 0U, 0U, 0U, 0));
  sf_mex_setcell(c24_y, 1, c24_c_y);
  sf_mex_assign(&c24_st, c24_y);
  return c24_st;
}

static void set_sim_state_c24_controlMCUSlugsMKII
  (SFc24_controlMCUSlugsMKIIInstanceStruct *chartInstance, const mxArray *c24_st)
{
  const mxArray *c24_u;
  real32_T *c24_y;
  c24_y = (real32_T *)ssGetOutputPortSignal(chartInstance->S, 1);
  chartInstance->c24_doneDoubleBufferReInit = TRUE;
  c24_u = sf_mex_dup(c24_st);
  *c24_y = c24_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(c24_u,
    0)), "y");
  chartInstance->c24_is_active_c24_controlMCUSlugsMKII = c24_b_emlrt_marshallIn
    (chartInstance, sf_mex_dup(sf_mex_getcell(c24_u, 1)),
     "is_active_c24_controlMCUSlugsMKII");
  sf_mex_destroy(&c24_u);
  c24_update_debugger_state_c24_controlMCUSlugsMKII(chartInstance);
  sf_mex_destroy(&c24_st);
}

static void finalize_c24_controlMCUSlugsMKII
  (SFc24_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
}

static void sf_c24_controlMCUSlugsMKII(SFc24_controlMCUSlugsMKIIInstanceStruct
  *chartInstance)
{
  int32_T c24_previousEvent;
  real32_T c24_hoistedGlobal;
  real32_T c24_u;
  uint32_T c24_debug_family_var_map[4];
  real_T c24_nargin = 1.0;
  real_T c24_nargout = 1.0;
  real32_T c24_y;
  real32_T *c24_b_u;
  real32_T *c24_b_y;
  c24_b_y = (real32_T *)ssGetOutputPortSignal(chartInstance->S, 1);
  c24_b_u = (real32_T *)ssGetInputPortSignal(chartInstance->S, 0);
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
  _SFD_CC_CALL(CHART_ENTER_SFUNCTION_TAG,23);
  _SFD_DATA_RANGE_CHECK((real_T)*c24_b_u, 0U);
  _SFD_DATA_RANGE_CHECK((real_T)*c24_b_y, 1U);
  c24_previousEvent = _sfEvent_;
  _sfEvent_ = CALL_EVENT;
  _SFD_CC_CALL(CHART_ENTER_DURING_FUNCTION_TAG,23);
  c24_hoistedGlobal = *c24_b_u;
  c24_u = c24_hoistedGlobal;
  sf_debug_symbol_scope_push_eml(0U, 4U, 4U, c24_debug_family_names,
    c24_debug_family_var_map);
  sf_debug_symbol_scope_add_eml(&c24_nargin, c24_b_sf_marshall, 0U);
  sf_debug_symbol_scope_add_eml(&c24_nargout, c24_b_sf_marshall, 1U);
  sf_debug_symbol_scope_add_eml(&c24_u, c24_sf_marshall, 2U);
  sf_debug_symbol_scope_add_eml(&c24_y, c24_sf_marshall, 3U);
  CV_EML_FCN(0, 0);

  /*  This block supports an embeddable subset of the MATLAB language. */
  /*  See the help menu for details.  */
  _SFD_EML_CALL(0,5);
  if (CV_EML_IF(0, 0, (real_T)c24_u < 0.0)) {
    _SFD_EML_CALL(0,6);
    c24_y = c24_u + 6.283185482E+000F;
  } else {
    _SFD_EML_CALL(0,8);
    c24_y = c24_u;
  }

  _SFD_EML_CALL(0,-8);
  sf_debug_symbol_scope_pop();
  *c24_b_y = c24_y;
  _SFD_CC_CALL(EXIT_OUT_OF_FUNCTION_TAG,23);
  _sfEvent_ = c24_previousEvent;
  sf_debug_check_for_state_inconsistency(_controlMCUSlugsMKIIMachineNumber_,
    chartInstance->chartNumber, chartInstance->instanceNumber
    );
}

static void init_script_number_translation(uint32_T c24_machineNumber, uint32_T
  c24_chartNumber)
{
}

static const mxArray *c24_sf_marshall(void *chartInstanceVoid, void *c24_u)
{
  const mxArray *c24_y = NULL;
  real32_T c24_b_u;
  const mxArray *c24_b_y = NULL;
  SFc24_controlMCUSlugsMKIIInstanceStruct *chartInstance;
  chartInstance = (SFc24_controlMCUSlugsMKIIInstanceStruct *)chartInstanceVoid;
  c24_y = NULL;
  c24_b_u = *((real32_T *)c24_u);
  c24_b_y = NULL;
  sf_mex_assign(&c24_b_y, sf_mex_create("y", &c24_b_u, 1, 0U, 0U, 0U, 0));
  sf_mex_assign(&c24_y, c24_b_y);
  return c24_y;
}

static const mxArray *c24_b_sf_marshall(void *chartInstanceVoid, void *c24_u)
{
  const mxArray *c24_y = NULL;
  real_T c24_b_u;
  const mxArray *c24_b_y = NULL;
  SFc24_controlMCUSlugsMKIIInstanceStruct *chartInstance;
  chartInstance = (SFc24_controlMCUSlugsMKIIInstanceStruct *)chartInstanceVoid;
  c24_y = NULL;
  c24_b_u = *((real_T *)c24_u);
  c24_b_y = NULL;
  sf_mex_assign(&c24_b_y, sf_mex_create("y", &c24_b_u, 0, 0U, 0U, 0U, 0));
  sf_mex_assign(&c24_y, c24_b_y);
  return c24_y;
}

const mxArray *sf_c24_controlMCUSlugsMKII_get_eml_resolved_functions_info(void)
{
  const mxArray *c24_nameCaptureInfo = NULL;
  c24_ResolvedFunctionInfo c24_info[14];
  c24_ResolvedFunctionInfo (*c24_b_info)[14];
  const mxArray *c24_m0 = NULL;
  int32_T c24_i0;
  c24_ResolvedFunctionInfo *c24_r0;
  c24_nameCaptureInfo = NULL;
  c24_b_info = (c24_ResolvedFunctionInfo (*)[14])c24_info;
  (*c24_b_info)[0].context = "";
  (*c24_b_info)[0].name = "lt";
  (*c24_b_info)[0].dominantType = "single";
  (*c24_b_info)[0].resolved = "[B]lt";
  (*c24_b_info)[0].fileLength = 0U;
  (*c24_b_info)[0].fileTime1 = 0U;
  (*c24_b_info)[0].fileTime2 = 0U;
  (*c24_b_info)[1].context = "";
  (*c24_b_info)[1].name = "pi";
  (*c24_b_info)[1].dominantType = "";
  (*c24_b_info)[1].resolved = "[B]pi";
  (*c24_b_info)[1].fileLength = 0U;
  (*c24_b_info)[1].fileTime1 = 0U;
  (*c24_b_info)[1].fileTime2 = 0U;
  (*c24_b_info)[2].context = "";
  (*c24_b_info)[2].name = "mtimes";
  (*c24_b_info)[2].dominantType = "double";
  (*c24_b_info)[2].resolved =
    "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  (*c24_b_info)[2].fileLength = 3425U;
  (*c24_b_info)[2].fileTime1 = 1250701566U;
  (*c24_b_info)[2].fileTime2 = 0U;
  (*c24_b_info)[3].context =
    "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  (*c24_b_info)[3].name = "nargin";
  (*c24_b_info)[3].dominantType = "";
  (*c24_b_info)[3].resolved = "[B]nargin";
  (*c24_b_info)[3].fileLength = 0U;
  (*c24_b_info)[3].fileTime1 = 0U;
  (*c24_b_info)[3].fileTime2 = 0U;
  (*c24_b_info)[4].context =
    "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  (*c24_b_info)[4].name = "gt";
  (*c24_b_info)[4].dominantType = "double";
  (*c24_b_info)[4].resolved = "[B]gt";
  (*c24_b_info)[4].fileLength = 0U;
  (*c24_b_info)[4].fileTime1 = 0U;
  (*c24_b_info)[4].fileTime2 = 0U;
  (*c24_b_info)[5].context =
    "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  (*c24_b_info)[5].name = "isa";
  (*c24_b_info)[5].dominantType = "double";
  (*c24_b_info)[5].resolved = "[B]isa";
  (*c24_b_info)[5].fileLength = 0U;
  (*c24_b_info)[5].fileTime1 = 0U;
  (*c24_b_info)[5].fileTime2 = 0U;
  (*c24_b_info)[6].context =
    "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  (*c24_b_info)[6].name = "isinteger";
  (*c24_b_info)[6].dominantType = "double";
  (*c24_b_info)[6].resolved = "[B]isinteger";
  (*c24_b_info)[6].fileLength = 0U;
  (*c24_b_info)[6].fileTime1 = 0U;
  (*c24_b_info)[6].fileTime2 = 0U;
  (*c24_b_info)[7].context =
    "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  (*c24_b_info)[7].name = "isscalar";
  (*c24_b_info)[7].dominantType = "double";
  (*c24_b_info)[7].resolved = "[B]isscalar";
  (*c24_b_info)[7].fileLength = 0U;
  (*c24_b_info)[7].fileTime1 = 0U;
  (*c24_b_info)[7].fileTime2 = 0U;
  (*c24_b_info)[8].context =
    "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  (*c24_b_info)[8].name = "strcmp";
  (*c24_b_info)[8].dominantType = "char";
  (*c24_b_info)[8].resolved = "[B]strcmp";
  (*c24_b_info)[8].fileLength = 0U;
  (*c24_b_info)[8].fileTime1 = 0U;
  (*c24_b_info)[8].fileTime2 = 0U;
  (*c24_b_info)[9].context =
    "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  (*c24_b_info)[9].name = "size";
  (*c24_b_info)[9].dominantType = "double";
  (*c24_b_info)[9].resolved = "[B]size";
  (*c24_b_info)[9].fileLength = 0U;
  (*c24_b_info)[9].fileTime1 = 0U;
  (*c24_b_info)[9].fileTime2 = 0U;
  (*c24_b_info)[10].context =
    "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  (*c24_b_info)[10].name = "eq";
  (*c24_b_info)[10].dominantType = "double";
  (*c24_b_info)[10].resolved = "[B]eq";
  (*c24_b_info)[10].fileLength = 0U;
  (*c24_b_info)[10].fileTime1 = 0U;
  (*c24_b_info)[10].fileTime2 = 0U;
  (*c24_b_info)[11].context =
    "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  (*c24_b_info)[11].name = "class";
  (*c24_b_info)[11].dominantType = "double";
  (*c24_b_info)[11].resolved = "[B]class";
  (*c24_b_info)[11].fileLength = 0U;
  (*c24_b_info)[11].fileTime1 = 0U;
  (*c24_b_info)[11].fileTime2 = 0U;
  (*c24_b_info)[12].context =
    "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  (*c24_b_info)[12].name = "not";
  (*c24_b_info)[12].dominantType = "logical";
  (*c24_b_info)[12].resolved = "[B]not";
  (*c24_b_info)[12].fileLength = 0U;
  (*c24_b_info)[12].fileTime1 = 0U;
  (*c24_b_info)[12].fileTime2 = 0U;
  (*c24_b_info)[13].context = "";
  (*c24_b_info)[13].name = "plus";
  (*c24_b_info)[13].dominantType = "single";
  (*c24_b_info)[13].resolved = "[B]plus";
  (*c24_b_info)[13].fileLength = 0U;
  (*c24_b_info)[13].fileTime1 = 0U;
  (*c24_b_info)[13].fileTime2 = 0U;
  sf_mex_assign(&c24_m0, sf_mex_createstruct("nameCaptureInfo", 1, 14));
  for (c24_i0 = 0; c24_i0 < 14; c24_i0 = c24_i0 + 1) {
    c24_r0 = &c24_info[c24_i0];
    sf_mex_addfield(c24_m0, sf_mex_create("nameCaptureInfo", c24_r0->context, 15,
      0U, 0U, 0U, 2, 1, strlen(c24_r0->context)), "context"
                    , "nameCaptureInfo", c24_i0);
    sf_mex_addfield(c24_m0, sf_mex_create("nameCaptureInfo", c24_r0->name, 15,
      0U, 0U, 0U, 2, 1, strlen(c24_r0->name)), "name",
                    "nameCaptureInfo", c24_i0);
    sf_mex_addfield(c24_m0, sf_mex_create("nameCaptureInfo",
      c24_r0->dominantType, 15, 0U, 0U, 0U, 2, 1, strlen(c24_r0->dominantType)),
                    "dominantType", "nameCaptureInfo", c24_i0);
    sf_mex_addfield(c24_m0, sf_mex_create("nameCaptureInfo", c24_r0->resolved,
      15, 0U, 0U, 0U, 2, 1, strlen(c24_r0->resolved)),
                    "resolved", "nameCaptureInfo", c24_i0);
    sf_mex_addfield(c24_m0, sf_mex_create("nameCaptureInfo", &c24_r0->fileLength,
      7, 0U, 0U, 0U, 0), "fileLength", "nameCaptureInfo",
                    c24_i0);
    sf_mex_addfield(c24_m0, sf_mex_create("nameCaptureInfo", &c24_r0->fileTime1,
      7, 0U, 0U, 0U, 0), "fileTime1", "nameCaptureInfo",
                    c24_i0);
    sf_mex_addfield(c24_m0, sf_mex_create("nameCaptureInfo", &c24_r0->fileTime2,
      7, 0U, 0U, 0U, 0), "fileTime2", "nameCaptureInfo",
                    c24_i0);
  }

  sf_mex_assign(&c24_nameCaptureInfo, c24_m0);
  return c24_nameCaptureInfo;
}

static const mxArray *c24_c_sf_marshall(void *chartInstanceVoid, void *c24_u)
{
  const mxArray *c24_y = NULL;
  boolean_T c24_b_u;
  const mxArray *c24_b_y = NULL;
  SFc24_controlMCUSlugsMKIIInstanceStruct *chartInstance;
  chartInstance = (SFc24_controlMCUSlugsMKIIInstanceStruct *)chartInstanceVoid;
  c24_y = NULL;
  c24_b_u = *((boolean_T *)c24_u);
  c24_b_y = NULL;
  sf_mex_assign(&c24_b_y, sf_mex_create("y", &c24_b_u, 11, 0U, 0U, 0U, 0));
  sf_mex_assign(&c24_y, c24_b_y);
  return c24_y;
}

static real32_T c24_emlrt_marshallIn(SFc24_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c24_y, const char_T *
  c24_name)
{
  real32_T c24_b_y;
  real32_T c24_f0;
  sf_mex_import(c24_name, sf_mex_dup(c24_y), &c24_f0, 1, 1, 0U, 0, 0U, 0);
  c24_b_y = c24_f0;
  sf_mex_destroy(&c24_y);
  return c24_b_y;
}

static uint8_T c24_b_emlrt_marshallIn(SFc24_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *
  c24_b_is_active_c24_controlMCUSlugsMKII, const char_T *c24_name)
{
  uint8_T c24_y;
  uint8_T c24_u0;
  sf_mex_import(c24_name, sf_mex_dup(c24_b_is_active_c24_controlMCUSlugsMKII),
                &c24_u0, 1, 3, 0U, 0, 0U, 0);
  c24_y = c24_u0;
  sf_mex_destroy(&c24_b_is_active_c24_controlMCUSlugsMKII);
  return c24_y;
}

static void init_dsm_address_info(SFc24_controlMCUSlugsMKIIInstanceStruct
  *chartInstance)
{
}

/* SFunction Glue Code */
void sf_c24_controlMCUSlugsMKII_get_check_sum(mxArray *plhs[])
{
  ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(697089792U);
  ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(4003326228U);
  ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(3077031690U);
  ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(507253272U);
}

mxArray *sf_c24_controlMCUSlugsMKII_get_autoinheritance_info(void)
{
  const char *autoinheritanceFields[] = { "checksum", "inputs", "parameters",
    "outputs" };

  mxArray *mxAutoinheritanceInfo = mxCreateStructMatrix(1,1,4,
    autoinheritanceFields);

  {
    mxArray *mxChecksum = mxCreateDoubleMatrix(4,1,mxREAL);
    double *pr = mxGetPr(mxChecksum);
    pr[0] = (double)(3739115378U);
    pr[1] = (double)(202824936U);
    pr[2] = (double)(540133940U);
    pr[3] = (double)(1603199134U);
    mxSetField(mxAutoinheritanceInfo,0,"checksum",mxChecksum);
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,1,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(9));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"inputs",mxData);
  }

  {
    mxSetField(mxAutoinheritanceInfo,0,"parameters",mxCreateDoubleMatrix(0,0,
                mxREAL));
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,1,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(9));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"outputs",mxData);
  }

  return(mxAutoinheritanceInfo);
}

static mxArray *sf_get_sim_state_info_c24_controlMCUSlugsMKII(void)
{
  const char *infoFields[] = { "chartChecksum", "varInfo" };

  mxArray *mxInfo = mxCreateStructMatrix(1, 1, 2, infoFields);
  const char *infoEncStr[] = {
    "100 S1x2'type','srcId','name','auxInfo'{{M[1],M[5],T\"y\",},{M[8],M[0],T\"is_active_c24_controlMCUSlugsMKII\",}}"
  };

  mxArray *mxVarInfo = sf_mex_decode_encoded_mx_struct_array(infoEncStr, 2, 10);
  mxArray *mxChecksum = mxCreateDoubleMatrix(1, 4, mxREAL);
  sf_c24_controlMCUSlugsMKII_get_check_sum(&mxChecksum);
  mxSetField(mxInfo, 0, infoFields[0], mxChecksum);
  mxSetField(mxInfo, 0, infoFields[1], mxVarInfo);
  return mxInfo;
}

static void chart_debug_initialization(SimStruct *S, unsigned int
  fullDebuggerInitialization)
{
  if (!sim_mode_is_rtw_gen(S)) {
    SFc24_controlMCUSlugsMKIIInstanceStruct *chartInstance;
    chartInstance = (SFc24_controlMCUSlugsMKIIInstanceStruct *)
      ((ChartInfoStruct *)(ssGetUserData(S)))->chartInstance;
    if (ssIsFirstInitCond(S) && fullDebuggerInitialization==1) {
      /* do this only if simulation is starting */
      {
        unsigned int chartAlreadyPresent;
        chartAlreadyPresent = sf_debug_initialize_chart
          (_controlMCUSlugsMKIIMachineNumber_,
           24,
           1,
           1,
           2,
           0,
           0,
           0,
           0,
           0,
           &(chartInstance->chartNumber),
           &(chartInstance->instanceNumber),
           ssGetPath(S),
           (void *)S);
        if (chartAlreadyPresent==0) {
          /* this is the first instance */
          init_script_number_translation(_controlMCUSlugsMKIIMachineNumber_,
            chartInstance->chartNumber);
          sf_debug_set_chart_disable_implicit_casting
            (_controlMCUSlugsMKIIMachineNumber_,chartInstance->chartNumber,1);
          sf_debug_set_chart_event_thresholds(_controlMCUSlugsMKIIMachineNumber_,
            chartInstance->chartNumber,
            0,
            0,
            0);
          _SFD_SET_DATA_PROPS(0,1,1,0,SF_SINGLE,0,NULL,0,0,0,0.0,1.0,0,"u",0,
                              (MexFcnForType)c24_sf_marshall);
          _SFD_SET_DATA_PROPS(1,2,0,1,SF_SINGLE,0,NULL,0,0,0,0.0,1.0,0,"y",0,
                              (MexFcnForType)c24_sf_marshall);
          _SFD_STATE_INFO(0,0,2);
          _SFD_CH_SUBSTATE_COUNT(0);
          _SFD_CH_SUBSTATE_DECOMP(0);
        }

        _SFD_CV_INIT_CHART(0,0,0,0);

        {
          _SFD_CV_INIT_STATE(0,0,0,0,0,0,NULL,NULL);
        }

        _SFD_CV_INIT_TRANS(0,0,NULL,NULL,0,NULL);

        /* Initialization of EML Model Coverage */
        _SFD_CV_INIT_EML(0,1,1,0,0,0,0,0,0);
        _SFD_CV_INIT_EML_FCN(0,0,"eML_blk_kernel",0,-1,174);
        _SFD_CV_INIT_EML_IF(0,0,124,134,155,174);
        _SFD_TRANS_COV_WTS(0,0,0,1,0);
        if (chartAlreadyPresent==0) {
          _SFD_TRANS_COV_MAPS(0,
                              0,NULL,NULL,
                              0,NULL,NULL,
                              1,NULL,NULL,
                              0,NULL,NULL);
        }

        {
          real32_T *c24_u;
          real32_T *c24_y;
          c24_y = (real32_T *)ssGetOutputPortSignal(chartInstance->S, 1);
          c24_u = (real32_T *)ssGetInputPortSignal(chartInstance->S, 0);
          _SFD_SET_DATA_VALUE_PTR(0U, c24_u);
          _SFD_SET_DATA_VALUE_PTR(1U, c24_y);
        }
      }
    } else {
      sf_debug_reset_current_state_configuration
        (_controlMCUSlugsMKIIMachineNumber_,chartInstance->chartNumber,
         chartInstance->instanceNumber);
    }
  }
}

static void sf_opaque_initialize_c24_controlMCUSlugsMKII(void *chartInstanceVar)
{
  chart_debug_initialization(((SFc24_controlMCUSlugsMKIIInstanceStruct*)
    chartInstanceVar)->S,0);
  initialize_params_c24_controlMCUSlugsMKII
    ((SFc24_controlMCUSlugsMKIIInstanceStruct*) chartInstanceVar);
  initialize_c24_controlMCUSlugsMKII((SFc24_controlMCUSlugsMKIIInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_enable_c24_controlMCUSlugsMKII(void *chartInstanceVar)
{
  enable_c24_controlMCUSlugsMKII((SFc24_controlMCUSlugsMKIIInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_disable_c24_controlMCUSlugsMKII(void *chartInstanceVar)
{
  disable_c24_controlMCUSlugsMKII((SFc24_controlMCUSlugsMKIIInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_gateway_c24_controlMCUSlugsMKII(void *chartInstanceVar)
{
  sf_c24_controlMCUSlugsMKII((SFc24_controlMCUSlugsMKIIInstanceStruct*)
    chartInstanceVar);
}

static mxArray* sf_internal_get_sim_state_c24_controlMCUSlugsMKII(SimStruct* S)
{
  ChartInfoStruct *chartInfo = (ChartInfoStruct*) ssGetUserData(S);
  mxArray *plhs[1] = { NULL };

  mxArray *prhs[4];
  int mxError = 0;
  prhs[0] = mxCreateString("chart_simctx_raw2high");
  prhs[1] = mxCreateDoubleScalar(ssGetSFuncBlockHandle(S));
  prhs[2] = (mxArray*) get_sim_state_c24_controlMCUSlugsMKII
    ((SFc24_controlMCUSlugsMKIIInstanceStruct*)chartInfo->chartInstance);/* raw sim ctx */
  prhs[3] = sf_get_sim_state_info_c24_controlMCUSlugsMKII();/* state var info */
  mxError = sf_mex_call_matlab(1, plhs, 4, prhs, "sfprivate");
  mxDestroyArray(prhs[0]);
  mxDestroyArray(prhs[1]);
  mxDestroyArray(prhs[2]);
  mxDestroyArray(prhs[3]);
  if (mxError || plhs[0] == NULL) {
    sf_mex_error_message("Stateflow Internal Error: \nError calling 'chart_simctx_raw2high'.\n");
  }

  return plhs[0];
}

static void sf_internal_set_sim_state_c24_controlMCUSlugsMKII(SimStruct* S,
  const mxArray *st)
{
  ChartInfoStruct *chartInfo = (ChartInfoStruct*) ssGetUserData(S);
  mxArray *plhs[1] = { NULL };

  mxArray *prhs[4];
  int mxError = 0;
  prhs[0] = mxCreateString("chart_simctx_high2raw");
  prhs[1] = mxCreateDoubleScalar(ssGetSFuncBlockHandle(S));
  prhs[2] = mxDuplicateArray(st);      /* high level simctx */
  prhs[3] = (mxArray*) sf_get_sim_state_info_c24_controlMCUSlugsMKII();/* state var info */
  mxError = sf_mex_call_matlab(1, plhs, 4, prhs, "sfprivate");
  mxDestroyArray(prhs[0]);
  mxDestroyArray(prhs[1]);
  mxDestroyArray(prhs[2]);
  mxDestroyArray(prhs[3]);
  if (mxError || plhs[0] == NULL) {
    sf_mex_error_message("Stateflow Internal Error: \nError calling 'chart_simctx_high2raw'.\n");
  }

  set_sim_state_c24_controlMCUSlugsMKII((SFc24_controlMCUSlugsMKIIInstanceStruct*)
    chartInfo->chartInstance, mxDuplicateArray(plhs[0]));
  mxDestroyArray(plhs[0]);
}

static mxArray* sf_opaque_get_sim_state_c24_controlMCUSlugsMKII(SimStruct* S)
{
  return sf_internal_get_sim_state_c24_controlMCUSlugsMKII(S);
}

static void sf_opaque_set_sim_state_c24_controlMCUSlugsMKII(SimStruct* S, const
  mxArray *st)
{
  sf_internal_set_sim_state_c24_controlMCUSlugsMKII(S, st);
}

static void sf_opaque_terminate_c24_controlMCUSlugsMKII(void *chartInstanceVar)
{
  if (chartInstanceVar!=NULL) {
    SimStruct *S = ((SFc24_controlMCUSlugsMKIIInstanceStruct*) chartInstanceVar
      )->S;
    if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
      sf_clear_rtw_identifier(S);
    }

    finalize_c24_controlMCUSlugsMKII((SFc24_controlMCUSlugsMKIIInstanceStruct*)
      chartInstanceVar);
    free((void *)chartInstanceVar);
    ssSetUserData(S,NULL);
  }
}

extern unsigned int sf_machine_global_initializer_called(void);
static void mdlProcessParameters_c24_controlMCUSlugsMKII(SimStruct *S)
{
  int i;
  for (i=0;i<ssGetNumRunTimeParams(S);i++) {
    if (ssGetSFcnParamTunable(S,i)) {
      ssUpdateDlgParamAsRunTimeParam(S,i);
    }
  }

  if (sf_machine_global_initializer_called()) {
    initialize_params_c24_controlMCUSlugsMKII
      ((SFc24_controlMCUSlugsMKIIInstanceStruct*)(((ChartInfoStruct *)
         ssGetUserData(S))->chartInstance));
  }
}

static void mdlSetWorkWidths_c24_controlMCUSlugsMKII(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
    int_T chartIsInlinable =
      (int_T)sf_is_chart_inlinable("controlMCUSlugsMKII","controlMCUSlugsMKII",
      24);
    ssSetStateflowIsInlinable(S,chartIsInlinable);
    ssSetRTWCG(S,sf_rtw_info_uint_prop("controlMCUSlugsMKII",
                "controlMCUSlugsMKII",24,"RTWCG"));
    ssSetEnableFcnIsTrivial(S,1);
    ssSetDisableFcnIsTrivial(S,1);
    ssSetNotMultipleInlinable(S,sf_rtw_info_uint_prop("controlMCUSlugsMKII",
      "controlMCUSlugsMKII",24,"gatewayCannotBeInlinedMultipleTimes"));
    if (chartIsInlinable) {
      ssSetInputPortOptimOpts(S, 0, SS_REUSABLE_AND_LOCAL);
      sf_mark_chart_expressionable_inputs(S,"controlMCUSlugsMKII",
        "controlMCUSlugsMKII",24,1);
      sf_mark_chart_reusable_outputs(S,"controlMCUSlugsMKII",
        "controlMCUSlugsMKII",24,1);
    }

    sf_set_rtw_dwork_info(S,"controlMCUSlugsMKII","controlMCUSlugsMKII",24);
    ssSetHasSubFunctions(S,!(chartIsInlinable));
    ssSetOptions(S,ssGetOptions(S)|SS_OPTION_WORKS_WITH_CODE_REUSE);
  }

  ssSetChecksum0(S,(1102290319U));
  ssSetChecksum1(S,(1877695399U));
  ssSetChecksum2(S,(1378176718U));
  ssSetChecksum3(S,(3388116728U));
  ssSetmdlDerivatives(S, NULL);
  ssSetExplicitFCSSCtrl(S,1);
}

static void mdlRTW_c24_controlMCUSlugsMKII(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S)) {
    sf_write_symbol_mapping(S, "controlMCUSlugsMKII", "controlMCUSlugsMKII",24);
    ssWriteRTWStrParam(S, "StateflowChartType", "Embedded MATLAB");
  }
}

static void mdlStart_c24_controlMCUSlugsMKII(SimStruct *S)
{
  SFc24_controlMCUSlugsMKIIInstanceStruct *chartInstance;
  chartInstance = (SFc24_controlMCUSlugsMKIIInstanceStruct *)malloc(sizeof
    (SFc24_controlMCUSlugsMKIIInstanceStruct));
  memset(chartInstance, 0, sizeof(SFc24_controlMCUSlugsMKIIInstanceStruct));
  if (chartInstance==NULL) {
    sf_mex_error_message("Could not allocate memory for chart instance.");
  }

  chartInstance->chartInfo.chartInstance = chartInstance;
  chartInstance->chartInfo.isEMLChart = 1;
  chartInstance->chartInfo.chartInitialized = 0;
  chartInstance->chartInfo.sFunctionGateway =
    sf_opaque_gateway_c24_controlMCUSlugsMKII;
  chartInstance->chartInfo.initializeChart =
    sf_opaque_initialize_c24_controlMCUSlugsMKII;
  chartInstance->chartInfo.terminateChart =
    sf_opaque_terminate_c24_controlMCUSlugsMKII;
  chartInstance->chartInfo.enableChart =
    sf_opaque_enable_c24_controlMCUSlugsMKII;
  chartInstance->chartInfo.disableChart =
    sf_opaque_disable_c24_controlMCUSlugsMKII;
  chartInstance->chartInfo.getSimState =
    sf_opaque_get_sim_state_c24_controlMCUSlugsMKII;
  chartInstance->chartInfo.setSimState =
    sf_opaque_set_sim_state_c24_controlMCUSlugsMKII;
  chartInstance->chartInfo.getSimStateInfo =
    sf_get_sim_state_info_c24_controlMCUSlugsMKII;
  chartInstance->chartInfo.zeroCrossings = NULL;
  chartInstance->chartInfo.outputs = NULL;
  chartInstance->chartInfo.derivatives = NULL;
  chartInstance->chartInfo.mdlRTW = mdlRTW_c24_controlMCUSlugsMKII;
  chartInstance->chartInfo.mdlStart = mdlStart_c24_controlMCUSlugsMKII;
  chartInstance->chartInfo.mdlSetWorkWidths =
    mdlSetWorkWidths_c24_controlMCUSlugsMKII;
  chartInstance->chartInfo.extModeExec = NULL;
  chartInstance->chartInfo.restoreLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.restoreBeforeLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.storeCurrentConfiguration = NULL;
  chartInstance->S = S;
  ssSetUserData(S,(void *)(&(chartInstance->chartInfo)));/* register the chart instance with simstruct */
  if (!sim_mode_is_rtw_gen(S)) {
    init_dsm_address_info(chartInstance);
  }

  chart_debug_initialization(S,1);
}

void c24_controlMCUSlugsMKII_method_dispatcher(SimStruct *S, int_T method, void *
  data)
{
  switch (method) {
   case SS_CALL_MDL_START:
    mdlStart_c24_controlMCUSlugsMKII(S);
    break;

   case SS_CALL_MDL_SET_WORK_WIDTHS:
    mdlSetWorkWidths_c24_controlMCUSlugsMKII(S);
    break;

   case SS_CALL_MDL_PROCESS_PARAMETERS:
    mdlProcessParameters_c24_controlMCUSlugsMKII(S);
    break;

   default:
    /* Unhandled method */
    sf_mex_error_message("Stateflow Internal Error:\n"
                         "Error calling c24_controlMCUSlugsMKII_method_dispatcher.\n"
                         "Can't handle method %d.\n", method);
    break;
  }
}
