/* Include files */

#include "blascompat32.h"
#include "controlMCUSlugsMKII_sfun.h"
#include "c23_controlMCUSlugsMKII.h"
#define CHARTINSTANCE_CHARTNUMBER      (chartInstance->chartNumber)
#define CHARTINSTANCE_INSTANCENUMBER   (chartInstance->instanceNumber)
#include "controlMCUSlugsMKII_sfun_debug_macros.h"

/* Type Definitions */

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */
static const char *c23_debug_family_names[5] = { "nargin", "nargout", "u1", "u2",
  "y" };

/* Function Declarations */
static void initialize_c23_controlMCUSlugsMKII
  (SFc23_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void initialize_params_c23_controlMCUSlugsMKII
  (SFc23_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void enable_c23_controlMCUSlugsMKII
  (SFc23_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void disable_c23_controlMCUSlugsMKII
  (SFc23_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void c23_update_debugger_state_c23_controlMCUSlugsMKII
  (SFc23_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static const mxArray *get_sim_state_c23_controlMCUSlugsMKII
  (SFc23_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void set_sim_state_c23_controlMCUSlugsMKII
  (SFc23_controlMCUSlugsMKIIInstanceStruct *chartInstance, const mxArray *c23_st);
static void finalize_c23_controlMCUSlugsMKII
  (SFc23_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void sf_c23_controlMCUSlugsMKII(SFc23_controlMCUSlugsMKIIInstanceStruct
  *chartInstance);
static void init_script_number_translation(uint32_T c23_machineNumber, uint32_T
  c23_chartNumber);
static const mxArray *c23_sf_marshall(void *chartInstanceVoid, void *c23_u);
static const mxArray *c23_b_sf_marshall(void *chartInstanceVoid, void *c23_u);
static const mxArray *c23_c_sf_marshall(void *chartInstanceVoid, void *c23_u);
static const mxArray *c23_d_sf_marshall(void *chartInstanceVoid, void *c23_u);
static const mxArray *c23_e_sf_marshall(void *chartInstanceVoid, void *c23_u);
static void c23_emlrt_marshallIn(SFc23_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c23_y, const char_T *c23_name, uint16_T
  c23_b_y[5]);
static uint8_T c23_b_emlrt_marshallIn(SFc23_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c23_b_is_active_c23_controlMCUSlugsMKII, const
  char_T *c23_name);
static void init_dsm_address_info(SFc23_controlMCUSlugsMKIIInstanceStruct
  *chartInstance);

/* Function Definitions */
static void initialize_c23_controlMCUSlugsMKII
  (SFc23_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
  chartInstance->c23_is_active_c23_controlMCUSlugsMKII = 0U;
}

static void initialize_params_c23_controlMCUSlugsMKII
  (SFc23_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
}

static void enable_c23_controlMCUSlugsMKII
  (SFc23_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
}

static void disable_c23_controlMCUSlugsMKII
  (SFc23_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
}

static void c23_update_debugger_state_c23_controlMCUSlugsMKII
  (SFc23_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
}

static const mxArray *get_sim_state_c23_controlMCUSlugsMKII
  (SFc23_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
  const mxArray *c23_st = NULL;
  const mxArray *c23_y = NULL;
  int32_T c23_i0;
  uint16_T c23_hoistedGlobal[5];
  int32_T c23_i1;
  uint16_T c23_u[5];
  const mxArray *c23_b_y = NULL;
  uint8_T c23_b_hoistedGlobal;
  uint8_T c23_b_u;
  const mxArray *c23_c_y = NULL;
  uint16_T (*c23_d_y)[5];
  c23_d_y = (uint16_T (*)[5])ssGetOutputPortSignal(chartInstance->S, 1);
  c23_st = NULL;
  c23_y = NULL;
  sf_mex_assign(&c23_y, sf_mex_createcellarray(2));
  for (c23_i0 = 0; c23_i0 < 5; c23_i0 = c23_i0 + 1) {
    c23_hoistedGlobal[c23_i0] = (*c23_d_y)[c23_i0];
  }

  for (c23_i1 = 0; c23_i1 < 5; c23_i1 = c23_i1 + 1) {
    c23_u[c23_i1] = c23_hoistedGlobal[c23_i1];
  }

  c23_b_y = NULL;
  sf_mex_assign(&c23_b_y, sf_mex_create("y", &c23_u, 5, 0U, 1U, 0U, 1, 5));
  sf_mex_setcell(c23_y, 0, c23_b_y);
  c23_b_hoistedGlobal = chartInstance->c23_is_active_c23_controlMCUSlugsMKII;
  c23_b_u = c23_b_hoistedGlobal;
  c23_c_y = NULL;
  sf_mex_assign(&c23_c_y, sf_mex_create("y", &c23_b_u, 3, 0U, 0U, 0U, 0));
  sf_mex_setcell(c23_y, 1, c23_c_y);
  sf_mex_assign(&c23_st, c23_y);
  return c23_st;
}

static void set_sim_state_c23_controlMCUSlugsMKII
  (SFc23_controlMCUSlugsMKIIInstanceStruct *chartInstance, const mxArray *c23_st)
{
  const mxArray *c23_u;
  uint16_T c23_uv0[5];
  int32_T c23_i2;
  uint16_T (*c23_y)[5];
  c23_y = (uint16_T (*)[5])ssGetOutputPortSignal(chartInstance->S, 1);
  chartInstance->c23_doneDoubleBufferReInit = TRUE;
  c23_u = sf_mex_dup(c23_st);
  c23_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(c23_u, 0)), "y",
                       c23_uv0);
  for (c23_i2 = 0; c23_i2 < 5; c23_i2 = c23_i2 + 1) {
    (*c23_y)[c23_i2] = c23_uv0[c23_i2];
  }

  chartInstance->c23_is_active_c23_controlMCUSlugsMKII = c23_b_emlrt_marshallIn
    (chartInstance, sf_mex_dup(sf_mex_getcell(c23_u, 1)),
     "is_active_c23_controlMCUSlugsMKII");
  sf_mex_destroy(&c23_u);
  c23_update_debugger_state_c23_controlMCUSlugsMKII(chartInstance);
  sf_mex_destroy(&c23_st);
}

static void finalize_c23_controlMCUSlugsMKII
  (SFc23_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
}

static void sf_c23_controlMCUSlugsMKII(SFc23_controlMCUSlugsMKIIInstanceStruct
  *chartInstance)
{
  int32_T c23_i3;
  int32_T c23_i4;
  int32_T c23_previousEvent;
  int32_T c23_i5;
  uint16_T c23_hoistedGlobal[4];
  uint16_T c23_b_hoistedGlobal;
  int32_T c23_i6;
  uint16_T c23_u1[4];
  uint16_T c23_u2;
  uint32_T c23_debug_family_var_map[5];
  static const char *c23_sv0[5] = { "nargin", "nargout", "u1", "u2", "y" };

  real_T c23_nargin = 2.0;
  real_T c23_nargout = 1.0;
  uint16_T c23_y[5];
  int32_T c23_i7;
  int32_T c23_i8;
  uint16_T *c23_b_u2;
  uint16_T (*c23_b_y)[5];
  uint16_T (*c23_b_u1)[4];
  c23_b_u2 = (uint16_T *)ssGetInputPortSignal(chartInstance->S, 1);
  c23_b_y = (uint16_T (*)[5])ssGetOutputPortSignal(chartInstance->S, 1);
  c23_b_u1 = (uint16_T (*)[4])ssGetInputPortSignal(chartInstance->S, 0);
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
  _SFD_CC_CALL(CHART_ENTER_SFUNCTION_TAG,22);
  for (c23_i3 = 0; c23_i3 < 4; c23_i3 = c23_i3 + 1) {
    _SFD_DATA_RANGE_CHECK((real_T)(*c23_b_u1)[c23_i3], 0U);
  }

  for (c23_i4 = 0; c23_i4 < 5; c23_i4 = c23_i4 + 1) {
    _SFD_DATA_RANGE_CHECK((real_T)(*c23_b_y)[c23_i4], 1U);
  }

  _SFD_DATA_RANGE_CHECK((real_T)*c23_b_u2, 2U);
  c23_previousEvent = _sfEvent_;
  _sfEvent_ = CALL_EVENT;
  _SFD_CC_CALL(CHART_ENTER_DURING_FUNCTION_TAG,22);
  for (c23_i5 = 0; c23_i5 < 4; c23_i5 = c23_i5 + 1) {
    c23_hoistedGlobal[c23_i5] = (*c23_b_u1)[c23_i5];
  }

  c23_b_hoistedGlobal = *c23_b_u2;
  for (c23_i6 = 0; c23_i6 < 4; c23_i6 = c23_i6 + 1) {
    c23_u1[c23_i6] = c23_hoistedGlobal[c23_i6];
  }

  c23_u2 = c23_b_hoistedGlobal;
  sf_debug_symbol_scope_push_eml(0U, 5U, 5U, c23_sv0, c23_debug_family_var_map);
  sf_debug_symbol_scope_add_eml(&c23_nargin, c23_d_sf_marshall, 0U);
  sf_debug_symbol_scope_add_eml(&c23_nargout, c23_d_sf_marshall, 1U);
  sf_debug_symbol_scope_add_eml(&c23_u1, c23_c_sf_marshall, 2U);
  sf_debug_symbol_scope_add_eml(&c23_u2, c23_b_sf_marshall, 3U);
  sf_debug_symbol_scope_add_eml(&c23_y, c23_sf_marshall, 4U);
  CV_EML_FCN(0, 0);

  /*  This block supports an embeddable subset of the MATLAB language. */
  /*  See the help menu for details.  */
  _SFD_EML_CALL(0,5);
  for (c23_i7 = 0; c23_i7 < 4; c23_i7 = c23_i7 + 1) {
    c23_y[c23_i7] = c23_u1[c23_i7];
  }

  c23_y[4] = c23_u2;
  _SFD_EML_CALL(0,-5);
  sf_debug_symbol_scope_pop();
  for (c23_i8 = 0; c23_i8 < 5; c23_i8 = c23_i8 + 1) {
    (*c23_b_y)[c23_i8] = c23_y[c23_i8];
  }

  _SFD_CC_CALL(EXIT_OUT_OF_FUNCTION_TAG,22);
  _sfEvent_ = c23_previousEvent;
  sf_debug_check_for_state_inconsistency(_controlMCUSlugsMKIIMachineNumber_,
    chartInstance->chartNumber, chartInstance->instanceNumber
    );
}

static void init_script_number_translation(uint32_T c23_machineNumber, uint32_T
  c23_chartNumber)
{
}

static const mxArray *c23_sf_marshall(void *chartInstanceVoid, void *c23_u)
{
  const mxArray *c23_y = NULL;
  int32_T c23_i9;
  uint16_T c23_b_u[5];
  const mxArray *c23_b_y = NULL;
  SFc23_controlMCUSlugsMKIIInstanceStruct *chartInstance;
  chartInstance = (SFc23_controlMCUSlugsMKIIInstanceStruct *)chartInstanceVoid;
  c23_y = NULL;
  for (c23_i9 = 0; c23_i9 < 5; c23_i9 = c23_i9 + 1) {
    c23_b_u[c23_i9] = (*((uint16_T (*)[5])c23_u))[c23_i9];
  }

  c23_b_y = NULL;
  sf_mex_assign(&c23_b_y, sf_mex_create("y", &c23_b_u, 5, 0U, 1U, 0U, 1, 5));
  sf_mex_assign(&c23_y, c23_b_y);
  return c23_y;
}

static const mxArray *c23_b_sf_marshall(void *chartInstanceVoid, void *c23_u)
{
  const mxArray *c23_y = NULL;
  uint16_T c23_b_u;
  const mxArray *c23_b_y = NULL;
  SFc23_controlMCUSlugsMKIIInstanceStruct *chartInstance;
  chartInstance = (SFc23_controlMCUSlugsMKIIInstanceStruct *)chartInstanceVoid;
  c23_y = NULL;
  c23_b_u = *((uint16_T *)c23_u);
  c23_b_y = NULL;
  sf_mex_assign(&c23_b_y, sf_mex_create("y", &c23_b_u, 5, 0U, 0U, 0U, 0));
  sf_mex_assign(&c23_y, c23_b_y);
  return c23_y;
}

static const mxArray *c23_c_sf_marshall(void *chartInstanceVoid, void *c23_u)
{
  const mxArray *c23_y = NULL;
  int32_T c23_i10;
  uint16_T c23_b_u[4];
  const mxArray *c23_b_y = NULL;
  SFc23_controlMCUSlugsMKIIInstanceStruct *chartInstance;
  chartInstance = (SFc23_controlMCUSlugsMKIIInstanceStruct *)chartInstanceVoid;
  c23_y = NULL;
  for (c23_i10 = 0; c23_i10 < 4; c23_i10 = c23_i10 + 1) {
    c23_b_u[c23_i10] = (*((uint16_T (*)[4])c23_u))[c23_i10];
  }

  c23_b_y = NULL;
  sf_mex_assign(&c23_b_y, sf_mex_create("y", &c23_b_u, 5, 0U, 1U, 0U, 1, 4));
  sf_mex_assign(&c23_y, c23_b_y);
  return c23_y;
}

static const mxArray *c23_d_sf_marshall(void *chartInstanceVoid, void *c23_u)
{
  const mxArray *c23_y = NULL;
  real_T c23_b_u;
  const mxArray *c23_b_y = NULL;
  SFc23_controlMCUSlugsMKIIInstanceStruct *chartInstance;
  chartInstance = (SFc23_controlMCUSlugsMKIIInstanceStruct *)chartInstanceVoid;
  c23_y = NULL;
  c23_b_u = *((real_T *)c23_u);
  c23_b_y = NULL;
  sf_mex_assign(&c23_b_y, sf_mex_create("y", &c23_b_u, 0, 0U, 0U, 0U, 0));
  sf_mex_assign(&c23_y, c23_b_y);
  return c23_y;
}

const mxArray *sf_c23_controlMCUSlugsMKII_get_eml_resolved_functions_info(void)
{
  const mxArray *c23_nameCaptureInfo = NULL;
  c23_nameCaptureInfo = NULL;
  sf_mex_assign(&c23_nameCaptureInfo, sf_mex_create("nameCaptureInfo", NULL, 0,
    0U, 1U, 0U, 2, 0, 1));
  return c23_nameCaptureInfo;
}

static const mxArray *c23_e_sf_marshall(void *chartInstanceVoid, void *c23_u)
{
  const mxArray *c23_y = NULL;
  boolean_T c23_b_u;
  const mxArray *c23_b_y = NULL;
  SFc23_controlMCUSlugsMKIIInstanceStruct *chartInstance;
  chartInstance = (SFc23_controlMCUSlugsMKIIInstanceStruct *)chartInstanceVoid;
  c23_y = NULL;
  c23_b_u = *((boolean_T *)c23_u);
  c23_b_y = NULL;
  sf_mex_assign(&c23_b_y, sf_mex_create("y", &c23_b_u, 11, 0U, 0U, 0U, 0));
  sf_mex_assign(&c23_y, c23_b_y);
  return c23_y;
}

static void c23_emlrt_marshallIn(SFc23_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c23_y, const char_T *
  c23_name, uint16_T c23_b_y[5])
{
  uint16_T c23_uv1[5];
  int32_T c23_i11;
  sf_mex_import(c23_name, sf_mex_dup(c23_y), &c23_uv1, 1, 5, 0U, 1, 0U, 1, 5);
  for (c23_i11 = 0; c23_i11 < 5; c23_i11 = c23_i11 + 1) {
    c23_b_y[c23_i11] = c23_uv1[c23_i11];
  }

  sf_mex_destroy(&c23_y);
}

static uint8_T c23_b_emlrt_marshallIn(SFc23_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *
  c23_b_is_active_c23_controlMCUSlugsMKII, const char_T *c23_name)
{
  uint8_T c23_y;
  uint8_T c23_u0;
  sf_mex_import(c23_name, sf_mex_dup(c23_b_is_active_c23_controlMCUSlugsMKII),
                &c23_u0, 1, 3, 0U, 0, 0U, 0);
  c23_y = c23_u0;
  sf_mex_destroy(&c23_b_is_active_c23_controlMCUSlugsMKII);
  return c23_y;
}

static void init_dsm_address_info(SFc23_controlMCUSlugsMKIIInstanceStruct
  *chartInstance)
{
}

/* SFunction Glue Code */
void sf_c23_controlMCUSlugsMKII_get_check_sum(mxArray *plhs[])
{
  ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(1552087731U);
  ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(2852860509U);
  ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(3537648034U);
  ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(2573162406U);
}

mxArray *sf_c23_controlMCUSlugsMKII_get_autoinheritance_info(void)
{
  const char *autoinheritanceFields[] = { "checksum", "inputs", "parameters",
    "outputs" };

  mxArray *mxAutoinheritanceInfo = mxCreateStructMatrix(1,1,4,
    autoinheritanceFields);

  {
    mxArray *mxChecksum = mxCreateDoubleMatrix(4,1,mxREAL);
    double *pr = mxGetPr(mxChecksum);
    pr[0] = (double)(3212203804U);
    pr[1] = (double)(2580251856U);
    pr[2] = (double)(227040928U);
    pr[3] = (double)(1996472616U);
    mxSetField(mxAutoinheritanceInfo,0,"checksum",mxChecksum);
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,2,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(4);
      pr[1] = (double)(1);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(5));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,1,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(5));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,1,"type",mxType);
    }

    mxSetField(mxData,1,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"inputs",mxData);
  }

  {
    mxSetField(mxAutoinheritanceInfo,0,"parameters",mxCreateDoubleMatrix(0,0,
                mxREAL));
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,1,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(5);
      pr[1] = (double)(1);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(5));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"outputs",mxData);
  }

  return(mxAutoinheritanceInfo);
}

static mxArray *sf_get_sim_state_info_c23_controlMCUSlugsMKII(void)
{
  const char *infoFields[] = { "chartChecksum", "varInfo" };

  mxArray *mxInfo = mxCreateStructMatrix(1, 1, 2, infoFields);
  const char *infoEncStr[] = {
    "100 S1x2'type','srcId','name','auxInfo'{{M[1],M[5],T\"y\",},{M[8],M[0],T\"is_active_c23_controlMCUSlugsMKII\",}}"
  };

  mxArray *mxVarInfo = sf_mex_decode_encoded_mx_struct_array(infoEncStr, 2, 10);
  mxArray *mxChecksum = mxCreateDoubleMatrix(1, 4, mxREAL);
  sf_c23_controlMCUSlugsMKII_get_check_sum(&mxChecksum);
  mxSetField(mxInfo, 0, infoFields[0], mxChecksum);
  mxSetField(mxInfo, 0, infoFields[1], mxVarInfo);
  return mxInfo;
}

static void chart_debug_initialization(SimStruct *S, unsigned int
  fullDebuggerInitialization)
{
  if (!sim_mode_is_rtw_gen(S)) {
    SFc23_controlMCUSlugsMKIIInstanceStruct *chartInstance;
    chartInstance = (SFc23_controlMCUSlugsMKIIInstanceStruct *)
      ((ChartInfoStruct *)(ssGetUserData(S)))->chartInstance;
    if (ssIsFirstInitCond(S) && fullDebuggerInitialization==1) {
      /* do this only if simulation is starting */
      {
        unsigned int chartAlreadyPresent;
        chartAlreadyPresent = sf_debug_initialize_chart
          (_controlMCUSlugsMKIIMachineNumber_,
           23,
           1,
           1,
           3,
           0,
           0,
           0,
           0,
           0,
           &(chartInstance->chartNumber),
           &(chartInstance->instanceNumber),
           ssGetPath(S),
           (void *)S);
        if (chartAlreadyPresent==0) {
          /* this is the first instance */
          init_script_number_translation(_controlMCUSlugsMKIIMachineNumber_,
            chartInstance->chartNumber);
          sf_debug_set_chart_disable_implicit_casting
            (_controlMCUSlugsMKIIMachineNumber_,chartInstance->chartNumber,1);
          sf_debug_set_chart_event_thresholds(_controlMCUSlugsMKIIMachineNumber_,
            chartInstance->chartNumber,
            0,
            0,
            0);

          {
            unsigned int dimVector[1];
            dimVector[0]= 4;
            _SFD_SET_DATA_PROPS(0,1,1,0,SF_UINT16,1,&(dimVector[0]),0,0,0,0.0,
                                1.0,0,"u1",0,(MexFcnForType)c23_c_sf_marshall);
          }

          {
            unsigned int dimVector[1];
            dimVector[0]= 5;
            _SFD_SET_DATA_PROPS(1,2,0,1,SF_UINT16,1,&(dimVector[0]),0,0,0,0.0,
                                1.0,0,"y",0,(MexFcnForType)c23_sf_marshall);
          }

          _SFD_SET_DATA_PROPS(2,1,1,0,SF_UINT16,0,NULL,0,0,0,0.0,1.0,0,"u2",0,
                              (MexFcnForType)c23_b_sf_marshall);
          _SFD_STATE_INFO(0,0,2);
          _SFD_CH_SUBSTATE_COUNT(0);
          _SFD_CH_SUBSTATE_DECOMP(0);
        }

        _SFD_CV_INIT_CHART(0,0,0,0);

        {
          _SFD_CV_INIT_STATE(0,0,0,0,0,0,NULL,NULL);
        }

        _SFD_CV_INIT_TRANS(0,0,NULL,NULL,0,NULL);

        /* Initialization of EML Model Coverage */
        _SFD_CV_INIT_EML(0,1,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML_FCN(0,0,"eML_blk_kernel",0,-1,150);
        _SFD_TRANS_COV_WTS(0,0,0,1,0);
        if (chartAlreadyPresent==0) {
          _SFD_TRANS_COV_MAPS(0,
                              0,NULL,NULL,
                              0,NULL,NULL,
                              1,NULL,NULL,
                              0,NULL,NULL);
        }

        {
          uint16_T (*c23_u1)[4];
          uint16_T (*c23_y)[5];
          uint16_T *c23_u2;
          c23_u2 = (uint16_T *)ssGetInputPortSignal(chartInstance->S, 1);
          c23_y = (uint16_T (*)[5])ssGetOutputPortSignal(chartInstance->S, 1);
          c23_u1 = (uint16_T (*)[4])ssGetInputPortSignal(chartInstance->S, 0);
          _SFD_SET_DATA_VALUE_PTR(0U, c23_u1);
          _SFD_SET_DATA_VALUE_PTR(1U, c23_y);
          _SFD_SET_DATA_VALUE_PTR(2U, c23_u2);
        }
      }
    } else {
      sf_debug_reset_current_state_configuration
        (_controlMCUSlugsMKIIMachineNumber_,chartInstance->chartNumber,
         chartInstance->instanceNumber);
    }
  }
}

static void sf_opaque_initialize_c23_controlMCUSlugsMKII(void *chartInstanceVar)
{
  chart_debug_initialization(((SFc23_controlMCUSlugsMKIIInstanceStruct*)
    chartInstanceVar)->S,0);
  initialize_params_c23_controlMCUSlugsMKII
    ((SFc23_controlMCUSlugsMKIIInstanceStruct*) chartInstanceVar);
  initialize_c23_controlMCUSlugsMKII((SFc23_controlMCUSlugsMKIIInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_enable_c23_controlMCUSlugsMKII(void *chartInstanceVar)
{
  enable_c23_controlMCUSlugsMKII((SFc23_controlMCUSlugsMKIIInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_disable_c23_controlMCUSlugsMKII(void *chartInstanceVar)
{
  disable_c23_controlMCUSlugsMKII((SFc23_controlMCUSlugsMKIIInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_gateway_c23_controlMCUSlugsMKII(void *chartInstanceVar)
{
  sf_c23_controlMCUSlugsMKII((SFc23_controlMCUSlugsMKIIInstanceStruct*)
    chartInstanceVar);
}

static mxArray* sf_internal_get_sim_state_c23_controlMCUSlugsMKII(SimStruct* S)
{
  ChartInfoStruct *chartInfo = (ChartInfoStruct*) ssGetUserData(S);
  mxArray *plhs[1] = { NULL };

  mxArray *prhs[4];
  int mxError = 0;
  prhs[0] = mxCreateString("chart_simctx_raw2high");
  prhs[1] = mxCreateDoubleScalar(ssGetSFuncBlockHandle(S));
  prhs[2] = (mxArray*) get_sim_state_c23_controlMCUSlugsMKII
    ((SFc23_controlMCUSlugsMKIIInstanceStruct*)chartInfo->chartInstance);/* raw sim ctx */
  prhs[3] = sf_get_sim_state_info_c23_controlMCUSlugsMKII();/* state var info */
  mxError = sf_mex_call_matlab(1, plhs, 4, prhs, "sfprivate");
  mxDestroyArray(prhs[0]);
  mxDestroyArray(prhs[1]);
  mxDestroyArray(prhs[2]);
  mxDestroyArray(prhs[3]);
  if (mxError || plhs[0] == NULL) {
    sf_mex_error_message("Stateflow Internal Error: \nError calling 'chart_simctx_raw2high'.\n");
  }

  return plhs[0];
}

static void sf_internal_set_sim_state_c23_controlMCUSlugsMKII(SimStruct* S,
  const mxArray *st)
{
  ChartInfoStruct *chartInfo = (ChartInfoStruct*) ssGetUserData(S);
  mxArray *plhs[1] = { NULL };

  mxArray *prhs[4];
  int mxError = 0;
  prhs[0] = mxCreateString("chart_simctx_high2raw");
  prhs[1] = mxCreateDoubleScalar(ssGetSFuncBlockHandle(S));
  prhs[2] = mxDuplicateArray(st);      /* high level simctx */
  prhs[3] = (mxArray*) sf_get_sim_state_info_c23_controlMCUSlugsMKII();/* state var info */
  mxError = sf_mex_call_matlab(1, plhs, 4, prhs, "sfprivate");
  mxDestroyArray(prhs[0]);
  mxDestroyArray(prhs[1]);
  mxDestroyArray(prhs[2]);
  mxDestroyArray(prhs[3]);
  if (mxError || plhs[0] == NULL) {
    sf_mex_error_message("Stateflow Internal Error: \nError calling 'chart_simctx_high2raw'.\n");
  }

  set_sim_state_c23_controlMCUSlugsMKII((SFc23_controlMCUSlugsMKIIInstanceStruct*)
    chartInfo->chartInstance, mxDuplicateArray(plhs[0]));
  mxDestroyArray(plhs[0]);
}

static mxArray* sf_opaque_get_sim_state_c23_controlMCUSlugsMKII(SimStruct* S)
{
  return sf_internal_get_sim_state_c23_controlMCUSlugsMKII(S);
}

static void sf_opaque_set_sim_state_c23_controlMCUSlugsMKII(SimStruct* S, const
  mxArray *st)
{
  sf_internal_set_sim_state_c23_controlMCUSlugsMKII(S, st);
}

static void sf_opaque_terminate_c23_controlMCUSlugsMKII(void *chartInstanceVar)
{
  if (chartInstanceVar!=NULL) {
    SimStruct *S = ((SFc23_controlMCUSlugsMKIIInstanceStruct*) chartInstanceVar
      )->S;
    if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
      sf_clear_rtw_identifier(S);
    }

    finalize_c23_controlMCUSlugsMKII((SFc23_controlMCUSlugsMKIIInstanceStruct*)
      chartInstanceVar);
    free((void *)chartInstanceVar);
    ssSetUserData(S,NULL);
  }
}

extern unsigned int sf_machine_global_initializer_called(void);
static void mdlProcessParameters_c23_controlMCUSlugsMKII(SimStruct *S)
{
  int i;
  for (i=0;i<ssGetNumRunTimeParams(S);i++) {
    if (ssGetSFcnParamTunable(S,i)) {
      ssUpdateDlgParamAsRunTimeParam(S,i);
    }
  }

  if (sf_machine_global_initializer_called()) {
    initialize_params_c23_controlMCUSlugsMKII
      ((SFc23_controlMCUSlugsMKIIInstanceStruct*)(((ChartInfoStruct *)
         ssGetUserData(S))->chartInstance));
  }
}

static void mdlSetWorkWidths_c23_controlMCUSlugsMKII(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
    int_T chartIsInlinable =
      (int_T)sf_is_chart_inlinable("controlMCUSlugsMKII","controlMCUSlugsMKII",
      23);
    ssSetStateflowIsInlinable(S,chartIsInlinable);
    ssSetRTWCG(S,sf_rtw_info_uint_prop("controlMCUSlugsMKII",
                "controlMCUSlugsMKII",23,"RTWCG"));
    ssSetEnableFcnIsTrivial(S,1);
    ssSetDisableFcnIsTrivial(S,1);
    ssSetNotMultipleInlinable(S,sf_rtw_info_uint_prop("controlMCUSlugsMKII",
      "controlMCUSlugsMKII",23,"gatewayCannotBeInlinedMultipleTimes"));
    if (chartIsInlinable) {
      ssSetInputPortOptimOpts(S, 0, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 1, SS_REUSABLE_AND_LOCAL);
      sf_mark_chart_expressionable_inputs(S,"controlMCUSlugsMKII",
        "controlMCUSlugsMKII",23,2);
      sf_mark_chart_reusable_outputs(S,"controlMCUSlugsMKII",
        "controlMCUSlugsMKII",23,1);
    }

    sf_set_rtw_dwork_info(S,"controlMCUSlugsMKII","controlMCUSlugsMKII",23);
    ssSetHasSubFunctions(S,!(chartIsInlinable));
    ssSetOptions(S,ssGetOptions(S)|SS_OPTION_WORKS_WITH_CODE_REUSE);
  }

  ssSetChecksum0(S,(2931860148U));
  ssSetChecksum1(S,(1510260454U));
  ssSetChecksum2(S,(56017478U));
  ssSetChecksum3(S,(1814569240U));
  ssSetmdlDerivatives(S, NULL);
  ssSetExplicitFCSSCtrl(S,1);
}

static void mdlRTW_c23_controlMCUSlugsMKII(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S)) {
    sf_write_symbol_mapping(S, "controlMCUSlugsMKII", "controlMCUSlugsMKII",23);
    ssWriteRTWStrParam(S, "StateflowChartType", "Embedded MATLAB");
  }
}

static void mdlStart_c23_controlMCUSlugsMKII(SimStruct *S)
{
  SFc23_controlMCUSlugsMKIIInstanceStruct *chartInstance;
  chartInstance = (SFc23_controlMCUSlugsMKIIInstanceStruct *)malloc(sizeof
    (SFc23_controlMCUSlugsMKIIInstanceStruct));
  memset(chartInstance, 0, sizeof(SFc23_controlMCUSlugsMKIIInstanceStruct));
  if (chartInstance==NULL) {
    sf_mex_error_message("Could not allocate memory for chart instance.");
  }

  chartInstance->chartInfo.chartInstance = chartInstance;
  chartInstance->chartInfo.isEMLChart = 1;
  chartInstance->chartInfo.chartInitialized = 0;
  chartInstance->chartInfo.sFunctionGateway =
    sf_opaque_gateway_c23_controlMCUSlugsMKII;
  chartInstance->chartInfo.initializeChart =
    sf_opaque_initialize_c23_controlMCUSlugsMKII;
  chartInstance->chartInfo.terminateChart =
    sf_opaque_terminate_c23_controlMCUSlugsMKII;
  chartInstance->chartInfo.enableChart =
    sf_opaque_enable_c23_controlMCUSlugsMKII;
  chartInstance->chartInfo.disableChart =
    sf_opaque_disable_c23_controlMCUSlugsMKII;
  chartInstance->chartInfo.getSimState =
    sf_opaque_get_sim_state_c23_controlMCUSlugsMKII;
  chartInstance->chartInfo.setSimState =
    sf_opaque_set_sim_state_c23_controlMCUSlugsMKII;
  chartInstance->chartInfo.getSimStateInfo =
    sf_get_sim_state_info_c23_controlMCUSlugsMKII;
  chartInstance->chartInfo.zeroCrossings = NULL;
  chartInstance->chartInfo.outputs = NULL;
  chartInstance->chartInfo.derivatives = NULL;
  chartInstance->chartInfo.mdlRTW = mdlRTW_c23_controlMCUSlugsMKII;
  chartInstance->chartInfo.mdlStart = mdlStart_c23_controlMCUSlugsMKII;
  chartInstance->chartInfo.mdlSetWorkWidths =
    mdlSetWorkWidths_c23_controlMCUSlugsMKII;
  chartInstance->chartInfo.extModeExec = NULL;
  chartInstance->chartInfo.restoreLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.restoreBeforeLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.storeCurrentConfiguration = NULL;
  chartInstance->S = S;
  ssSetUserData(S,(void *)(&(chartInstance->chartInfo)));/* register the chart instance with simstruct */
  if (!sim_mode_is_rtw_gen(S)) {
    init_dsm_address_info(chartInstance);
  }

  chart_debug_initialization(S,1);
}

void c23_controlMCUSlugsMKII_method_dispatcher(SimStruct *S, int_T method, void *
  data)
{
  switch (method) {
   case SS_CALL_MDL_START:
    mdlStart_c23_controlMCUSlugsMKII(S);
    break;

   case SS_CALL_MDL_SET_WORK_WIDTHS:
    mdlSetWorkWidths_c23_controlMCUSlugsMKII(S);
    break;

   case SS_CALL_MDL_PROCESS_PARAMETERS:
    mdlProcessParameters_c23_controlMCUSlugsMKII(S);
    break;

   default:
    /* Unhandled method */
    sf_mex_error_message("Stateflow Internal Error:\n"
                         "Error calling c23_controlMCUSlugsMKII_method_dispatcher.\n"
                         "Can't handle method %d.\n", method);
    break;
  }
}
