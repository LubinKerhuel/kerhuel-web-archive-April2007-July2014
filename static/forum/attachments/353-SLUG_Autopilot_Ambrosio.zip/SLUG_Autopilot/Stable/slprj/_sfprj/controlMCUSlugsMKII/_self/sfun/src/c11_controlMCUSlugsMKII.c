/* Include files */

#include "blascompat32.h"
#include "controlMCUSlugsMKII_sfun.h"
#include "c11_controlMCUSlugsMKII.h"

/* Type Definitions */

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */

/* Function Declarations */
static void initialize_c11_controlMCUSlugsMKII
  (SFc11_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void initialize_params_c11_controlMCUSlugsMKII
  (SFc11_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void enable_c11_controlMCUSlugsMKII
  (SFc11_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void disable_c11_controlMCUSlugsMKII
  (SFc11_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static const mxArray *get_sim_state_c11_controlMCUSlugsMKII
  (SFc11_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void set_sim_state_c11_controlMCUSlugsMKII
  (SFc11_controlMCUSlugsMKIIInstanceStruct *chartInstance, const mxArray *c11_st);
static void finalize_c11_controlMCUSlugsMKII
  (SFc11_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void sf_c11_controlMCUSlugsMKII(SFc11_controlMCUSlugsMKIIInstanceStruct
  *chartInstance);
static void init_script_number_translation(uint32_T c11_machineNumber, uint32_T
  c11_chartNumber);
static real_T c11_emlrt_marshallIn(SFc11_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c11_swIncrement, const char_T *c11_name);
static uint16_T c11_b_emlrt_marshallIn(SFc11_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c11_b_internalTimer, const char_T *c11_name);
static uint8_T c11_c_emlrt_marshallIn(SFc11_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c11_b_oldSw, const char_T *c11_name);
static uint8_T c11_d_emlrt_marshallIn(SFc11_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c11_b_is_active_c11_controlMCUSlugsMKII, const
  char_T *c11_name);
static void init_dsm_address_info(SFc11_controlMCUSlugsMKIIInstanceStruct
  *chartInstance);

/* Function Definitions */
static void initialize_c11_controlMCUSlugsMKII
  (SFc11_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
  chartInstance->c11_oldSw_not_empty = FALSE;
  chartInstance->c11_internalTimer_not_empty = FALSE;
  chartInstance->c11_is_active_c11_controlMCUSlugsMKII = 0U;
  chartInstance->c11_oldSw = 0U;
  chartInstance->c11_internalTimer = 0U;
}

static void initialize_params_c11_controlMCUSlugsMKII
  (SFc11_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
}

static void enable_c11_controlMCUSlugsMKII
  (SFc11_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
}

static void disable_c11_controlMCUSlugsMKII
  (SFc11_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
}

static const mxArray *get_sim_state_c11_controlMCUSlugsMKII
  (SFc11_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
  const mxArray *c11_st;
  const mxArray *c11_y = NULL;
  real_T c11_u;
  const mxArray *c11_b_y = NULL;
  uint16_T c11_b_u;
  const mxArray *c11_c_y = NULL;
  uint8_T c11_c_u;
  const mxArray *c11_d_y = NULL;
  uint8_T c11_d_u;
  const mxArray *c11_e_y = NULL;
  real_T *c11_swIncrement;
  c11_swIncrement = (real_T *)ssGetOutputPortSignal(chartInstance->S, 1);
  c11_st = NULL;
  c11_st = NULL;
  c11_y = NULL;
  sf_mex_assign(&c11_y, sf_mex_createcellarray(4));
  c11_u = *c11_swIncrement;
  c11_b_y = NULL;
  sf_mex_assign(&c11_b_y, sf_mex_create("y", &c11_u, 0, 0U, 0U, 0U, 0));
  sf_mex_setcell(c11_y, 0, c11_b_y);
  c11_b_u = chartInstance->c11_internalTimer;
  c11_c_y = NULL;
  if (!chartInstance->c11_internalTimer_not_empty) {
    sf_mex_assign(&c11_c_y, sf_mex_create("y", NULL, 0, 0U, 1U, 0U, 2, 0, 0));
  } else {
    sf_mex_assign(&c11_c_y, sf_mex_create("y", &c11_b_u, 5, 0U, 0U, 0U, 0));
  }

  sf_mex_setcell(c11_y, 1, c11_c_y);
  c11_c_u = chartInstance->c11_oldSw;
  c11_d_y = NULL;
  if (!chartInstance->c11_oldSw_not_empty) {
    sf_mex_assign(&c11_d_y, sf_mex_create("y", NULL, 0, 0U, 1U, 0U, 2, 0, 0));
  } else {
    sf_mex_assign(&c11_d_y, sf_mex_create("y", &c11_c_u, 3, 0U, 0U, 0U, 0));
  }

  sf_mex_setcell(c11_y, 2, c11_d_y);
  c11_d_u = chartInstance->c11_is_active_c11_controlMCUSlugsMKII;
  c11_e_y = NULL;
  sf_mex_assign(&c11_e_y, sf_mex_create("y", &c11_d_u, 3, 0U, 0U, 0U, 0));
  sf_mex_setcell(c11_y, 3, c11_e_y);
  sf_mex_assign(&c11_st, c11_y);
  return c11_st;
}

static void set_sim_state_c11_controlMCUSlugsMKII
  (SFc11_controlMCUSlugsMKIIInstanceStruct *chartInstance, const mxArray *c11_st)
{
  const mxArray *c11_u;
  real_T *c11_swIncrement;
  c11_swIncrement = (real_T *)ssGetOutputPortSignal(chartInstance->S, 1);
  c11_u = sf_mex_dup(c11_st);
  *c11_swIncrement = c11_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getcell(c11_u, 0)), "swIncrement");
  chartInstance->c11_internalTimer = c11_b_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c11_u, 1)), "internalTimer");
  chartInstance->c11_oldSw = c11_c_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getcell(c11_u, 2)), "oldSw");
  chartInstance->c11_is_active_c11_controlMCUSlugsMKII = c11_d_emlrt_marshallIn
    (chartInstance, sf_mex_dup(sf_mex_getcell(c11_u, 3)),
     "is_active_c11_controlMCUSlugsMKII");
  sf_mex_destroy(&c11_u);
  sf_mex_destroy(&c11_st);
}

static void finalize_c11_controlMCUSlugsMKII
  (SFc11_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
}

static void sf_c11_controlMCUSlugsMKII(SFc11_controlMCUSlugsMKIIInstanceStruct
  *chartInstance)
{
  int32_T c11_previousEvent;
  uint32_T c11_u0;
  real_T *c11_swIncrement;
  uint8_T *c11_swDistanceRdy;
  real32_T *c11_timeLimit;
  c11_swIncrement = (real_T *)ssGetOutputPortSignal(chartInstance->S, 1);
  c11_timeLimit = (real32_T *)ssGetInputPortSignal(chartInstance->S, 1);
  c11_swDistanceRdy = (uint8_T *)ssGetInputPortSignal(chartInstance->S, 0);
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
  c11_previousEvent = _sfEvent_;
  _sfEvent_ = CALL_EVENT;

  /*  Declare static variables */
  /* initialize the static variables */
  chartInstance->c11_oldSw_not_empty = TRUE;
  chartInstance->c11_internalTimer_not_empty = TRUE;
  *c11_swIncrement = 0.0;

  /* if we just had a flip */
  if ((*c11_swDistanceRdy == 1) && (chartInstance->c11_oldSw == 0) && ((real32_T)
       chartInstance->c11_internalTimer > *c11_timeLimit)) {
    /*  if enough time has passed that another switch is valid */
    *c11_swIncrement = 1.0;
    chartInstance->c11_internalTimer = 0U;
  }

  c11_u0 = (uint32_T)(chartInstance->c11_internalTimer + 1);
  if (c11_u0 > 65535U) {
    chartInstance->c11_internalTimer = MAX_uint16_T;
  } else {
    chartInstance->c11_internalTimer = (uint16_T)c11_u0;
  }

  chartInstance->c11_oldSw = *c11_swDistanceRdy;
  _sfEvent_ = c11_previousEvent;
}

static void init_script_number_translation(uint32_T c11_machineNumber, uint32_T
  c11_chartNumber)
{
}

const mxArray *sf_c11_controlMCUSlugsMKII_get_eml_resolved_functions_info(void)
{
  const mxArray *c11_nameCaptureInfo;
  c11_ResolvedFunctionInfo c11_info[5];
  c11_ResolvedFunctionInfo (*c11_b_info)[5];
  const mxArray *c11_m0 = NULL;
  int32_T c11_i0;
  c11_ResolvedFunctionInfo *c11_r0;
  c11_nameCaptureInfo = NULL;
  c11_nameCaptureInfo = NULL;
  c11_b_info = (c11_ResolvedFunctionInfo (*)[5])c11_info;
  (*c11_b_info)[0].context = "";
  (*c11_b_info)[0].name = "uint8";
  (*c11_b_info)[0].dominantType = "double";
  (*c11_b_info)[0].resolved = "[B]uint8";
  (*c11_b_info)[0].fileLength = 0U;
  (*c11_b_info)[0].fileTime1 = 0U;
  (*c11_b_info)[0].fileTime2 = 0U;
  (*c11_b_info)[1].context = "";
  (*c11_b_info)[1].name = "uint16";
  (*c11_b_info)[1].dominantType = "double";
  (*c11_b_info)[1].resolved = "[B]uint16";
  (*c11_b_info)[1].fileLength = 0U;
  (*c11_b_info)[1].fileTime1 = 0U;
  (*c11_b_info)[1].fileTime2 = 0U;
  (*c11_b_info)[2].context = "";
  (*c11_b_info)[2].name = "eq";
  (*c11_b_info)[2].dominantType = "uint8";
  (*c11_b_info)[2].resolved = "[B]eq";
  (*c11_b_info)[2].fileLength = 0U;
  (*c11_b_info)[2].fileTime1 = 0U;
  (*c11_b_info)[2].fileTime2 = 0U;
  (*c11_b_info)[3].context = "";
  (*c11_b_info)[3].name = "gt";
  (*c11_b_info)[3].dominantType = "uint16";
  (*c11_b_info)[3].resolved = "[B]gt";
  (*c11_b_info)[3].fileLength = 0U;
  (*c11_b_info)[3].fileTime1 = 0U;
  (*c11_b_info)[3].fileTime2 = 0U;
  (*c11_b_info)[4].context = "";
  (*c11_b_info)[4].name = "plus";
  (*c11_b_info)[4].dominantType = "uint16";
  (*c11_b_info)[4].resolved = "[B]plus";
  (*c11_b_info)[4].fileLength = 0U;
  (*c11_b_info)[4].fileTime1 = 0U;
  (*c11_b_info)[4].fileTime2 = 0U;
  sf_mex_assign(&c11_m0, sf_mex_createstruct("nameCaptureInfo", 1, 5));
  for (c11_i0 = 0; c11_i0 < 5; c11_i0 = c11_i0 + 1) {
    c11_r0 = &c11_info[c11_i0];
    sf_mex_addfield(c11_m0, sf_mex_create("nameCaptureInfo", (const char *)
      c11_r0->context, 15, 0U, 0U, 0U, 2, 1, strlen((const char *)
      c11_r0->context)), "context", "nameCaptureInfo", c11_i0);
    sf_mex_addfield(c11_m0, sf_mex_create("nameCaptureInfo", (const char *)
      c11_r0->name, 15, 0U, 0U, 0U, 2, 1, strlen((const char *)
      c11_r0->name)), "name", "nameCaptureInfo", c11_i0);
    sf_mex_addfield(c11_m0, sf_mex_create("nameCaptureInfo", (const char *)
      c11_r0->dominantType, 15, 0U, 0U, 0U, 2, 1, strlen((const
      char *)c11_r0->dominantType)), "dominantType", "nameCaptureInfo", c11_i0);
    sf_mex_addfield(c11_m0, sf_mex_create("nameCaptureInfo", (const char *)
      c11_r0->resolved, 15, 0U, 0U, 0U, 2, 1, strlen((const char *)
      c11_r0->resolved)), "resolved", "nameCaptureInfo", c11_i0);
    sf_mex_addfield(c11_m0, sf_mex_create("nameCaptureInfo", &c11_r0->fileLength,
      7, 0U, 0U, 0U, 0), "fileLength", "nameCaptureInfo",
                    c11_i0);
    sf_mex_addfield(c11_m0, sf_mex_create("nameCaptureInfo", &c11_r0->fileTime1,
      7, 0U, 0U, 0U, 0), "fileTime1", "nameCaptureInfo",
                    c11_i0);
    sf_mex_addfield(c11_m0, sf_mex_create("nameCaptureInfo", &c11_r0->fileTime2,
      7, 0U, 0U, 0U, 0), "fileTime2", "nameCaptureInfo",
                    c11_i0);
  }

  sf_mex_assign(&c11_nameCaptureInfo, c11_m0);
  return c11_nameCaptureInfo;
}

static real_T c11_emlrt_marshallIn(SFc11_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c11_swIncrement, const
  char_T *c11_name)
{
  real_T c11_y;
  real_T c11_d0;
  sf_mex_import(c11_name, sf_mex_dup(c11_swIncrement), &c11_d0, 1, 0, 0U, 0, 0U,
                0);
  c11_y = c11_d0;
  sf_mex_destroy(&c11_swIncrement);
  return c11_y;
}

static uint16_T c11_b_emlrt_marshallIn(SFc11_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c11_b_internalTimer,
  const char_T *c11_name)
{
  uint16_T c11_y;
  uint16_T c11_u1;
  if (mxIsEmpty(c11_b_internalTimer)) {
    chartInstance->c11_internalTimer_not_empty = FALSE;
  } else {
    chartInstance->c11_internalTimer_not_empty = TRUE;
    sf_mex_import(c11_name, sf_mex_dup(c11_b_internalTimer), &c11_u1, 1, 5, 0U,
                  0, 0U, 0);
    c11_y = c11_u1;
  }

  sf_mex_destroy(&c11_b_internalTimer);
  return c11_y;
}

static uint8_T c11_c_emlrt_marshallIn(SFc11_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c11_b_oldSw, const
  char_T *c11_name)
{
  uint8_T c11_y;
  uint8_T c11_u2;
  if (mxIsEmpty(c11_b_oldSw)) {
    chartInstance->c11_oldSw_not_empty = FALSE;
  } else {
    chartInstance->c11_oldSw_not_empty = TRUE;
    sf_mex_import(c11_name, sf_mex_dup(c11_b_oldSw), &c11_u2, 1, 3, 0U, 0, 0U, 0);
    c11_y = c11_u2;
  }

  sf_mex_destroy(&c11_b_oldSw);
  return c11_y;
}

static uint8_T c11_d_emlrt_marshallIn(SFc11_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *
  c11_b_is_active_c11_controlMCUSlugsMKII, const char_T *c11_name)
{
  uint8_T c11_y;
  uint8_T c11_u3;
  sf_mex_import(c11_name, sf_mex_dup(c11_b_is_active_c11_controlMCUSlugsMKII),
                &c11_u3, 1, 3, 0U, 0, 0U, 0);
  c11_y = c11_u3;
  sf_mex_destroy(&c11_b_is_active_c11_controlMCUSlugsMKII);
  return c11_y;
}

static void init_dsm_address_info(SFc11_controlMCUSlugsMKIIInstanceStruct
  *chartInstance)
{
}

/* SFunction Glue Code */
void sf_c11_controlMCUSlugsMKII_get_check_sum(mxArray *plhs[])
{
  ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(210014453U);
  ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(3567579742U);
  ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(3537402597U);
  ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(2157839127U);
}

mxArray *sf_c11_controlMCUSlugsMKII_get_autoinheritance_info(void)
{
  const char *autoinheritanceFields[] = { "checksum", "inputs", "parameters",
    "outputs" };

  mxArray *mxAutoinheritanceInfo = mxCreateStructMatrix(1,1,4,
    autoinheritanceFields);

  {
    mxArray *mxChecksum = mxCreateDoubleMatrix(4,1,mxREAL);
    double *pr = mxGetPr(mxChecksum);
    pr[0] = (double)(2059883759U);
    pr[1] = (double)(1238810908U);
    pr[2] = (double)(490543319U);
    pr[3] = (double)(1903927412U);
    mxSetField(mxAutoinheritanceInfo,0,"checksum",mxChecksum);
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,2,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(3));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,1,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(9));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,1,"type",mxType);
    }

    mxSetField(mxData,1,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"inputs",mxData);
  }

  {
    mxSetField(mxAutoinheritanceInfo,0,"parameters",mxCreateDoubleMatrix(0,0,
                mxREAL));
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,1,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"outputs",mxData);
  }

  return(mxAutoinheritanceInfo);
}

static mxArray *sf_get_sim_state_info_c11_controlMCUSlugsMKII(void)
{
  const char *infoFields[] = { "chartChecksum", "varInfo" };

  mxArray *mxInfo = mxCreateStructMatrix(1, 1, 2, infoFields);
  const char *infoEncStr[] = {
    "100 S1x4'type','srcId','name','auxInfo'{{M[1],M[6],T\"swIncrement\",},{M[4],M[0],T\"internalTimer\",S'l','i','p'{{M1x2[121 134],M[0],}}},{M[4],M[0],T\"oldSw\",S'l','i','p'{{M1x2[103 108],M[0],}}},{M[8],M[0],T\"is_active_c11_controlMCUSlugsMKII\",}}"
  };

  mxArray *mxVarInfo = sf_mex_decode_encoded_mx_struct_array(infoEncStr, 4, 10);
  mxArray *mxChecksum = mxCreateDoubleMatrix(1, 4, mxREAL);
  sf_c11_controlMCUSlugsMKII_get_check_sum(&mxChecksum);
  mxSetField(mxInfo, 0, infoFields[0], mxChecksum);
  mxSetField(mxInfo, 0, infoFields[1], mxVarInfo);
  return mxInfo;
}

static void sf_opaque_initialize_c11_controlMCUSlugsMKII(void *chartInstanceVar)
{
  initialize_params_c11_controlMCUSlugsMKII
    ((SFc11_controlMCUSlugsMKIIInstanceStruct*) chartInstanceVar);
  initialize_c11_controlMCUSlugsMKII((SFc11_controlMCUSlugsMKIIInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_enable_c11_controlMCUSlugsMKII(void *chartInstanceVar)
{
  enable_c11_controlMCUSlugsMKII((SFc11_controlMCUSlugsMKIIInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_disable_c11_controlMCUSlugsMKII(void *chartInstanceVar)
{
  disable_c11_controlMCUSlugsMKII((SFc11_controlMCUSlugsMKIIInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_gateway_c11_controlMCUSlugsMKII(void *chartInstanceVar)
{
  sf_c11_controlMCUSlugsMKII((SFc11_controlMCUSlugsMKIIInstanceStruct*)
    chartInstanceVar);
}

static mxArray* sf_internal_get_sim_state_c11_controlMCUSlugsMKII(SimStruct* S)
{
  ChartInfoStruct *chartInfo = (ChartInfoStruct*) ssGetUserData(S);
  mxArray *plhs[1] = { NULL };

  mxArray *prhs[4];
  int mxError = 0;
  prhs[0] = mxCreateString("chart_simctx_raw2high");
  prhs[1] = mxCreateDoubleScalar(ssGetSFuncBlockHandle(S));
  prhs[2] = (mxArray*) get_sim_state_c11_controlMCUSlugsMKII
    ((SFc11_controlMCUSlugsMKIIInstanceStruct*)chartInfo->chartInstance);/* raw sim ctx */
  prhs[3] = sf_get_sim_state_info_c11_controlMCUSlugsMKII();/* state var info */
  mxError = sf_mex_call_matlab(1, plhs, 4, prhs, "sfprivate");
  mxDestroyArray(prhs[0]);
  mxDestroyArray(prhs[1]);
  mxDestroyArray(prhs[2]);
  mxDestroyArray(prhs[3]);
  if (mxError || plhs[0] == NULL) {
    sf_mex_error_message("Stateflow Internal Error: \nError calling 'chart_simctx_raw2high'.\n");
  }

  return plhs[0];
}

static void sf_internal_set_sim_state_c11_controlMCUSlugsMKII(SimStruct* S,
  const mxArray *st)
{
  ChartInfoStruct *chartInfo = (ChartInfoStruct*) ssGetUserData(S);
  mxArray *plhs[1] = { NULL };

  mxArray *prhs[4];
  int mxError = 0;
  prhs[0] = mxCreateString("chart_simctx_high2raw");
  prhs[1] = mxCreateDoubleScalar(ssGetSFuncBlockHandle(S));
  prhs[2] = mxDuplicateArray(st);      /* high level simctx */
  prhs[3] = (mxArray*) sf_get_sim_state_info_c11_controlMCUSlugsMKII();/* state var info */
  mxError = sf_mex_call_matlab(1, plhs, 4, prhs, "sfprivate");
  mxDestroyArray(prhs[0]);
  mxDestroyArray(prhs[1]);
  mxDestroyArray(prhs[2]);
  mxDestroyArray(prhs[3]);
  if (mxError || plhs[0] == NULL) {
    sf_mex_error_message("Stateflow Internal Error: \nError calling 'chart_simctx_high2raw'.\n");
  }

  set_sim_state_c11_controlMCUSlugsMKII((SFc11_controlMCUSlugsMKIIInstanceStruct*)
    chartInfo->chartInstance, mxDuplicateArray(plhs[0]));
  mxDestroyArray(plhs[0]);
}

static mxArray* sf_opaque_get_sim_state_c11_controlMCUSlugsMKII(SimStruct* S)
{
  return sf_internal_get_sim_state_c11_controlMCUSlugsMKII(S);
}

static void sf_opaque_set_sim_state_c11_controlMCUSlugsMKII(SimStruct* S, const
  mxArray *st)
{
  sf_internal_set_sim_state_c11_controlMCUSlugsMKII(S, st);
}

static void sf_opaque_terminate_c11_controlMCUSlugsMKII(void *chartInstanceVar)
{
  if (chartInstanceVar!=NULL) {
    SimStruct *S = ((SFc11_controlMCUSlugsMKIIInstanceStruct*) chartInstanceVar
      )->S;
    if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
      sf_clear_rtw_identifier(S);
    }

    finalize_c11_controlMCUSlugsMKII((SFc11_controlMCUSlugsMKIIInstanceStruct*)
      chartInstanceVar);
    free((void *)chartInstanceVar);
    ssSetUserData(S,NULL);
  }
}

extern unsigned int sf_machine_global_initializer_called(void);
static void mdlProcessParameters_c11_controlMCUSlugsMKII(SimStruct *S)
{
  int i;
  for (i=0;i<ssGetNumRunTimeParams(S);i++) {
    if (ssGetSFcnParamTunable(S,i)) {
      ssUpdateDlgParamAsRunTimeParam(S,i);
    }
  }

  if (sf_machine_global_initializer_called()) {
    initialize_params_c11_controlMCUSlugsMKII
      ((SFc11_controlMCUSlugsMKIIInstanceStruct*)(((ChartInfoStruct *)
         ssGetUserData(S))->chartInstance));
  }
}

static void mdlSetWorkWidths_c11_controlMCUSlugsMKII(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
    int_T chartIsInlinable =
      (int_T)sf_is_chart_inlinable("controlMCUSlugsMKII","controlMCUSlugsMKII",
      11);
    ssSetStateflowIsInlinable(S,chartIsInlinable);
    ssSetRTWCG(S,sf_rtw_info_uint_prop("controlMCUSlugsMKII",
                "controlMCUSlugsMKII",11,"RTWCG"));
    ssSetEnableFcnIsTrivial(S,1);
    ssSetDisableFcnIsTrivial(S,1);
    ssSetNotMultipleInlinable(S,sf_rtw_info_uint_prop("controlMCUSlugsMKII",
      "controlMCUSlugsMKII",11,"gatewayCannotBeInlinedMultipleTimes"));
    if (chartIsInlinable) {
      ssSetInputPortOptimOpts(S, 0, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 1, SS_REUSABLE_AND_LOCAL);
      sf_mark_chart_expressionable_inputs(S,"controlMCUSlugsMKII",
        "controlMCUSlugsMKII",11,2);
      sf_mark_chart_reusable_outputs(S,"controlMCUSlugsMKII",
        "controlMCUSlugsMKII",11,1);
    }

    sf_set_rtw_dwork_info(S,"controlMCUSlugsMKII","controlMCUSlugsMKII",11);
    ssSetHasSubFunctions(S,!(chartIsInlinable));
    ssSetOptions(S,ssGetOptions(S)|SS_OPTION_WORKS_WITH_CODE_REUSE);
  }

  ssSetChecksum0(S,(4016683350U));
  ssSetChecksum1(S,(3627397037U));
  ssSetChecksum2(S,(624701240U));
  ssSetChecksum3(S,(3246448922U));
  ssSetmdlDerivatives(S, NULL);
  ssSetExplicitFCSSCtrl(S,1);
}

static void mdlRTW_c11_controlMCUSlugsMKII(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S)) {
    sf_write_symbol_mapping(S, "controlMCUSlugsMKII", "controlMCUSlugsMKII",11);
    ssWriteRTWStrParam(S, "StateflowChartType", "Embedded MATLAB");
  }
}

static void mdlStart_c11_controlMCUSlugsMKII(SimStruct *S)
{
  SFc11_controlMCUSlugsMKIIInstanceStruct *chartInstance;
  chartInstance = (SFc11_controlMCUSlugsMKIIInstanceStruct *)malloc(sizeof
    (SFc11_controlMCUSlugsMKIIInstanceStruct));
  memset(chartInstance, 0, sizeof(SFc11_controlMCUSlugsMKIIInstanceStruct));
  if (chartInstance==NULL) {
    sf_mex_error_message("Could not allocate memory for chart instance.");
  }

  chartInstance->chartInfo.chartInstance = chartInstance;
  chartInstance->chartInfo.isEMLChart = 1;
  chartInstance->chartInfo.chartInitialized = 0;
  chartInstance->chartInfo.sFunctionGateway =
    sf_opaque_gateway_c11_controlMCUSlugsMKII;
  chartInstance->chartInfo.initializeChart =
    sf_opaque_initialize_c11_controlMCUSlugsMKII;
  chartInstance->chartInfo.terminateChart =
    sf_opaque_terminate_c11_controlMCUSlugsMKII;
  chartInstance->chartInfo.enableChart =
    sf_opaque_enable_c11_controlMCUSlugsMKII;
  chartInstance->chartInfo.disableChart =
    sf_opaque_disable_c11_controlMCUSlugsMKII;
  chartInstance->chartInfo.getSimState =
    sf_opaque_get_sim_state_c11_controlMCUSlugsMKII;
  chartInstance->chartInfo.setSimState =
    sf_opaque_set_sim_state_c11_controlMCUSlugsMKII;
  chartInstance->chartInfo.getSimStateInfo =
    sf_get_sim_state_info_c11_controlMCUSlugsMKII;
  chartInstance->chartInfo.zeroCrossings = NULL;
  chartInstance->chartInfo.outputs = NULL;
  chartInstance->chartInfo.derivatives = NULL;
  chartInstance->chartInfo.mdlRTW = mdlRTW_c11_controlMCUSlugsMKII;
  chartInstance->chartInfo.mdlStart = mdlStart_c11_controlMCUSlugsMKII;
  chartInstance->chartInfo.mdlSetWorkWidths =
    mdlSetWorkWidths_c11_controlMCUSlugsMKII;
  chartInstance->chartInfo.extModeExec = NULL;
  chartInstance->chartInfo.restoreLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.restoreBeforeLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.storeCurrentConfiguration = NULL;
  chartInstance->S = S;
  ssSetUserData(S,(void *)(&(chartInstance->chartInfo)));/* register the chart instance with simstruct */
  if (!sim_mode_is_rtw_gen(S)) {
    init_dsm_address_info(chartInstance);
  }
}

void c11_controlMCUSlugsMKII_method_dispatcher(SimStruct *S, int_T method, void *
  data)
{
  switch (method) {
   case SS_CALL_MDL_START:
    mdlStart_c11_controlMCUSlugsMKII(S);
    break;

   case SS_CALL_MDL_SET_WORK_WIDTHS:
    mdlSetWorkWidths_c11_controlMCUSlugsMKII(S);
    break;

   case SS_CALL_MDL_PROCESS_PARAMETERS:
    mdlProcessParameters_c11_controlMCUSlugsMKII(S);
    break;

   default:
    /* Unhandled method */
    sf_mex_error_message("Stateflow Internal Error:\n"
                         "Error calling c11_controlMCUSlugsMKII_method_dispatcher.\n"
                         "Can't handle method %d.\n", method);
    break;
  }
}
