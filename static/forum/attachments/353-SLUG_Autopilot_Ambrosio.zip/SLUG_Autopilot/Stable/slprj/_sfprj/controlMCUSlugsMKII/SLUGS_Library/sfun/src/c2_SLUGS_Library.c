/* Include files */

#include "blascompat32.h"
#include "SLUGS_Library_sfun.h"
#include "c2_SLUGS_Library.h"
#define CHARTINSTANCE_CHARTNUMBER      (chartInstance->chartNumber)
#define CHARTINSTANCE_INSTANCENUMBER   (chartInstance->instanceNumber)
#include "SLUGS_Library_sfun_debug_macros.h"

/* Type Definitions */

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */
static const char *c2_debug_family_names[4] = { "nargin", "nargout", "T", "N" };

/* Function Declarations */
static void initialize_c2_SLUGS_Library(SFc2_SLUGS_LibraryInstanceStruct
  *chartInstance);
static void initialize_params_c2_SLUGS_Library(SFc2_SLUGS_LibraryInstanceStruct *
  chartInstance);
static void enable_c2_SLUGS_Library(SFc2_SLUGS_LibraryInstanceStruct
  *chartInstance);
static void disable_c2_SLUGS_Library(SFc2_SLUGS_LibraryInstanceStruct
  *chartInstance);
static void c2_update_debugger_state_c2_SLUGS_Library
  (SFc2_SLUGS_LibraryInstanceStruct *chartInstance);
static const mxArray *get_sim_state_c2_SLUGS_Library
  (SFc2_SLUGS_LibraryInstanceStruct *chartInstance);
static void set_sim_state_c2_SLUGS_Library(SFc2_SLUGS_LibraryInstanceStruct
  *chartInstance, const mxArray *c2_st);
static void finalize_c2_SLUGS_Library(SFc2_SLUGS_LibraryInstanceStruct
  *chartInstance);
static void sf_c2_SLUGS_Library(SFc2_SLUGS_LibraryInstanceStruct *chartInstance);
static void init_script_number_translation(uint32_T c2_machineNumber, uint32_T
  c2_chartNumber);
static const mxArray *c2_sf_marshall(void *chartInstanceVoid, void *c2_u);
static const mxArray *c2_b_sf_marshall(void *chartInstanceVoid, void *c2_u);
static const mxArray *c2_c_sf_marshall(void *chartInstanceVoid, void *c2_u);
static void c2_emlrt_marshallIn(SFc2_SLUGS_LibraryInstanceStruct *chartInstance,
  const mxArray *c2_N, const char_T *c2_name, real32_T c2_y[3]);
static uint8_T c2_b_emlrt_marshallIn(SFc2_SLUGS_LibraryInstanceStruct
  *chartInstance, const mxArray *c2_b_is_active_c2_SLUGS_Library, const char_T
  *c2_name);
static void init_dsm_address_info(SFc2_SLUGS_LibraryInstanceStruct
  *chartInstance);

/* Function Definitions */
static void initialize_c2_SLUGS_Library(SFc2_SLUGS_LibraryInstanceStruct
  *chartInstance)
{
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
  chartInstance->c2_is_active_c2_SLUGS_Library = 0U;
}

static void initialize_params_c2_SLUGS_Library(SFc2_SLUGS_LibraryInstanceStruct *
  chartInstance)
{
}

static void enable_c2_SLUGS_Library(SFc2_SLUGS_LibraryInstanceStruct
  *chartInstance)
{
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
}

static void disable_c2_SLUGS_Library(SFc2_SLUGS_LibraryInstanceStruct
  *chartInstance)
{
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
}

static void c2_update_debugger_state_c2_SLUGS_Library
  (SFc2_SLUGS_LibraryInstanceStruct *chartInstance)
{
}

static const mxArray *get_sim_state_c2_SLUGS_Library
  (SFc2_SLUGS_LibraryInstanceStruct *chartInstance)
{
  const mxArray *c2_st = NULL;
  const mxArray *c2_y = NULL;
  int32_T c2_i0;
  real32_T c2_hoistedGlobal[3];
  int32_T c2_i1;
  real32_T c2_u[3];
  const mxArray *c2_b_y = NULL;
  uint8_T c2_b_hoistedGlobal;
  uint8_T c2_b_u;
  const mxArray *c2_c_y = NULL;
  real32_T (*c2_N)[3];
  c2_N = (real32_T (*)[3])ssGetOutputPortSignal(chartInstance->S, 1);
  c2_st = NULL;
  c2_y = NULL;
  sf_mex_assign(&c2_y, sf_mex_createcellarray(2));
  for (c2_i0 = 0; c2_i0 < 3; c2_i0 = c2_i0 + 1) {
    c2_hoistedGlobal[c2_i0] = (*c2_N)[c2_i0];
  }

  for (c2_i1 = 0; c2_i1 < 3; c2_i1 = c2_i1 + 1) {
    c2_u[c2_i1] = c2_hoistedGlobal[c2_i1];
  }

  c2_b_y = NULL;
  sf_mex_assign(&c2_b_y, sf_mex_create("y", &c2_u, 1, 0U, 1U, 0U, 1, 3));
  sf_mex_setcell(c2_y, 0, c2_b_y);
  c2_b_hoistedGlobal = chartInstance->c2_is_active_c2_SLUGS_Library;
  c2_b_u = c2_b_hoistedGlobal;
  c2_c_y = NULL;
  sf_mex_assign(&c2_c_y, sf_mex_create("y", &c2_b_u, 3, 0U, 0U, 0U, 0));
  sf_mex_setcell(c2_y, 1, c2_c_y);
  sf_mex_assign(&c2_st, c2_y);
  return c2_st;
}

static void set_sim_state_c2_SLUGS_Library(SFc2_SLUGS_LibraryInstanceStruct
  *chartInstance, const mxArray *c2_st)
{
  const mxArray *c2_u;
  real32_T c2_fv0[3];
  int32_T c2_i2;
  real32_T (*c2_N)[3];
  c2_N = (real32_T (*)[3])ssGetOutputPortSignal(chartInstance->S, 1);
  chartInstance->c2_doneDoubleBufferReInit = TRUE;
  c2_u = sf_mex_dup(c2_st);
  c2_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(c2_u, 0)), "N",
                      c2_fv0);
  for (c2_i2 = 0; c2_i2 < 3; c2_i2 = c2_i2 + 1) {
    (*c2_N)[c2_i2] = c2_fv0[c2_i2];
  }

  chartInstance->c2_is_active_c2_SLUGS_Library = c2_b_emlrt_marshallIn
    (chartInstance, sf_mex_dup(sf_mex_getcell(c2_u, 1)),
     "is_active_c2_SLUGS_Library");
  sf_mex_destroy(&c2_u);
  c2_update_debugger_state_c2_SLUGS_Library(chartInstance);
  sf_mex_destroy(&c2_st);
}

static void finalize_c2_SLUGS_Library(SFc2_SLUGS_LibraryInstanceStruct
  *chartInstance)
{
}

static void sf_c2_SLUGS_Library(SFc2_SLUGS_LibraryInstanceStruct *chartInstance)
{
  int32_T c2_i3;
  int32_T c2_i4;
  int32_T c2_previousEvent;
  int32_T c2_i5;
  real32_T c2_hoistedGlobal[3];
  int32_T c2_i6;
  real32_T c2_T[3];
  uint32_T c2_debug_family_var_map[4];
  real_T c2_nargin = 1.0;
  real_T c2_nargout = 1.0;
  real32_T c2_N[3];
  int32_T c2_i7;
  real32_T (*c2_b_N)[3];
  real32_T (*c2_b_T)[3];
  c2_b_N = (real32_T (*)[3])ssGetOutputPortSignal(chartInstance->S, 1);
  c2_b_T = (real32_T (*)[3])ssGetInputPortSignal(chartInstance->S, 0);
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
  _SFD_CC_CALL(CHART_ENTER_SFUNCTION_TAG,0);
  for (c2_i3 = 0; c2_i3 < 3; c2_i3 = c2_i3 + 1) {
    _SFD_DATA_RANGE_CHECK((real_T)(*c2_b_T)[c2_i3], 0U);
  }

  for (c2_i4 = 0; c2_i4 < 3; c2_i4 = c2_i4 + 1) {
    _SFD_DATA_RANGE_CHECK((real_T)(*c2_b_N)[c2_i4], 1U);
  }

  c2_previousEvent = _sfEvent_;
  _sfEvent_ = CALL_EVENT;
  _SFD_CC_CALL(CHART_ENTER_DURING_FUNCTION_TAG,0);
  for (c2_i5 = 0; c2_i5 < 3; c2_i5 = c2_i5 + 1) {
    c2_hoistedGlobal[c2_i5] = (*c2_b_T)[c2_i5];
  }

  for (c2_i6 = 0; c2_i6 < 3; c2_i6 = c2_i6 + 1) {
    c2_T[c2_i6] = c2_hoistedGlobal[c2_i6];
  }

  sf_debug_symbol_scope_push_eml(0U, 4U, 4U, c2_debug_family_names,
    c2_debug_family_var_map);
  sf_debug_symbol_scope_add_eml(&c2_nargin, c2_b_sf_marshall, 0U);
  sf_debug_symbol_scope_add_eml(&c2_nargout, c2_b_sf_marshall, 1U);
  sf_debug_symbol_scope_add_eml(&c2_T, c2_sf_marshall, 2U);
  sf_debug_symbol_scope_add_eml(&c2_N, c2_sf_marshall, 3U);
  CV_EML_FCN(0, 0);

  /*  This block supports an embeddable subset of the MATLAB language. */
  /*  See the help menu for details.  */
  _SFD_EML_CALL(0,5);
  c2_N[0] = -c2_T[1];
  c2_N[1] = c2_T[0];
  c2_N[2] = 0.0F;
  _SFD_EML_CALL(0,-5);
  sf_debug_symbol_scope_pop();
  for (c2_i7 = 0; c2_i7 < 3; c2_i7 = c2_i7 + 1) {
    (*c2_b_N)[c2_i7] = c2_N[c2_i7];
  }

  _SFD_CC_CALL(EXIT_OUT_OF_FUNCTION_TAG,0);
  _sfEvent_ = c2_previousEvent;
  sf_debug_check_for_state_inconsistency(_SLUGS_LibraryMachineNumber_,
    chartInstance->chartNumber, chartInstance->instanceNumber);
}

static void init_script_number_translation(uint32_T c2_machineNumber, uint32_T
  c2_chartNumber)
{
}

static const mxArray *c2_sf_marshall(void *chartInstanceVoid, void *c2_u)
{
  const mxArray *c2_y = NULL;
  int32_T c2_i8;
  real32_T c2_b_u[3];
  const mxArray *c2_b_y = NULL;
  SFc2_SLUGS_LibraryInstanceStruct *chartInstance;
  chartInstance = (SFc2_SLUGS_LibraryInstanceStruct *)chartInstanceVoid;
  c2_y = NULL;
  for (c2_i8 = 0; c2_i8 < 3; c2_i8 = c2_i8 + 1) {
    c2_b_u[c2_i8] = (*((real32_T (*)[3])c2_u))[c2_i8];
  }

  c2_b_y = NULL;
  sf_mex_assign(&c2_b_y, sf_mex_create("y", &c2_b_u, 1, 0U, 1U, 0U, 1, 3));
  sf_mex_assign(&c2_y, c2_b_y);
  return c2_y;
}

static const mxArray *c2_b_sf_marshall(void *chartInstanceVoid, void *c2_u)
{
  const mxArray *c2_y = NULL;
  real_T c2_b_u;
  const mxArray *c2_b_y = NULL;
  SFc2_SLUGS_LibraryInstanceStruct *chartInstance;
  chartInstance = (SFc2_SLUGS_LibraryInstanceStruct *)chartInstanceVoid;
  c2_y = NULL;
  c2_b_u = *((real_T *)c2_u);
  c2_b_y = NULL;
  sf_mex_assign(&c2_b_y, sf_mex_create("y", &c2_b_u, 0, 0U, 0U, 0U, 0));
  sf_mex_assign(&c2_y, c2_b_y);
  return c2_y;
}

const mxArray *sf_c2_SLUGS_Library_get_eml_resolved_functions_info(void)
{
  const mxArray *c2_nameCaptureInfo = NULL;
  c2_ResolvedFunctionInfo c2_info[1];
  c2_ResolvedFunctionInfo (*c2_b_info)[1];
  const mxArray *c2_m0 = NULL;
  int32_T c2_i9;
  c2_ResolvedFunctionInfo *c2_r0;
  c2_nameCaptureInfo = NULL;
  c2_b_info = (c2_ResolvedFunctionInfo (*)[1])c2_info;
  (*c2_b_info)[0].context = "";
  (*c2_b_info)[0].name = "uminus";
  (*c2_b_info)[0].dominantType = "single";
  (*c2_b_info)[0].resolved = "[B]uminus";
  (*c2_b_info)[0].fileLength = 0U;
  (*c2_b_info)[0].fileTime1 = 0U;
  (*c2_b_info)[0].fileTime2 = 0U;
  sf_mex_assign(&c2_m0, sf_mex_createstruct("nameCaptureInfo", 1, 1));
  for (c2_i9 = 0; c2_i9 < 1; c2_i9 = c2_i9 + 1) {
    c2_r0 = &c2_info[c2_i9];
    sf_mex_addfield(c2_m0, sf_mex_create("nameCaptureInfo", c2_r0->context, 15,
      0U, 0U, 0U, 2, 1, strlen(c2_r0->context)), "context",
                    "nameCaptureInfo", c2_i9);
    sf_mex_addfield(c2_m0, sf_mex_create("nameCaptureInfo", c2_r0->name, 15, 0U,
      0U, 0U, 2, 1, strlen(c2_r0->name)), "name",
                    "nameCaptureInfo", c2_i9);
    sf_mex_addfield(c2_m0, sf_mex_create("nameCaptureInfo", c2_r0->dominantType,
      15, 0U, 0U, 0U, 2, 1, strlen(c2_r0->dominantType)),
                    "dominantType", "nameCaptureInfo", c2_i9);
    sf_mex_addfield(c2_m0, sf_mex_create("nameCaptureInfo", c2_r0->resolved, 15,
      0U, 0U, 0U, 2, 1, strlen(c2_r0->resolved)), "resolved"
                    , "nameCaptureInfo", c2_i9);
    sf_mex_addfield(c2_m0, sf_mex_create("nameCaptureInfo", &c2_r0->fileLength,
      7, 0U, 0U, 0U, 0), "fileLength", "nameCaptureInfo",
                    c2_i9);
    sf_mex_addfield(c2_m0, sf_mex_create("nameCaptureInfo", &c2_r0->fileTime1, 7,
      0U, 0U, 0U, 0), "fileTime1", "nameCaptureInfo", c2_i9);
    sf_mex_addfield(c2_m0, sf_mex_create("nameCaptureInfo", &c2_r0->fileTime2, 7,
      0U, 0U, 0U, 0), "fileTime2", "nameCaptureInfo", c2_i9);
  }

  sf_mex_assign(&c2_nameCaptureInfo, c2_m0);
  return c2_nameCaptureInfo;
}

static const mxArray *c2_c_sf_marshall(void *chartInstanceVoid, void *c2_u)
{
  const mxArray *c2_y = NULL;
  boolean_T c2_b_u;
  const mxArray *c2_b_y = NULL;
  SFc2_SLUGS_LibraryInstanceStruct *chartInstance;
  chartInstance = (SFc2_SLUGS_LibraryInstanceStruct *)chartInstanceVoid;
  c2_y = NULL;
  c2_b_u = *((boolean_T *)c2_u);
  c2_b_y = NULL;
  sf_mex_assign(&c2_b_y, sf_mex_create("y", &c2_b_u, 11, 0U, 0U, 0U, 0));
  sf_mex_assign(&c2_y, c2_b_y);
  return c2_y;
}

static void c2_emlrt_marshallIn(SFc2_SLUGS_LibraryInstanceStruct *chartInstance,
  const mxArray *c2_N, const char_T *c2_name,
  real32_T c2_y[3])
{
  real32_T c2_fv1[3];
  int32_T c2_i10;
  sf_mex_import(c2_name, sf_mex_dup(c2_N), &c2_fv1, 1, 1, 0U, 1, 0U, 1, 3);
  for (c2_i10 = 0; c2_i10 < 3; c2_i10 = c2_i10 + 1) {
    c2_y[c2_i10] = c2_fv1[c2_i10];
  }

  sf_mex_destroy(&c2_N);
}

static uint8_T c2_b_emlrt_marshallIn(SFc2_SLUGS_LibraryInstanceStruct
  *chartInstance, const mxArray *c2_b_is_active_c2_SLUGS_Library
  , const char_T *c2_name)
{
  uint8_T c2_y;
  uint8_T c2_u0;
  sf_mex_import(c2_name, sf_mex_dup(c2_b_is_active_c2_SLUGS_Library), &c2_u0, 1,
                3, 0U, 0, 0U, 0);
  c2_y = c2_u0;
  sf_mex_destroy(&c2_b_is_active_c2_SLUGS_Library);
  return c2_y;
}

static void init_dsm_address_info(SFc2_SLUGS_LibraryInstanceStruct
  *chartInstance)
{
}

/* SFunction Glue Code */
void sf_c2_SLUGS_Library_get_check_sum(mxArray *plhs[])
{
  ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(366270055U);
  ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(4261831585U);
  ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(3094902540U);
  ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(3202123856U);
}

mxArray *sf_c2_SLUGS_Library_get_autoinheritance_info(void)
{
  const char *autoinheritanceFields[] = { "checksum", "inputs", "parameters",
    "outputs" };

  mxArray *mxAutoinheritanceInfo = mxCreateStructMatrix(1,1,4,
    autoinheritanceFields);

  {
    mxArray *mxChecksum = mxCreateDoubleMatrix(4,1,mxREAL);
    double *pr = mxGetPr(mxChecksum);
    pr[0] = (double)(4084607255U);
    pr[1] = (double)(4092273833U);
    pr[2] = (double)(107690655U);
    pr[3] = (double)(1900100110U);
    mxSetField(mxAutoinheritanceInfo,0,"checksum",mxChecksum);
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,1,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(3);
      pr[1] = (double)(1);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(9));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"inputs",mxData);
  }

  {
    mxSetField(mxAutoinheritanceInfo,0,"parameters",mxCreateDoubleMatrix(0,0,
                mxREAL));
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,1,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(3);
      pr[1] = (double)(1);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(9));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"outputs",mxData);
  }

  return(mxAutoinheritanceInfo);
}

static mxArray *sf_get_sim_state_info_c2_SLUGS_Library(void)
{
  const char *infoFields[] = { "chartChecksum", "varInfo" };

  mxArray *mxInfo = mxCreateStructMatrix(1, 1, 2, infoFields);
  const char *infoEncStr[] = {
    "100 S1x2'type','srcId','name','auxInfo'{{M[1],M[5],T\"N\",},{M[8],M[0],T\"is_active_c2_SLUGS_Library\",}}"
  };

  mxArray *mxVarInfo = sf_mex_decode_encoded_mx_struct_array(infoEncStr, 2, 10);
  mxArray *mxChecksum = mxCreateDoubleMatrix(1, 4, mxREAL);
  sf_c2_SLUGS_Library_get_check_sum(&mxChecksum);
  mxSetField(mxInfo, 0, infoFields[0], mxChecksum);
  mxSetField(mxInfo, 0, infoFields[1], mxVarInfo);
  return mxInfo;
}

static void chart_debug_initialization(SimStruct *S, unsigned int
  fullDebuggerInitialization)
{
  if (!sim_mode_is_rtw_gen(S)) {
    SFc2_SLUGS_LibraryInstanceStruct *chartInstance;
    chartInstance = (SFc2_SLUGS_LibraryInstanceStruct *) ((ChartInfoStruct *)
      (ssGetUserData(S)))->chartInstance;
    if (ssIsFirstInitCond(S) && fullDebuggerInitialization==1) {
      /* do this only if simulation is starting */
      {
        unsigned int chartAlreadyPresent;
        chartAlreadyPresent = sf_debug_initialize_chart
          (_SLUGS_LibraryMachineNumber_,
           2,
           1,
           1,
           2,
           0,
           0,
           0,
           0,
           0,
           &(chartInstance->chartNumber),
           &(chartInstance->instanceNumber),
           ssGetPath(S),
           (void *)S);
        if (chartAlreadyPresent==0) {
          /* this is the first instance */
          init_script_number_translation(_SLUGS_LibraryMachineNumber_,
            chartInstance->chartNumber);
          sf_debug_set_chart_disable_implicit_casting
            (_SLUGS_LibraryMachineNumber_,chartInstance->chartNumber,1);
          sf_debug_set_chart_event_thresholds(_SLUGS_LibraryMachineNumber_,
            chartInstance->chartNumber,
            0,
            0,
            0);

          {
            unsigned int dimVector[1];
            dimVector[0]= 3;
            _SFD_SET_DATA_PROPS(0,1,1,0,SF_SINGLE,1,&(dimVector[0]),0,0,0,0.0,
                                1.0,0,"T",0,(MexFcnForType)c2_sf_marshall);
          }

          {
            unsigned int dimVector[1];
            dimVector[0]= 3;
            _SFD_SET_DATA_PROPS(1,2,0,1,SF_SINGLE,1,&(dimVector[0]),0,0,0,0.0,
                                1.0,0,"N",0,(MexFcnForType)c2_sf_marshall);
          }

          _SFD_STATE_INFO(0,0,2);
          _SFD_CH_SUBSTATE_COUNT(0);
          _SFD_CH_SUBSTATE_DECOMP(0);
        }

        _SFD_CV_INIT_CHART(0,0,0,0);

        {
          _SFD_CV_INIT_STATE(0,0,0,0,0,0,NULL,NULL);
        }

        _SFD_CV_INIT_TRANS(0,0,NULL,NULL,0,NULL);

        /* Initialization of EML Model Coverage */
        _SFD_CV_INIT_EML(0,1,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML_FCN(0,0,"eML_blk_kernel",0,-1,144);
        _SFD_TRANS_COV_WTS(0,0,0,1,0);
        if (chartAlreadyPresent==0) {
          _SFD_TRANS_COV_MAPS(0,
                              0,NULL,NULL,
                              0,NULL,NULL,
                              1,NULL,NULL,
                              0,NULL,NULL);
        }

        {
          real32_T (*c2_T)[3];
          real32_T (*c2_N)[3];
          c2_N = (real32_T (*)[3])ssGetOutputPortSignal(chartInstance->S, 1);
          c2_T = (real32_T (*)[3])ssGetInputPortSignal(chartInstance->S, 0);
          _SFD_SET_DATA_VALUE_PTR(0U, c2_T);
          _SFD_SET_DATA_VALUE_PTR(1U, c2_N);
        }
      }
    } else {
      sf_debug_reset_current_state_configuration(_SLUGS_LibraryMachineNumber_,
        chartInstance->chartNumber,chartInstance->instanceNumber);
    }
  }
}

static void sf_opaque_initialize_c2_SLUGS_Library(void *chartInstanceVar)
{
  chart_debug_initialization(((SFc2_SLUGS_LibraryInstanceStruct*)
    chartInstanceVar)->S,0);
  initialize_params_c2_SLUGS_Library((SFc2_SLUGS_LibraryInstanceStruct*)
    chartInstanceVar);
  initialize_c2_SLUGS_Library((SFc2_SLUGS_LibraryInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_enable_c2_SLUGS_Library(void *chartInstanceVar)
{
  enable_c2_SLUGS_Library((SFc2_SLUGS_LibraryInstanceStruct*) chartInstanceVar);
}

static void sf_opaque_disable_c2_SLUGS_Library(void *chartInstanceVar)
{
  disable_c2_SLUGS_Library((SFc2_SLUGS_LibraryInstanceStruct*) chartInstanceVar);
}

static void sf_opaque_gateway_c2_SLUGS_Library(void *chartInstanceVar)
{
  sf_c2_SLUGS_Library((SFc2_SLUGS_LibraryInstanceStruct*) chartInstanceVar);
}

static mxArray* sf_internal_get_sim_state_c2_SLUGS_Library(SimStruct* S)
{
  ChartInfoStruct *chartInfo = (ChartInfoStruct*) ssGetUserData(S);
  mxArray *plhs[1] = { NULL };

  mxArray *prhs[4];
  int mxError = 0;
  prhs[0] = mxCreateString("chart_simctx_raw2high");
  prhs[1] = mxCreateDoubleScalar(ssGetSFuncBlockHandle(S));
  prhs[2] = (mxArray*) get_sim_state_c2_SLUGS_Library
    ((SFc2_SLUGS_LibraryInstanceStruct*)chartInfo->chartInstance);/* raw sim ctx */
  prhs[3] = sf_get_sim_state_info_c2_SLUGS_Library();/* state var info */
  mxError = sf_mex_call_matlab(1, plhs, 4, prhs, "sfprivate");
  mxDestroyArray(prhs[0]);
  mxDestroyArray(prhs[1]);
  mxDestroyArray(prhs[2]);
  mxDestroyArray(prhs[3]);
  if (mxError || plhs[0] == NULL) {
    sf_mex_error_message("Stateflow Internal Error: \nError calling 'chart_simctx_raw2high'.\n");
  }

  return plhs[0];
}

static void sf_internal_set_sim_state_c2_SLUGS_Library(SimStruct* S, const
  mxArray *st)
{
  ChartInfoStruct *chartInfo = (ChartInfoStruct*) ssGetUserData(S);
  mxArray *plhs[1] = { NULL };

  mxArray *prhs[4];
  int mxError = 0;
  prhs[0] = mxCreateString("chart_simctx_high2raw");
  prhs[1] = mxCreateDoubleScalar(ssGetSFuncBlockHandle(S));
  prhs[2] = mxDuplicateArray(st);      /* high level simctx */
  prhs[3] = (mxArray*) sf_get_sim_state_info_c2_SLUGS_Library();/* state var info */
  mxError = sf_mex_call_matlab(1, plhs, 4, prhs, "sfprivate");
  mxDestroyArray(prhs[0]);
  mxDestroyArray(prhs[1]);
  mxDestroyArray(prhs[2]);
  mxDestroyArray(prhs[3]);
  if (mxError || plhs[0] == NULL) {
    sf_mex_error_message("Stateflow Internal Error: \nError calling 'chart_simctx_high2raw'.\n");
  }

  set_sim_state_c2_SLUGS_Library((SFc2_SLUGS_LibraryInstanceStruct*)
    chartInfo->chartInstance, mxDuplicateArray(plhs[0]));
  mxDestroyArray(plhs[0]);
}

static mxArray* sf_opaque_get_sim_state_c2_SLUGS_Library(SimStruct* S)
{
  return sf_internal_get_sim_state_c2_SLUGS_Library(S);
}

static void sf_opaque_set_sim_state_c2_SLUGS_Library(SimStruct* S, const mxArray
  *st)
{
  sf_internal_set_sim_state_c2_SLUGS_Library(S, st);
}

static void sf_opaque_terminate_c2_SLUGS_Library(void *chartInstanceVar)
{
  if (chartInstanceVar!=NULL) {
    SimStruct *S = ((SFc2_SLUGS_LibraryInstanceStruct*) chartInstanceVar)->S;
    if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
      sf_clear_rtw_identifier(S);
    }

    finalize_c2_SLUGS_Library((SFc2_SLUGS_LibraryInstanceStruct*)
      chartInstanceVar);
    free((void *)chartInstanceVar);
    ssSetUserData(S,NULL);
  }
}

extern unsigned int sf_machine_global_initializer_called(void);
static void mdlProcessParameters_c2_SLUGS_Library(SimStruct *S)
{
  int i;
  for (i=0;i<ssGetNumRunTimeParams(S);i++) {
    if (ssGetSFcnParamTunable(S,i)) {
      ssUpdateDlgParamAsRunTimeParam(S,i);
    }
  }

  if (sf_machine_global_initializer_called()) {
    initialize_params_c2_SLUGS_Library((SFc2_SLUGS_LibraryInstanceStruct*)
      (((ChartInfoStruct *)ssGetUserData(S))->chartInstance));
  }
}

static void mdlSetWorkWidths_c2_SLUGS_Library(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
    int_T chartIsInlinable =
      (int_T)sf_is_chart_inlinable("SLUGS_Library","controlMCUSlugsMKII",2);
    ssSetStateflowIsInlinable(S,chartIsInlinable);
    ssSetRTWCG(S,sf_rtw_info_uint_prop("SLUGS_Library","controlMCUSlugsMKII",2,
                "RTWCG"));
    ssSetEnableFcnIsTrivial(S,1);
    ssSetDisableFcnIsTrivial(S,1);
    ssSetNotMultipleInlinable(S,sf_rtw_info_uint_prop("SLUGS_Library",
      "controlMCUSlugsMKII",2,"gatewayCannotBeInlinedMultipleTimes"));
    if (chartIsInlinable) {
      ssSetInputPortOptimOpts(S, 0, SS_REUSABLE_AND_LOCAL);
      sf_mark_chart_expressionable_inputs(S,"SLUGS_Library",
        "controlMCUSlugsMKII",2,1);
      sf_mark_chart_reusable_outputs(S,"SLUGS_Library","controlMCUSlugsMKII",2,1);
    }

    sf_set_rtw_dwork_info(S,"SLUGS_Library","controlMCUSlugsMKII",2);
    ssSetHasSubFunctions(S,!(chartIsInlinable));
    ssSetOptions(S,ssGetOptions(S)|SS_OPTION_WORKS_WITH_CODE_REUSE);
  }

  ssSetChecksum0(S,(2491556982U));
  ssSetChecksum1(S,(2037111286U));
  ssSetChecksum2(S,(3698685482U));
  ssSetChecksum3(S,(1543998237U));
  ssSetmdlDerivatives(S, NULL);
  ssSetExplicitFCSSCtrl(S,1);
}

static void mdlRTW_c2_SLUGS_Library(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S)) {
    sf_write_symbol_mapping(S, "SLUGS_Library", "controlMCUSlugsMKII",2);
    ssWriteRTWStrParam(S, "StateflowChartType", "Embedded MATLAB");
  }
}

static void mdlStart_c2_SLUGS_Library(SimStruct *S)
{
  SFc2_SLUGS_LibraryInstanceStruct *chartInstance;
  chartInstance = (SFc2_SLUGS_LibraryInstanceStruct *)malloc(sizeof
    (SFc2_SLUGS_LibraryInstanceStruct));
  memset(chartInstance, 0, sizeof(SFc2_SLUGS_LibraryInstanceStruct));
  if (chartInstance==NULL) {
    sf_mex_error_message("Could not allocate memory for chart instance.");
  }

  chartInstance->chartInfo.chartInstance = chartInstance;
  chartInstance->chartInfo.isEMLChart = 1;
  chartInstance->chartInfo.chartInitialized = 0;
  chartInstance->chartInfo.sFunctionGateway = sf_opaque_gateway_c2_SLUGS_Library;
  chartInstance->chartInfo.initializeChart =
    sf_opaque_initialize_c2_SLUGS_Library;
  chartInstance->chartInfo.terminateChart = sf_opaque_terminate_c2_SLUGS_Library;
  chartInstance->chartInfo.enableChart = sf_opaque_enable_c2_SLUGS_Library;
  chartInstance->chartInfo.disableChart = sf_opaque_disable_c2_SLUGS_Library;
  chartInstance->chartInfo.getSimState =
    sf_opaque_get_sim_state_c2_SLUGS_Library;
  chartInstance->chartInfo.setSimState =
    sf_opaque_set_sim_state_c2_SLUGS_Library;
  chartInstance->chartInfo.getSimStateInfo =
    sf_get_sim_state_info_c2_SLUGS_Library;
  chartInstance->chartInfo.zeroCrossings = NULL;
  chartInstance->chartInfo.outputs = NULL;
  chartInstance->chartInfo.derivatives = NULL;
  chartInstance->chartInfo.mdlRTW = mdlRTW_c2_SLUGS_Library;
  chartInstance->chartInfo.mdlStart = mdlStart_c2_SLUGS_Library;
  chartInstance->chartInfo.mdlSetWorkWidths = mdlSetWorkWidths_c2_SLUGS_Library;
  chartInstance->chartInfo.extModeExec = NULL;
  chartInstance->chartInfo.restoreLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.restoreBeforeLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.storeCurrentConfiguration = NULL;
  chartInstance->S = S;
  ssSetUserData(S,(void *)(&(chartInstance->chartInfo)));/* register the chart instance with simstruct */
  if (!sim_mode_is_rtw_gen(S)) {
    init_dsm_address_info(chartInstance);
  }

  chart_debug_initialization(S,1);
}

void c2_SLUGS_Library_method_dispatcher(SimStruct *S, int_T method, void *data)
{
  switch (method) {
   case SS_CALL_MDL_START:
    mdlStart_c2_SLUGS_Library(S);
    break;

   case SS_CALL_MDL_SET_WORK_WIDTHS:
    mdlSetWorkWidths_c2_SLUGS_Library(S);
    break;

   case SS_CALL_MDL_PROCESS_PARAMETERS:
    mdlProcessParameters_c2_SLUGS_Library(S);
    break;

   default:
    /* Unhandled method */
    sf_mex_error_message("Stateflow Internal Error:\n"
                         "Error calling c2_SLUGS_Library_method_dispatcher.\n"
                         "Can't handle method %d.\n", method);
    break;
  }
}
