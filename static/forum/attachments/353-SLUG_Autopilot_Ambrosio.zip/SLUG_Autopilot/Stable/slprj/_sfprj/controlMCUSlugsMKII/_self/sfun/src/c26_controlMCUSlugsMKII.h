#ifndef __c26_controlMCUSlugsMKII_h__
#define __c26_controlMCUSlugsMKII_h__

/* Include files */
#include "sfc_sf.h"
#include "sfc_mex.h"
#include "rtwtypes.h"

/* Type Definitions */
typedef struct {
  const char *context;
  const char *name;
  const char *dominantType;
  const char *resolved;
  uint32_T fileLength;
  uint32_T fileTime1;
  uint32_T fileTime2;
} c26_ResolvedFunctionInfo;

typedef struct {
  SimStruct *S;
  uint32_T chartNumber;
  uint32_T instanceNumber;
  uint16_T c26_oldValues[7];
  boolean_T c26_doneDoubleBufferReInit;
  boolean_T c26_isStable;
  boolean_T c26_oldValues_not_empty;
  uint8_T c26_is_active_c26_controlMCUSlugsMKII;
  ChartInfoStruct chartInfo;
} SFc26_controlMCUSlugsMKIIInstanceStruct;

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */

/* Function Declarations */
extern const mxArray *sf_c26_controlMCUSlugsMKII_get_eml_resolved_functions_info
  (void);

/* Function Definitions */
extern void sf_c26_controlMCUSlugsMKII_get_check_sum(mxArray *plhs[]);
extern void c26_controlMCUSlugsMKII_method_dispatcher(SimStruct *S, int_T method,
  void *data);

#endif
