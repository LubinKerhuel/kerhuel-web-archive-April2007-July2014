#ifndef __c34_controlMCUSlugsMKII_h__
#define __c34_controlMCUSlugsMKII_h__

/* Include files */
#include "sfc_sf.h"
#include "sfc_mex.h"
#include "rtwtypes.h"

/* Type Definitions */
typedef struct {
  SimStruct *S;
  uint8_T c34_is_active_c34_controlMCUSlugsMKII;
  ChartInfoStruct chartInfo;
} SFc34_controlMCUSlugsMKIIInstanceStruct;

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */

/* Function Declarations */
extern const mxArray *sf_c34_controlMCUSlugsMKII_get_eml_resolved_functions_info
  (void);

/* Function Definitions */
extern void sf_c34_controlMCUSlugsMKII_get_check_sum(mxArray *plhs[]);
extern void c34_controlMCUSlugsMKII_method_dispatcher(SimStruct *S, int_T method,
  void *data);

#endif
