#ifndef __c29_controlMCUSlugsMKII_h__
#define __c29_controlMCUSlugsMKII_h__

/* Include files */
#include "sfc_sf.h"
#include "sfc_mex.h"
#include "rtwtypes.h"

/* Type Definitions */
typedef struct {
  SimStruct *S;
  uint8_T c29_is_active_c29_controlMCUSlugsMKII;
  ChartInfoStruct chartInfo;
} SFc29_controlMCUSlugsMKIIInstanceStruct;

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */

/* Function Declarations */
extern const mxArray *sf_c29_controlMCUSlugsMKII_get_eml_resolved_functions_info
  (void);

/* Function Definitions */
extern void sf_c29_controlMCUSlugsMKII_get_check_sum(mxArray *plhs[]);
extern void c29_controlMCUSlugsMKII_method_dispatcher(SimStruct *S, int_T method,
  void *data);

#endif
