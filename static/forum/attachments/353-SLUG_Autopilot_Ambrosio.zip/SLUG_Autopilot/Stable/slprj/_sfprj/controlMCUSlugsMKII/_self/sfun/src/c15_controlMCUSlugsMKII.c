/* Include files */

#include "blascompat32.h"
#include "controlMCUSlugsMKII_sfun.h"
#include "c15_controlMCUSlugsMKII.h"
#define CHARTINSTANCE_CHARTNUMBER      (chartInstance->chartNumber)
#define CHARTINSTANCE_INSTANCENUMBER   (chartInstance->instanceNumber)
#include "controlMCUSlugsMKII_sfun_debug_macros.h"

/* Type Definitions */

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */
static const char *c15_debug_family_names[4] = { "nargin", "nargout", "val",
  "zpVal" };

/* Function Declarations */
static void initialize_c15_controlMCUSlugsMKII
  (SFc15_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void initialize_params_c15_controlMCUSlugsMKII
  (SFc15_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void enable_c15_controlMCUSlugsMKII
  (SFc15_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void disable_c15_controlMCUSlugsMKII
  (SFc15_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void c15_update_debugger_state_c15_controlMCUSlugsMKII
  (SFc15_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static const mxArray *get_sim_state_c15_controlMCUSlugsMKII
  (SFc15_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void set_sim_state_c15_controlMCUSlugsMKII
  (SFc15_controlMCUSlugsMKIIInstanceStruct *chartInstance, const mxArray *c15_st);
static void finalize_c15_controlMCUSlugsMKII
  (SFc15_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void sf_c15_controlMCUSlugsMKII(SFc15_controlMCUSlugsMKIIInstanceStruct
  *chartInstance);
static void init_script_number_translation(uint32_T c15_machineNumber, uint32_T
  c15_chartNumber);
static const mxArray *c15_sf_marshall(void *chartInstanceVoid, void *c15_u);
static const mxArray *c15_b_sf_marshall(void *chartInstanceVoid, void *c15_u);
static const mxArray *c15_c_sf_marshall(void *chartInstanceVoid, void *c15_u);
static real32_T c15_emlrt_marshallIn(SFc15_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c15_zpVal, const char_T *c15_name);
static uint8_T c15_b_emlrt_marshallIn(SFc15_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c15_b_is_active_c15_controlMCUSlugsMKII, const
  char_T *c15_name);
static void init_dsm_address_info(SFc15_controlMCUSlugsMKIIInstanceStruct
  *chartInstance);

/* Function Definitions */
static void initialize_c15_controlMCUSlugsMKII
  (SFc15_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
  chartInstance->c15_is_active_c15_controlMCUSlugsMKII = 0U;
}

static void initialize_params_c15_controlMCUSlugsMKII
  (SFc15_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
}

static void enable_c15_controlMCUSlugsMKII
  (SFc15_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
}

static void disable_c15_controlMCUSlugsMKII
  (SFc15_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
}

static void c15_update_debugger_state_c15_controlMCUSlugsMKII
  (SFc15_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
}

static const mxArray *get_sim_state_c15_controlMCUSlugsMKII
  (SFc15_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
  const mxArray *c15_st = NULL;
  const mxArray *c15_y = NULL;
  real32_T c15_hoistedGlobal;
  real32_T c15_u;
  const mxArray *c15_b_y = NULL;
  uint8_T c15_b_hoistedGlobal;
  uint8_T c15_b_u;
  const mxArray *c15_c_y = NULL;
  real32_T *c15_zpVal;
  c15_zpVal = (real32_T *)ssGetOutputPortSignal(chartInstance->S, 1);
  c15_st = NULL;
  c15_y = NULL;
  sf_mex_assign(&c15_y, sf_mex_createcellarray(2));
  c15_hoistedGlobal = *c15_zpVal;
  c15_u = c15_hoistedGlobal;
  c15_b_y = NULL;
  sf_mex_assign(&c15_b_y, sf_mex_create("y", &c15_u, 1, 0U, 0U, 0U, 0));
  sf_mex_setcell(c15_y, 0, c15_b_y);
  c15_b_hoistedGlobal = chartInstance->c15_is_active_c15_controlMCUSlugsMKII;
  c15_b_u = c15_b_hoistedGlobal;
  c15_c_y = NULL;
  sf_mex_assign(&c15_c_y, sf_mex_create("y", &c15_b_u, 3, 0U, 0U, 0U, 0));
  sf_mex_setcell(c15_y, 1, c15_c_y);
  sf_mex_assign(&c15_st, c15_y);
  return c15_st;
}

static void set_sim_state_c15_controlMCUSlugsMKII
  (SFc15_controlMCUSlugsMKIIInstanceStruct *chartInstance, const mxArray *c15_st)
{
  const mxArray *c15_u;
  real32_T *c15_zpVal;
  c15_zpVal = (real32_T *)ssGetOutputPortSignal(chartInstance->S, 1);
  chartInstance->c15_doneDoubleBufferReInit = TRUE;
  c15_u = sf_mex_dup(c15_st);
  *c15_zpVal = c15_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell
    (c15_u, 0)), "zpVal");
  chartInstance->c15_is_active_c15_controlMCUSlugsMKII = c15_b_emlrt_marshallIn
    (chartInstance, sf_mex_dup(sf_mex_getcell(c15_u, 1)),
     "is_active_c15_controlMCUSlugsMKII");
  sf_mex_destroy(&c15_u);
  c15_update_debugger_state_c15_controlMCUSlugsMKII(chartInstance);
  sf_mex_destroy(&c15_st);
}

static void finalize_c15_controlMCUSlugsMKII
  (SFc15_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
}

static void sf_c15_controlMCUSlugsMKII(SFc15_controlMCUSlugsMKIIInstanceStruct
  *chartInstance)
{
  int32_T c15_previousEvent;
  real32_T c15_hoistedGlobal;
  real32_T c15_val;
  uint32_T c15_debug_family_var_map[4];
  real_T c15_nargin = 1.0;
  real_T c15_nargout = 1.0;
  real32_T c15_zpVal;
  real32_T *c15_b_val;
  real32_T *c15_b_zpVal;
  c15_b_zpVal = (real32_T *)ssGetOutputPortSignal(chartInstance->S, 1);
  c15_b_val = (real32_T *)ssGetInputPortSignal(chartInstance->S, 0);
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
  _SFD_CC_CALL(CHART_ENTER_SFUNCTION_TAG,14);
  _SFD_DATA_RANGE_CHECK((real_T)*c15_b_val, 0U);
  _SFD_DATA_RANGE_CHECK((real_T)*c15_b_zpVal, 1U);
  c15_previousEvent = _sfEvent_;
  _sfEvent_ = CALL_EVENT;
  _SFD_CC_CALL(CHART_ENTER_DURING_FUNCTION_TAG,14);
  c15_hoistedGlobal = *c15_b_val;
  c15_val = c15_hoistedGlobal;
  sf_debug_symbol_scope_push_eml(0U, 4U, 4U, c15_debug_family_names,
    c15_debug_family_var_map);
  sf_debug_symbol_scope_add_eml(&c15_nargin, c15_b_sf_marshall, 0U);
  sf_debug_symbol_scope_add_eml(&c15_nargout, c15_b_sf_marshall, 1U);
  sf_debug_symbol_scope_add_eml(&c15_val, c15_sf_marshall, 2U);
  sf_debug_symbol_scope_add_eml(&c15_zpVal, c15_sf_marshall, 3U);
  CV_EML_FCN(0, 0);

  /*  This block supports an embeddable subset of the MATLAB language. */
  /*  See the help menu for details.  */
  _SFD_EML_CALL(0,5);
  if (CV_EML_IF(0, 0, c15_val >= 1.000000047E-003F)) {
    _SFD_EML_CALL(0,6);
    c15_zpVal = c15_val;
  } else {
    _SFD_EML_CALL(0,8);
    c15_zpVal = 1.000000047E-003F;
  }

  _SFD_EML_CALL(0,-8);
  sf_debug_symbol_scope_pop();
  *c15_b_zpVal = c15_zpVal;
  _SFD_CC_CALL(EXIT_OUT_OF_FUNCTION_TAG,14);
  _sfEvent_ = c15_previousEvent;
  sf_debug_check_for_state_inconsistency(_controlMCUSlugsMKIIMachineNumber_,
    chartInstance->chartNumber, chartInstance->instanceNumber
    );
}

static void init_script_number_translation(uint32_T c15_machineNumber, uint32_T
  c15_chartNumber)
{
}

static const mxArray *c15_sf_marshall(void *chartInstanceVoid, void *c15_u)
{
  const mxArray *c15_y = NULL;
  real32_T c15_b_u;
  const mxArray *c15_b_y = NULL;
  SFc15_controlMCUSlugsMKIIInstanceStruct *chartInstance;
  chartInstance = (SFc15_controlMCUSlugsMKIIInstanceStruct *)chartInstanceVoid;
  c15_y = NULL;
  c15_b_u = *((real32_T *)c15_u);
  c15_b_y = NULL;
  sf_mex_assign(&c15_b_y, sf_mex_create("y", &c15_b_u, 1, 0U, 0U, 0U, 0));
  sf_mex_assign(&c15_y, c15_b_y);
  return c15_y;
}

static const mxArray *c15_b_sf_marshall(void *chartInstanceVoid, void *c15_u)
{
  const mxArray *c15_y = NULL;
  real_T c15_b_u;
  const mxArray *c15_b_y = NULL;
  SFc15_controlMCUSlugsMKIIInstanceStruct *chartInstance;
  chartInstance = (SFc15_controlMCUSlugsMKIIInstanceStruct *)chartInstanceVoid;
  c15_y = NULL;
  c15_b_u = *((real_T *)c15_u);
  c15_b_y = NULL;
  sf_mex_assign(&c15_b_y, sf_mex_create("y", &c15_b_u, 0, 0U, 0U, 0U, 0));
  sf_mex_assign(&c15_y, c15_b_y);
  return c15_y;
}

const mxArray *sf_c15_controlMCUSlugsMKII_get_eml_resolved_functions_info(void)
{
  const mxArray *c15_nameCaptureInfo = NULL;
  c15_ResolvedFunctionInfo c15_info[2];
  c15_ResolvedFunctionInfo (*c15_b_info)[2];
  const mxArray *c15_m0 = NULL;
  int32_T c15_i0;
  c15_ResolvedFunctionInfo *c15_r0;
  c15_nameCaptureInfo = NULL;
  c15_b_info = (c15_ResolvedFunctionInfo (*)[2])c15_info;
  (*c15_b_info)[0].context = "";
  (*c15_b_info)[0].name = "single";
  (*c15_b_info)[0].dominantType = "double";
  (*c15_b_info)[0].resolved = "[B]single";
  (*c15_b_info)[0].fileLength = 0U;
  (*c15_b_info)[0].fileTime1 = 0U;
  (*c15_b_info)[0].fileTime2 = 0U;
  (*c15_b_info)[1].context = "";
  (*c15_b_info)[1].name = "ge";
  (*c15_b_info)[1].dominantType = "single";
  (*c15_b_info)[1].resolved = "[B]ge";
  (*c15_b_info)[1].fileLength = 0U;
  (*c15_b_info)[1].fileTime1 = 0U;
  (*c15_b_info)[1].fileTime2 = 0U;
  sf_mex_assign(&c15_m0, sf_mex_createstruct("nameCaptureInfo", 1, 2));
  for (c15_i0 = 0; c15_i0 < 2; c15_i0 = c15_i0 + 1) {
    c15_r0 = &c15_info[c15_i0];
    sf_mex_addfield(c15_m0, sf_mex_create("nameCaptureInfo", c15_r0->context, 15,
      0U, 0U, 0U, 2, 1, strlen(c15_r0->context)), "context"
                    , "nameCaptureInfo", c15_i0);
    sf_mex_addfield(c15_m0, sf_mex_create("nameCaptureInfo", c15_r0->name, 15,
      0U, 0U, 0U, 2, 1, strlen(c15_r0->name)), "name",
                    "nameCaptureInfo", c15_i0);
    sf_mex_addfield(c15_m0, sf_mex_create("nameCaptureInfo",
      c15_r0->dominantType, 15, 0U, 0U, 0U, 2, 1, strlen(c15_r0->dominantType)),
                    "dominantType", "nameCaptureInfo", c15_i0);
    sf_mex_addfield(c15_m0, sf_mex_create("nameCaptureInfo", c15_r0->resolved,
      15, 0U, 0U, 0U, 2, 1, strlen(c15_r0->resolved)),
                    "resolved", "nameCaptureInfo", c15_i0);
    sf_mex_addfield(c15_m0, sf_mex_create("nameCaptureInfo", &c15_r0->fileLength,
      7, 0U, 0U, 0U, 0), "fileLength", "nameCaptureInfo",
                    c15_i0);
    sf_mex_addfield(c15_m0, sf_mex_create("nameCaptureInfo", &c15_r0->fileTime1,
      7, 0U, 0U, 0U, 0), "fileTime1", "nameCaptureInfo",
                    c15_i0);
    sf_mex_addfield(c15_m0, sf_mex_create("nameCaptureInfo", &c15_r0->fileTime2,
      7, 0U, 0U, 0U, 0), "fileTime2", "nameCaptureInfo",
                    c15_i0);
  }

  sf_mex_assign(&c15_nameCaptureInfo, c15_m0);
  return c15_nameCaptureInfo;
}

static const mxArray *c15_c_sf_marshall(void *chartInstanceVoid, void *c15_u)
{
  const mxArray *c15_y = NULL;
  boolean_T c15_b_u;
  const mxArray *c15_b_y = NULL;
  SFc15_controlMCUSlugsMKIIInstanceStruct *chartInstance;
  chartInstance = (SFc15_controlMCUSlugsMKIIInstanceStruct *)chartInstanceVoid;
  c15_y = NULL;
  c15_b_u = *((boolean_T *)c15_u);
  c15_b_y = NULL;
  sf_mex_assign(&c15_b_y, sf_mex_create("y", &c15_b_u, 11, 0U, 0U, 0U, 0));
  sf_mex_assign(&c15_y, c15_b_y);
  return c15_y;
}

static real32_T c15_emlrt_marshallIn(SFc15_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c15_zpVal, const char_T
  *c15_name)
{
  real32_T c15_y;
  real32_T c15_f0;
  sf_mex_import(c15_name, sf_mex_dup(c15_zpVal), &c15_f0, 1, 1, 0U, 0, 0U, 0);
  c15_y = c15_f0;
  sf_mex_destroy(&c15_zpVal);
  return c15_y;
}

static uint8_T c15_b_emlrt_marshallIn(SFc15_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *
  c15_b_is_active_c15_controlMCUSlugsMKII, const char_T *c15_name)
{
  uint8_T c15_y;
  uint8_T c15_u0;
  sf_mex_import(c15_name, sf_mex_dup(c15_b_is_active_c15_controlMCUSlugsMKII),
                &c15_u0, 1, 3, 0U, 0, 0U, 0);
  c15_y = c15_u0;
  sf_mex_destroy(&c15_b_is_active_c15_controlMCUSlugsMKII);
  return c15_y;
}

static void init_dsm_address_info(SFc15_controlMCUSlugsMKIIInstanceStruct
  *chartInstance)
{
}

/* SFunction Glue Code */
void sf_c15_controlMCUSlugsMKII_get_check_sum(mxArray *plhs[])
{
  ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(3428125909U);
  ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(174483551U);
  ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(4158533105U);
  ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(1747214418U);
}

mxArray *sf_c15_controlMCUSlugsMKII_get_autoinheritance_info(void)
{
  const char *autoinheritanceFields[] = { "checksum", "inputs", "parameters",
    "outputs" };

  mxArray *mxAutoinheritanceInfo = mxCreateStructMatrix(1,1,4,
    autoinheritanceFields);

  {
    mxArray *mxChecksum = mxCreateDoubleMatrix(4,1,mxREAL);
    double *pr = mxGetPr(mxChecksum);
    pr[0] = (double)(3430806999U);
    pr[1] = (double)(451935001U);
    pr[2] = (double)(2969676645U);
    pr[3] = (double)(3257644899U);
    mxSetField(mxAutoinheritanceInfo,0,"checksum",mxChecksum);
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,1,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(9));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"inputs",mxData);
  }

  {
    mxSetField(mxAutoinheritanceInfo,0,"parameters",mxCreateDoubleMatrix(0,0,
                mxREAL));
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,1,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(9));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"outputs",mxData);
  }

  return(mxAutoinheritanceInfo);
}

static mxArray *sf_get_sim_state_info_c15_controlMCUSlugsMKII(void)
{
  const char *infoFields[] = { "chartChecksum", "varInfo" };

  mxArray *mxInfo = mxCreateStructMatrix(1, 1, 2, infoFields);
  const char *infoEncStr[] = {
    "100 S1x2'type','srcId','name','auxInfo'{{M[1],M[5],T\"zpVal\",},{M[8],M[0],T\"is_active_c15_controlMCUSlugsMKII\",}}"
  };

  mxArray *mxVarInfo = sf_mex_decode_encoded_mx_struct_array(infoEncStr, 2, 10);
  mxArray *mxChecksum = mxCreateDoubleMatrix(1, 4, mxREAL);
  sf_c15_controlMCUSlugsMKII_get_check_sum(&mxChecksum);
  mxSetField(mxInfo, 0, infoFields[0], mxChecksum);
  mxSetField(mxInfo, 0, infoFields[1], mxVarInfo);
  return mxInfo;
}

static void chart_debug_initialization(SimStruct *S, unsigned int
  fullDebuggerInitialization)
{
  if (!sim_mode_is_rtw_gen(S)) {
    SFc15_controlMCUSlugsMKIIInstanceStruct *chartInstance;
    chartInstance = (SFc15_controlMCUSlugsMKIIInstanceStruct *)
      ((ChartInfoStruct *)(ssGetUserData(S)))->chartInstance;
    if (ssIsFirstInitCond(S) && fullDebuggerInitialization==1) {
      /* do this only if simulation is starting */
      {
        unsigned int chartAlreadyPresent;
        chartAlreadyPresent = sf_debug_initialize_chart
          (_controlMCUSlugsMKIIMachineNumber_,
           15,
           1,
           1,
           2,
           0,
           0,
           0,
           0,
           0,
           &(chartInstance->chartNumber),
           &(chartInstance->instanceNumber),
           ssGetPath(S),
           (void *)S);
        if (chartAlreadyPresent==0) {
          /* this is the first instance */
          init_script_number_translation(_controlMCUSlugsMKIIMachineNumber_,
            chartInstance->chartNumber);
          sf_debug_set_chart_disable_implicit_casting
            (_controlMCUSlugsMKIIMachineNumber_,chartInstance->chartNumber,1);
          sf_debug_set_chart_event_thresholds(_controlMCUSlugsMKIIMachineNumber_,
            chartInstance->chartNumber,
            0,
            0,
            0);
          _SFD_SET_DATA_PROPS(0,1,1,0,SF_SINGLE,0,NULL,0,0,0,0.0,1.0,0,"val",0,
                              (MexFcnForType)c15_sf_marshall);
          _SFD_SET_DATA_PROPS(1,2,0,1,SF_SINGLE,0,NULL,0,0,0,0.0,1.0,0,"zpVal",0,
                              (MexFcnForType)c15_sf_marshall);
          _SFD_STATE_INFO(0,0,2);
          _SFD_CH_SUBSTATE_COUNT(0);
          _SFD_CH_SUBSTATE_DECOMP(0);
        }

        _SFD_CV_INIT_CHART(0,0,0,0);

        {
          _SFD_CV_INIT_STATE(0,0,0,0,0,0,NULL,NULL);
        }

        _SFD_CV_INIT_TRANS(0,0,NULL,NULL,0,NULL);

        /* Initialization of EML Model Coverage */
        _SFD_CV_INIT_EML(0,1,1,0,0,0,0,0,0);
        _SFD_CV_INIT_EML_FCN(0,0,"eML_blk_kernel",0,-1,208);
        _SFD_CV_INIT_EML_IF(0,0,132,155,173,208);
        _SFD_TRANS_COV_WTS(0,0,0,1,0);
        if (chartAlreadyPresent==0) {
          _SFD_TRANS_COV_MAPS(0,
                              0,NULL,NULL,
                              0,NULL,NULL,
                              1,NULL,NULL,
                              0,NULL,NULL);
        }

        {
          real32_T *c15_val;
          real32_T *c15_zpVal;
          c15_zpVal = (real32_T *)ssGetOutputPortSignal(chartInstance->S, 1);
          c15_val = (real32_T *)ssGetInputPortSignal(chartInstance->S, 0);
          _SFD_SET_DATA_VALUE_PTR(0U, c15_val);
          _SFD_SET_DATA_VALUE_PTR(1U, c15_zpVal);
        }
      }
    } else {
      sf_debug_reset_current_state_configuration
        (_controlMCUSlugsMKIIMachineNumber_,chartInstance->chartNumber,
         chartInstance->instanceNumber);
    }
  }
}

static void sf_opaque_initialize_c15_controlMCUSlugsMKII(void *chartInstanceVar)
{
  chart_debug_initialization(((SFc15_controlMCUSlugsMKIIInstanceStruct*)
    chartInstanceVar)->S,0);
  initialize_params_c15_controlMCUSlugsMKII
    ((SFc15_controlMCUSlugsMKIIInstanceStruct*) chartInstanceVar);
  initialize_c15_controlMCUSlugsMKII((SFc15_controlMCUSlugsMKIIInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_enable_c15_controlMCUSlugsMKII(void *chartInstanceVar)
{
  enable_c15_controlMCUSlugsMKII((SFc15_controlMCUSlugsMKIIInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_disable_c15_controlMCUSlugsMKII(void *chartInstanceVar)
{
  disable_c15_controlMCUSlugsMKII((SFc15_controlMCUSlugsMKIIInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_gateway_c15_controlMCUSlugsMKII(void *chartInstanceVar)
{
  sf_c15_controlMCUSlugsMKII((SFc15_controlMCUSlugsMKIIInstanceStruct*)
    chartInstanceVar);
}

static mxArray* sf_internal_get_sim_state_c15_controlMCUSlugsMKII(SimStruct* S)
{
  ChartInfoStruct *chartInfo = (ChartInfoStruct*) ssGetUserData(S);
  mxArray *plhs[1] = { NULL };

  mxArray *prhs[4];
  int mxError = 0;
  prhs[0] = mxCreateString("chart_simctx_raw2high");
  prhs[1] = mxCreateDoubleScalar(ssGetSFuncBlockHandle(S));
  prhs[2] = (mxArray*) get_sim_state_c15_controlMCUSlugsMKII
    ((SFc15_controlMCUSlugsMKIIInstanceStruct*)chartInfo->chartInstance);/* raw sim ctx */
  prhs[3] = sf_get_sim_state_info_c15_controlMCUSlugsMKII();/* state var info */
  mxError = sf_mex_call_matlab(1, plhs, 4, prhs, "sfprivate");
  mxDestroyArray(prhs[0]);
  mxDestroyArray(prhs[1]);
  mxDestroyArray(prhs[2]);
  mxDestroyArray(prhs[3]);
  if (mxError || plhs[0] == NULL) {
    sf_mex_error_message("Stateflow Internal Error: \nError calling 'chart_simctx_raw2high'.\n");
  }

  return plhs[0];
}

static void sf_internal_set_sim_state_c15_controlMCUSlugsMKII(SimStruct* S,
  const mxArray *st)
{
  ChartInfoStruct *chartInfo = (ChartInfoStruct*) ssGetUserData(S);
  mxArray *plhs[1] = { NULL };

  mxArray *prhs[4];
  int mxError = 0;
  prhs[0] = mxCreateString("chart_simctx_high2raw");
  prhs[1] = mxCreateDoubleScalar(ssGetSFuncBlockHandle(S));
  prhs[2] = mxDuplicateArray(st);      /* high level simctx */
  prhs[3] = (mxArray*) sf_get_sim_state_info_c15_controlMCUSlugsMKII();/* state var info */
  mxError = sf_mex_call_matlab(1, plhs, 4, prhs, "sfprivate");
  mxDestroyArray(prhs[0]);
  mxDestroyArray(prhs[1]);
  mxDestroyArray(prhs[2]);
  mxDestroyArray(prhs[3]);
  if (mxError || plhs[0] == NULL) {
    sf_mex_error_message("Stateflow Internal Error: \nError calling 'chart_simctx_high2raw'.\n");
  }

  set_sim_state_c15_controlMCUSlugsMKII((SFc15_controlMCUSlugsMKIIInstanceStruct*)
    chartInfo->chartInstance, mxDuplicateArray(plhs[0]));
  mxDestroyArray(plhs[0]);
}

static mxArray* sf_opaque_get_sim_state_c15_controlMCUSlugsMKII(SimStruct* S)
{
  return sf_internal_get_sim_state_c15_controlMCUSlugsMKII(S);
}

static void sf_opaque_set_sim_state_c15_controlMCUSlugsMKII(SimStruct* S, const
  mxArray *st)
{
  sf_internal_set_sim_state_c15_controlMCUSlugsMKII(S, st);
}

static void sf_opaque_terminate_c15_controlMCUSlugsMKII(void *chartInstanceVar)
{
  if (chartInstanceVar!=NULL) {
    SimStruct *S = ((SFc15_controlMCUSlugsMKIIInstanceStruct*) chartInstanceVar
      )->S;
    if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
      sf_clear_rtw_identifier(S);
    }

    finalize_c15_controlMCUSlugsMKII((SFc15_controlMCUSlugsMKIIInstanceStruct*)
      chartInstanceVar);
    free((void *)chartInstanceVar);
    ssSetUserData(S,NULL);
  }
}

extern unsigned int sf_machine_global_initializer_called(void);
static void mdlProcessParameters_c15_controlMCUSlugsMKII(SimStruct *S)
{
  int i;
  for (i=0;i<ssGetNumRunTimeParams(S);i++) {
    if (ssGetSFcnParamTunable(S,i)) {
      ssUpdateDlgParamAsRunTimeParam(S,i);
    }
  }

  if (sf_machine_global_initializer_called()) {
    initialize_params_c15_controlMCUSlugsMKII
      ((SFc15_controlMCUSlugsMKIIInstanceStruct*)(((ChartInfoStruct *)
         ssGetUserData(S))->chartInstance));
  }
}

static void mdlSetWorkWidths_c15_controlMCUSlugsMKII(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
    int_T chartIsInlinable =
      (int_T)sf_is_chart_inlinable("controlMCUSlugsMKII","controlMCUSlugsMKII",
      15);
    ssSetStateflowIsInlinable(S,chartIsInlinable);
    ssSetRTWCG(S,sf_rtw_info_uint_prop("controlMCUSlugsMKII",
                "controlMCUSlugsMKII",15,"RTWCG"));
    ssSetEnableFcnIsTrivial(S,1);
    ssSetDisableFcnIsTrivial(S,1);
    ssSetNotMultipleInlinable(S,sf_rtw_info_uint_prop("controlMCUSlugsMKII",
      "controlMCUSlugsMKII",15,"gatewayCannotBeInlinedMultipleTimes"));
    if (chartIsInlinable) {
      ssSetInputPortOptimOpts(S, 0, SS_REUSABLE_AND_LOCAL);
      sf_mark_chart_expressionable_inputs(S,"controlMCUSlugsMKII",
        "controlMCUSlugsMKII",15,1);
      sf_mark_chart_reusable_outputs(S,"controlMCUSlugsMKII",
        "controlMCUSlugsMKII",15,1);
    }

    sf_set_rtw_dwork_info(S,"controlMCUSlugsMKII","controlMCUSlugsMKII",15);
    ssSetHasSubFunctions(S,!(chartIsInlinable));
    ssSetOptions(S,ssGetOptions(S)|SS_OPTION_WORKS_WITH_CODE_REUSE);
  }

  ssSetChecksum0(S,(2239637201U));
  ssSetChecksum1(S,(2355683107U));
  ssSetChecksum2(S,(1129766403U));
  ssSetChecksum3(S,(2969991789U));
  ssSetmdlDerivatives(S, NULL);
  ssSetExplicitFCSSCtrl(S,1);
}

static void mdlRTW_c15_controlMCUSlugsMKII(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S)) {
    sf_write_symbol_mapping(S, "controlMCUSlugsMKII", "controlMCUSlugsMKII",15);
    ssWriteRTWStrParam(S, "StateflowChartType", "Embedded MATLAB");
  }
}

static void mdlStart_c15_controlMCUSlugsMKII(SimStruct *S)
{
  SFc15_controlMCUSlugsMKIIInstanceStruct *chartInstance;
  chartInstance = (SFc15_controlMCUSlugsMKIIInstanceStruct *)malloc(sizeof
    (SFc15_controlMCUSlugsMKIIInstanceStruct));
  memset(chartInstance, 0, sizeof(SFc15_controlMCUSlugsMKIIInstanceStruct));
  if (chartInstance==NULL) {
    sf_mex_error_message("Could not allocate memory for chart instance.");
  }

  chartInstance->chartInfo.chartInstance = chartInstance;
  chartInstance->chartInfo.isEMLChart = 1;
  chartInstance->chartInfo.chartInitialized = 0;
  chartInstance->chartInfo.sFunctionGateway =
    sf_opaque_gateway_c15_controlMCUSlugsMKII;
  chartInstance->chartInfo.initializeChart =
    sf_opaque_initialize_c15_controlMCUSlugsMKII;
  chartInstance->chartInfo.terminateChart =
    sf_opaque_terminate_c15_controlMCUSlugsMKII;
  chartInstance->chartInfo.enableChart =
    sf_opaque_enable_c15_controlMCUSlugsMKII;
  chartInstance->chartInfo.disableChart =
    sf_opaque_disable_c15_controlMCUSlugsMKII;
  chartInstance->chartInfo.getSimState =
    sf_opaque_get_sim_state_c15_controlMCUSlugsMKII;
  chartInstance->chartInfo.setSimState =
    sf_opaque_set_sim_state_c15_controlMCUSlugsMKII;
  chartInstance->chartInfo.getSimStateInfo =
    sf_get_sim_state_info_c15_controlMCUSlugsMKII;
  chartInstance->chartInfo.zeroCrossings = NULL;
  chartInstance->chartInfo.outputs = NULL;
  chartInstance->chartInfo.derivatives = NULL;
  chartInstance->chartInfo.mdlRTW = mdlRTW_c15_controlMCUSlugsMKII;
  chartInstance->chartInfo.mdlStart = mdlStart_c15_controlMCUSlugsMKII;
  chartInstance->chartInfo.mdlSetWorkWidths =
    mdlSetWorkWidths_c15_controlMCUSlugsMKII;
  chartInstance->chartInfo.extModeExec = NULL;
  chartInstance->chartInfo.restoreLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.restoreBeforeLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.storeCurrentConfiguration = NULL;
  chartInstance->S = S;
  ssSetUserData(S,(void *)(&(chartInstance->chartInfo)));/* register the chart instance with simstruct */
  if (!sim_mode_is_rtw_gen(S)) {
    init_dsm_address_info(chartInstance);
  }

  chart_debug_initialization(S,1);
}

void c15_controlMCUSlugsMKII_method_dispatcher(SimStruct *S, int_T method, void *
  data)
{
  switch (method) {
   case SS_CALL_MDL_START:
    mdlStart_c15_controlMCUSlugsMKII(S);
    break;

   case SS_CALL_MDL_SET_WORK_WIDTHS:
    mdlSetWorkWidths_c15_controlMCUSlugsMKII(S);
    break;

   case SS_CALL_MDL_PROCESS_PARAMETERS:
    mdlProcessParameters_c15_controlMCUSlugsMKII(S);
    break;

   default:
    /* Unhandled method */
    sf_mex_error_message("Stateflow Internal Error:\n"
                         "Error calling c15_controlMCUSlugsMKII_method_dispatcher.\n"
                         "Can't handle method %d.\n", method);
    break;
  }
}
