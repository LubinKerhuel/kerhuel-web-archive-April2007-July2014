/* Include files */

#include "blascompat32.h"
#include "controlMCUSlugsMKII_sfun.h"
#include "c4_controlMCUSlugsMKII.h"
#define CHARTINSTANCE_CHARTNUMBER      (chartInstance->chartNumber)
#define CHARTINSTANCE_INSTANCENUMBER   (chartInstance->instanceNumber)
#include "controlMCUSlugsMKII_sfun_debug_macros.h"

/* Type Definitions */

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */
static const char *c4_debug_family_names[6] = { "i", "nargin", "nargout",
  "latest", "history", "oldValues" };

/* Function Declarations */
static void initialize_c4_controlMCUSlugsMKII
  (SFc4_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void initialize_params_c4_controlMCUSlugsMKII
  (SFc4_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void enable_c4_controlMCUSlugsMKII(SFc4_controlMCUSlugsMKIIInstanceStruct
  *chartInstance);
static void disable_c4_controlMCUSlugsMKII
  (SFc4_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void c4_update_debugger_state_c4_controlMCUSlugsMKII
  (SFc4_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static const mxArray *get_sim_state_c4_controlMCUSlugsMKII
  (SFc4_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void set_sim_state_c4_controlMCUSlugsMKII
  (SFc4_controlMCUSlugsMKIIInstanceStruct *chartInstance, const mxArray *c4_st);
static void finalize_c4_controlMCUSlugsMKII
  (SFc4_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void sf_c4_controlMCUSlugsMKII(SFc4_controlMCUSlugsMKIIInstanceStruct
  *chartInstance);
static void init_script_number_translation(uint32_T c4_machineNumber, uint32_T
  c4_chartNumber);
static const mxArray *c4_sf_marshall(void *chartInstanceVoid, void *c4_u);
static const mxArray *c4_b_sf_marshall(void *chartInstanceVoid, void *c4_u);
static const mxArray *c4_c_sf_marshall(void *chartInstanceVoid, void *c4_u);
static const mxArray *c4_d_sf_marshall(void *chartInstanceVoid, void *c4_u);
static const mxArray *c4_e_sf_marshall(void *chartInstanceVoid, void *c4_u);
static void c4_emlrt_marshallIn(SFc4_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c4_history, const char_T *c4_name, uint16_T
  c4_y[7]);
static void c4_b_emlrt_marshallIn(SFc4_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c4_b_oldValues, const char_T *c4_name, uint16_T
  c4_y[7]);
static uint8_T c4_c_emlrt_marshallIn(SFc4_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c4_b_is_active_c4_controlMCUSlugsMKII, const
  char_T *c4_name);
static void init_dsm_address_info(SFc4_controlMCUSlugsMKIIInstanceStruct
  *chartInstance);

/* Function Definitions */
static void initialize_c4_controlMCUSlugsMKII
  (SFc4_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
  chartInstance->c4_oldValues_not_empty = FALSE;
  chartInstance->c4_is_active_c4_controlMCUSlugsMKII = 0U;
}

static void initialize_params_c4_controlMCUSlugsMKII
  (SFc4_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
}

static void enable_c4_controlMCUSlugsMKII(SFc4_controlMCUSlugsMKIIInstanceStruct
  *chartInstance)
{
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
}

static void disable_c4_controlMCUSlugsMKII
  (SFc4_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
}

static void c4_update_debugger_state_c4_controlMCUSlugsMKII
  (SFc4_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
}

static const mxArray *get_sim_state_c4_controlMCUSlugsMKII
  (SFc4_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
  const mxArray *c4_st = NULL;
  const mxArray *c4_y = NULL;
  int32_T c4_i0;
  uint16_T c4_hoistedGlobal[7];
  int32_T c4_i1;
  uint16_T c4_u[7];
  const mxArray *c4_b_y = NULL;
  int32_T c4_i2;
  uint16_T c4_b_hoistedGlobal[7];
  int32_T c4_i3;
  uint16_T c4_b_u[7];
  const mxArray *c4_c_y = NULL;
  uint8_T c4_c_hoistedGlobal;
  uint8_T c4_c_u;
  const mxArray *c4_d_y = NULL;
  uint16_T (*c4_history)[7];
  c4_history = (uint16_T (*)[7])ssGetOutputPortSignal(chartInstance->S, 1);
  c4_st = NULL;
  c4_y = NULL;
  sf_mex_assign(&c4_y, sf_mex_createcellarray(3));
  for (c4_i0 = 0; c4_i0 < 7; c4_i0 = c4_i0 + 1) {
    c4_hoistedGlobal[c4_i0] = (*c4_history)[c4_i0];
  }

  for (c4_i1 = 0; c4_i1 < 7; c4_i1 = c4_i1 + 1) {
    c4_u[c4_i1] = c4_hoistedGlobal[c4_i1];
  }

  c4_b_y = NULL;
  sf_mex_assign(&c4_b_y, sf_mex_create("y", &c4_u, 5, 0U, 1U, 0U, 2, 1, 7));
  sf_mex_setcell(c4_y, 0, c4_b_y);
  for (c4_i2 = 0; c4_i2 < 7; c4_i2 = c4_i2 + 1) {
    c4_b_hoistedGlobal[c4_i2] = chartInstance->c4_oldValues[c4_i2];
  }

  for (c4_i3 = 0; c4_i3 < 7; c4_i3 = c4_i3 + 1) {
    c4_b_u[c4_i3] = c4_b_hoistedGlobal[c4_i3];
  }

  c4_c_y = NULL;
  if (!chartInstance->c4_oldValues_not_empty) {
    sf_mex_assign(&c4_c_y, sf_mex_create("y", NULL, 0, 0U, 1U, 0U, 2, 0, 0));
  } else {
    sf_mex_assign(&c4_c_y, sf_mex_create("y", &c4_b_u, 5, 0U, 1U, 0U, 2, 1, 7));
  }

  sf_mex_setcell(c4_y, 1, c4_c_y);
  c4_c_hoistedGlobal = chartInstance->c4_is_active_c4_controlMCUSlugsMKII;
  c4_c_u = c4_c_hoistedGlobal;
  c4_d_y = NULL;
  sf_mex_assign(&c4_d_y, sf_mex_create("y", &c4_c_u, 3, 0U, 0U, 0U, 0));
  sf_mex_setcell(c4_y, 2, c4_d_y);
  sf_mex_assign(&c4_st, c4_y);
  return c4_st;
}

static void set_sim_state_c4_controlMCUSlugsMKII
  (SFc4_controlMCUSlugsMKIIInstanceStruct *chartInstance, const mxArray *c4_st)
{
  const mxArray *c4_u;
  uint16_T c4_uv0[7];
  int32_T c4_i4;
  uint16_T c4_uv1[7];
  int32_T c4_i5;
  uint16_T (*c4_history)[7];
  c4_history = (uint16_T (*)[7])ssGetOutputPortSignal(chartInstance->S, 1);
  chartInstance->c4_doneDoubleBufferReInit = TRUE;
  c4_u = sf_mex_dup(c4_st);
  c4_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(c4_u, 0)),
                      "history", c4_uv0);
  for (c4_i4 = 0; c4_i4 < 7; c4_i4 = c4_i4 + 1) {
    (*c4_history)[c4_i4] = c4_uv0[c4_i4];
  }

  c4_b_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(c4_u, 1)),
                        "oldValues", c4_uv1);
  for (c4_i5 = 0; c4_i5 < 7; c4_i5 = c4_i5 + 1) {
    chartInstance->c4_oldValues[c4_i5] = c4_uv1[c4_i5];
  }

  chartInstance->c4_is_active_c4_controlMCUSlugsMKII = c4_c_emlrt_marshallIn
    (chartInstance, sf_mex_dup(sf_mex_getcell(c4_u, 2)),
     "is_active_c4_controlMCUSlugsMKII");
  sf_mex_destroy(&c4_u);
  c4_update_debugger_state_c4_controlMCUSlugsMKII(chartInstance);
  sf_mex_destroy(&c4_st);
}

static void finalize_c4_controlMCUSlugsMKII
  (SFc4_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
}

static void sf_c4_controlMCUSlugsMKII(SFc4_controlMCUSlugsMKIIInstanceStruct
  *chartInstance)
{
  int32_T c4_i6;
  int32_T c4_previousEvent;
  uint16_T c4_hoistedGlobal;
  uint16_T c4_latest;
  uint32_T c4_debug_family_var_map[6];
  static const char *c4_sv0[6] = { "i", "nargin", "nargout", "latest", "history",
    "oldValues" };

  real_T c4_i;
  real_T c4_nargin = 1.0;
  real_T c4_nargout = 1.0;
  uint16_T c4_history[7];
  int32_T c4_i7;
  int32_T c4_i8;
  real_T c4_b_i;
  int32_T c4_i9;
  uint16_T *c4_b_latest;
  uint16_T (*c4_b_history)[7];
  c4_b_history = (uint16_T (*)[7])ssGetOutputPortSignal(chartInstance->S, 1);
  c4_b_latest = (uint16_T *)ssGetInputPortSignal(chartInstance->S, 0);
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
  _SFD_CC_CALL(CHART_ENTER_SFUNCTION_TAG,3);
  _SFD_DATA_RANGE_CHECK((real_T)*c4_b_latest, 0U);
  for (c4_i6 = 0; c4_i6 < 7; c4_i6 = c4_i6 + 1) {
    _SFD_DATA_RANGE_CHECK((real_T)(*c4_b_history)[c4_i6], 1U);
  }

  c4_previousEvent = _sfEvent_;
  _sfEvent_ = CALL_EVENT;
  _SFD_CC_CALL(CHART_ENTER_DURING_FUNCTION_TAG,3);
  c4_hoistedGlobal = *c4_b_latest;
  c4_latest = c4_hoistedGlobal;
  sf_debug_symbol_scope_push_eml(0U, 6U, 6U, c4_sv0, c4_debug_family_var_map);
  sf_debug_symbol_scope_add_eml(&c4_i, c4_d_sf_marshall, 0U);
  sf_debug_symbol_scope_add_eml(&c4_nargin, c4_d_sf_marshall, 1U);
  sf_debug_symbol_scope_add_eml(&c4_nargout, c4_d_sf_marshall, 2U);
  sf_debug_symbol_scope_add_eml(&c4_latest, c4_c_sf_marshall, 3U);
  sf_debug_symbol_scope_add_eml(&c4_history, c4_b_sf_marshall, 4U);
  sf_debug_symbol_scope_add_eml(&chartInstance->c4_oldValues, c4_sf_marshall, 5U);
  CV_EML_FCN(0, 0);

  /*  This block supports an embeddable subset of the MATLAB language. */
  /*  See the help menu for details.  */
  _SFD_EML_CALL(0,7);
  if (CV_EML_IF(0, 0, !chartInstance->c4_oldValues_not_empty)) {
    _SFD_EML_CALL(0,8);
    for (c4_i7 = 0; c4_i7 < 7; c4_i7 = c4_i7 + 1) {
      chartInstance->c4_oldValues[c4_i7] = 0U;
    }

    chartInstance->c4_oldValues_not_empty = TRUE;
  }

  _SFD_EML_CALL(0,11);
  for (c4_i8 = 0; c4_i8 < 7; c4_i8 = c4_i8 + 1) {
    c4_history[c4_i8] = 0U;
  }

  c4_i = 7.0;
  c4_b_i = 7.0;
  while (c4_b_i >= 2.0) {
    c4_i = c4_b_i;
    CV_EML_FOR(0, 0, 1);
    _SFD_EML_CALL(0,14);
    chartInstance->c4_oldValues[_SFD_EML_ARRAY_BOUNDS_CHECK("oldValues",
      (int32_T)_SFD_INTEGER_CHECK("i", c4_i), 1, 7, 1, 0) - 1] =
      chartInstance->c4_oldValues[_SFD_EML_ARRAY_BOUNDS_CHECK("oldValues",
      (int32_T)_SFD_INTEGER_CHECK("", c4_i - 1.0), 1, 7, 1, 0) - 1];
    _SFD_EML_CALL(0,15);
    c4_history[_SFD_EML_ARRAY_BOUNDS_CHECK("history", (int32_T)
      _SFD_INTEGER_CHECK("i", c4_i), 1, 7, 1, 0) - 1] = chartInstance->
      c4_oldValues[_SFD_EML_ARRAY_BOUNDS_CHECK("oldValues", (int32_T)
      _SFD_INTEGER_CHECK("", c4_i - 1.0), 1, 7, 1, 0) - 1];
    c4_b_i = c4_b_i + -1.0;
    sf_mex_listen_for_ctrl_c(chartInstance->S);
  }

  CV_EML_FOR(0, 0, 0);
  _SFD_EML_CALL(0,18);
  chartInstance->c4_oldValues[0] = c4_latest;
  _SFD_EML_CALL(0,19);
  c4_history[0] = c4_latest;
  _SFD_EML_CALL(0,-19);
  sf_debug_symbol_scope_pop();
  for (c4_i9 = 0; c4_i9 < 7; c4_i9 = c4_i9 + 1) {
    (*c4_b_history)[c4_i9] = c4_history[c4_i9];
  }

  _SFD_CC_CALL(EXIT_OUT_OF_FUNCTION_TAG,3);
  _sfEvent_ = c4_previousEvent;
  sf_debug_check_for_state_inconsistency(_controlMCUSlugsMKIIMachineNumber_,
    chartInstance->chartNumber, chartInstance->instanceNumber
    );
}

static void init_script_number_translation(uint32_T c4_machineNumber, uint32_T
  c4_chartNumber)
{
}

static const mxArray *c4_sf_marshall(void *chartInstanceVoid, void *c4_u)
{
  const mxArray *c4_y = NULL;
  int32_T c4_i10;
  uint16_T c4_b_u[7];
  const mxArray *c4_b_y = NULL;
  SFc4_controlMCUSlugsMKIIInstanceStruct *chartInstance;
  chartInstance = (SFc4_controlMCUSlugsMKIIInstanceStruct *)chartInstanceVoid;
  c4_y = NULL;
  for (c4_i10 = 0; c4_i10 < 7; c4_i10 = c4_i10 + 1) {
    c4_b_u[c4_i10] = (*((uint16_T (*)[7])c4_u))[c4_i10];
  }

  c4_b_y = NULL;
  if (!chartInstance->c4_oldValues_not_empty) {
    sf_mex_assign(&c4_b_y, sf_mex_create("y", NULL, 0, 0U, 1U, 0U, 2, 0, 0));
  } else {
    sf_mex_assign(&c4_b_y, sf_mex_create("y", &c4_b_u, 5, 0U, 1U, 0U, 2, 1, 7));
  }

  sf_mex_assign(&c4_y, c4_b_y);
  return c4_y;
}

static const mxArray *c4_b_sf_marshall(void *chartInstanceVoid, void *c4_u)
{
  const mxArray *c4_y = NULL;
  int32_T c4_i11;
  uint16_T c4_b_u[7];
  const mxArray *c4_b_y = NULL;
  SFc4_controlMCUSlugsMKIIInstanceStruct *chartInstance;
  chartInstance = (SFc4_controlMCUSlugsMKIIInstanceStruct *)chartInstanceVoid;
  c4_y = NULL;
  for (c4_i11 = 0; c4_i11 < 7; c4_i11 = c4_i11 + 1) {
    c4_b_u[c4_i11] = (*((uint16_T (*)[7])c4_u))[c4_i11];
  }

  c4_b_y = NULL;
  sf_mex_assign(&c4_b_y, sf_mex_create("y", &c4_b_u, 5, 0U, 1U, 0U, 2, 1, 7));
  sf_mex_assign(&c4_y, c4_b_y);
  return c4_y;
}

static const mxArray *c4_c_sf_marshall(void *chartInstanceVoid, void *c4_u)
{
  const mxArray *c4_y = NULL;
  uint16_T c4_b_u;
  const mxArray *c4_b_y = NULL;
  SFc4_controlMCUSlugsMKIIInstanceStruct *chartInstance;
  chartInstance = (SFc4_controlMCUSlugsMKIIInstanceStruct *)chartInstanceVoid;
  c4_y = NULL;
  c4_b_u = *((uint16_T *)c4_u);
  c4_b_y = NULL;
  sf_mex_assign(&c4_b_y, sf_mex_create("y", &c4_b_u, 5, 0U, 0U, 0U, 0));
  sf_mex_assign(&c4_y, c4_b_y);
  return c4_y;
}

static const mxArray *c4_d_sf_marshall(void *chartInstanceVoid, void *c4_u)
{
  const mxArray *c4_y = NULL;
  real_T c4_b_u;
  const mxArray *c4_b_y = NULL;
  SFc4_controlMCUSlugsMKIIInstanceStruct *chartInstance;
  chartInstance = (SFc4_controlMCUSlugsMKIIInstanceStruct *)chartInstanceVoid;
  c4_y = NULL;
  c4_b_u = *((real_T *)c4_u);
  c4_b_y = NULL;
  sf_mex_assign(&c4_b_y, sf_mex_create("y", &c4_b_u, 0, 0U, 0U, 0U, 0));
  sf_mex_assign(&c4_y, c4_b_y);
  return c4_y;
}

const mxArray *sf_c4_controlMCUSlugsMKII_get_eml_resolved_functions_info(void)
{
  const mxArray *c4_nameCaptureInfo = NULL;
  c4_ResolvedFunctionInfo c4_info[3];
  c4_ResolvedFunctionInfo (*c4_b_info)[3];
  const mxArray *c4_m0 = NULL;
  int32_T c4_i12;
  c4_ResolvedFunctionInfo *c4_r0;
  c4_nameCaptureInfo = NULL;
  c4_b_info = (c4_ResolvedFunctionInfo (*)[3])c4_info;
  (*c4_b_info)[0].context = "";
  (*c4_b_info)[0].name = "uint16";
  (*c4_b_info)[0].dominantType = "double";
  (*c4_b_info)[0].resolved = "[B]uint16";
  (*c4_b_info)[0].fileLength = 0U;
  (*c4_b_info)[0].fileTime1 = 0U;
  (*c4_b_info)[0].fileTime2 = 0U;
  (*c4_b_info)[1].context = "";
  (*c4_b_info)[1].name = "uminus";
  (*c4_b_info)[1].dominantType = "double";
  (*c4_b_info)[1].resolved = "[B]uminus";
  (*c4_b_info)[1].fileLength = 0U;
  (*c4_b_info)[1].fileTime1 = 0U;
  (*c4_b_info)[1].fileTime2 = 0U;
  (*c4_b_info)[2].context = "";
  (*c4_b_info)[2].name = "minus";
  (*c4_b_info)[2].dominantType = "double";
  (*c4_b_info)[2].resolved = "[B]minus";
  (*c4_b_info)[2].fileLength = 0U;
  (*c4_b_info)[2].fileTime1 = 0U;
  (*c4_b_info)[2].fileTime2 = 0U;
  sf_mex_assign(&c4_m0, sf_mex_createstruct("nameCaptureInfo", 1, 3));
  for (c4_i12 = 0; c4_i12 < 3; c4_i12 = c4_i12 + 1) {
    c4_r0 = &c4_info[c4_i12];
    sf_mex_addfield(c4_m0, sf_mex_create("nameCaptureInfo", c4_r0->context, 15,
      0U, 0U, 0U, 2, 1, strlen(c4_r0->context)), "context",
                    "nameCaptureInfo", c4_i12);
    sf_mex_addfield(c4_m0, sf_mex_create("nameCaptureInfo", c4_r0->name, 15, 0U,
      0U, 0U, 2, 1, strlen(c4_r0->name)), "name",
                    "nameCaptureInfo", c4_i12);
    sf_mex_addfield(c4_m0, sf_mex_create("nameCaptureInfo", c4_r0->dominantType,
      15, 0U, 0U, 0U, 2, 1, strlen(c4_r0->dominantType)),
                    "dominantType", "nameCaptureInfo", c4_i12);
    sf_mex_addfield(c4_m0, sf_mex_create("nameCaptureInfo", c4_r0->resolved, 15,
      0U, 0U, 0U, 2, 1, strlen(c4_r0->resolved)), "resolved"
                    , "nameCaptureInfo", c4_i12);
    sf_mex_addfield(c4_m0, sf_mex_create("nameCaptureInfo", &c4_r0->fileLength,
      7, 0U, 0U, 0U, 0), "fileLength", "nameCaptureInfo",
                    c4_i12);
    sf_mex_addfield(c4_m0, sf_mex_create("nameCaptureInfo", &c4_r0->fileTime1, 7,
      0U, 0U, 0U, 0), "fileTime1", "nameCaptureInfo", c4_i12
                    );
    sf_mex_addfield(c4_m0, sf_mex_create("nameCaptureInfo", &c4_r0->fileTime2, 7,
      0U, 0U, 0U, 0), "fileTime2", "nameCaptureInfo", c4_i12
                    );
  }

  sf_mex_assign(&c4_nameCaptureInfo, c4_m0);
  return c4_nameCaptureInfo;
}

static const mxArray *c4_e_sf_marshall(void *chartInstanceVoid, void *c4_u)
{
  const mxArray *c4_y = NULL;
  boolean_T c4_b_u;
  const mxArray *c4_b_y = NULL;
  SFc4_controlMCUSlugsMKIIInstanceStruct *chartInstance;
  chartInstance = (SFc4_controlMCUSlugsMKIIInstanceStruct *)chartInstanceVoid;
  c4_y = NULL;
  c4_b_u = *((boolean_T *)c4_u);
  c4_b_y = NULL;
  sf_mex_assign(&c4_b_y, sf_mex_create("y", &c4_b_u, 11, 0U, 0U, 0U, 0));
  sf_mex_assign(&c4_y, c4_b_y);
  return c4_y;
}

static void c4_emlrt_marshallIn(SFc4_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c4_history, const char_T *
  c4_name, uint16_T c4_y[7])
{
  uint16_T c4_uv2[7];
  int32_T c4_i13;
  sf_mex_import(c4_name, sf_mex_dup(c4_history), &c4_uv2, 1, 5, 0U, 1, 0U, 2, 1,
                7);
  for (c4_i13 = 0; c4_i13 < 7; c4_i13 = c4_i13 + 1) {
    c4_y[c4_i13] = c4_uv2[c4_i13];
  }

  sf_mex_destroy(&c4_history);
}

static void c4_b_emlrt_marshallIn(SFc4_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c4_b_oldValues, const char_T
  *c4_name, uint16_T c4_y[7])
{
  uint16_T c4_uv3[7];
  int32_T c4_i14;
  if (mxIsEmpty(c4_b_oldValues)) {
    chartInstance->c4_oldValues_not_empty = FALSE;
  } else {
    chartInstance->c4_oldValues_not_empty = TRUE;
    sf_mex_import(c4_name, sf_mex_dup(c4_b_oldValues), &c4_uv3, 1, 5, 0U, 1, 0U,
                  2, 1, 7);
    for (c4_i14 = 0; c4_i14 < 7; c4_i14 = c4_i14 + 1) {
      c4_y[c4_i14] = c4_uv3[c4_i14];
    }
  }

  sf_mex_destroy(&c4_b_oldValues);
}

static uint8_T c4_c_emlrt_marshallIn(SFc4_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *
  c4_b_is_active_c4_controlMCUSlugsMKII, const char_T *c4_name)
{
  uint8_T c4_y;
  uint8_T c4_u0;
  sf_mex_import(c4_name, sf_mex_dup(c4_b_is_active_c4_controlMCUSlugsMKII),
                &c4_u0, 1, 3, 0U, 0, 0U, 0);
  c4_y = c4_u0;
  sf_mex_destroy(&c4_b_is_active_c4_controlMCUSlugsMKII);
  return c4_y;
}

static void init_dsm_address_info(SFc4_controlMCUSlugsMKIIInstanceStruct
  *chartInstance)
{
}

/* SFunction Glue Code */
void sf_c4_controlMCUSlugsMKII_get_check_sum(mxArray *plhs[])
{
  ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(3049553855U);
  ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(3855393594U);
  ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(2617099463U);
  ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(3712596425U);
}

mxArray *sf_c4_controlMCUSlugsMKII_get_autoinheritance_info(void)
{
  const char *autoinheritanceFields[] = { "checksum", "inputs", "parameters",
    "outputs" };

  mxArray *mxAutoinheritanceInfo = mxCreateStructMatrix(1,1,4,
    autoinheritanceFields);

  {
    mxArray *mxChecksum = mxCreateDoubleMatrix(4,1,mxREAL);
    double *pr = mxGetPr(mxChecksum);
    pr[0] = (double)(56377951U);
    pr[1] = (double)(3457466682U);
    pr[2] = (double)(3732190819U);
    pr[3] = (double)(462973925U);
    mxSetField(mxAutoinheritanceInfo,0,"checksum",mxChecksum);
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,1,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(5));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"inputs",mxData);
  }

  {
    mxSetField(mxAutoinheritanceInfo,0,"parameters",mxCreateDoubleMatrix(0,0,
                mxREAL));
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,1,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(7);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(5));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"outputs",mxData);
  }

  return(mxAutoinheritanceInfo);
}

static mxArray *sf_get_sim_state_info_c4_controlMCUSlugsMKII(void)
{
  const char *infoFields[] = { "chartChecksum", "varInfo" };

  mxArray *mxInfo = mxCreateStructMatrix(1, 1, 2, infoFields);
  const char *infoEncStr[] = {
    "100 S1x3'type','srcId','name','auxInfo'{{M[1],M[5],T\"history\",},{M[4],M[0],T\"oldValues\",S'l','i','p'{{M1x2[155 164],M[0],}}},{M[8],M[0],T\"is_active_c4_controlMCUSlugsMKII\",}}"
  };

  mxArray *mxVarInfo = sf_mex_decode_encoded_mx_struct_array(infoEncStr, 3, 10);
  mxArray *mxChecksum = mxCreateDoubleMatrix(1, 4, mxREAL);
  sf_c4_controlMCUSlugsMKII_get_check_sum(&mxChecksum);
  mxSetField(mxInfo, 0, infoFields[0], mxChecksum);
  mxSetField(mxInfo, 0, infoFields[1], mxVarInfo);
  return mxInfo;
}

static void chart_debug_initialization(SimStruct *S, unsigned int
  fullDebuggerInitialization)
{
  if (!sim_mode_is_rtw_gen(S)) {
    SFc4_controlMCUSlugsMKIIInstanceStruct *chartInstance;
    chartInstance = (SFc4_controlMCUSlugsMKIIInstanceStruct *) ((ChartInfoStruct
      *)(ssGetUserData(S)))->chartInstance;
    if (ssIsFirstInitCond(S) && fullDebuggerInitialization==1) {
      /* do this only if simulation is starting */
      {
        unsigned int chartAlreadyPresent;
        chartAlreadyPresent = sf_debug_initialize_chart
          (_controlMCUSlugsMKIIMachineNumber_,
           4,
           1,
           1,
           2,
           0,
           0,
           0,
           0,
           0,
           &(chartInstance->chartNumber),
           &(chartInstance->instanceNumber),
           ssGetPath(S),
           (void *)S);
        if (chartAlreadyPresent==0) {
          /* this is the first instance */
          init_script_number_translation(_controlMCUSlugsMKIIMachineNumber_,
            chartInstance->chartNumber);
          sf_debug_set_chart_disable_implicit_casting
            (_controlMCUSlugsMKIIMachineNumber_,chartInstance->chartNumber,1);
          sf_debug_set_chart_event_thresholds(_controlMCUSlugsMKIIMachineNumber_,
            chartInstance->chartNumber,
            0,
            0,
            0);
          _SFD_SET_DATA_PROPS(0,1,1,0,SF_UINT16,0,NULL,0,0,0,0.0,1.0,0,"latest",
                              0,(MexFcnForType)c4_c_sf_marshall);

          {
            unsigned int dimVector[2];
            dimVector[0]= 1;
            dimVector[1]= 7;
            _SFD_SET_DATA_PROPS(1,2,0,1,SF_UINT16,2,&(dimVector[0]),0,0,0,0.0,
                                1.0,0,"history",0,(MexFcnForType)
                                c4_b_sf_marshall);
          }

          _SFD_STATE_INFO(0,0,2);
          _SFD_CH_SUBSTATE_COUNT(0);
          _SFD_CH_SUBSTATE_DECOMP(0);
        }

        _SFD_CV_INIT_CHART(0,0,0,0);

        {
          _SFD_CV_INIT_STATE(0,0,0,0,0,0,NULL,NULL);
        }

        _SFD_CV_INIT_TRANS(0,0,NULL,NULL,0,NULL);

        /* Initialization of EML Model Coverage */
        _SFD_CV_INIT_EML(0,1,1,0,0,1,0,0,0);
        _SFD_CV_INIT_EML_FCN(0,0,"eML_blk_kernel",0,-1,398);
        _SFD_CV_INIT_EML_IF(0,0,167,188,-1,233);
        _SFD_CV_INIT_EML_FOR(0,0,271,284,352);
        _SFD_TRANS_COV_WTS(0,0,0,1,0);
        if (chartAlreadyPresent==0) {
          _SFD_TRANS_COV_MAPS(0,
                              0,NULL,NULL,
                              0,NULL,NULL,
                              1,NULL,NULL,
                              0,NULL,NULL);
        }

        {
          uint16_T *c4_latest;
          uint16_T (*c4_history)[7];
          c4_history = (uint16_T (*)[7])ssGetOutputPortSignal(chartInstance->S,
            1);
          c4_latest = (uint16_T *)ssGetInputPortSignal(chartInstance->S, 0);
          _SFD_SET_DATA_VALUE_PTR(0U, c4_latest);
          _SFD_SET_DATA_VALUE_PTR(1U, c4_history);
        }
      }
    } else {
      sf_debug_reset_current_state_configuration
        (_controlMCUSlugsMKIIMachineNumber_,chartInstance->chartNumber,
         chartInstance->instanceNumber);
    }
  }
}

static void sf_opaque_initialize_c4_controlMCUSlugsMKII(void *chartInstanceVar)
{
  chart_debug_initialization(((SFc4_controlMCUSlugsMKIIInstanceStruct*)
    chartInstanceVar)->S,0);
  initialize_params_c4_controlMCUSlugsMKII
    ((SFc4_controlMCUSlugsMKIIInstanceStruct*) chartInstanceVar);
  initialize_c4_controlMCUSlugsMKII((SFc4_controlMCUSlugsMKIIInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_enable_c4_controlMCUSlugsMKII(void *chartInstanceVar)
{
  enable_c4_controlMCUSlugsMKII((SFc4_controlMCUSlugsMKIIInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_disable_c4_controlMCUSlugsMKII(void *chartInstanceVar)
{
  disable_c4_controlMCUSlugsMKII((SFc4_controlMCUSlugsMKIIInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_gateway_c4_controlMCUSlugsMKII(void *chartInstanceVar)
{
  sf_c4_controlMCUSlugsMKII((SFc4_controlMCUSlugsMKIIInstanceStruct*)
    chartInstanceVar);
}

static mxArray* sf_internal_get_sim_state_c4_controlMCUSlugsMKII(SimStruct* S)
{
  ChartInfoStruct *chartInfo = (ChartInfoStruct*) ssGetUserData(S);
  mxArray *plhs[1] = { NULL };

  mxArray *prhs[4];
  int mxError = 0;
  prhs[0] = mxCreateString("chart_simctx_raw2high");
  prhs[1] = mxCreateDoubleScalar(ssGetSFuncBlockHandle(S));
  prhs[2] = (mxArray*) get_sim_state_c4_controlMCUSlugsMKII
    ((SFc4_controlMCUSlugsMKIIInstanceStruct*)chartInfo->chartInstance);/* raw sim ctx */
  prhs[3] = sf_get_sim_state_info_c4_controlMCUSlugsMKII();/* state var info */
  mxError = sf_mex_call_matlab(1, plhs, 4, prhs, "sfprivate");
  mxDestroyArray(prhs[0]);
  mxDestroyArray(prhs[1]);
  mxDestroyArray(prhs[2]);
  mxDestroyArray(prhs[3]);
  if (mxError || plhs[0] == NULL) {
    sf_mex_error_message("Stateflow Internal Error: \nError calling 'chart_simctx_raw2high'.\n");
  }

  return plhs[0];
}

static void sf_internal_set_sim_state_c4_controlMCUSlugsMKII(SimStruct* S, const
  mxArray *st)
{
  ChartInfoStruct *chartInfo = (ChartInfoStruct*) ssGetUserData(S);
  mxArray *plhs[1] = { NULL };

  mxArray *prhs[4];
  int mxError = 0;
  prhs[0] = mxCreateString("chart_simctx_high2raw");
  prhs[1] = mxCreateDoubleScalar(ssGetSFuncBlockHandle(S));
  prhs[2] = mxDuplicateArray(st);      /* high level simctx */
  prhs[3] = (mxArray*) sf_get_sim_state_info_c4_controlMCUSlugsMKII();/* state var info */
  mxError = sf_mex_call_matlab(1, plhs, 4, prhs, "sfprivate");
  mxDestroyArray(prhs[0]);
  mxDestroyArray(prhs[1]);
  mxDestroyArray(prhs[2]);
  mxDestroyArray(prhs[3]);
  if (mxError || plhs[0] == NULL) {
    sf_mex_error_message("Stateflow Internal Error: \nError calling 'chart_simctx_high2raw'.\n");
  }

  set_sim_state_c4_controlMCUSlugsMKII((SFc4_controlMCUSlugsMKIIInstanceStruct*)
    chartInfo->chartInstance, mxDuplicateArray(plhs[0]));
  mxDestroyArray(plhs[0]);
}

static mxArray* sf_opaque_get_sim_state_c4_controlMCUSlugsMKII(SimStruct* S)
{
  return sf_internal_get_sim_state_c4_controlMCUSlugsMKII(S);
}

static void sf_opaque_set_sim_state_c4_controlMCUSlugsMKII(SimStruct* S, const
  mxArray *st)
{
  sf_internal_set_sim_state_c4_controlMCUSlugsMKII(S, st);
}

static void sf_opaque_terminate_c4_controlMCUSlugsMKII(void *chartInstanceVar)
{
  if (chartInstanceVar!=NULL) {
    SimStruct *S = ((SFc4_controlMCUSlugsMKIIInstanceStruct*) chartInstanceVar
      )->S;
    if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
      sf_clear_rtw_identifier(S);
    }

    finalize_c4_controlMCUSlugsMKII((SFc4_controlMCUSlugsMKIIInstanceStruct*)
      chartInstanceVar);
    free((void *)chartInstanceVar);
    ssSetUserData(S,NULL);
  }
}

extern unsigned int sf_machine_global_initializer_called(void);
static void mdlProcessParameters_c4_controlMCUSlugsMKII(SimStruct *S)
{
  int i;
  for (i=0;i<ssGetNumRunTimeParams(S);i++) {
    if (ssGetSFcnParamTunable(S,i)) {
      ssUpdateDlgParamAsRunTimeParam(S,i);
    }
  }

  if (sf_machine_global_initializer_called()) {
    initialize_params_c4_controlMCUSlugsMKII
      ((SFc4_controlMCUSlugsMKIIInstanceStruct*)(((ChartInfoStruct *)
         ssGetUserData(S))->chartInstance));
  }
}

static void mdlSetWorkWidths_c4_controlMCUSlugsMKII(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
    int_T chartIsInlinable =
      (int_T)sf_is_chart_inlinable("controlMCUSlugsMKII","controlMCUSlugsMKII",4);
    ssSetStateflowIsInlinable(S,chartIsInlinable);
    ssSetRTWCG(S,sf_rtw_info_uint_prop("controlMCUSlugsMKII",
                "controlMCUSlugsMKII",4,"RTWCG"));
    ssSetEnableFcnIsTrivial(S,1);
    ssSetDisableFcnIsTrivial(S,1);
    ssSetNotMultipleInlinable(S,sf_rtw_info_uint_prop("controlMCUSlugsMKII",
      "controlMCUSlugsMKII",4,"gatewayCannotBeInlinedMultipleTimes"));
    if (chartIsInlinable) {
      ssSetInputPortOptimOpts(S, 0, SS_REUSABLE_AND_LOCAL);
      sf_mark_chart_expressionable_inputs(S,"controlMCUSlugsMKII",
        "controlMCUSlugsMKII",4,1);
      sf_mark_chart_reusable_outputs(S,"controlMCUSlugsMKII",
        "controlMCUSlugsMKII",4,1);
    }

    sf_set_rtw_dwork_info(S,"controlMCUSlugsMKII","controlMCUSlugsMKII",4);
    ssSetHasSubFunctions(S,!(chartIsInlinable));
    ssSetOptions(S,ssGetOptions(S)|SS_OPTION_WORKS_WITH_CODE_REUSE);
  }

  ssSetChecksum0(S,(3695902711U));
  ssSetChecksum1(S,(3275118431U));
  ssSetChecksum2(S,(1593227314U));
  ssSetChecksum3(S,(1624611914U));
  ssSetmdlDerivatives(S, NULL);
  ssSetExplicitFCSSCtrl(S,1);
}

static void mdlRTW_c4_controlMCUSlugsMKII(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S)) {
    sf_write_symbol_mapping(S, "controlMCUSlugsMKII", "controlMCUSlugsMKII",4);
    ssWriteRTWStrParam(S, "StateflowChartType", "Embedded MATLAB");
  }
}

static void mdlStart_c4_controlMCUSlugsMKII(SimStruct *S)
{
  SFc4_controlMCUSlugsMKIIInstanceStruct *chartInstance;
  chartInstance = (SFc4_controlMCUSlugsMKIIInstanceStruct *)malloc(sizeof
    (SFc4_controlMCUSlugsMKIIInstanceStruct));
  memset(chartInstance, 0, sizeof(SFc4_controlMCUSlugsMKIIInstanceStruct));
  if (chartInstance==NULL) {
    sf_mex_error_message("Could not allocate memory for chart instance.");
  }

  chartInstance->chartInfo.chartInstance = chartInstance;
  chartInstance->chartInfo.isEMLChart = 1;
  chartInstance->chartInfo.chartInitialized = 0;
  chartInstance->chartInfo.sFunctionGateway =
    sf_opaque_gateway_c4_controlMCUSlugsMKII;
  chartInstance->chartInfo.initializeChart =
    sf_opaque_initialize_c4_controlMCUSlugsMKII;
  chartInstance->chartInfo.terminateChart =
    sf_opaque_terminate_c4_controlMCUSlugsMKII;
  chartInstance->chartInfo.enableChart = sf_opaque_enable_c4_controlMCUSlugsMKII;
  chartInstance->chartInfo.disableChart =
    sf_opaque_disable_c4_controlMCUSlugsMKII;
  chartInstance->chartInfo.getSimState =
    sf_opaque_get_sim_state_c4_controlMCUSlugsMKII;
  chartInstance->chartInfo.setSimState =
    sf_opaque_set_sim_state_c4_controlMCUSlugsMKII;
  chartInstance->chartInfo.getSimStateInfo =
    sf_get_sim_state_info_c4_controlMCUSlugsMKII;
  chartInstance->chartInfo.zeroCrossings = NULL;
  chartInstance->chartInfo.outputs = NULL;
  chartInstance->chartInfo.derivatives = NULL;
  chartInstance->chartInfo.mdlRTW = mdlRTW_c4_controlMCUSlugsMKII;
  chartInstance->chartInfo.mdlStart = mdlStart_c4_controlMCUSlugsMKII;
  chartInstance->chartInfo.mdlSetWorkWidths =
    mdlSetWorkWidths_c4_controlMCUSlugsMKII;
  chartInstance->chartInfo.extModeExec = NULL;
  chartInstance->chartInfo.restoreLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.restoreBeforeLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.storeCurrentConfiguration = NULL;
  chartInstance->S = S;
  ssSetUserData(S,(void *)(&(chartInstance->chartInfo)));/* register the chart instance with simstruct */
  if (!sim_mode_is_rtw_gen(S)) {
    init_dsm_address_info(chartInstance);
  }

  chart_debug_initialization(S,1);
}

void c4_controlMCUSlugsMKII_method_dispatcher(SimStruct *S, int_T method, void
  *data)
{
  switch (method) {
   case SS_CALL_MDL_START:
    mdlStart_c4_controlMCUSlugsMKII(S);
    break;

   case SS_CALL_MDL_SET_WORK_WIDTHS:
    mdlSetWorkWidths_c4_controlMCUSlugsMKII(S);
    break;

   case SS_CALL_MDL_PROCESS_PARAMETERS:
    mdlProcessParameters_c4_controlMCUSlugsMKII(S);
    break;

   default:
    /* Unhandled method */
    sf_mex_error_message("Stateflow Internal Error:\n"
                         "Error calling c4_controlMCUSlugsMKII_method_dispatcher.\n"
                         "Can't handle method %d.\n", method);
    break;
  }
}
