#ifndef __c36_controlMCUSlugsMKII_h__
#define __c36_controlMCUSlugsMKII_h__

/* Include files */
#include "sfc_sf.h"
#include "sfc_mex.h"
#include "rtwtypes.h"

/* Type Definitions */
typedef struct {
  const char *context;
  const char *name;
  const char *dominantType;
  const char *resolved;
  uint32_T fileLength;
  uint32_T fileTime1;
  uint32_T fileTime2;
} c36_ResolvedFunctionInfo;

typedef struct {
  SimStruct *S;
  uint32_T chartNumber;
  uint32_T instanceNumber;
  boolean_T c36_doneDoubleBufferReInit;
  boolean_T c36_isStable;
  uint8_T c36_is_active_c36_controlMCUSlugsMKII;
  ChartInfoStruct chartInfo;
} SFc36_controlMCUSlugsMKIIInstanceStruct;

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */

/* Function Declarations */
extern const mxArray *sf_c36_controlMCUSlugsMKII_get_eml_resolved_functions_info
  (void);

/* Function Definitions */
extern void sf_c36_controlMCUSlugsMKII_get_check_sum(mxArray *plhs[]);
extern void c36_controlMCUSlugsMKII_method_dispatcher(SimStruct *S, int_T method,
  void *data);

#endif
