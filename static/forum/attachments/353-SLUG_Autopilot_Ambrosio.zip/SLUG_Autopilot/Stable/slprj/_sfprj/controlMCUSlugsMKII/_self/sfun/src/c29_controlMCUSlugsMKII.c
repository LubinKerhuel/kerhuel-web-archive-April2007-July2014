/* Include files */

#include "blascompat32.h"
#include "controlMCUSlugsMKII_sfun.h"
#include "c29_controlMCUSlugsMKII.h"

/* Type Definitions */

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */

/* Function Declarations */
static void initialize_c29_controlMCUSlugsMKII
  (SFc29_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void initialize_params_c29_controlMCUSlugsMKII
  (SFc29_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void enable_c29_controlMCUSlugsMKII
  (SFc29_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void disable_c29_controlMCUSlugsMKII
  (SFc29_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static const mxArray *get_sim_state_c29_controlMCUSlugsMKII
  (SFc29_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void set_sim_state_c29_controlMCUSlugsMKII
  (SFc29_controlMCUSlugsMKIIInstanceStruct *chartInstance, const mxArray *c29_st);
static void finalize_c29_controlMCUSlugsMKII
  (SFc29_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void sf_c29_controlMCUSlugsMKII(SFc29_controlMCUSlugsMKIIInstanceStruct
  *chartInstance);
static void init_script_number_translation(uint32_T c29_machineNumber, uint32_T
  c29_chartNumber);
static void c29_emlrt_marshallIn(SFc29_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c29_y, const char_T *c29_name, real32_T
  c29_b_y[6]);
static uint8_T c29_b_emlrt_marshallIn(SFc29_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c29_b_is_active_c29_controlMCUSlugsMKII, const
  char_T *c29_name);
static void init_dsm_address_info(SFc29_controlMCUSlugsMKIIInstanceStruct
  *chartInstance);

/* Function Definitions */
static void initialize_c29_controlMCUSlugsMKII
  (SFc29_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
  chartInstance->c29_is_active_c29_controlMCUSlugsMKII = 0U;
}

static void initialize_params_c29_controlMCUSlugsMKII
  (SFc29_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
}

static void enable_c29_controlMCUSlugsMKII
  (SFc29_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
}

static void disable_c29_controlMCUSlugsMKII
  (SFc29_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
}

static const mxArray *get_sim_state_c29_controlMCUSlugsMKII
  (SFc29_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
  const mxArray *c29_st;
  const mxArray *c29_y = NULL;
  int32_T c29_i0;
  real32_T c29_u[6];
  const mxArray *c29_b_y = NULL;
  uint8_T c29_b_u;
  const mxArray *c29_c_y = NULL;
  real32_T (*c29_d_y)[6];
  c29_d_y = (real32_T (*)[6])ssGetOutputPortSignal(chartInstance->S, 1);
  c29_st = NULL;
  c29_st = NULL;
  c29_y = NULL;
  sf_mex_assign(&c29_y, sf_mex_createcellarray(2));
  for (c29_i0 = 0; c29_i0 < 6; c29_i0 = c29_i0 + 1) {
    c29_u[c29_i0] = (*c29_d_y)[c29_i0];
  }

  c29_b_y = NULL;
  sf_mex_assign(&c29_b_y, sf_mex_create("y", &c29_u, 1, 0U, 1U, 0U, 1, 6));
  sf_mex_setcell(c29_y, 0, c29_b_y);
  c29_b_u = chartInstance->c29_is_active_c29_controlMCUSlugsMKII;
  c29_c_y = NULL;
  sf_mex_assign(&c29_c_y, sf_mex_create("y", &c29_b_u, 3, 0U, 0U, 0U, 0));
  sf_mex_setcell(c29_y, 1, c29_c_y);
  sf_mex_assign(&c29_st, c29_y);
  return c29_st;
}

static void set_sim_state_c29_controlMCUSlugsMKII
  (SFc29_controlMCUSlugsMKIIInstanceStruct *chartInstance, const mxArray *c29_st)
{
  const mxArray *c29_u;
  real32_T c29_fv0[6];
  int32_T c29_i1;
  real32_T (*c29_y)[6];
  c29_y = (real32_T (*)[6])ssGetOutputPortSignal(chartInstance->S, 1);
  c29_u = sf_mex_dup(c29_st);
  c29_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(c29_u, 0)), "y",
                       c29_fv0);
  for (c29_i1 = 0; c29_i1 < 6; c29_i1 = c29_i1 + 1) {
    (*c29_y)[c29_i1] = c29_fv0[c29_i1];
  }

  chartInstance->c29_is_active_c29_controlMCUSlugsMKII = c29_b_emlrt_marshallIn
    (chartInstance, sf_mex_dup(sf_mex_getcell(c29_u, 1)),
     "is_active_c29_controlMCUSlugsMKII");
  sf_mex_destroy(&c29_u);
  sf_mex_destroy(&c29_st);
}

static void finalize_c29_controlMCUSlugsMKII
  (SFc29_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
}

static void sf_c29_controlMCUSlugsMKII(SFc29_controlMCUSlugsMKIIInstanceStruct
  *chartInstance)
{
  int32_T c29_i2;
  real32_T (*c29_y)[6];
  real32_T (*c29_u2)[3];
  real32_T (*c29_u1)[3];
  c29_u2 = (real32_T (*)[3])ssGetInputPortSignal(chartInstance->S, 1);
  c29_y = (real32_T (*)[6])ssGetOutputPortSignal(chartInstance->S, 1);
  c29_u1 = (real32_T (*)[3])ssGetInputPortSignal(chartInstance->S, 0);
  _sfTime_ = (real_T)ssGetT(chartInstance->S);

  /*  This block supports an embeddable subset of the MATLAB language. */
  /*  See the help menu for details.  */
  for (c29_i2 = 0; c29_i2 < 3; c29_i2 = c29_i2 + 1) {
    (*c29_y)[c29_i2] = (*c29_u1)[c29_i2];
  }

  for (c29_i2 = 0; c29_i2 < 3; c29_i2 = c29_i2 + 1) {
    (*c29_y)[c29_i2 + 3] = (*c29_u2)[c29_i2];
  }
}

static void init_script_number_translation(uint32_T c29_machineNumber, uint32_T
  c29_chartNumber)
{
}

const mxArray *sf_c29_controlMCUSlugsMKII_get_eml_resolved_functions_info(void)
{
  const mxArray *c29_nameCaptureInfo = NULL;
  c29_nameCaptureInfo = NULL;
  sf_mex_assign(&c29_nameCaptureInfo, sf_mex_create("nameCaptureInfo", NULL, 0,
    0U, 1U, 0U, 2, 0, 1));
  return c29_nameCaptureInfo;
}

static void c29_emlrt_marshallIn(SFc29_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c29_y, const char_T *
  c29_name, real32_T c29_b_y[6])
{
  real32_T c29_fv1[6];
  int32_T c29_i3;
  sf_mex_import(c29_name, sf_mex_dup(c29_y), &c29_fv1, 1, 1, 0U, 1, 0U, 1, 6);
  for (c29_i3 = 0; c29_i3 < 6; c29_i3 = c29_i3 + 1) {
    c29_b_y[c29_i3] = c29_fv1[c29_i3];
  }

  sf_mex_destroy(&c29_y);
}

static uint8_T c29_b_emlrt_marshallIn(SFc29_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *
  c29_b_is_active_c29_controlMCUSlugsMKII, const char_T *c29_name)
{
  uint8_T c29_y;
  uint8_T c29_u0;
  sf_mex_import(c29_name, sf_mex_dup(c29_b_is_active_c29_controlMCUSlugsMKII),
                &c29_u0, 1, 3, 0U, 0, 0U, 0);
  c29_y = c29_u0;
  sf_mex_destroy(&c29_b_is_active_c29_controlMCUSlugsMKII);
  return c29_y;
}

static void init_dsm_address_info(SFc29_controlMCUSlugsMKIIInstanceStruct
  *chartInstance)
{
}

/* SFunction Glue Code */
void sf_c29_controlMCUSlugsMKII_get_check_sum(mxArray *plhs[])
{
  ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(2951515456U);
  ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(4031799813U);
  ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(2864675784U);
  ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(1494798133U);
}

mxArray *sf_c29_controlMCUSlugsMKII_get_autoinheritance_info(void)
{
  const char *autoinheritanceFields[] = { "checksum", "inputs", "parameters",
    "outputs" };

  mxArray *mxAutoinheritanceInfo = mxCreateStructMatrix(1,1,4,
    autoinheritanceFields);

  {
    mxArray *mxChecksum = mxCreateDoubleMatrix(4,1,mxREAL);
    double *pr = mxGetPr(mxChecksum);
    pr[0] = (double)(925195676U);
    pr[1] = (double)(3685885104U);
    pr[2] = (double)(1802236966U);
    pr[3] = (double)(1480283553U);
    mxSetField(mxAutoinheritanceInfo,0,"checksum",mxChecksum);
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,2,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(3);
      pr[1] = (double)(1);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(9));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(3);
      pr[1] = (double)(1);
      mxSetField(mxData,1,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(9));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,1,"type",mxType);
    }

    mxSetField(mxData,1,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"inputs",mxData);
  }

  {
    mxSetField(mxAutoinheritanceInfo,0,"parameters",mxCreateDoubleMatrix(0,0,
                mxREAL));
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,1,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(6);
      pr[1] = (double)(1);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(9));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"outputs",mxData);
  }

  return(mxAutoinheritanceInfo);
}

static mxArray *sf_get_sim_state_info_c29_controlMCUSlugsMKII(void)
{
  const char *infoFields[] = { "chartChecksum", "varInfo" };

  mxArray *mxInfo = mxCreateStructMatrix(1, 1, 2, infoFields);
  const char *infoEncStr[] = {
    "100 S1x2'type','srcId','name','auxInfo'{{M[1],M[5],T\"y\",},{M[8],M[0],T\"is_active_c29_controlMCUSlugsMKII\",}}"
  };

  mxArray *mxVarInfo = sf_mex_decode_encoded_mx_struct_array(infoEncStr, 2, 10);
  mxArray *mxChecksum = mxCreateDoubleMatrix(1, 4, mxREAL);
  sf_c29_controlMCUSlugsMKII_get_check_sum(&mxChecksum);
  mxSetField(mxInfo, 0, infoFields[0], mxChecksum);
  mxSetField(mxInfo, 0, infoFields[1], mxVarInfo);
  return mxInfo;
}

static void sf_opaque_initialize_c29_controlMCUSlugsMKII(void *chartInstanceVar)
{
  initialize_params_c29_controlMCUSlugsMKII
    ((SFc29_controlMCUSlugsMKIIInstanceStruct*) chartInstanceVar);
  initialize_c29_controlMCUSlugsMKII((SFc29_controlMCUSlugsMKIIInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_enable_c29_controlMCUSlugsMKII(void *chartInstanceVar)
{
  enable_c29_controlMCUSlugsMKII((SFc29_controlMCUSlugsMKIIInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_disable_c29_controlMCUSlugsMKII(void *chartInstanceVar)
{
  disable_c29_controlMCUSlugsMKII((SFc29_controlMCUSlugsMKIIInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_gateway_c29_controlMCUSlugsMKII(void *chartInstanceVar)
{
  sf_c29_controlMCUSlugsMKII((SFc29_controlMCUSlugsMKIIInstanceStruct*)
    chartInstanceVar);
}

static mxArray* sf_internal_get_sim_state_c29_controlMCUSlugsMKII(SimStruct* S)
{
  ChartInfoStruct *chartInfo = (ChartInfoStruct*) ssGetUserData(S);
  mxArray *plhs[1] = { NULL };

  mxArray *prhs[4];
  int mxError = 0;
  prhs[0] = mxCreateString("chart_simctx_raw2high");
  prhs[1] = mxCreateDoubleScalar(ssGetSFuncBlockHandle(S));
  prhs[2] = (mxArray*) get_sim_state_c29_controlMCUSlugsMKII
    ((SFc29_controlMCUSlugsMKIIInstanceStruct*)chartInfo->chartInstance);/* raw sim ctx */
  prhs[3] = sf_get_sim_state_info_c29_controlMCUSlugsMKII();/* state var info */
  mxError = sf_mex_call_matlab(1, plhs, 4, prhs, "sfprivate");
  mxDestroyArray(prhs[0]);
  mxDestroyArray(prhs[1]);
  mxDestroyArray(prhs[2]);
  mxDestroyArray(prhs[3]);
  if (mxError || plhs[0] == NULL) {
    sf_mex_error_message("Stateflow Internal Error: \nError calling 'chart_simctx_raw2high'.\n");
  }

  return plhs[0];
}

static void sf_internal_set_sim_state_c29_controlMCUSlugsMKII(SimStruct* S,
  const mxArray *st)
{
  ChartInfoStruct *chartInfo = (ChartInfoStruct*) ssGetUserData(S);
  mxArray *plhs[1] = { NULL };

  mxArray *prhs[4];
  int mxError = 0;
  prhs[0] = mxCreateString("chart_simctx_high2raw");
  prhs[1] = mxCreateDoubleScalar(ssGetSFuncBlockHandle(S));
  prhs[2] = mxDuplicateArray(st);      /* high level simctx */
  prhs[3] = (mxArray*) sf_get_sim_state_info_c29_controlMCUSlugsMKII();/* state var info */
  mxError = sf_mex_call_matlab(1, plhs, 4, prhs, "sfprivate");
  mxDestroyArray(prhs[0]);
  mxDestroyArray(prhs[1]);
  mxDestroyArray(prhs[2]);
  mxDestroyArray(prhs[3]);
  if (mxError || plhs[0] == NULL) {
    sf_mex_error_message("Stateflow Internal Error: \nError calling 'chart_simctx_high2raw'.\n");
  }

  set_sim_state_c29_controlMCUSlugsMKII((SFc29_controlMCUSlugsMKIIInstanceStruct*)
    chartInfo->chartInstance, mxDuplicateArray(plhs[0]));
  mxDestroyArray(plhs[0]);
}

static mxArray* sf_opaque_get_sim_state_c29_controlMCUSlugsMKII(SimStruct* S)
{
  return sf_internal_get_sim_state_c29_controlMCUSlugsMKII(S);
}

static void sf_opaque_set_sim_state_c29_controlMCUSlugsMKII(SimStruct* S, const
  mxArray *st)
{
  sf_internal_set_sim_state_c29_controlMCUSlugsMKII(S, st);
}

static void sf_opaque_terminate_c29_controlMCUSlugsMKII(void *chartInstanceVar)
{
  if (chartInstanceVar!=NULL) {
    SimStruct *S = ((SFc29_controlMCUSlugsMKIIInstanceStruct*) chartInstanceVar
      )->S;
    if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
      sf_clear_rtw_identifier(S);
    }

    finalize_c29_controlMCUSlugsMKII((SFc29_controlMCUSlugsMKIIInstanceStruct*)
      chartInstanceVar);
    free((void *)chartInstanceVar);
    ssSetUserData(S,NULL);
  }
}

extern unsigned int sf_machine_global_initializer_called(void);
static void mdlProcessParameters_c29_controlMCUSlugsMKII(SimStruct *S)
{
  int i;
  for (i=0;i<ssGetNumRunTimeParams(S);i++) {
    if (ssGetSFcnParamTunable(S,i)) {
      ssUpdateDlgParamAsRunTimeParam(S,i);
    }
  }

  if (sf_machine_global_initializer_called()) {
    initialize_params_c29_controlMCUSlugsMKII
      ((SFc29_controlMCUSlugsMKIIInstanceStruct*)(((ChartInfoStruct *)
         ssGetUserData(S))->chartInstance));
  }
}

static void mdlSetWorkWidths_c29_controlMCUSlugsMKII(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
    int_T chartIsInlinable =
      (int_T)sf_is_chart_inlinable("controlMCUSlugsMKII","controlMCUSlugsMKII",
      29);
    ssSetStateflowIsInlinable(S,chartIsInlinable);
    ssSetRTWCG(S,sf_rtw_info_uint_prop("controlMCUSlugsMKII",
                "controlMCUSlugsMKII",29,"RTWCG"));
    ssSetEnableFcnIsTrivial(S,1);
    ssSetDisableFcnIsTrivial(S,1);
    ssSetNotMultipleInlinable(S,sf_rtw_info_uint_prop("controlMCUSlugsMKII",
      "controlMCUSlugsMKII",29,"gatewayCannotBeInlinedMultipleTimes"));
    if (chartIsInlinable) {
      ssSetInputPortOptimOpts(S, 0, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 1, SS_REUSABLE_AND_LOCAL);
      sf_mark_chart_expressionable_inputs(S,"controlMCUSlugsMKII",
        "controlMCUSlugsMKII",29,2);
      sf_mark_chart_reusable_outputs(S,"controlMCUSlugsMKII",
        "controlMCUSlugsMKII",29,1);
    }

    sf_set_rtw_dwork_info(S,"controlMCUSlugsMKII","controlMCUSlugsMKII",29);
    ssSetHasSubFunctions(S,!(chartIsInlinable));
    ssSetOptions(S,ssGetOptions(S)|SS_OPTION_WORKS_WITH_CODE_REUSE);
  }

  ssSetChecksum0(S,(2288527514U));
  ssSetChecksum1(S,(2464534531U));
  ssSetChecksum2(S,(883731235U));
  ssSetChecksum3(S,(3510084233U));
  ssSetmdlDerivatives(S, NULL);
  ssSetExplicitFCSSCtrl(S,1);
}

static void mdlRTW_c29_controlMCUSlugsMKII(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S)) {
    sf_write_symbol_mapping(S, "controlMCUSlugsMKII", "controlMCUSlugsMKII",29);
    ssWriteRTWStrParam(S, "StateflowChartType", "Embedded MATLAB");
  }
}

static void mdlStart_c29_controlMCUSlugsMKII(SimStruct *S)
{
  SFc29_controlMCUSlugsMKIIInstanceStruct *chartInstance;
  chartInstance = (SFc29_controlMCUSlugsMKIIInstanceStruct *)malloc(sizeof
    (SFc29_controlMCUSlugsMKIIInstanceStruct));
  memset(chartInstance, 0, sizeof(SFc29_controlMCUSlugsMKIIInstanceStruct));
  if (chartInstance==NULL) {
    sf_mex_error_message("Could not allocate memory for chart instance.");
  }

  chartInstance->chartInfo.chartInstance = chartInstance;
  chartInstance->chartInfo.isEMLChart = 1;
  chartInstance->chartInfo.chartInitialized = 0;
  chartInstance->chartInfo.sFunctionGateway =
    sf_opaque_gateway_c29_controlMCUSlugsMKII;
  chartInstance->chartInfo.initializeChart =
    sf_opaque_initialize_c29_controlMCUSlugsMKII;
  chartInstance->chartInfo.terminateChart =
    sf_opaque_terminate_c29_controlMCUSlugsMKII;
  chartInstance->chartInfo.enableChart =
    sf_opaque_enable_c29_controlMCUSlugsMKII;
  chartInstance->chartInfo.disableChart =
    sf_opaque_disable_c29_controlMCUSlugsMKII;
  chartInstance->chartInfo.getSimState =
    sf_opaque_get_sim_state_c29_controlMCUSlugsMKII;
  chartInstance->chartInfo.setSimState =
    sf_opaque_set_sim_state_c29_controlMCUSlugsMKII;
  chartInstance->chartInfo.getSimStateInfo =
    sf_get_sim_state_info_c29_controlMCUSlugsMKII;
  chartInstance->chartInfo.zeroCrossings = NULL;
  chartInstance->chartInfo.outputs = NULL;
  chartInstance->chartInfo.derivatives = NULL;
  chartInstance->chartInfo.mdlRTW = mdlRTW_c29_controlMCUSlugsMKII;
  chartInstance->chartInfo.mdlStart = mdlStart_c29_controlMCUSlugsMKII;
  chartInstance->chartInfo.mdlSetWorkWidths =
    mdlSetWorkWidths_c29_controlMCUSlugsMKII;
  chartInstance->chartInfo.extModeExec = NULL;
  chartInstance->chartInfo.restoreLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.restoreBeforeLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.storeCurrentConfiguration = NULL;
  chartInstance->S = S;
  ssSetUserData(S,(void *)(&(chartInstance->chartInfo)));/* register the chart instance with simstruct */
  if (!sim_mode_is_rtw_gen(S)) {
    init_dsm_address_info(chartInstance);
  }
}

void c29_controlMCUSlugsMKII_method_dispatcher(SimStruct *S, int_T method, void *
  data)
{
  switch (method) {
   case SS_CALL_MDL_START:
    mdlStart_c29_controlMCUSlugsMKII(S);
    break;

   case SS_CALL_MDL_SET_WORK_WIDTHS:
    mdlSetWorkWidths_c29_controlMCUSlugsMKII(S);
    break;

   case SS_CALL_MDL_PROCESS_PARAMETERS:
    mdlProcessParameters_c29_controlMCUSlugsMKII(S);
    break;

   default:
    /* Unhandled method */
    sf_mex_error_message("Stateflow Internal Error:\n"
                         "Error calling c29_controlMCUSlugsMKII_method_dispatcher.\n"
                         "Can't handle method %d.\n", method);
    break;
  }
}
