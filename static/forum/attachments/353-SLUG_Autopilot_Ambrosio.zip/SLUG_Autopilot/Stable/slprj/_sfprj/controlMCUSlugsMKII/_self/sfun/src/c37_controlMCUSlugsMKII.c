/* Include files */

#include "blascompat32.h"
#include "controlMCUSlugsMKII_sfun.h"
#include "c37_controlMCUSlugsMKII.h"
#define CHARTINSTANCE_CHARTNUMBER      (chartInstance->chartNumber)
#define CHARTINSTANCE_INSTANCENUMBER   (chartInstance->instanceNumber)
#include "controlMCUSlugsMKII_sfun_debug_macros.h"

/* Type Definitions */

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */
static const char *c37_debug_family_names[11] = { "omega", "nargin", "nargout",
  "u", "T", "f", "y", "a", "b", "y_km1", "u_km1" };

/* Function Declarations */
static void initialize_c37_controlMCUSlugsMKII
  (SFc37_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void initialize_params_c37_controlMCUSlugsMKII
  (SFc37_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void enable_c37_controlMCUSlugsMKII
  (SFc37_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void disable_c37_controlMCUSlugsMKII
  (SFc37_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void c37_update_debugger_state_c37_controlMCUSlugsMKII
  (SFc37_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static const mxArray *get_sim_state_c37_controlMCUSlugsMKII
  (SFc37_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void set_sim_state_c37_controlMCUSlugsMKII
  (SFc37_controlMCUSlugsMKIIInstanceStruct *chartInstance, const mxArray *c37_st);
static void finalize_c37_controlMCUSlugsMKII
  (SFc37_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void sf_c37_controlMCUSlugsMKII(SFc37_controlMCUSlugsMKIIInstanceStruct
  *chartInstance);
static void init_script_number_translation(uint32_T c37_machineNumber, uint32_T
  c37_chartNumber);
static const mxArray *c37_sf_marshall(void *chartInstanceVoid, void *c37_u);
static const mxArray *c37_b_sf_marshall(void *chartInstanceVoid, void *c37_u);
static const mxArray *c37_c_sf_marshall(void *chartInstanceVoid, void *c37_u);
static const mxArray *c37_d_sf_marshall(void *chartInstanceVoid, void *c37_u);
static const mxArray *c37_e_sf_marshall(void *chartInstanceVoid, void *c37_u);
static const mxArray *c37_f_sf_marshall(void *chartInstanceVoid, void *c37_u);
static void c37_info_helper(c37_ResolvedFunctionInfo c37_info[20]);
static const mxArray *c37_g_sf_marshall(void *chartInstanceVoid, void *c37_u);
static real32_T c37_emlrt_marshallIn(SFc37_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c37_y, const char_T *c37_name);
static real_T c37_b_emlrt_marshallIn(SFc37_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c37_b_a, const char_T *c37_name);
static real_T c37_c_emlrt_marshallIn(SFc37_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c37_b_b, const char_T *c37_name);
static real32_T c37_d_emlrt_marshallIn(SFc37_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c37_b_u_km1, const char_T *c37_name);
static real32_T c37_e_emlrt_marshallIn(SFc37_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c37_b_y_km1, const char_T *c37_name);
static uint8_T c37_f_emlrt_marshallIn(SFc37_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c37_b_is_active_c37_controlMCUSlugsMKII, const
  char_T *c37_name);
static void init_dsm_address_info(SFc37_controlMCUSlugsMKIIInstanceStruct
  *chartInstance);

/* Function Definitions */
static void initialize_c37_controlMCUSlugsMKII
  (SFc37_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
  chartInstance->c37_a_not_empty = FALSE;
  chartInstance->c37_b_not_empty = FALSE;
  chartInstance->c37_y_km1_not_empty = FALSE;
  chartInstance->c37_u_km1_not_empty = FALSE;
  chartInstance->c37_is_active_c37_controlMCUSlugsMKII = 0U;
}

static void initialize_params_c37_controlMCUSlugsMKII
  (SFc37_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
}

static void enable_c37_controlMCUSlugsMKII
  (SFc37_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
}

static void disable_c37_controlMCUSlugsMKII
  (SFc37_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
}

static void c37_update_debugger_state_c37_controlMCUSlugsMKII
  (SFc37_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
}

static const mxArray *get_sim_state_c37_controlMCUSlugsMKII
  (SFc37_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
  const mxArray *c37_st = NULL;
  const mxArray *c37_y = NULL;
  real32_T c37_hoistedGlobal;
  real32_T c37_u;
  const mxArray *c37_b_y = NULL;
  real_T c37_b_hoistedGlobal;
  real_T c37_b_u;
  const mxArray *c37_c_y = NULL;
  real_T c37_c_hoistedGlobal;
  real_T c37_c_u;
  const mxArray *c37_d_y = NULL;
  real32_T c37_d_hoistedGlobal;
  real32_T c37_d_u;
  const mxArray *c37_e_y = NULL;
  real32_T c37_e_hoistedGlobal;
  real32_T c37_e_u;
  const mxArray *c37_f_y = NULL;
  uint8_T c37_f_hoistedGlobal;
  uint8_T c37_f_u;
  const mxArray *c37_g_y = NULL;
  real32_T *c37_h_y;
  c37_h_y = (real32_T *)ssGetOutputPortSignal(chartInstance->S, 1);
  c37_st = NULL;
  c37_y = NULL;
  sf_mex_assign(&c37_y, sf_mex_createcellarray(6));
  c37_hoistedGlobal = *c37_h_y;
  c37_u = c37_hoistedGlobal;
  c37_b_y = NULL;
  sf_mex_assign(&c37_b_y, sf_mex_create("y", &c37_u, 1, 0U, 0U, 0U, 0));
  sf_mex_setcell(c37_y, 0, c37_b_y);
  c37_b_hoistedGlobal = chartInstance->c37_a;
  c37_b_u = c37_b_hoistedGlobal;
  c37_c_y = NULL;
  if (!chartInstance->c37_a_not_empty) {
    sf_mex_assign(&c37_c_y, sf_mex_create("y", NULL, 0, 0U, 1U, 0U, 2, 0, 0));
  } else {
    sf_mex_assign(&c37_c_y, sf_mex_create("y", &c37_b_u, 0, 0U, 0U, 0U, 0));
  }

  sf_mex_setcell(c37_y, 1, c37_c_y);
  c37_c_hoistedGlobal = chartInstance->c37_b;
  c37_c_u = c37_c_hoistedGlobal;
  c37_d_y = NULL;
  if (!chartInstance->c37_b_not_empty) {
    sf_mex_assign(&c37_d_y, sf_mex_create("y", NULL, 0, 0U, 1U, 0U, 2, 0, 0));
  } else {
    sf_mex_assign(&c37_d_y, sf_mex_create("y", &c37_c_u, 0, 0U, 0U, 0U, 0));
  }

  sf_mex_setcell(c37_y, 2, c37_d_y);
  c37_d_hoistedGlobal = chartInstance->c37_u_km1;
  c37_d_u = c37_d_hoistedGlobal;
  c37_e_y = NULL;
  if (!chartInstance->c37_u_km1_not_empty) {
    sf_mex_assign(&c37_e_y, sf_mex_create("y", NULL, 0, 0U, 1U, 0U, 2, 0, 0));
  } else {
    sf_mex_assign(&c37_e_y, sf_mex_create("y", &c37_d_u, 1, 0U, 0U, 0U, 0));
  }

  sf_mex_setcell(c37_y, 3, c37_e_y);
  c37_e_hoistedGlobal = chartInstance->c37_y_km1;
  c37_e_u = c37_e_hoistedGlobal;
  c37_f_y = NULL;
  if (!chartInstance->c37_y_km1_not_empty) {
    sf_mex_assign(&c37_f_y, sf_mex_create("y", NULL, 0, 0U, 1U, 0U, 2, 0, 0));
  } else {
    sf_mex_assign(&c37_f_y, sf_mex_create("y", &c37_e_u, 1, 0U, 0U, 0U, 0));
  }

  sf_mex_setcell(c37_y, 4, c37_f_y);
  c37_f_hoistedGlobal = chartInstance->c37_is_active_c37_controlMCUSlugsMKII;
  c37_f_u = c37_f_hoistedGlobal;
  c37_g_y = NULL;
  sf_mex_assign(&c37_g_y, sf_mex_create("y", &c37_f_u, 3, 0U, 0U, 0U, 0));
  sf_mex_setcell(c37_y, 5, c37_g_y);
  sf_mex_assign(&c37_st, c37_y);
  return c37_st;
}

static void set_sim_state_c37_controlMCUSlugsMKII
  (SFc37_controlMCUSlugsMKIIInstanceStruct *chartInstance, const mxArray *c37_st)
{
  const mxArray *c37_u;
  real32_T *c37_y;
  c37_y = (real32_T *)ssGetOutputPortSignal(chartInstance->S, 1);
  chartInstance->c37_doneDoubleBufferReInit = TRUE;
  c37_u = sf_mex_dup(c37_st);
  *c37_y = c37_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(c37_u,
    0)), "y");
  chartInstance->c37_a = c37_b_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getcell(c37_u, 1)), "a");
  chartInstance->c37_b = c37_c_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getcell(c37_u, 2)), "b");
  chartInstance->c37_u_km1 = c37_d_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getcell(c37_u, 3)), "u_km1");
  chartInstance->c37_y_km1 = c37_e_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getcell(c37_u, 4)), "y_km1");
  chartInstance->c37_is_active_c37_controlMCUSlugsMKII = c37_f_emlrt_marshallIn
    (chartInstance, sf_mex_dup(sf_mex_getcell(c37_u, 5)),
     "is_active_c37_controlMCUSlugsMKII");
  sf_mex_destroy(&c37_u);
  c37_update_debugger_state_c37_controlMCUSlugsMKII(chartInstance);
  sf_mex_destroy(&c37_st);
}

static void finalize_c37_controlMCUSlugsMKII
  (SFc37_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
}

static void sf_c37_controlMCUSlugsMKII(SFc37_controlMCUSlugsMKIIInstanceStruct
  *chartInstance)
{
  int32_T c37_previousEvent;
  real32_T c37_hoistedGlobal;
  real_T c37_b_hoistedGlobal;
  real_T c37_c_hoistedGlobal;
  real32_T c37_u;
  real_T c37_T;
  real_T c37_f;
  uint32_T c37_debug_family_var_map[11];
  real_T c37_omega;
  real_T c37_nargin = 3.0;
  real_T c37_nargout = 1.0;
  real32_T c37_y;
  real_T c37_b_b;
  real_T c37_b_a;
  real_T c37_c_b;
  real_T c37_b_y;
  real_T c37_c_a;
  real_T c37_d_b;
  real_T c37_c_y;
  real_T c37_A;
  real_T c37_B;
  real_T c37_x;
  real_T c37_d_y;
  real_T c37_b_x;
  real_T c37_e_y;
  real_T c37_c_x;
  real_T c37_f_y;
  real_T c37_d_a;
  real_T c37_e_b;
  real_T c37_g_y;
  real_T c37_e_a;
  real_T c37_f_b;
  real_T c37_h_y;
  real_T c37_b_A;
  real_T c37_b_B;
  real_T c37_d_x;
  real_T c37_i_y;
  real_T c37_e_x;
  real_T c37_j_y;
  real_T c37_f_x;
  real_T c37_k_y;
  real_T c37_d_hoistedGlobal;
  real32_T c37_e_hoistedGlobal;
  real_T c37_f_a;
  real32_T c37_g_b;
  real32_T c37_l_y;
  real_T c37_f_hoistedGlobal;
  real32_T c37_g_hoistedGlobal;
  real_T c37_g_a;
  real32_T c37_h_b;
  real32_T c37_m_y;
  real32_T *c37_b_u;
  real32_T *c37_n_y;
  real_T *c37_b_T;
  real_T *c37_b_f;
  c37_b_f = (real_T *)ssGetInputPortSignal(chartInstance->S, 2);
  c37_b_T = (real_T *)ssGetInputPortSignal(chartInstance->S, 1);
  c37_n_y = (real32_T *)ssGetOutputPortSignal(chartInstance->S, 1);
  c37_b_u = (real32_T *)ssGetInputPortSignal(chartInstance->S, 0);
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
  _SFD_CC_CALL(CHART_ENTER_SFUNCTION_TAG,36);
  _SFD_DATA_RANGE_CHECK((real_T)*c37_b_u, 0U);
  _SFD_DATA_RANGE_CHECK((real_T)*c37_n_y, 1U);
  _SFD_DATA_RANGE_CHECK(*c37_b_T, 2U);
  _SFD_DATA_RANGE_CHECK(*c37_b_f, 3U);
  c37_previousEvent = _sfEvent_;
  _sfEvent_ = CALL_EVENT;
  _SFD_CC_CALL(CHART_ENTER_DURING_FUNCTION_TAG,36);
  c37_hoistedGlobal = *c37_b_u;
  c37_b_hoistedGlobal = *c37_b_T;
  c37_c_hoistedGlobal = *c37_b_f;
  c37_u = c37_hoistedGlobal;
  c37_T = c37_b_hoistedGlobal;
  c37_f = c37_c_hoistedGlobal;
  sf_debug_symbol_scope_push_eml(0U, 11U, 11U, c37_debug_family_names,
    c37_debug_family_var_map);
  sf_debug_symbol_scope_add_eml(&c37_omega, c37_f_sf_marshall, 0U);
  sf_debug_symbol_scope_add_eml(&c37_nargin, c37_f_sf_marshall, 1U);
  sf_debug_symbol_scope_add_eml(&c37_nargout, c37_f_sf_marshall, 2U);
  sf_debug_symbol_scope_add_eml(&c37_u, c37_e_sf_marshall, 3U);
  sf_debug_symbol_scope_add_eml(&c37_T, c37_f_sf_marshall, 4U);
  sf_debug_symbol_scope_add_eml(&c37_f, c37_f_sf_marshall, 5U);
  sf_debug_symbol_scope_add_eml(&c37_y, c37_e_sf_marshall, 6U);
  sf_debug_symbol_scope_add_eml(&chartInstance->c37_a, c37_d_sf_marshall, 7U);
  sf_debug_symbol_scope_add_eml(&chartInstance->c37_b, c37_c_sf_marshall, 8U);
  sf_debug_symbol_scope_add_eml(&chartInstance->c37_y_km1, c37_b_sf_marshall, 9U);
  sf_debug_symbol_scope_add_eml(&chartInstance->c37_u_km1, c37_sf_marshall, 10U);
  CV_EML_FCN(0, 0);

  /*  This block supports an embeddable subset of the MATLAB language. */
  /*  See the help menu for details.  */
  _SFD_EML_CALL(0,9);
  if (CV_EML_IF(0, 0, !chartInstance->c37_a_not_empty)) {
    /* tf = [T*omega/(2+T*omega) T*omega/(2+T*omega)],[1 (T*omega-2)/(T*omega+2)] */
    /* tf = [a a],[1 -b] */
    _SFD_EML_CALL(0,12);
    c37_b_b = c37_f;
    c37_omega = 6.2831853071795862E+000 * c37_b_b;
    _SFD_EML_CALL(0,13);
    c37_b_a = c37_T;
    c37_c_b = c37_omega;
    c37_b_y = c37_b_a * c37_c_b;
    c37_c_a = c37_T;
    c37_d_b = c37_omega;
    c37_c_y = c37_c_a * c37_d_b;
    c37_A = c37_b_y;
    c37_B = 2.0 + c37_c_y;
    c37_x = c37_A;
    c37_d_y = c37_B;
    c37_b_x = c37_x;
    c37_e_y = c37_d_y;
    c37_c_x = c37_b_x;
    c37_f_y = c37_e_y;
    chartInstance->c37_a = c37_c_x / c37_f_y;
    chartInstance->c37_a_not_empty = TRUE;
    _SFD_EML_CALL(0,14);
    c37_d_a = c37_T;
    c37_e_b = c37_omega;
    c37_g_y = c37_d_a * c37_e_b;
    c37_e_a = c37_T;
    c37_f_b = c37_omega;
    c37_h_y = c37_e_a * c37_f_b;
    c37_b_A = -(c37_g_y - 2.0);
    c37_b_B = c37_h_y + 2.0;
    c37_d_x = c37_b_A;
    c37_i_y = c37_b_B;
    c37_e_x = c37_d_x;
    c37_j_y = c37_i_y;
    c37_f_x = c37_e_x;
    c37_k_y = c37_j_y;
    chartInstance->c37_b = c37_f_x / c37_k_y;
    chartInstance->c37_b_not_empty = TRUE;
    _SFD_EML_CALL(0,15);
    chartInstance->c37_y_km1 = c37_u;
    chartInstance->c37_y_km1_not_empty = TRUE;
    _SFD_EML_CALL(0,16);
    chartInstance->c37_u_km1 = c37_u;
    chartInstance->c37_u_km1_not_empty = TRUE;
  }

  _SFD_EML_CALL(0,19);
  c37_d_hoistedGlobal = chartInstance->c37_a;
  c37_e_hoistedGlobal = chartInstance->c37_u_km1;
  c37_f_a = c37_d_hoistedGlobal;
  c37_g_b = c37_u + c37_e_hoistedGlobal;
  c37_l_y = (real32_T)c37_f_a * c37_g_b;
  c37_f_hoistedGlobal = chartInstance->c37_b;
  c37_g_hoistedGlobal = chartInstance->c37_y_km1;
  c37_g_a = c37_f_hoistedGlobal;
  c37_h_b = c37_g_hoistedGlobal;
  c37_m_y = (real32_T)c37_g_a * c37_h_b;
  c37_y = c37_l_y + c37_m_y;
  _SFD_EML_CALL(0,20);
  chartInstance->c37_y_km1 = c37_y;
  _SFD_EML_CALL(0,21);
  chartInstance->c37_u_km1 = c37_u;
  _SFD_EML_CALL(0,-21);
  sf_debug_symbol_scope_pop();
  *c37_n_y = c37_y;
  _SFD_CC_CALL(EXIT_OUT_OF_FUNCTION_TAG,36);
  _sfEvent_ = c37_previousEvent;
  sf_debug_check_for_state_inconsistency(_controlMCUSlugsMKIIMachineNumber_,
    chartInstance->chartNumber, chartInstance->instanceNumber
    );
}

static void init_script_number_translation(uint32_T c37_machineNumber, uint32_T
  c37_chartNumber)
{
}

static const mxArray *c37_sf_marshall(void *chartInstanceVoid, void *c37_u)
{
  const mxArray *c37_y = NULL;
  real32_T c37_b_u;
  const mxArray *c37_b_y = NULL;
  SFc37_controlMCUSlugsMKIIInstanceStruct *chartInstance;
  chartInstance = (SFc37_controlMCUSlugsMKIIInstanceStruct *)chartInstanceVoid;
  c37_y = NULL;
  c37_b_u = *((real32_T *)c37_u);
  c37_b_y = NULL;
  if (!chartInstance->c37_u_km1_not_empty) {
    sf_mex_assign(&c37_b_y, sf_mex_create("y", NULL, 0, 0U, 1U, 0U, 2, 0, 0));
  } else {
    sf_mex_assign(&c37_b_y, sf_mex_create("y", &c37_b_u, 1, 0U, 0U, 0U, 0));
  }

  sf_mex_assign(&c37_y, c37_b_y);
  return c37_y;
}

static const mxArray *c37_b_sf_marshall(void *chartInstanceVoid, void *c37_u)
{
  const mxArray *c37_y = NULL;
  real32_T c37_b_u;
  const mxArray *c37_b_y = NULL;
  SFc37_controlMCUSlugsMKIIInstanceStruct *chartInstance;
  chartInstance = (SFc37_controlMCUSlugsMKIIInstanceStruct *)chartInstanceVoid;
  c37_y = NULL;
  c37_b_u = *((real32_T *)c37_u);
  c37_b_y = NULL;
  if (!chartInstance->c37_y_km1_not_empty) {
    sf_mex_assign(&c37_b_y, sf_mex_create("y", NULL, 0, 0U, 1U, 0U, 2, 0, 0));
  } else {
    sf_mex_assign(&c37_b_y, sf_mex_create("y", &c37_b_u, 1, 0U, 0U, 0U, 0));
  }

  sf_mex_assign(&c37_y, c37_b_y);
  return c37_y;
}

static const mxArray *c37_c_sf_marshall(void *chartInstanceVoid, void *c37_u)
{
  const mxArray *c37_y = NULL;
  real_T c37_b_u;
  const mxArray *c37_b_y = NULL;
  SFc37_controlMCUSlugsMKIIInstanceStruct *chartInstance;
  chartInstance = (SFc37_controlMCUSlugsMKIIInstanceStruct *)chartInstanceVoid;
  c37_y = NULL;
  c37_b_u = *((real_T *)c37_u);
  c37_b_y = NULL;
  if (!chartInstance->c37_b_not_empty) {
    sf_mex_assign(&c37_b_y, sf_mex_create("y", NULL, 0, 0U, 1U, 0U, 2, 0, 0));
  } else {
    sf_mex_assign(&c37_b_y, sf_mex_create("y", &c37_b_u, 0, 0U, 0U, 0U, 0));
  }

  sf_mex_assign(&c37_y, c37_b_y);
  return c37_y;
}

static const mxArray *c37_d_sf_marshall(void *chartInstanceVoid, void *c37_u)
{
  const mxArray *c37_y = NULL;
  real_T c37_b_u;
  const mxArray *c37_b_y = NULL;
  SFc37_controlMCUSlugsMKIIInstanceStruct *chartInstance;
  chartInstance = (SFc37_controlMCUSlugsMKIIInstanceStruct *)chartInstanceVoid;
  c37_y = NULL;
  c37_b_u = *((real_T *)c37_u);
  c37_b_y = NULL;
  if (!chartInstance->c37_a_not_empty) {
    sf_mex_assign(&c37_b_y, sf_mex_create("y", NULL, 0, 0U, 1U, 0U, 2, 0, 0));
  } else {
    sf_mex_assign(&c37_b_y, sf_mex_create("y", &c37_b_u, 0, 0U, 0U, 0U, 0));
  }

  sf_mex_assign(&c37_y, c37_b_y);
  return c37_y;
}

static const mxArray *c37_e_sf_marshall(void *chartInstanceVoid, void *c37_u)
{
  const mxArray *c37_y = NULL;
  real32_T c37_b_u;
  const mxArray *c37_b_y = NULL;
  SFc37_controlMCUSlugsMKIIInstanceStruct *chartInstance;
  chartInstance = (SFc37_controlMCUSlugsMKIIInstanceStruct *)chartInstanceVoid;
  c37_y = NULL;
  c37_b_u = *((real32_T *)c37_u);
  c37_b_y = NULL;
  sf_mex_assign(&c37_b_y, sf_mex_create("y", &c37_b_u, 1, 0U, 0U, 0U, 0));
  sf_mex_assign(&c37_y, c37_b_y);
  return c37_y;
}

static const mxArray *c37_f_sf_marshall(void *chartInstanceVoid, void *c37_u)
{
  const mxArray *c37_y = NULL;
  real_T c37_b_u;
  const mxArray *c37_b_y = NULL;
  SFc37_controlMCUSlugsMKIIInstanceStruct *chartInstance;
  chartInstance = (SFc37_controlMCUSlugsMKIIInstanceStruct *)chartInstanceVoid;
  c37_y = NULL;
  c37_b_u = *((real_T *)c37_u);
  c37_b_y = NULL;
  sf_mex_assign(&c37_b_y, sf_mex_create("y", &c37_b_u, 0, 0U, 0U, 0U, 0));
  sf_mex_assign(&c37_y, c37_b_y);
  return c37_y;
}

const mxArray *sf_c37_controlMCUSlugsMKII_get_eml_resolved_functions_info(void)
{
  const mxArray *c37_nameCaptureInfo = NULL;
  c37_ResolvedFunctionInfo c37_info[20];
  const mxArray *c37_m0 = NULL;
  int32_T c37_i0;
  c37_ResolvedFunctionInfo *c37_r0;
  c37_nameCaptureInfo = NULL;
  c37_info_helper(c37_info);
  sf_mex_assign(&c37_m0, sf_mex_createstruct("nameCaptureInfo", 1, 20));
  for (c37_i0 = 0; c37_i0 < 20; c37_i0 = c37_i0 + 1) {
    c37_r0 = &c37_info[c37_i0];
    sf_mex_addfield(c37_m0, sf_mex_create("nameCaptureInfo", c37_r0->context, 15,
      0U, 0U, 0U, 2, 1, strlen(c37_r0->context)), "context"
                    , "nameCaptureInfo", c37_i0);
    sf_mex_addfield(c37_m0, sf_mex_create("nameCaptureInfo", c37_r0->name, 15,
      0U, 0U, 0U, 2, 1, strlen(c37_r0->name)), "name",
                    "nameCaptureInfo", c37_i0);
    sf_mex_addfield(c37_m0, sf_mex_create("nameCaptureInfo",
      c37_r0->dominantType, 15, 0U, 0U, 0U, 2, 1, strlen(c37_r0->dominantType)),
                    "dominantType", "nameCaptureInfo", c37_i0);
    sf_mex_addfield(c37_m0, sf_mex_create("nameCaptureInfo", c37_r0->resolved,
      15, 0U, 0U, 0U, 2, 1, strlen(c37_r0->resolved)),
                    "resolved", "nameCaptureInfo", c37_i0);
    sf_mex_addfield(c37_m0, sf_mex_create("nameCaptureInfo", &c37_r0->fileLength,
      7, 0U, 0U, 0U, 0), "fileLength", "nameCaptureInfo",
                    c37_i0);
    sf_mex_addfield(c37_m0, sf_mex_create("nameCaptureInfo", &c37_r0->fileTime1,
      7, 0U, 0U, 0U, 0), "fileTime1", "nameCaptureInfo",
                    c37_i0);
    sf_mex_addfield(c37_m0, sf_mex_create("nameCaptureInfo", &c37_r0->fileTime2,
      7, 0U, 0U, 0U, 0), "fileTime2", "nameCaptureInfo",
                    c37_i0);
  }

  sf_mex_assign(&c37_nameCaptureInfo, c37_m0);
  return c37_nameCaptureInfo;
}

static void c37_info_helper(c37_ResolvedFunctionInfo c37_info[20])
{
  c37_info[0].context = "";
  c37_info[0].name = "pi";
  c37_info[0].dominantType = "";
  c37_info[0].resolved = "[B]pi";
  c37_info[0].fileLength = 0U;
  c37_info[0].fileTime1 = 0U;
  c37_info[0].fileTime2 = 0U;
  c37_info[1].context = "";
  c37_info[1].name = "mtimes";
  c37_info[1].dominantType = "double";
  c37_info[1].resolved = "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  c37_info[1].fileLength = 3425U;
  c37_info[1].fileTime1 = 1250701566U;
  c37_info[1].fileTime2 = 0U;
  c37_info[2].context = "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  c37_info[2].name = "nargin";
  c37_info[2].dominantType = "";
  c37_info[2].resolved = "[B]nargin";
  c37_info[2].fileLength = 0U;
  c37_info[2].fileTime1 = 0U;
  c37_info[2].fileTime2 = 0U;
  c37_info[3].context = "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  c37_info[3].name = "gt";
  c37_info[3].dominantType = "double";
  c37_info[3].resolved = "[B]gt";
  c37_info[3].fileLength = 0U;
  c37_info[3].fileTime1 = 0U;
  c37_info[3].fileTime2 = 0U;
  c37_info[4].context = "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  c37_info[4].name = "isa";
  c37_info[4].dominantType = "double";
  c37_info[4].resolved = "[B]isa";
  c37_info[4].fileLength = 0U;
  c37_info[4].fileTime1 = 0U;
  c37_info[4].fileTime2 = 0U;
  c37_info[5].context = "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  c37_info[5].name = "isinteger";
  c37_info[5].dominantType = "double";
  c37_info[5].resolved = "[B]isinteger";
  c37_info[5].fileLength = 0U;
  c37_info[5].fileTime1 = 0U;
  c37_info[5].fileTime2 = 0U;
  c37_info[6].context = "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  c37_info[6].name = "isscalar";
  c37_info[6].dominantType = "double";
  c37_info[6].resolved = "[B]isscalar";
  c37_info[6].fileLength = 0U;
  c37_info[6].fileTime1 = 0U;
  c37_info[6].fileTime2 = 0U;
  c37_info[7].context = "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  c37_info[7].name = "strcmp";
  c37_info[7].dominantType = "char";
  c37_info[7].resolved = "[B]strcmp";
  c37_info[7].fileLength = 0U;
  c37_info[7].fileTime1 = 0U;
  c37_info[7].fileTime2 = 0U;
  c37_info[8].context = "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  c37_info[8].name = "size";
  c37_info[8].dominantType = "double";
  c37_info[8].resolved = "[B]size";
  c37_info[8].fileLength = 0U;
  c37_info[8].fileTime1 = 0U;
  c37_info[8].fileTime2 = 0U;
  c37_info[9].context = "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  c37_info[9].name = "eq";
  c37_info[9].dominantType = "double";
  c37_info[9].resolved = "[B]eq";
  c37_info[9].fileLength = 0U;
  c37_info[9].fileTime1 = 0U;
  c37_info[9].fileTime2 = 0U;
  c37_info[10].context = "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  c37_info[10].name = "class";
  c37_info[10].dominantType = "double";
  c37_info[10].resolved = "[B]class";
  c37_info[10].fileLength = 0U;
  c37_info[10].fileTime1 = 0U;
  c37_info[10].fileTime2 = 0U;
  c37_info[11].context = "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  c37_info[11].name = "not";
  c37_info[11].dominantType = "logical";
  c37_info[11].resolved = "[B]not";
  c37_info[11].fileLength = 0U;
  c37_info[11].fileTime1 = 0U;
  c37_info[11].fileTime2 = 0U;
  c37_info[12].context = "";
  c37_info[12].name = "plus";
  c37_info[12].dominantType = "double";
  c37_info[12].resolved = "[B]plus";
  c37_info[12].fileLength = 0U;
  c37_info[12].fileTime1 = 0U;
  c37_info[12].fileTime2 = 0U;
  c37_info[13].context = "";
  c37_info[13].name = "mrdivide";
  c37_info[13].dominantType = "double";
  c37_info[13].resolved =
    "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mrdivide.m";
  c37_info[13].fileLength = 800U;
  c37_info[13].fileTime1 = 1238463090U;
  c37_info[13].fileTime2 = 0U;
  c37_info[14].context =
    "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mrdivide.m";
  c37_info[14].name = "ge";
  c37_info[14].dominantType = "double";
  c37_info[14].resolved = "[B]ge";
  c37_info[14].fileLength = 0U;
  c37_info[14].fileTime1 = 0U;
  c37_info[14].fileTime2 = 0U;
  c37_info[15].context =
    "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mrdivide.m";
  c37_info[15].name = "rdivide";
  c37_info[15].dominantType = "double";
  c37_info[15].resolved =
    "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/rdivide.m";
  c37_info[15].fileLength = 403U;
  c37_info[15].fileTime1 = 1244764352U;
  c37_info[15].fileTime2 = 0U;
  c37_info[16].context =
    "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/rdivide.m";
  c37_info[16].name = "eml_div";
  c37_info[16].dominantType = "double";
  c37_info[16].resolved =
    "[ILX]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_div.m";
  c37_info[16].fileLength = 4269U;
  c37_info[16].fileTime1 = 1228122626U;
  c37_info[16].fileTime2 = 0U;
  c37_info[17].context =
    "[ILX]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_div.m/eml_fldiv";
  c37_info[17].name = "isreal";
  c37_info[17].dominantType = "double";
  c37_info[17].resolved = "[B]isreal";
  c37_info[17].fileLength = 0U;
  c37_info[17].fileTime1 = 0U;
  c37_info[17].fileTime2 = 0U;
  c37_info[18].context = "";
  c37_info[18].name = "minus";
  c37_info[18].dominantType = "double";
  c37_info[18].resolved = "[B]minus";
  c37_info[18].fileLength = 0U;
  c37_info[18].fileTime1 = 0U;
  c37_info[18].fileTime2 = 0U;
  c37_info[19].context = "";
  c37_info[19].name = "uminus";
  c37_info[19].dominantType = "double";
  c37_info[19].resolved = "[B]uminus";
  c37_info[19].fileLength = 0U;
  c37_info[19].fileTime1 = 0U;
  c37_info[19].fileTime2 = 0U;
}

static const mxArray *c37_g_sf_marshall(void *chartInstanceVoid, void *c37_u)
{
  const mxArray *c37_y = NULL;
  boolean_T c37_b_u;
  const mxArray *c37_b_y = NULL;
  SFc37_controlMCUSlugsMKIIInstanceStruct *chartInstance;
  chartInstance = (SFc37_controlMCUSlugsMKIIInstanceStruct *)chartInstanceVoid;
  c37_y = NULL;
  c37_b_u = *((boolean_T *)c37_u);
  c37_b_y = NULL;
  sf_mex_assign(&c37_b_y, sf_mex_create("y", &c37_b_u, 11, 0U, 0U, 0U, 0));
  sf_mex_assign(&c37_y, c37_b_y);
  return c37_y;
}

static real32_T c37_emlrt_marshallIn(SFc37_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c37_y, const char_T *
  c37_name)
{
  real32_T c37_b_y;
  real32_T c37_f0;
  sf_mex_import(c37_name, sf_mex_dup(c37_y), &c37_f0, 1, 1, 0U, 0, 0U, 0);
  c37_b_y = c37_f0;
  sf_mex_destroy(&c37_y);
  return c37_b_y;
}

static real_T c37_b_emlrt_marshallIn(SFc37_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c37_b_a, const char_T *
  c37_name)
{
  real_T c37_y;
  real_T c37_d0;
  if (mxIsEmpty(c37_b_a)) {
    chartInstance->c37_a_not_empty = FALSE;
  } else {
    chartInstance->c37_a_not_empty = TRUE;
    sf_mex_import(c37_name, sf_mex_dup(c37_b_a), &c37_d0, 1, 0, 0U, 0, 0U, 0);
    c37_y = c37_d0;
  }

  sf_mex_destroy(&c37_b_a);
  return c37_y;
}

static real_T c37_c_emlrt_marshallIn(SFc37_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c37_b_b, const char_T *
  c37_name)
{
  real_T c37_y;
  real_T c37_d1;
  if (mxIsEmpty(c37_b_b)) {
    chartInstance->c37_b_not_empty = FALSE;
  } else {
    chartInstance->c37_b_not_empty = TRUE;
    sf_mex_import(c37_name, sf_mex_dup(c37_b_b), &c37_d1, 1, 0, 0U, 0, 0U, 0);
    c37_y = c37_d1;
  }

  sf_mex_destroy(&c37_b_b);
  return c37_y;
}

static real32_T c37_d_emlrt_marshallIn(SFc37_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c37_b_u_km1, const
  char_T *c37_name)
{
  real32_T c37_y;
  real32_T c37_f1;
  if (mxIsEmpty(c37_b_u_km1)) {
    chartInstance->c37_u_km1_not_empty = FALSE;
  } else {
    chartInstance->c37_u_km1_not_empty = TRUE;
    sf_mex_import(c37_name, sf_mex_dup(c37_b_u_km1), &c37_f1, 1, 1, 0U, 0, 0U, 0);
    c37_y = c37_f1;
  }

  sf_mex_destroy(&c37_b_u_km1);
  return c37_y;
}

static real32_T c37_e_emlrt_marshallIn(SFc37_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c37_b_y_km1, const
  char_T *c37_name)
{
  real32_T c37_y;
  real32_T c37_f2;
  if (mxIsEmpty(c37_b_y_km1)) {
    chartInstance->c37_y_km1_not_empty = FALSE;
  } else {
    chartInstance->c37_y_km1_not_empty = TRUE;
    sf_mex_import(c37_name, sf_mex_dup(c37_b_y_km1), &c37_f2, 1, 1, 0U, 0, 0U, 0);
    c37_y = c37_f2;
  }

  sf_mex_destroy(&c37_b_y_km1);
  return c37_y;
}

static uint8_T c37_f_emlrt_marshallIn(SFc37_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *
  c37_b_is_active_c37_controlMCUSlugsMKII, const char_T *c37_name)
{
  uint8_T c37_y;
  uint8_T c37_u0;
  sf_mex_import(c37_name, sf_mex_dup(c37_b_is_active_c37_controlMCUSlugsMKII),
                &c37_u0, 1, 3, 0U, 0, 0U, 0);
  c37_y = c37_u0;
  sf_mex_destroy(&c37_b_is_active_c37_controlMCUSlugsMKII);
  return c37_y;
}

static void init_dsm_address_info(SFc37_controlMCUSlugsMKIIInstanceStruct
  *chartInstance)
{
}

/* SFunction Glue Code */
void sf_c37_controlMCUSlugsMKII_get_check_sum(mxArray *plhs[])
{
  ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(1353272664U);
  ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(3696758036U);
  ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(3888534806U);
  ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(1976201762U);
}

mxArray *sf_c37_controlMCUSlugsMKII_get_autoinheritance_info(void)
{
  const char *autoinheritanceFields[] = { "checksum", "inputs", "parameters",
    "outputs" };

  mxArray *mxAutoinheritanceInfo = mxCreateStructMatrix(1,1,4,
    autoinheritanceFields);

  {
    mxArray *mxChecksum = mxCreateDoubleMatrix(4,1,mxREAL);
    double *pr = mxGetPr(mxChecksum);
    pr[0] = (double)(128223108U);
    pr[1] = (double)(2697122563U);
    pr[2] = (double)(1981904500U);
    pr[3] = (double)(4073712045U);
    mxSetField(mxAutoinheritanceInfo,0,"checksum",mxChecksum);
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,3,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(9));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,1,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,1,"type",mxType);
    }

    mxSetField(mxData,1,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,2,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,2,"type",mxType);
    }

    mxSetField(mxData,2,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"inputs",mxData);
  }

  {
    mxSetField(mxAutoinheritanceInfo,0,"parameters",mxCreateDoubleMatrix(0,0,
                mxREAL));
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,1,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(9));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"outputs",mxData);
  }

  return(mxAutoinheritanceInfo);
}

static mxArray *sf_get_sim_state_info_c37_controlMCUSlugsMKII(void)
{
  const char *infoFields[] = { "chartChecksum", "varInfo" };

  mxArray *mxInfo = mxCreateStructMatrix(1, 1, 2, infoFields);
  const char *infoEncStr[] = {
    "100 S1x6'type','srcId','name','auxInfo'{{M[1],M[5],T\"y\",},{M[4],M[0],T\"a\",S'l','i','p'{{M1x2[137 138],M[0],}}},{M[4],M[0],T\"b\",S'l','i','p'{{M1x2[150 151],M[0],}}},{M[4],M[0],T\"u_km1\",S'l','i','p'{{M1x2[180 185],M[0],}}},{M[4],M[0],T\"y_km1\",S'l','i','p'{{M1x2[163 168],M[0],}}},{M[8],M[0],T\"is_active_c37_controlMCUSlugsMKII\",}}"
  };

  mxArray *mxVarInfo = sf_mex_decode_encoded_mx_struct_array(infoEncStr, 6, 10);
  mxArray *mxChecksum = mxCreateDoubleMatrix(1, 4, mxREAL);
  sf_c37_controlMCUSlugsMKII_get_check_sum(&mxChecksum);
  mxSetField(mxInfo, 0, infoFields[0], mxChecksum);
  mxSetField(mxInfo, 0, infoFields[1], mxVarInfo);
  return mxInfo;
}

static void chart_debug_initialization(SimStruct *S, unsigned int
  fullDebuggerInitialization)
{
  if (!sim_mode_is_rtw_gen(S)) {
    SFc37_controlMCUSlugsMKIIInstanceStruct *chartInstance;
    chartInstance = (SFc37_controlMCUSlugsMKIIInstanceStruct *)
      ((ChartInfoStruct *)(ssGetUserData(S)))->chartInstance;
    if (ssIsFirstInitCond(S) && fullDebuggerInitialization==1) {
      /* do this only if simulation is starting */
      {
        unsigned int chartAlreadyPresent;
        chartAlreadyPresent = sf_debug_initialize_chart
          (_controlMCUSlugsMKIIMachineNumber_,
           37,
           1,
           1,
           4,
           0,
           0,
           0,
           0,
           0,
           &(chartInstance->chartNumber),
           &(chartInstance->instanceNumber),
           ssGetPath(S),
           (void *)S);
        if (chartAlreadyPresent==0) {
          /* this is the first instance */
          init_script_number_translation(_controlMCUSlugsMKIIMachineNumber_,
            chartInstance->chartNumber);
          sf_debug_set_chart_disable_implicit_casting
            (_controlMCUSlugsMKIIMachineNumber_,chartInstance->chartNumber,1);
          sf_debug_set_chart_event_thresholds(_controlMCUSlugsMKIIMachineNumber_,
            chartInstance->chartNumber,
            0,
            0,
            0);
          _SFD_SET_DATA_PROPS(0,1,1,0,SF_SINGLE,0,NULL,0,0,0,0.0,1.0,0,"u",0,
                              (MexFcnForType)c37_e_sf_marshall);
          _SFD_SET_DATA_PROPS(1,2,0,1,SF_SINGLE,0,NULL,0,0,0,0.0,1.0,0,"y",0,
                              (MexFcnForType)c37_e_sf_marshall);
          _SFD_SET_DATA_PROPS(2,1,1,0,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,"T",0,
                              (MexFcnForType)c37_f_sf_marshall);
          _SFD_SET_DATA_PROPS(3,1,1,0,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,"f",0,
                              (MexFcnForType)c37_f_sf_marshall);
          _SFD_STATE_INFO(0,0,2);
          _SFD_CH_SUBSTATE_COUNT(0);
          _SFD_CH_SUBSTATE_DECOMP(0);
        }

        _SFD_CV_INIT_CHART(0,0,0,0);

        {
          _SFD_CV_INIT_STATE(0,0,0,0,0,0,NULL,NULL);
        }

        _SFD_CV_INIT_TRANS(0,0,NULL,NULL,0,NULL);

        /* Initialization of EML Model Coverage */
        _SFD_CV_INIT_EML(0,1,1,0,0,0,0,0,0);
        _SFD_CV_INIT_EML_FCN(0,0,"eML_blk_kernel",0,-1,455);
        _SFD_CV_INIT_EML_IF(0,0,186,199,-1,411);
        _SFD_TRANS_COV_WTS(0,0,0,1,0);
        if (chartAlreadyPresent==0) {
          _SFD_TRANS_COV_MAPS(0,
                              0,NULL,NULL,
                              0,NULL,NULL,
                              1,NULL,NULL,
                              0,NULL,NULL);
        }

        {
          real32_T *c37_u;
          real32_T *c37_y;
          real_T *c37_T;
          real_T *c37_f;
          c37_f = (real_T *)ssGetInputPortSignal(chartInstance->S, 2);
          c37_T = (real_T *)ssGetInputPortSignal(chartInstance->S, 1);
          c37_y = (real32_T *)ssGetOutputPortSignal(chartInstance->S, 1);
          c37_u = (real32_T *)ssGetInputPortSignal(chartInstance->S, 0);
          _SFD_SET_DATA_VALUE_PTR(0U, c37_u);
          _SFD_SET_DATA_VALUE_PTR(1U, c37_y);
          _SFD_SET_DATA_VALUE_PTR(2U, c37_T);
          _SFD_SET_DATA_VALUE_PTR(3U, c37_f);
        }
      }
    } else {
      sf_debug_reset_current_state_configuration
        (_controlMCUSlugsMKIIMachineNumber_,chartInstance->chartNumber,
         chartInstance->instanceNumber);
    }
  }
}

static void sf_opaque_initialize_c37_controlMCUSlugsMKII(void *chartInstanceVar)
{
  chart_debug_initialization(((SFc37_controlMCUSlugsMKIIInstanceStruct*)
    chartInstanceVar)->S,0);
  initialize_params_c37_controlMCUSlugsMKII
    ((SFc37_controlMCUSlugsMKIIInstanceStruct*) chartInstanceVar);
  initialize_c37_controlMCUSlugsMKII((SFc37_controlMCUSlugsMKIIInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_enable_c37_controlMCUSlugsMKII(void *chartInstanceVar)
{
  enable_c37_controlMCUSlugsMKII((SFc37_controlMCUSlugsMKIIInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_disable_c37_controlMCUSlugsMKII(void *chartInstanceVar)
{
  disable_c37_controlMCUSlugsMKII((SFc37_controlMCUSlugsMKIIInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_gateway_c37_controlMCUSlugsMKII(void *chartInstanceVar)
{
  sf_c37_controlMCUSlugsMKII((SFc37_controlMCUSlugsMKIIInstanceStruct*)
    chartInstanceVar);
}

static mxArray* sf_internal_get_sim_state_c37_controlMCUSlugsMKII(SimStruct* S)
{
  ChartInfoStruct *chartInfo = (ChartInfoStruct*) ssGetUserData(S);
  mxArray *plhs[1] = { NULL };

  mxArray *prhs[4];
  int mxError = 0;
  prhs[0] = mxCreateString("chart_simctx_raw2high");
  prhs[1] = mxCreateDoubleScalar(ssGetSFuncBlockHandle(S));
  prhs[2] = (mxArray*) get_sim_state_c37_controlMCUSlugsMKII
    ((SFc37_controlMCUSlugsMKIIInstanceStruct*)chartInfo->chartInstance);/* raw sim ctx */
  prhs[3] = sf_get_sim_state_info_c37_controlMCUSlugsMKII();/* state var info */
  mxError = sf_mex_call_matlab(1, plhs, 4, prhs, "sfprivate");
  mxDestroyArray(prhs[0]);
  mxDestroyArray(prhs[1]);
  mxDestroyArray(prhs[2]);
  mxDestroyArray(prhs[3]);
  if (mxError || plhs[0] == NULL) {
    sf_mex_error_message("Stateflow Internal Error: \nError calling 'chart_simctx_raw2high'.\n");
  }

  return plhs[0];
}

static void sf_internal_set_sim_state_c37_controlMCUSlugsMKII(SimStruct* S,
  const mxArray *st)
{
  ChartInfoStruct *chartInfo = (ChartInfoStruct*) ssGetUserData(S);
  mxArray *plhs[1] = { NULL };

  mxArray *prhs[4];
  int mxError = 0;
  prhs[0] = mxCreateString("chart_simctx_high2raw");
  prhs[1] = mxCreateDoubleScalar(ssGetSFuncBlockHandle(S));
  prhs[2] = mxDuplicateArray(st);      /* high level simctx */
  prhs[3] = (mxArray*) sf_get_sim_state_info_c37_controlMCUSlugsMKII();/* state var info */
  mxError = sf_mex_call_matlab(1, plhs, 4, prhs, "sfprivate");
  mxDestroyArray(prhs[0]);
  mxDestroyArray(prhs[1]);
  mxDestroyArray(prhs[2]);
  mxDestroyArray(prhs[3]);
  if (mxError || plhs[0] == NULL) {
    sf_mex_error_message("Stateflow Internal Error: \nError calling 'chart_simctx_high2raw'.\n");
  }

  set_sim_state_c37_controlMCUSlugsMKII((SFc37_controlMCUSlugsMKIIInstanceStruct*)
    chartInfo->chartInstance, mxDuplicateArray(plhs[0]));
  mxDestroyArray(plhs[0]);
}

static mxArray* sf_opaque_get_sim_state_c37_controlMCUSlugsMKII(SimStruct* S)
{
  return sf_internal_get_sim_state_c37_controlMCUSlugsMKII(S);
}

static void sf_opaque_set_sim_state_c37_controlMCUSlugsMKII(SimStruct* S, const
  mxArray *st)
{
  sf_internal_set_sim_state_c37_controlMCUSlugsMKII(S, st);
}

static void sf_opaque_terminate_c37_controlMCUSlugsMKII(void *chartInstanceVar)
{
  if (chartInstanceVar!=NULL) {
    SimStruct *S = ((SFc37_controlMCUSlugsMKIIInstanceStruct*) chartInstanceVar
      )->S;
    if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
      sf_clear_rtw_identifier(S);
    }

    finalize_c37_controlMCUSlugsMKII((SFc37_controlMCUSlugsMKIIInstanceStruct*)
      chartInstanceVar);
    free((void *)chartInstanceVar);
    ssSetUserData(S,NULL);
  }
}

extern unsigned int sf_machine_global_initializer_called(void);
static void mdlProcessParameters_c37_controlMCUSlugsMKII(SimStruct *S)
{
  int i;
  for (i=0;i<ssGetNumRunTimeParams(S);i++) {
    if (ssGetSFcnParamTunable(S,i)) {
      ssUpdateDlgParamAsRunTimeParam(S,i);
    }
  }

  if (sf_machine_global_initializer_called()) {
    initialize_params_c37_controlMCUSlugsMKII
      ((SFc37_controlMCUSlugsMKIIInstanceStruct*)(((ChartInfoStruct *)
         ssGetUserData(S))->chartInstance));
  }
}

static void mdlSetWorkWidths_c37_controlMCUSlugsMKII(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
    int_T chartIsInlinable =
      (int_T)sf_is_chart_inlinable("controlMCUSlugsMKII","controlMCUSlugsMKII",
      37);
    ssSetStateflowIsInlinable(S,chartIsInlinable);
    ssSetRTWCG(S,sf_rtw_info_uint_prop("controlMCUSlugsMKII",
                "controlMCUSlugsMKII",37,"RTWCG"));
    ssSetEnableFcnIsTrivial(S,1);
    ssSetDisableFcnIsTrivial(S,1);
    ssSetNotMultipleInlinable(S,sf_rtw_info_uint_prop("controlMCUSlugsMKII",
      "controlMCUSlugsMKII",37,"gatewayCannotBeInlinedMultipleTimes"));
    if (chartIsInlinable) {
      ssSetInputPortOptimOpts(S, 0, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 1, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 2, SS_REUSABLE_AND_LOCAL);
      sf_mark_chart_expressionable_inputs(S,"controlMCUSlugsMKII",
        "controlMCUSlugsMKII",37,3);
      sf_mark_chart_reusable_outputs(S,"controlMCUSlugsMKII",
        "controlMCUSlugsMKII",37,1);
    }

    sf_set_rtw_dwork_info(S,"controlMCUSlugsMKII","controlMCUSlugsMKII",37);
    ssSetHasSubFunctions(S,!(chartIsInlinable));
    ssSetOptions(S,ssGetOptions(S)|SS_OPTION_WORKS_WITH_CODE_REUSE);
  }

  ssSetChecksum0(S,(2564540360U));
  ssSetChecksum1(S,(692271509U));
  ssSetChecksum2(S,(3514050889U));
  ssSetChecksum3(S,(3050027828U));
  ssSetmdlDerivatives(S, NULL);
  ssSetExplicitFCSSCtrl(S,1);
}

static void mdlRTW_c37_controlMCUSlugsMKII(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S)) {
    sf_write_symbol_mapping(S, "controlMCUSlugsMKII", "controlMCUSlugsMKII",37);
    ssWriteRTWStrParam(S, "StateflowChartType", "Embedded MATLAB");
  }
}

static void mdlStart_c37_controlMCUSlugsMKII(SimStruct *S)
{
  SFc37_controlMCUSlugsMKIIInstanceStruct *chartInstance;
  chartInstance = (SFc37_controlMCUSlugsMKIIInstanceStruct *)malloc(sizeof
    (SFc37_controlMCUSlugsMKIIInstanceStruct));
  memset(chartInstance, 0, sizeof(SFc37_controlMCUSlugsMKIIInstanceStruct));
  if (chartInstance==NULL) {
    sf_mex_error_message("Could not allocate memory for chart instance.");
  }

  chartInstance->chartInfo.chartInstance = chartInstance;
  chartInstance->chartInfo.isEMLChart = 1;
  chartInstance->chartInfo.chartInitialized = 0;
  chartInstance->chartInfo.sFunctionGateway =
    sf_opaque_gateway_c37_controlMCUSlugsMKII;
  chartInstance->chartInfo.initializeChart =
    sf_opaque_initialize_c37_controlMCUSlugsMKII;
  chartInstance->chartInfo.terminateChart =
    sf_opaque_terminate_c37_controlMCUSlugsMKII;
  chartInstance->chartInfo.enableChart =
    sf_opaque_enable_c37_controlMCUSlugsMKII;
  chartInstance->chartInfo.disableChart =
    sf_opaque_disable_c37_controlMCUSlugsMKII;
  chartInstance->chartInfo.getSimState =
    sf_opaque_get_sim_state_c37_controlMCUSlugsMKII;
  chartInstance->chartInfo.setSimState =
    sf_opaque_set_sim_state_c37_controlMCUSlugsMKII;
  chartInstance->chartInfo.getSimStateInfo =
    sf_get_sim_state_info_c37_controlMCUSlugsMKII;
  chartInstance->chartInfo.zeroCrossings = NULL;
  chartInstance->chartInfo.outputs = NULL;
  chartInstance->chartInfo.derivatives = NULL;
  chartInstance->chartInfo.mdlRTW = mdlRTW_c37_controlMCUSlugsMKII;
  chartInstance->chartInfo.mdlStart = mdlStart_c37_controlMCUSlugsMKII;
  chartInstance->chartInfo.mdlSetWorkWidths =
    mdlSetWorkWidths_c37_controlMCUSlugsMKII;
  chartInstance->chartInfo.extModeExec = NULL;
  chartInstance->chartInfo.restoreLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.restoreBeforeLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.storeCurrentConfiguration = NULL;
  chartInstance->S = S;
  ssSetUserData(S,(void *)(&(chartInstance->chartInfo)));/* register the chart instance with simstruct */
  if (!sim_mode_is_rtw_gen(S)) {
    init_dsm_address_info(chartInstance);
  }

  chart_debug_initialization(S,1);
}

void c37_controlMCUSlugsMKII_method_dispatcher(SimStruct *S, int_T method, void *
  data)
{
  switch (method) {
   case SS_CALL_MDL_START:
    mdlStart_c37_controlMCUSlugsMKII(S);
    break;

   case SS_CALL_MDL_SET_WORK_WIDTHS:
    mdlSetWorkWidths_c37_controlMCUSlugsMKII(S);
    break;

   case SS_CALL_MDL_PROCESS_PARAMETERS:
    mdlProcessParameters_c37_controlMCUSlugsMKII(S);
    break;

   default:
    /* Unhandled method */
    sf_mex_error_message("Stateflow Internal Error:\n"
                         "Error calling c37_controlMCUSlugsMKII_method_dispatcher.\n"
                         "Can't handle method %d.\n", method);
    break;
  }
}
