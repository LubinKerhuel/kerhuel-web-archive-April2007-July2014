/* Include files */

#include "SLUGS_Library_sfun.h"
#include "c2_SLUGS_Library.h"
#include "c5_SLUGS_Library.h"
#include "c13_SLUGS_Library.h"

/* Type Definitions */

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */
uint32_T _SLUGS_LibraryMachineNumber_;

/* Function Declarations */

/* Function Definitions */
void SLUGS_Library_initializer(void)
{
  _sfEvent_ = CALL_EVENT;
}

void SLUGS_Library_terminator(void)
{
}

/* SFunction Glue Code */
unsigned int sf_SLUGS_Library_method_dispatcher(SimStruct *simstructPtr,
  unsigned int chartFileNumber, const char* specsCksum, int_T method, void *data)
{
  if (chartFileNumber==2) {
    c2_SLUGS_Library_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==5) {
    c5_SLUGS_Library_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==13) {
    c13_SLUGS_Library_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  return 0;
}

unsigned int sf_SLUGS_Library_process_check_sum_call( int nlhs, mxArray * plhs[],
  int nrhs, const mxArray * prhs[] )
{

#ifdef MATLAB_MEX_FILE

  char commandName[20];
  if (nrhs<1 || !mxIsChar(prhs[0]) )
    return 0;

  /* Possible call to get the checksum */
  mxGetString(prhs[0], commandName,sizeof(commandName)/sizeof(char));
  commandName[(sizeof(commandName)/sizeof(char)-1)] = '\0';
  if (strcmp(commandName,"sf_get_check_sum"))
    return 0;
  plhs[0] = mxCreateDoubleMatrix( 1,4,mxREAL);
  if (nrhs>2 && mxIsChar(prhs[1])) {
    mxGetString(prhs[1], commandName,sizeof(commandName)/sizeof(char));
    commandName[(sizeof(commandName)/sizeof(char)-1)] = '\0';
    if (!strcmp(commandName,"library")) {
      char machineName[100];
      mxGetString(prhs[2], machineName,sizeof(machineName)/sizeof(char));
      machineName[(sizeof(machineName)/sizeof(char)-1)] = '\0';
      if (!strcmp(machineName,"SLUGS_Library")) {
        if (nrhs==3) {
          ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(32094611U);
          ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(1730952204U);
          ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(1571104950U);
          ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(822081214U);
        } else if (nrhs==4) {
          unsigned int chartFileNumber;
          chartFileNumber = (unsigned int)mxGetScalar(prhs[3]);
          switch (chartFileNumber) {
           case 2:
            {
              extern void sf_c2_SLUGS_Library_get_check_sum(mxArray *plhs[]);
              sf_c2_SLUGS_Library_get_check_sum(plhs);
              break;
            }

           case 5:
            {
              extern void sf_c5_SLUGS_Library_get_check_sum(mxArray *plhs[]);
              sf_c5_SLUGS_Library_get_check_sum(plhs);
              break;
            }

           case 13:
            {
              extern void sf_c13_SLUGS_Library_get_check_sum(mxArray *plhs[]);
              sf_c13_SLUGS_Library_get_check_sum(plhs);
              break;
            }

           default:
            ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(0.0);
            ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(0.0);
            ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(0.0);
            ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(0.0);
          }
        } else {
          return 0;
        }
      } else {
        return 0;
      }
    } else {
      return 0;
    }
  } else {
    return 0;
  }

  return 1;

#else

  return 0;

#endif

}

unsigned int sf_SLUGS_Library_autoinheritance_info( int nlhs, mxArray * plhs[],
  int nrhs, const mxArray * prhs[] )
{

#ifdef MATLAB_MEX_FILE

  char commandName[32];
  if (nrhs<2 || !mxIsChar(prhs[0]) )
    return 0;

  /* Possible call to get the autoinheritance_info */
  mxGetString(prhs[0], commandName,sizeof(commandName)/sizeof(char));
  commandName[(sizeof(commandName)/sizeof(char)-1)] = '\0';
  if (strcmp(commandName,"get_autoinheritance_info"))
    return 0;

  {
    unsigned int chartFileNumber;
    chartFileNumber = (unsigned int)mxGetScalar(prhs[1]);
    switch (chartFileNumber) {
     case 2:
      {
        extern mxArray *sf_c2_SLUGS_Library_get_autoinheritance_info(void);
        plhs[0] = sf_c2_SLUGS_Library_get_autoinheritance_info();
        break;
      }

     case 5:
      {
        extern mxArray *sf_c5_SLUGS_Library_get_autoinheritance_info(void);
        plhs[0] = sf_c5_SLUGS_Library_get_autoinheritance_info();
        break;
      }

     case 13:
      {
        extern mxArray *sf_c13_SLUGS_Library_get_autoinheritance_info(void);
        plhs[0] = sf_c13_SLUGS_Library_get_autoinheritance_info();
        break;
      }

     default:
      plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
    }
  }

  return 1;

#else

  return 0;

#endif

}

unsigned int sf_SLUGS_Library_get_eml_resolved_functions_info( int nlhs, mxArray
  * plhs[], int nrhs, const mxArray * prhs[] )
{

#ifdef MATLAB_MEX_FILE

  char commandName[64];
  if (nrhs<2 || !mxIsChar(prhs[0]))
    return 0;

  /* Possible call to get the get_eml_resolved_functions_info */
  mxGetString(prhs[0], commandName,sizeof(commandName)/sizeof(char));
  commandName[(sizeof(commandName)/sizeof(char)-1)] = '\0';
  if (strcmp(commandName,"get_eml_resolved_functions_info"))
    return 0;

  {
    unsigned int chartFileNumber;
    chartFileNumber = (unsigned int)mxGetScalar(prhs[1]);
    switch (chartFileNumber) {
     case 2:
      {
        extern const mxArray
          *sf_c2_SLUGS_Library_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c2_SLUGS_Library_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 5:
      {
        extern const mxArray
          *sf_c5_SLUGS_Library_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c5_SLUGS_Library_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 13:
      {
        extern const mxArray
          *sf_c13_SLUGS_Library_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c13_SLUGS_Library_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     default:
      plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
    }
  }

  return 1;

#else

  return 0;

#endif

}

void SLUGS_Library_debug_initialize(void)
{
  _SLUGS_LibraryMachineNumber_ = sf_debug_initialize_machine("SLUGS_Library",
    "sfun",1,3,0,0,0);
  sf_debug_set_machine_event_thresholds(_SLUGS_LibraryMachineNumber_,0,0);
  sf_debug_set_machine_data_thresholds(_SLUGS_LibraryMachineNumber_,0);
}

void SLUGS_Library_register_exported_symbols(SimStruct* S)
{
}
