#ifndef __c11_controlMCUSlugsMKII_h__
#define __c11_controlMCUSlugsMKII_h__

/* Include files */
#include "sfc_sf.h"
#include "sfc_mex.h"
#include "rtwtypes.h"

/* Type Definitions */
typedef struct {
  const char *context;
  const char *name;
  const char *dominantType;
  const char *resolved;
  uint32_T fileLength;
  uint32_T fileTime1;
  uint32_T fileTime2;
} c11_ResolvedFunctionInfo;

typedef struct {
  SimStruct *S;
  uint16_T c11_internalTimer;
  boolean_T c11_internalTimer_not_empty;
  boolean_T c11_oldSw_not_empty;
  uint8_T c11_is_active_c11_controlMCUSlugsMKII;
  uint8_T c11_oldSw;
  ChartInfoStruct chartInfo;
} SFc11_controlMCUSlugsMKIIInstanceStruct;

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */

/* Function Declarations */
extern const mxArray *sf_c11_controlMCUSlugsMKII_get_eml_resolved_functions_info
  (void);

/* Function Definitions */
extern void sf_c11_controlMCUSlugsMKII_get_check_sum(mxArray *plhs[]);
extern void c11_controlMCUSlugsMKII_method_dispatcher(SimStruct *S, int_T method,
  void *data);

#endif
