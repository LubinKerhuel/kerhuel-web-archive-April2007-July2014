/* Include files */

#include "blascompat32.h"
#include "controlMCUSlugsMKII_sfun.h"
#include "c48_controlMCUSlugsMKII.h"
#define CHARTINSTANCE_CHARTNUMBER      (chartInstance->chartNumber)
#define CHARTINSTANCE_INSTANCENUMBER   (chartInstance->instanceNumber)
#include "controlMCUSlugsMKII_sfun_debug_macros.h"

/* Type Definitions */

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */
static const char *c48_debug_family_names[11] = { "omega", "nargin", "nargout",
  "u", "T", "f", "y", "a", "b", "y_km1", "u_km1" };

/* Function Declarations */
static void initialize_c48_controlMCUSlugsMKII
  (SFc48_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void initialize_params_c48_controlMCUSlugsMKII
  (SFc48_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void enable_c48_controlMCUSlugsMKII
  (SFc48_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void disable_c48_controlMCUSlugsMKII
  (SFc48_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void c48_update_debugger_state_c48_controlMCUSlugsMKII
  (SFc48_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static const mxArray *get_sim_state_c48_controlMCUSlugsMKII
  (SFc48_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void set_sim_state_c48_controlMCUSlugsMKII
  (SFc48_controlMCUSlugsMKIIInstanceStruct *chartInstance, const mxArray *c48_st);
static void finalize_c48_controlMCUSlugsMKII
  (SFc48_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void sf_c48_controlMCUSlugsMKII(SFc48_controlMCUSlugsMKIIInstanceStruct
  *chartInstance);
static void init_script_number_translation(uint32_T c48_machineNumber, uint32_T
  c48_chartNumber);
static const mxArray *c48_sf_marshall(void *chartInstanceVoid, void *c48_u);
static const mxArray *c48_b_sf_marshall(void *chartInstanceVoid, void *c48_u);
static const mxArray *c48_c_sf_marshall(void *chartInstanceVoid, void *c48_u);
static const mxArray *c48_d_sf_marshall(void *chartInstanceVoid, void *c48_u);
static const mxArray *c48_e_sf_marshall(void *chartInstanceVoid, void *c48_u);
static const mxArray *c48_f_sf_marshall(void *chartInstanceVoid, void *c48_u);
static void c48_info_helper(c48_ResolvedFunctionInfo c48_info[20]);
static const mxArray *c48_g_sf_marshall(void *chartInstanceVoid, void *c48_u);
static real32_T c48_emlrt_marshallIn(SFc48_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c48_y, const char_T *c48_name);
static real_T c48_b_emlrt_marshallIn(SFc48_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c48_b_a, const char_T *c48_name);
static real_T c48_c_emlrt_marshallIn(SFc48_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c48_b_b, const char_T *c48_name);
static real32_T c48_d_emlrt_marshallIn(SFc48_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c48_b_u_km1, const char_T *c48_name);
static real32_T c48_e_emlrt_marshallIn(SFc48_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c48_b_y_km1, const char_T *c48_name);
static uint8_T c48_f_emlrt_marshallIn(SFc48_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c48_b_is_active_c48_controlMCUSlugsMKII, const
  char_T *c48_name);
static void init_dsm_address_info(SFc48_controlMCUSlugsMKIIInstanceStruct
  *chartInstance);

/* Function Definitions */
static void initialize_c48_controlMCUSlugsMKII
  (SFc48_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
  chartInstance->c48_a_not_empty = FALSE;
  chartInstance->c48_b_not_empty = FALSE;
  chartInstance->c48_y_km1_not_empty = FALSE;
  chartInstance->c48_u_km1_not_empty = FALSE;
  chartInstance->c48_is_active_c48_controlMCUSlugsMKII = 0U;
}

static void initialize_params_c48_controlMCUSlugsMKII
  (SFc48_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
}

static void enable_c48_controlMCUSlugsMKII
  (SFc48_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
}

static void disable_c48_controlMCUSlugsMKII
  (SFc48_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
}

static void c48_update_debugger_state_c48_controlMCUSlugsMKII
  (SFc48_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
}

static const mxArray *get_sim_state_c48_controlMCUSlugsMKII
  (SFc48_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
  const mxArray *c48_st = NULL;
  const mxArray *c48_y = NULL;
  real32_T c48_hoistedGlobal;
  real32_T c48_u;
  const mxArray *c48_b_y = NULL;
  real_T c48_b_hoistedGlobal;
  real_T c48_b_u;
  const mxArray *c48_c_y = NULL;
  real_T c48_c_hoistedGlobal;
  real_T c48_c_u;
  const mxArray *c48_d_y = NULL;
  real32_T c48_d_hoistedGlobal;
  real32_T c48_d_u;
  const mxArray *c48_e_y = NULL;
  real32_T c48_e_hoistedGlobal;
  real32_T c48_e_u;
  const mxArray *c48_f_y = NULL;
  uint8_T c48_f_hoistedGlobal;
  uint8_T c48_f_u;
  const mxArray *c48_g_y = NULL;
  real32_T *c48_h_y;
  c48_h_y = (real32_T *)ssGetOutputPortSignal(chartInstance->S, 1);
  c48_st = NULL;
  c48_y = NULL;
  sf_mex_assign(&c48_y, sf_mex_createcellarray(6));
  c48_hoistedGlobal = *c48_h_y;
  c48_u = c48_hoistedGlobal;
  c48_b_y = NULL;
  sf_mex_assign(&c48_b_y, sf_mex_create("y", &c48_u, 1, 0U, 0U, 0U, 0));
  sf_mex_setcell(c48_y, 0, c48_b_y);
  c48_b_hoistedGlobal = chartInstance->c48_a;
  c48_b_u = c48_b_hoistedGlobal;
  c48_c_y = NULL;
  if (!chartInstance->c48_a_not_empty) {
    sf_mex_assign(&c48_c_y, sf_mex_create("y", NULL, 0, 0U, 1U, 0U, 2, 0, 0));
  } else {
    sf_mex_assign(&c48_c_y, sf_mex_create("y", &c48_b_u, 0, 0U, 0U, 0U, 0));
  }

  sf_mex_setcell(c48_y, 1, c48_c_y);
  c48_c_hoistedGlobal = chartInstance->c48_b;
  c48_c_u = c48_c_hoistedGlobal;
  c48_d_y = NULL;
  if (!chartInstance->c48_b_not_empty) {
    sf_mex_assign(&c48_d_y, sf_mex_create("y", NULL, 0, 0U, 1U, 0U, 2, 0, 0));
  } else {
    sf_mex_assign(&c48_d_y, sf_mex_create("y", &c48_c_u, 0, 0U, 0U, 0U, 0));
  }

  sf_mex_setcell(c48_y, 2, c48_d_y);
  c48_d_hoistedGlobal = chartInstance->c48_u_km1;
  c48_d_u = c48_d_hoistedGlobal;
  c48_e_y = NULL;
  if (!chartInstance->c48_u_km1_not_empty) {
    sf_mex_assign(&c48_e_y, sf_mex_create("y", NULL, 0, 0U, 1U, 0U, 2, 0, 0));
  } else {
    sf_mex_assign(&c48_e_y, sf_mex_create("y", &c48_d_u, 1, 0U, 0U, 0U, 0));
  }

  sf_mex_setcell(c48_y, 3, c48_e_y);
  c48_e_hoistedGlobal = chartInstance->c48_y_km1;
  c48_e_u = c48_e_hoistedGlobal;
  c48_f_y = NULL;
  if (!chartInstance->c48_y_km1_not_empty) {
    sf_mex_assign(&c48_f_y, sf_mex_create("y", NULL, 0, 0U, 1U, 0U, 2, 0, 0));
  } else {
    sf_mex_assign(&c48_f_y, sf_mex_create("y", &c48_e_u, 1, 0U, 0U, 0U, 0));
  }

  sf_mex_setcell(c48_y, 4, c48_f_y);
  c48_f_hoistedGlobal = chartInstance->c48_is_active_c48_controlMCUSlugsMKII;
  c48_f_u = c48_f_hoistedGlobal;
  c48_g_y = NULL;
  sf_mex_assign(&c48_g_y, sf_mex_create("y", &c48_f_u, 3, 0U, 0U, 0U, 0));
  sf_mex_setcell(c48_y, 5, c48_g_y);
  sf_mex_assign(&c48_st, c48_y);
  return c48_st;
}

static void set_sim_state_c48_controlMCUSlugsMKII
  (SFc48_controlMCUSlugsMKIIInstanceStruct *chartInstance, const mxArray *c48_st)
{
  const mxArray *c48_u;
  real32_T *c48_y;
  c48_y = (real32_T *)ssGetOutputPortSignal(chartInstance->S, 1);
  chartInstance->c48_doneDoubleBufferReInit = TRUE;
  c48_u = sf_mex_dup(c48_st);
  *c48_y = c48_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(c48_u,
    0)), "y");
  chartInstance->c48_a = c48_b_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getcell(c48_u, 1)), "a");
  chartInstance->c48_b = c48_c_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getcell(c48_u, 2)), "b");
  chartInstance->c48_u_km1 = c48_d_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getcell(c48_u, 3)), "u_km1");
  chartInstance->c48_y_km1 = c48_e_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getcell(c48_u, 4)), "y_km1");
  chartInstance->c48_is_active_c48_controlMCUSlugsMKII = c48_f_emlrt_marshallIn
    (chartInstance, sf_mex_dup(sf_mex_getcell(c48_u, 5)),
     "is_active_c48_controlMCUSlugsMKII");
  sf_mex_destroy(&c48_u);
  c48_update_debugger_state_c48_controlMCUSlugsMKII(chartInstance);
  sf_mex_destroy(&c48_st);
}

static void finalize_c48_controlMCUSlugsMKII
  (SFc48_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
}

static void sf_c48_controlMCUSlugsMKII(SFc48_controlMCUSlugsMKIIInstanceStruct
  *chartInstance)
{
  int32_T c48_previousEvent;
  real32_T c48_hoistedGlobal;
  real_T c48_b_hoistedGlobal;
  real_T c48_c_hoistedGlobal;
  real32_T c48_u;
  real_T c48_T;
  real_T c48_f;
  uint32_T c48_debug_family_var_map[11];
  real_T c48_omega;
  real_T c48_nargin = 3.0;
  real_T c48_nargout = 1.0;
  real32_T c48_y;
  real_T c48_b_b;
  real_T c48_b_a;
  real_T c48_c_b;
  real_T c48_b_y;
  real_T c48_c_a;
  real_T c48_d_b;
  real_T c48_c_y;
  real_T c48_A;
  real_T c48_B;
  real_T c48_x;
  real_T c48_d_y;
  real_T c48_b_x;
  real_T c48_e_y;
  real_T c48_c_x;
  real_T c48_f_y;
  real_T c48_d_a;
  real_T c48_e_b;
  real_T c48_g_y;
  real_T c48_e_a;
  real_T c48_f_b;
  real_T c48_h_y;
  real_T c48_b_A;
  real_T c48_b_B;
  real_T c48_d_x;
  real_T c48_i_y;
  real_T c48_e_x;
  real_T c48_j_y;
  real_T c48_f_x;
  real_T c48_k_y;
  real_T c48_d_hoistedGlobal;
  real32_T c48_e_hoistedGlobal;
  real_T c48_f_a;
  real32_T c48_g_b;
  real32_T c48_l_y;
  real_T c48_f_hoistedGlobal;
  real32_T c48_g_hoistedGlobal;
  real_T c48_g_a;
  real32_T c48_h_b;
  real32_T c48_m_y;
  real32_T *c48_b_u;
  real32_T *c48_n_y;
  real_T *c48_b_T;
  real_T *c48_b_f;
  c48_b_f = (real_T *)ssGetInputPortSignal(chartInstance->S, 2);
  c48_b_T = (real_T *)ssGetInputPortSignal(chartInstance->S, 1);
  c48_n_y = (real32_T *)ssGetOutputPortSignal(chartInstance->S, 1);
  c48_b_u = (real32_T *)ssGetInputPortSignal(chartInstance->S, 0);
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
  _SFD_CC_CALL(CHART_ENTER_SFUNCTION_TAG,41);
  _SFD_DATA_RANGE_CHECK((real_T)*c48_b_u, 0U);
  _SFD_DATA_RANGE_CHECK((real_T)*c48_n_y, 1U);
  _SFD_DATA_RANGE_CHECK(*c48_b_T, 2U);
  _SFD_DATA_RANGE_CHECK(*c48_b_f, 3U);
  c48_previousEvent = _sfEvent_;
  _sfEvent_ = CALL_EVENT;
  _SFD_CC_CALL(CHART_ENTER_DURING_FUNCTION_TAG,41);
  c48_hoistedGlobal = *c48_b_u;
  c48_b_hoistedGlobal = *c48_b_T;
  c48_c_hoistedGlobal = *c48_b_f;
  c48_u = c48_hoistedGlobal;
  c48_T = c48_b_hoistedGlobal;
  c48_f = c48_c_hoistedGlobal;
  sf_debug_symbol_scope_push_eml(0U, 11U, 11U, c48_debug_family_names,
    c48_debug_family_var_map);
  sf_debug_symbol_scope_add_eml(&c48_omega, c48_f_sf_marshall, 0U);
  sf_debug_symbol_scope_add_eml(&c48_nargin, c48_f_sf_marshall, 1U);
  sf_debug_symbol_scope_add_eml(&c48_nargout, c48_f_sf_marshall, 2U);
  sf_debug_symbol_scope_add_eml(&c48_u, c48_e_sf_marshall, 3U);
  sf_debug_symbol_scope_add_eml(&c48_T, c48_f_sf_marshall, 4U);
  sf_debug_symbol_scope_add_eml(&c48_f, c48_f_sf_marshall, 5U);
  sf_debug_symbol_scope_add_eml(&c48_y, c48_e_sf_marshall, 6U);
  sf_debug_symbol_scope_add_eml(&chartInstance->c48_a, c48_d_sf_marshall, 7U);
  sf_debug_symbol_scope_add_eml(&chartInstance->c48_b, c48_c_sf_marshall, 8U);
  sf_debug_symbol_scope_add_eml(&chartInstance->c48_y_km1, c48_b_sf_marshall, 9U);
  sf_debug_symbol_scope_add_eml(&chartInstance->c48_u_km1, c48_sf_marshall, 10U);
  CV_EML_FCN(0, 0);

  /*  This block supports an embeddable subset of the MATLAB language. */
  /*  See the help menu for details.  */
  _SFD_EML_CALL(0,9);
  if (CV_EML_IF(0, 0, !chartInstance->c48_a_not_empty)) {
    /* tf = [T*omega/(2+T*omega) T*omega/(2+T*omega)],[1 (T*omega-2)/(T*omega+2)] */
    /* tf = [a a],[1 -b] */
    _SFD_EML_CALL(0,12);
    c48_b_b = c48_f;
    c48_omega = 6.2831853071795862E+000 * c48_b_b;
    _SFD_EML_CALL(0,13);
    c48_b_a = c48_T;
    c48_c_b = c48_omega;
    c48_b_y = c48_b_a * c48_c_b;
    c48_c_a = c48_T;
    c48_d_b = c48_omega;
    c48_c_y = c48_c_a * c48_d_b;
    c48_A = c48_b_y;
    c48_B = 2.0 + c48_c_y;
    c48_x = c48_A;
    c48_d_y = c48_B;
    c48_b_x = c48_x;
    c48_e_y = c48_d_y;
    c48_c_x = c48_b_x;
    c48_f_y = c48_e_y;
    chartInstance->c48_a = c48_c_x / c48_f_y;
    chartInstance->c48_a_not_empty = TRUE;
    _SFD_EML_CALL(0,14);
    c48_d_a = c48_T;
    c48_e_b = c48_omega;
    c48_g_y = c48_d_a * c48_e_b;
    c48_e_a = c48_T;
    c48_f_b = c48_omega;
    c48_h_y = c48_e_a * c48_f_b;
    c48_b_A = -(c48_g_y - 2.0);
    c48_b_B = c48_h_y + 2.0;
    c48_d_x = c48_b_A;
    c48_i_y = c48_b_B;
    c48_e_x = c48_d_x;
    c48_j_y = c48_i_y;
    c48_f_x = c48_e_x;
    c48_k_y = c48_j_y;
    chartInstance->c48_b = c48_f_x / c48_k_y;
    chartInstance->c48_b_not_empty = TRUE;
    _SFD_EML_CALL(0,15);
    chartInstance->c48_y_km1 = c48_u;
    chartInstance->c48_y_km1_not_empty = TRUE;
    _SFD_EML_CALL(0,16);
    chartInstance->c48_u_km1 = c48_u;
    chartInstance->c48_u_km1_not_empty = TRUE;
  }

  _SFD_EML_CALL(0,19);
  c48_d_hoistedGlobal = chartInstance->c48_a;
  c48_e_hoistedGlobal = chartInstance->c48_u_km1;
  c48_f_a = c48_d_hoistedGlobal;
  c48_g_b = c48_u + c48_e_hoistedGlobal;
  c48_l_y = (real32_T)c48_f_a * c48_g_b;
  c48_f_hoistedGlobal = chartInstance->c48_b;
  c48_g_hoistedGlobal = chartInstance->c48_y_km1;
  c48_g_a = c48_f_hoistedGlobal;
  c48_h_b = c48_g_hoistedGlobal;
  c48_m_y = (real32_T)c48_g_a * c48_h_b;
  c48_y = c48_l_y + c48_m_y;
  _SFD_EML_CALL(0,20);
  chartInstance->c48_y_km1 = c48_y;
  _SFD_EML_CALL(0,21);
  chartInstance->c48_u_km1 = c48_u;
  _SFD_EML_CALL(0,-21);
  sf_debug_symbol_scope_pop();
  *c48_n_y = c48_y;
  _SFD_CC_CALL(EXIT_OUT_OF_FUNCTION_TAG,41);
  _sfEvent_ = c48_previousEvent;
  sf_debug_check_for_state_inconsistency(_controlMCUSlugsMKIIMachineNumber_,
    chartInstance->chartNumber, chartInstance->instanceNumber
    );
}

static void init_script_number_translation(uint32_T c48_machineNumber, uint32_T
  c48_chartNumber)
{
}

static const mxArray *c48_sf_marshall(void *chartInstanceVoid, void *c48_u)
{
  const mxArray *c48_y = NULL;
  real32_T c48_b_u;
  const mxArray *c48_b_y = NULL;
  SFc48_controlMCUSlugsMKIIInstanceStruct *chartInstance;
  chartInstance = (SFc48_controlMCUSlugsMKIIInstanceStruct *)chartInstanceVoid;
  c48_y = NULL;
  c48_b_u = *((real32_T *)c48_u);
  c48_b_y = NULL;
  if (!chartInstance->c48_u_km1_not_empty) {
    sf_mex_assign(&c48_b_y, sf_mex_create("y", NULL, 0, 0U, 1U, 0U, 2, 0, 0));
  } else {
    sf_mex_assign(&c48_b_y, sf_mex_create("y", &c48_b_u, 1, 0U, 0U, 0U, 0));
  }

  sf_mex_assign(&c48_y, c48_b_y);
  return c48_y;
}

static const mxArray *c48_b_sf_marshall(void *chartInstanceVoid, void *c48_u)
{
  const mxArray *c48_y = NULL;
  real32_T c48_b_u;
  const mxArray *c48_b_y = NULL;
  SFc48_controlMCUSlugsMKIIInstanceStruct *chartInstance;
  chartInstance = (SFc48_controlMCUSlugsMKIIInstanceStruct *)chartInstanceVoid;
  c48_y = NULL;
  c48_b_u = *((real32_T *)c48_u);
  c48_b_y = NULL;
  if (!chartInstance->c48_y_km1_not_empty) {
    sf_mex_assign(&c48_b_y, sf_mex_create("y", NULL, 0, 0U, 1U, 0U, 2, 0, 0));
  } else {
    sf_mex_assign(&c48_b_y, sf_mex_create("y", &c48_b_u, 1, 0U, 0U, 0U, 0));
  }

  sf_mex_assign(&c48_y, c48_b_y);
  return c48_y;
}

static const mxArray *c48_c_sf_marshall(void *chartInstanceVoid, void *c48_u)
{
  const mxArray *c48_y = NULL;
  real_T c48_b_u;
  const mxArray *c48_b_y = NULL;
  SFc48_controlMCUSlugsMKIIInstanceStruct *chartInstance;
  chartInstance = (SFc48_controlMCUSlugsMKIIInstanceStruct *)chartInstanceVoid;
  c48_y = NULL;
  c48_b_u = *((real_T *)c48_u);
  c48_b_y = NULL;
  if (!chartInstance->c48_b_not_empty) {
    sf_mex_assign(&c48_b_y, sf_mex_create("y", NULL, 0, 0U, 1U, 0U, 2, 0, 0));
  } else {
    sf_mex_assign(&c48_b_y, sf_mex_create("y", &c48_b_u, 0, 0U, 0U, 0U, 0));
  }

  sf_mex_assign(&c48_y, c48_b_y);
  return c48_y;
}

static const mxArray *c48_d_sf_marshall(void *chartInstanceVoid, void *c48_u)
{
  const mxArray *c48_y = NULL;
  real_T c48_b_u;
  const mxArray *c48_b_y = NULL;
  SFc48_controlMCUSlugsMKIIInstanceStruct *chartInstance;
  chartInstance = (SFc48_controlMCUSlugsMKIIInstanceStruct *)chartInstanceVoid;
  c48_y = NULL;
  c48_b_u = *((real_T *)c48_u);
  c48_b_y = NULL;
  if (!chartInstance->c48_a_not_empty) {
    sf_mex_assign(&c48_b_y, sf_mex_create("y", NULL, 0, 0U, 1U, 0U, 2, 0, 0));
  } else {
    sf_mex_assign(&c48_b_y, sf_mex_create("y", &c48_b_u, 0, 0U, 0U, 0U, 0));
  }

  sf_mex_assign(&c48_y, c48_b_y);
  return c48_y;
}

static const mxArray *c48_e_sf_marshall(void *chartInstanceVoid, void *c48_u)
{
  const mxArray *c48_y = NULL;
  real32_T c48_b_u;
  const mxArray *c48_b_y = NULL;
  SFc48_controlMCUSlugsMKIIInstanceStruct *chartInstance;
  chartInstance = (SFc48_controlMCUSlugsMKIIInstanceStruct *)chartInstanceVoid;
  c48_y = NULL;
  c48_b_u = *((real32_T *)c48_u);
  c48_b_y = NULL;
  sf_mex_assign(&c48_b_y, sf_mex_create("y", &c48_b_u, 1, 0U, 0U, 0U, 0));
  sf_mex_assign(&c48_y, c48_b_y);
  return c48_y;
}

static const mxArray *c48_f_sf_marshall(void *chartInstanceVoid, void *c48_u)
{
  const mxArray *c48_y = NULL;
  real_T c48_b_u;
  const mxArray *c48_b_y = NULL;
  SFc48_controlMCUSlugsMKIIInstanceStruct *chartInstance;
  chartInstance = (SFc48_controlMCUSlugsMKIIInstanceStruct *)chartInstanceVoid;
  c48_y = NULL;
  c48_b_u = *((real_T *)c48_u);
  c48_b_y = NULL;
  sf_mex_assign(&c48_b_y, sf_mex_create("y", &c48_b_u, 0, 0U, 0U, 0U, 0));
  sf_mex_assign(&c48_y, c48_b_y);
  return c48_y;
}

const mxArray *sf_c48_controlMCUSlugsMKII_get_eml_resolved_functions_info(void)
{
  const mxArray *c48_nameCaptureInfo = NULL;
  c48_ResolvedFunctionInfo c48_info[20];
  const mxArray *c48_m0 = NULL;
  int32_T c48_i0;
  c48_ResolvedFunctionInfo *c48_r0;
  c48_nameCaptureInfo = NULL;
  c48_info_helper(c48_info);
  sf_mex_assign(&c48_m0, sf_mex_createstruct("nameCaptureInfo", 1, 20));
  for (c48_i0 = 0; c48_i0 < 20; c48_i0 = c48_i0 + 1) {
    c48_r0 = &c48_info[c48_i0];
    sf_mex_addfield(c48_m0, sf_mex_create("nameCaptureInfo", c48_r0->context, 15,
      0U, 0U, 0U, 2, 1, strlen(c48_r0->context)), "context"
                    , "nameCaptureInfo", c48_i0);
    sf_mex_addfield(c48_m0, sf_mex_create("nameCaptureInfo", c48_r0->name, 15,
      0U, 0U, 0U, 2, 1, strlen(c48_r0->name)), "name",
                    "nameCaptureInfo", c48_i0);
    sf_mex_addfield(c48_m0, sf_mex_create("nameCaptureInfo",
      c48_r0->dominantType, 15, 0U, 0U, 0U, 2, 1, strlen(c48_r0->dominantType)),
                    "dominantType", "nameCaptureInfo", c48_i0);
    sf_mex_addfield(c48_m0, sf_mex_create("nameCaptureInfo", c48_r0->resolved,
      15, 0U, 0U, 0U, 2, 1, strlen(c48_r0->resolved)),
                    "resolved", "nameCaptureInfo", c48_i0);
    sf_mex_addfield(c48_m0, sf_mex_create("nameCaptureInfo", &c48_r0->fileLength,
      7, 0U, 0U, 0U, 0), "fileLength", "nameCaptureInfo",
                    c48_i0);
    sf_mex_addfield(c48_m0, sf_mex_create("nameCaptureInfo", &c48_r0->fileTime1,
      7, 0U, 0U, 0U, 0), "fileTime1", "nameCaptureInfo",
                    c48_i0);
    sf_mex_addfield(c48_m0, sf_mex_create("nameCaptureInfo", &c48_r0->fileTime2,
      7, 0U, 0U, 0U, 0), "fileTime2", "nameCaptureInfo",
                    c48_i0);
  }

  sf_mex_assign(&c48_nameCaptureInfo, c48_m0);
  return c48_nameCaptureInfo;
}

static void c48_info_helper(c48_ResolvedFunctionInfo c48_info[20])
{
  c48_info[0].context = "";
  c48_info[0].name = "pi";
  c48_info[0].dominantType = "";
  c48_info[0].resolved = "[B]pi";
  c48_info[0].fileLength = 0U;
  c48_info[0].fileTime1 = 0U;
  c48_info[0].fileTime2 = 0U;
  c48_info[1].context = "";
  c48_info[1].name = "mtimes";
  c48_info[1].dominantType = "double";
  c48_info[1].resolved = "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  c48_info[1].fileLength = 3425U;
  c48_info[1].fileTime1 = 1250701566U;
  c48_info[1].fileTime2 = 0U;
  c48_info[2].context = "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  c48_info[2].name = "nargin";
  c48_info[2].dominantType = "";
  c48_info[2].resolved = "[B]nargin";
  c48_info[2].fileLength = 0U;
  c48_info[2].fileTime1 = 0U;
  c48_info[2].fileTime2 = 0U;
  c48_info[3].context = "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  c48_info[3].name = "gt";
  c48_info[3].dominantType = "double";
  c48_info[3].resolved = "[B]gt";
  c48_info[3].fileLength = 0U;
  c48_info[3].fileTime1 = 0U;
  c48_info[3].fileTime2 = 0U;
  c48_info[4].context = "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  c48_info[4].name = "isa";
  c48_info[4].dominantType = "double";
  c48_info[4].resolved = "[B]isa";
  c48_info[4].fileLength = 0U;
  c48_info[4].fileTime1 = 0U;
  c48_info[4].fileTime2 = 0U;
  c48_info[5].context = "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  c48_info[5].name = "isinteger";
  c48_info[5].dominantType = "double";
  c48_info[5].resolved = "[B]isinteger";
  c48_info[5].fileLength = 0U;
  c48_info[5].fileTime1 = 0U;
  c48_info[5].fileTime2 = 0U;
  c48_info[6].context = "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  c48_info[6].name = "isscalar";
  c48_info[6].dominantType = "double";
  c48_info[6].resolved = "[B]isscalar";
  c48_info[6].fileLength = 0U;
  c48_info[6].fileTime1 = 0U;
  c48_info[6].fileTime2 = 0U;
  c48_info[7].context = "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  c48_info[7].name = "strcmp";
  c48_info[7].dominantType = "char";
  c48_info[7].resolved = "[B]strcmp";
  c48_info[7].fileLength = 0U;
  c48_info[7].fileTime1 = 0U;
  c48_info[7].fileTime2 = 0U;
  c48_info[8].context = "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  c48_info[8].name = "size";
  c48_info[8].dominantType = "double";
  c48_info[8].resolved = "[B]size";
  c48_info[8].fileLength = 0U;
  c48_info[8].fileTime1 = 0U;
  c48_info[8].fileTime2 = 0U;
  c48_info[9].context = "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  c48_info[9].name = "eq";
  c48_info[9].dominantType = "double";
  c48_info[9].resolved = "[B]eq";
  c48_info[9].fileLength = 0U;
  c48_info[9].fileTime1 = 0U;
  c48_info[9].fileTime2 = 0U;
  c48_info[10].context = "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  c48_info[10].name = "class";
  c48_info[10].dominantType = "double";
  c48_info[10].resolved = "[B]class";
  c48_info[10].fileLength = 0U;
  c48_info[10].fileTime1 = 0U;
  c48_info[10].fileTime2 = 0U;
  c48_info[11].context = "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  c48_info[11].name = "not";
  c48_info[11].dominantType = "logical";
  c48_info[11].resolved = "[B]not";
  c48_info[11].fileLength = 0U;
  c48_info[11].fileTime1 = 0U;
  c48_info[11].fileTime2 = 0U;
  c48_info[12].context = "";
  c48_info[12].name = "plus";
  c48_info[12].dominantType = "double";
  c48_info[12].resolved = "[B]plus";
  c48_info[12].fileLength = 0U;
  c48_info[12].fileTime1 = 0U;
  c48_info[12].fileTime2 = 0U;
  c48_info[13].context = "";
  c48_info[13].name = "mrdivide";
  c48_info[13].dominantType = "double";
  c48_info[13].resolved =
    "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mrdivide.m";
  c48_info[13].fileLength = 800U;
  c48_info[13].fileTime1 = 1238463090U;
  c48_info[13].fileTime2 = 0U;
  c48_info[14].context =
    "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mrdivide.m";
  c48_info[14].name = "ge";
  c48_info[14].dominantType = "double";
  c48_info[14].resolved = "[B]ge";
  c48_info[14].fileLength = 0U;
  c48_info[14].fileTime1 = 0U;
  c48_info[14].fileTime2 = 0U;
  c48_info[15].context =
    "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/mrdivide.m";
  c48_info[15].name = "rdivide";
  c48_info[15].dominantType = "double";
  c48_info[15].resolved =
    "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/rdivide.m";
  c48_info[15].fileLength = 403U;
  c48_info[15].fileTime1 = 1244764352U;
  c48_info[15].fileTime2 = 0U;
  c48_info[16].context =
    "[ILX]$matlabroot$/toolbox/eml/lib/matlab/ops/rdivide.m";
  c48_info[16].name = "eml_div";
  c48_info[16].dominantType = "double";
  c48_info[16].resolved =
    "[ILX]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_div.m";
  c48_info[16].fileLength = 4269U;
  c48_info[16].fileTime1 = 1228122626U;
  c48_info[16].fileTime2 = 0U;
  c48_info[17].context =
    "[ILX]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_div.m/eml_fldiv";
  c48_info[17].name = "isreal";
  c48_info[17].dominantType = "double";
  c48_info[17].resolved = "[B]isreal";
  c48_info[17].fileLength = 0U;
  c48_info[17].fileTime1 = 0U;
  c48_info[17].fileTime2 = 0U;
  c48_info[18].context = "";
  c48_info[18].name = "minus";
  c48_info[18].dominantType = "double";
  c48_info[18].resolved = "[B]minus";
  c48_info[18].fileLength = 0U;
  c48_info[18].fileTime1 = 0U;
  c48_info[18].fileTime2 = 0U;
  c48_info[19].context = "";
  c48_info[19].name = "uminus";
  c48_info[19].dominantType = "double";
  c48_info[19].resolved = "[B]uminus";
  c48_info[19].fileLength = 0U;
  c48_info[19].fileTime1 = 0U;
  c48_info[19].fileTime2 = 0U;
}

static const mxArray *c48_g_sf_marshall(void *chartInstanceVoid, void *c48_u)
{
  const mxArray *c48_y = NULL;
  boolean_T c48_b_u;
  const mxArray *c48_b_y = NULL;
  SFc48_controlMCUSlugsMKIIInstanceStruct *chartInstance;
  chartInstance = (SFc48_controlMCUSlugsMKIIInstanceStruct *)chartInstanceVoid;
  c48_y = NULL;
  c48_b_u = *((boolean_T *)c48_u);
  c48_b_y = NULL;
  sf_mex_assign(&c48_b_y, sf_mex_create("y", &c48_b_u, 11, 0U, 0U, 0U, 0));
  sf_mex_assign(&c48_y, c48_b_y);
  return c48_y;
}

static real32_T c48_emlrt_marshallIn(SFc48_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c48_y, const char_T *
  c48_name)
{
  real32_T c48_b_y;
  real32_T c48_f0;
  sf_mex_import(c48_name, sf_mex_dup(c48_y), &c48_f0, 1, 1, 0U, 0, 0U, 0);
  c48_b_y = c48_f0;
  sf_mex_destroy(&c48_y);
  return c48_b_y;
}

static real_T c48_b_emlrt_marshallIn(SFc48_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c48_b_a, const char_T *
  c48_name)
{
  real_T c48_y;
  real_T c48_d0;
  if (mxIsEmpty(c48_b_a)) {
    chartInstance->c48_a_not_empty = FALSE;
  } else {
    chartInstance->c48_a_not_empty = TRUE;
    sf_mex_import(c48_name, sf_mex_dup(c48_b_a), &c48_d0, 1, 0, 0U, 0, 0U, 0);
    c48_y = c48_d0;
  }

  sf_mex_destroy(&c48_b_a);
  return c48_y;
}

static real_T c48_c_emlrt_marshallIn(SFc48_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c48_b_b, const char_T *
  c48_name)
{
  real_T c48_y;
  real_T c48_d1;
  if (mxIsEmpty(c48_b_b)) {
    chartInstance->c48_b_not_empty = FALSE;
  } else {
    chartInstance->c48_b_not_empty = TRUE;
    sf_mex_import(c48_name, sf_mex_dup(c48_b_b), &c48_d1, 1, 0, 0U, 0, 0U, 0);
    c48_y = c48_d1;
  }

  sf_mex_destroy(&c48_b_b);
  return c48_y;
}

static real32_T c48_d_emlrt_marshallIn(SFc48_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c48_b_u_km1, const
  char_T *c48_name)
{
  real32_T c48_y;
  real32_T c48_f1;
  if (mxIsEmpty(c48_b_u_km1)) {
    chartInstance->c48_u_km1_not_empty = FALSE;
  } else {
    chartInstance->c48_u_km1_not_empty = TRUE;
    sf_mex_import(c48_name, sf_mex_dup(c48_b_u_km1), &c48_f1, 1, 1, 0U, 0, 0U, 0);
    c48_y = c48_f1;
  }

  sf_mex_destroy(&c48_b_u_km1);
  return c48_y;
}

static real32_T c48_e_emlrt_marshallIn(SFc48_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c48_b_y_km1, const
  char_T *c48_name)
{
  real32_T c48_y;
  real32_T c48_f2;
  if (mxIsEmpty(c48_b_y_km1)) {
    chartInstance->c48_y_km1_not_empty = FALSE;
  } else {
    chartInstance->c48_y_km1_not_empty = TRUE;
    sf_mex_import(c48_name, sf_mex_dup(c48_b_y_km1), &c48_f2, 1, 1, 0U, 0, 0U, 0);
    c48_y = c48_f2;
  }

  sf_mex_destroy(&c48_b_y_km1);
  return c48_y;
}

static uint8_T c48_f_emlrt_marshallIn(SFc48_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *
  c48_b_is_active_c48_controlMCUSlugsMKII, const char_T *c48_name)
{
  uint8_T c48_y;
  uint8_T c48_u0;
  sf_mex_import(c48_name, sf_mex_dup(c48_b_is_active_c48_controlMCUSlugsMKII),
                &c48_u0, 1, 3, 0U, 0, 0U, 0);
  c48_y = c48_u0;
  sf_mex_destroy(&c48_b_is_active_c48_controlMCUSlugsMKII);
  return c48_y;
}

static void init_dsm_address_info(SFc48_controlMCUSlugsMKIIInstanceStruct
  *chartInstance)
{
}

/* SFunction Glue Code */
void sf_c48_controlMCUSlugsMKII_get_check_sum(mxArray *plhs[])
{
  ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(1353272664U);
  ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(3696758036U);
  ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(3888534806U);
  ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(1976201762U);
}

mxArray *sf_c48_controlMCUSlugsMKII_get_autoinheritance_info(void)
{
  const char *autoinheritanceFields[] = { "checksum", "inputs", "parameters",
    "outputs" };

  mxArray *mxAutoinheritanceInfo = mxCreateStructMatrix(1,1,4,
    autoinheritanceFields);

  {
    mxArray *mxChecksum = mxCreateDoubleMatrix(4,1,mxREAL);
    double *pr = mxGetPr(mxChecksum);
    pr[0] = (double)(128223108U);
    pr[1] = (double)(2697122563U);
    pr[2] = (double)(1981904500U);
    pr[3] = (double)(4073712045U);
    mxSetField(mxAutoinheritanceInfo,0,"checksum",mxChecksum);
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,3,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(9));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,1,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,1,"type",mxType);
    }

    mxSetField(mxData,1,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,2,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,2,"type",mxType);
    }

    mxSetField(mxData,2,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"inputs",mxData);
  }

  {
    mxSetField(mxAutoinheritanceInfo,0,"parameters",mxCreateDoubleMatrix(0,0,
                mxREAL));
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,1,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(9));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"outputs",mxData);
  }

  return(mxAutoinheritanceInfo);
}

static mxArray *sf_get_sim_state_info_c48_controlMCUSlugsMKII(void)
{
  const char *infoFields[] = { "chartChecksum", "varInfo" };

  mxArray *mxInfo = mxCreateStructMatrix(1, 1, 2, infoFields);
  const char *infoEncStr[] = {
    "100 S1x6'type','srcId','name','auxInfo'{{M[1],M[5],T\"y\",},{M[4],M[0],T\"a\",S'l','i','p'{{M1x2[137 138],M[0],}}},{M[4],M[0],T\"b\",S'l','i','p'{{M1x2[150 151],M[0],}}},{M[4],M[0],T\"u_km1\",S'l','i','p'{{M1x2[180 185],M[0],}}},{M[4],M[0],T\"y_km1\",S'l','i','p'{{M1x2[163 168],M[0],}}},{M[8],M[0],T\"is_active_c48_controlMCUSlugsMKII\",}}"
  };

  mxArray *mxVarInfo = sf_mex_decode_encoded_mx_struct_array(infoEncStr, 6, 10);
  mxArray *mxChecksum = mxCreateDoubleMatrix(1, 4, mxREAL);
  sf_c48_controlMCUSlugsMKII_get_check_sum(&mxChecksum);
  mxSetField(mxInfo, 0, infoFields[0], mxChecksum);
  mxSetField(mxInfo, 0, infoFields[1], mxVarInfo);
  return mxInfo;
}

static void chart_debug_initialization(SimStruct *S, unsigned int
  fullDebuggerInitialization)
{
  if (!sim_mode_is_rtw_gen(S)) {
    SFc48_controlMCUSlugsMKIIInstanceStruct *chartInstance;
    chartInstance = (SFc48_controlMCUSlugsMKIIInstanceStruct *)
      ((ChartInfoStruct *)(ssGetUserData(S)))->chartInstance;
    if (ssIsFirstInitCond(S) && fullDebuggerInitialization==1) {
      /* do this only if simulation is starting */
      {
        unsigned int chartAlreadyPresent;
        chartAlreadyPresent = sf_debug_initialize_chart
          (_controlMCUSlugsMKIIMachineNumber_,
           48,
           1,
           1,
           4,
           0,
           0,
           0,
           0,
           0,
           &(chartInstance->chartNumber),
           &(chartInstance->instanceNumber),
           ssGetPath(S),
           (void *)S);
        if (chartAlreadyPresent==0) {
          /* this is the first instance */
          init_script_number_translation(_controlMCUSlugsMKIIMachineNumber_,
            chartInstance->chartNumber);
          sf_debug_set_chart_disable_implicit_casting
            (_controlMCUSlugsMKIIMachineNumber_,chartInstance->chartNumber,1);
          sf_debug_set_chart_event_thresholds(_controlMCUSlugsMKIIMachineNumber_,
            chartInstance->chartNumber,
            0,
            0,
            0);
          _SFD_SET_DATA_PROPS(0,1,1,0,SF_SINGLE,0,NULL,0,0,0,0.0,1.0,0,"u",0,
                              (MexFcnForType)c48_e_sf_marshall);
          _SFD_SET_DATA_PROPS(1,2,0,1,SF_SINGLE,0,NULL,0,0,0,0.0,1.0,0,"y",0,
                              (MexFcnForType)c48_e_sf_marshall);
          _SFD_SET_DATA_PROPS(2,1,1,0,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,"T",0,
                              (MexFcnForType)c48_f_sf_marshall);
          _SFD_SET_DATA_PROPS(3,1,1,0,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,"f",0,
                              (MexFcnForType)c48_f_sf_marshall);
          _SFD_STATE_INFO(0,0,2);
          _SFD_CH_SUBSTATE_COUNT(0);
          _SFD_CH_SUBSTATE_DECOMP(0);
        }

        _SFD_CV_INIT_CHART(0,0,0,0);

        {
          _SFD_CV_INIT_STATE(0,0,0,0,0,0,NULL,NULL);
        }

        _SFD_CV_INIT_TRANS(0,0,NULL,NULL,0,NULL);

        /* Initialization of EML Model Coverage */
        _SFD_CV_INIT_EML(0,1,1,0,0,0,0,0,0);
        _SFD_CV_INIT_EML_FCN(0,0,"eML_blk_kernel",0,-1,455);
        _SFD_CV_INIT_EML_IF(0,0,186,199,-1,411);
        _SFD_TRANS_COV_WTS(0,0,0,1,0);
        if (chartAlreadyPresent==0) {
          _SFD_TRANS_COV_MAPS(0,
                              0,NULL,NULL,
                              0,NULL,NULL,
                              1,NULL,NULL,
                              0,NULL,NULL);
        }

        {
          real32_T *c48_u;
          real32_T *c48_y;
          real_T *c48_T;
          real_T *c48_f;
          c48_f = (real_T *)ssGetInputPortSignal(chartInstance->S, 2);
          c48_T = (real_T *)ssGetInputPortSignal(chartInstance->S, 1);
          c48_y = (real32_T *)ssGetOutputPortSignal(chartInstance->S, 1);
          c48_u = (real32_T *)ssGetInputPortSignal(chartInstance->S, 0);
          _SFD_SET_DATA_VALUE_PTR(0U, c48_u);
          _SFD_SET_DATA_VALUE_PTR(1U, c48_y);
          _SFD_SET_DATA_VALUE_PTR(2U, c48_T);
          _SFD_SET_DATA_VALUE_PTR(3U, c48_f);
        }
      }
    } else {
      sf_debug_reset_current_state_configuration
        (_controlMCUSlugsMKIIMachineNumber_,chartInstance->chartNumber,
         chartInstance->instanceNumber);
    }
  }
}

static void sf_opaque_initialize_c48_controlMCUSlugsMKII(void *chartInstanceVar)
{
  chart_debug_initialization(((SFc48_controlMCUSlugsMKIIInstanceStruct*)
    chartInstanceVar)->S,0);
  initialize_params_c48_controlMCUSlugsMKII
    ((SFc48_controlMCUSlugsMKIIInstanceStruct*) chartInstanceVar);
  initialize_c48_controlMCUSlugsMKII((SFc48_controlMCUSlugsMKIIInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_enable_c48_controlMCUSlugsMKII(void *chartInstanceVar)
{
  enable_c48_controlMCUSlugsMKII((SFc48_controlMCUSlugsMKIIInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_disable_c48_controlMCUSlugsMKII(void *chartInstanceVar)
{
  disable_c48_controlMCUSlugsMKII((SFc48_controlMCUSlugsMKIIInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_gateway_c48_controlMCUSlugsMKII(void *chartInstanceVar)
{
  sf_c48_controlMCUSlugsMKII((SFc48_controlMCUSlugsMKIIInstanceStruct*)
    chartInstanceVar);
}

static mxArray* sf_internal_get_sim_state_c48_controlMCUSlugsMKII(SimStruct* S)
{
  ChartInfoStruct *chartInfo = (ChartInfoStruct*) ssGetUserData(S);
  mxArray *plhs[1] = { NULL };

  mxArray *prhs[4];
  int mxError = 0;
  prhs[0] = mxCreateString("chart_simctx_raw2high");
  prhs[1] = mxCreateDoubleScalar(ssGetSFuncBlockHandle(S));
  prhs[2] = (mxArray*) get_sim_state_c48_controlMCUSlugsMKII
    ((SFc48_controlMCUSlugsMKIIInstanceStruct*)chartInfo->chartInstance);/* raw sim ctx */
  prhs[3] = sf_get_sim_state_info_c48_controlMCUSlugsMKII();/* state var info */
  mxError = sf_mex_call_matlab(1, plhs, 4, prhs, "sfprivate");
  mxDestroyArray(prhs[0]);
  mxDestroyArray(prhs[1]);
  mxDestroyArray(prhs[2]);
  mxDestroyArray(prhs[3]);
  if (mxError || plhs[0] == NULL) {
    sf_mex_error_message("Stateflow Internal Error: \nError calling 'chart_simctx_raw2high'.\n");
  }

  return plhs[0];
}

static void sf_internal_set_sim_state_c48_controlMCUSlugsMKII(SimStruct* S,
  const mxArray *st)
{
  ChartInfoStruct *chartInfo = (ChartInfoStruct*) ssGetUserData(S);
  mxArray *plhs[1] = { NULL };

  mxArray *prhs[4];
  int mxError = 0;
  prhs[0] = mxCreateString("chart_simctx_high2raw");
  prhs[1] = mxCreateDoubleScalar(ssGetSFuncBlockHandle(S));
  prhs[2] = mxDuplicateArray(st);      /* high level simctx */
  prhs[3] = (mxArray*) sf_get_sim_state_info_c48_controlMCUSlugsMKII();/* state var info */
  mxError = sf_mex_call_matlab(1, plhs, 4, prhs, "sfprivate");
  mxDestroyArray(prhs[0]);
  mxDestroyArray(prhs[1]);
  mxDestroyArray(prhs[2]);
  mxDestroyArray(prhs[3]);
  if (mxError || plhs[0] == NULL) {
    sf_mex_error_message("Stateflow Internal Error: \nError calling 'chart_simctx_high2raw'.\n");
  }

  set_sim_state_c48_controlMCUSlugsMKII((SFc48_controlMCUSlugsMKIIInstanceStruct*)
    chartInfo->chartInstance, mxDuplicateArray(plhs[0]));
  mxDestroyArray(plhs[0]);
}

static mxArray* sf_opaque_get_sim_state_c48_controlMCUSlugsMKII(SimStruct* S)
{
  return sf_internal_get_sim_state_c48_controlMCUSlugsMKII(S);
}

static void sf_opaque_set_sim_state_c48_controlMCUSlugsMKII(SimStruct* S, const
  mxArray *st)
{
  sf_internal_set_sim_state_c48_controlMCUSlugsMKII(S, st);
}

static void sf_opaque_terminate_c48_controlMCUSlugsMKII(void *chartInstanceVar)
{
  if (chartInstanceVar!=NULL) {
    SimStruct *S = ((SFc48_controlMCUSlugsMKIIInstanceStruct*) chartInstanceVar
      )->S;
    if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
      sf_clear_rtw_identifier(S);
    }

    finalize_c48_controlMCUSlugsMKII((SFc48_controlMCUSlugsMKIIInstanceStruct*)
      chartInstanceVar);
    free((void *)chartInstanceVar);
    ssSetUserData(S,NULL);
  }
}

extern unsigned int sf_machine_global_initializer_called(void);
static void mdlProcessParameters_c48_controlMCUSlugsMKII(SimStruct *S)
{
  int i;
  for (i=0;i<ssGetNumRunTimeParams(S);i++) {
    if (ssGetSFcnParamTunable(S,i)) {
      ssUpdateDlgParamAsRunTimeParam(S,i);
    }
  }

  if (sf_machine_global_initializer_called()) {
    initialize_params_c48_controlMCUSlugsMKII
      ((SFc48_controlMCUSlugsMKIIInstanceStruct*)(((ChartInfoStruct *)
         ssGetUserData(S))->chartInstance));
  }
}

static void mdlSetWorkWidths_c48_controlMCUSlugsMKII(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
    int_T chartIsInlinable =
      (int_T)sf_is_chart_inlinable("controlMCUSlugsMKII","controlMCUSlugsMKII",
      48);
    ssSetStateflowIsInlinable(S,chartIsInlinable);
    ssSetRTWCG(S,sf_rtw_info_uint_prop("controlMCUSlugsMKII",
                "controlMCUSlugsMKII",48,"RTWCG"));
    ssSetEnableFcnIsTrivial(S,1);
    ssSetDisableFcnIsTrivial(S,1);
    ssSetNotMultipleInlinable(S,sf_rtw_info_uint_prop("controlMCUSlugsMKII",
      "controlMCUSlugsMKII",48,"gatewayCannotBeInlinedMultipleTimes"));
    if (chartIsInlinable) {
      ssSetInputPortOptimOpts(S, 0, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 1, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 2, SS_REUSABLE_AND_LOCAL);
      sf_mark_chart_expressionable_inputs(S,"controlMCUSlugsMKII",
        "controlMCUSlugsMKII",48,3);
      sf_mark_chart_reusable_outputs(S,"controlMCUSlugsMKII",
        "controlMCUSlugsMKII",48,1);
    }

    sf_set_rtw_dwork_info(S,"controlMCUSlugsMKII","controlMCUSlugsMKII",48);
    ssSetHasSubFunctions(S,!(chartIsInlinable));
    ssSetOptions(S,ssGetOptions(S)|SS_OPTION_WORKS_WITH_CODE_REUSE);
  }

  ssSetChecksum0(S,(2564540360U));
  ssSetChecksum1(S,(692271509U));
  ssSetChecksum2(S,(3514050889U));
  ssSetChecksum3(S,(3050027828U));
  ssSetmdlDerivatives(S, NULL);
  ssSetExplicitFCSSCtrl(S,1);
}

static void mdlRTW_c48_controlMCUSlugsMKII(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S)) {
    sf_write_symbol_mapping(S, "controlMCUSlugsMKII", "controlMCUSlugsMKII",48);
    ssWriteRTWStrParam(S, "StateflowChartType", "Embedded MATLAB");
  }
}

static void mdlStart_c48_controlMCUSlugsMKII(SimStruct *S)
{
  SFc48_controlMCUSlugsMKIIInstanceStruct *chartInstance;
  chartInstance = (SFc48_controlMCUSlugsMKIIInstanceStruct *)malloc(sizeof
    (SFc48_controlMCUSlugsMKIIInstanceStruct));
  memset(chartInstance, 0, sizeof(SFc48_controlMCUSlugsMKIIInstanceStruct));
  if (chartInstance==NULL) {
    sf_mex_error_message("Could not allocate memory for chart instance.");
  }

  chartInstance->chartInfo.chartInstance = chartInstance;
  chartInstance->chartInfo.isEMLChart = 1;
  chartInstance->chartInfo.chartInitialized = 0;
  chartInstance->chartInfo.sFunctionGateway =
    sf_opaque_gateway_c48_controlMCUSlugsMKII;
  chartInstance->chartInfo.initializeChart =
    sf_opaque_initialize_c48_controlMCUSlugsMKII;
  chartInstance->chartInfo.terminateChart =
    sf_opaque_terminate_c48_controlMCUSlugsMKII;
  chartInstance->chartInfo.enableChart =
    sf_opaque_enable_c48_controlMCUSlugsMKII;
  chartInstance->chartInfo.disableChart =
    sf_opaque_disable_c48_controlMCUSlugsMKII;
  chartInstance->chartInfo.getSimState =
    sf_opaque_get_sim_state_c48_controlMCUSlugsMKII;
  chartInstance->chartInfo.setSimState =
    sf_opaque_set_sim_state_c48_controlMCUSlugsMKII;
  chartInstance->chartInfo.getSimStateInfo =
    sf_get_sim_state_info_c48_controlMCUSlugsMKII;
  chartInstance->chartInfo.zeroCrossings = NULL;
  chartInstance->chartInfo.outputs = NULL;
  chartInstance->chartInfo.derivatives = NULL;
  chartInstance->chartInfo.mdlRTW = mdlRTW_c48_controlMCUSlugsMKII;
  chartInstance->chartInfo.mdlStart = mdlStart_c48_controlMCUSlugsMKII;
  chartInstance->chartInfo.mdlSetWorkWidths =
    mdlSetWorkWidths_c48_controlMCUSlugsMKII;
  chartInstance->chartInfo.extModeExec = NULL;
  chartInstance->chartInfo.restoreLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.restoreBeforeLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.storeCurrentConfiguration = NULL;
  chartInstance->S = S;
  ssSetUserData(S,(void *)(&(chartInstance->chartInfo)));/* register the chart instance with simstruct */
  if (!sim_mode_is_rtw_gen(S)) {
    init_dsm_address_info(chartInstance);
  }

  chart_debug_initialization(S,1);
}

void c48_controlMCUSlugsMKII_method_dispatcher(SimStruct *S, int_T method, void *
  data)
{
  switch (method) {
   case SS_CALL_MDL_START:
    mdlStart_c48_controlMCUSlugsMKII(S);
    break;

   case SS_CALL_MDL_SET_WORK_WIDTHS:
    mdlSetWorkWidths_c48_controlMCUSlugsMKII(S);
    break;

   case SS_CALL_MDL_PROCESS_PARAMETERS:
    mdlProcessParameters_c48_controlMCUSlugsMKII(S);
    break;

   default:
    /* Unhandled method */
    sf_mex_error_message("Stateflow Internal Error:\n"
                         "Error calling c48_controlMCUSlugsMKII_method_dispatcher.\n"
                         "Can't handle method %d.\n", method);
    break;
  }
}
