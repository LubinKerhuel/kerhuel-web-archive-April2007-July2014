/* Include files */

#include "controlMCUSlugsMKII_sfun.h"
#include "c1_controlMCUSlugsMKII.h"
#include "c2_controlMCUSlugsMKII.h"
#include "c3_controlMCUSlugsMKII.h"
#include "c4_controlMCUSlugsMKII.h"
#include "c5_controlMCUSlugsMKII.h"
#include "c6_controlMCUSlugsMKII.h"
#include "c7_controlMCUSlugsMKII.h"
#include "c8_controlMCUSlugsMKII.h"
#include "c9_controlMCUSlugsMKII.h"
#include "c10_controlMCUSlugsMKII.h"
#include "c11_controlMCUSlugsMKII.h"
#include "c12_controlMCUSlugsMKII.h"
#include "c13_controlMCUSlugsMKII.h"
#include "c14_controlMCUSlugsMKII.h"
#include "c15_controlMCUSlugsMKII.h"
#include "c16_controlMCUSlugsMKII.h"
#include "c17_controlMCUSlugsMKII.h"
#include "c18_controlMCUSlugsMKII.h"
#include "c19_controlMCUSlugsMKII.h"
#include "c20_controlMCUSlugsMKII.h"
#include "c21_controlMCUSlugsMKII.h"
#include "c22_controlMCUSlugsMKII.h"
#include "c23_controlMCUSlugsMKII.h"
#include "c24_controlMCUSlugsMKII.h"
#include "c25_controlMCUSlugsMKII.h"
#include "c26_controlMCUSlugsMKII.h"
#include "c27_controlMCUSlugsMKII.h"
#include "c28_controlMCUSlugsMKII.h"
#include "c29_controlMCUSlugsMKII.h"
#include "c30_controlMCUSlugsMKII.h"
#include "c31_controlMCUSlugsMKII.h"
#include "c32_controlMCUSlugsMKII.h"
#include "c33_controlMCUSlugsMKII.h"
#include "c34_controlMCUSlugsMKII.h"
#include "c35_controlMCUSlugsMKII.h"
#include "c36_controlMCUSlugsMKII.h"
#include "c37_controlMCUSlugsMKII.h"
#include "c39_controlMCUSlugsMKII.h"
#include "c40_controlMCUSlugsMKII.h"
#include "c41_controlMCUSlugsMKII.h"
#include "c42_controlMCUSlugsMKII.h"
#include "c48_controlMCUSlugsMKII.h"
#include "c49_controlMCUSlugsMKII.h"

/* Type Definitions */

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */
int32_T _sfEvent_;
uint32_T _controlMCUSlugsMKIIMachineNumber_;
real_T _sfTime_;

/* Function Declarations */

/* Function Definitions */
void controlMCUSlugsMKII_initializer(void)
{
  _sfEvent_ = CALL_EVENT;
}

void controlMCUSlugsMKII_terminator(void)
{
}

/* SFunction Glue Code */
unsigned int sf_controlMCUSlugsMKII_method_dispatcher(SimStruct *simstructPtr,
  unsigned int chartFileNumber, const char* specsCksum, int_T method, void *data)
{
  if (chartFileNumber==1) {
    c1_controlMCUSlugsMKII_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==2) {
    c2_controlMCUSlugsMKII_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==3) {
    c3_controlMCUSlugsMKII_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==4) {
    c4_controlMCUSlugsMKII_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==5) {
    c5_controlMCUSlugsMKII_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==6) {
    c6_controlMCUSlugsMKII_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==7) {
    c7_controlMCUSlugsMKII_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==8) {
    c8_controlMCUSlugsMKII_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==9) {
    c9_controlMCUSlugsMKII_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==10) {
    c10_controlMCUSlugsMKII_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==11) {
    c11_controlMCUSlugsMKII_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==12) {
    c12_controlMCUSlugsMKII_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==13) {
    c13_controlMCUSlugsMKII_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==14) {
    c14_controlMCUSlugsMKII_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==15) {
    c15_controlMCUSlugsMKII_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==16) {
    c16_controlMCUSlugsMKII_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==17) {
    c17_controlMCUSlugsMKII_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==18) {
    c18_controlMCUSlugsMKII_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==19) {
    c19_controlMCUSlugsMKII_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==20) {
    c20_controlMCUSlugsMKII_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==21) {
    c21_controlMCUSlugsMKII_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==22) {
    c22_controlMCUSlugsMKII_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==23) {
    c23_controlMCUSlugsMKII_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==24) {
    c24_controlMCUSlugsMKII_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==25) {
    c25_controlMCUSlugsMKII_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==26) {
    c26_controlMCUSlugsMKII_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==27) {
    c27_controlMCUSlugsMKII_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==28) {
    c28_controlMCUSlugsMKII_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==29) {
    c29_controlMCUSlugsMKII_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==30) {
    c30_controlMCUSlugsMKII_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==31) {
    c31_controlMCUSlugsMKII_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==32) {
    c32_controlMCUSlugsMKII_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==33) {
    c33_controlMCUSlugsMKII_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==34) {
    c34_controlMCUSlugsMKII_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==35) {
    c35_controlMCUSlugsMKII_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==36) {
    c36_controlMCUSlugsMKII_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==37) {
    c37_controlMCUSlugsMKII_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==39) {
    c39_controlMCUSlugsMKII_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==40) {
    c40_controlMCUSlugsMKII_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==41) {
    c41_controlMCUSlugsMKII_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==42) {
    c42_controlMCUSlugsMKII_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==48) {
    c48_controlMCUSlugsMKII_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==49) {
    c49_controlMCUSlugsMKII_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  return 0;
}

unsigned int sf_controlMCUSlugsMKII_process_check_sum_call( int nlhs, mxArray *
  plhs[], int nrhs, const mxArray * prhs[] )
{

#ifdef MATLAB_MEX_FILE

  char commandName[20];
  if (nrhs<1 || !mxIsChar(prhs[0]) )
    return 0;

  /* Possible call to get the checksum */
  mxGetString(prhs[0], commandName,sizeof(commandName)/sizeof(char));
  commandName[(sizeof(commandName)/sizeof(char)-1)] = '\0';
  if (strcmp(commandName,"sf_get_check_sum"))
    return 0;
  plhs[0] = mxCreateDoubleMatrix( 1,4,mxREAL);
  if (nrhs>1 && mxIsChar(prhs[1])) {
    mxGetString(prhs[1], commandName,sizeof(commandName)/sizeof(char));
    commandName[(sizeof(commandName)/sizeof(char)-1)] = '\0';
    if (!strcmp(commandName,"machine")) {
      ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(1791027649U);
      ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(868199221U);
      ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(549306757U);
      ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(53851443U);
    } else if (!strcmp(commandName,"exportedFcn")) {
      ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(0U);
      ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(0U);
      ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(0U);
      ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(0U);
    } else if (!strcmp(commandName,"makefile")) {
      ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(3678056499U);
      ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(2560095740U);
      ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(2627421242U);
      ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(76821836U);
    } else if (nrhs==3 && !strcmp(commandName,"chart")) {
      unsigned int chartFileNumber;
      chartFileNumber = (unsigned int)mxGetScalar(prhs[2]);
      switch (chartFileNumber) {
       case 1:
        {
          extern void sf_c1_controlMCUSlugsMKII_get_check_sum(mxArray *plhs[]);
          sf_c1_controlMCUSlugsMKII_get_check_sum(plhs);
          break;
        }

       case 2:
        {
          extern void sf_c2_controlMCUSlugsMKII_get_check_sum(mxArray *plhs[]);
          sf_c2_controlMCUSlugsMKII_get_check_sum(plhs);
          break;
        }

       case 3:
        {
          extern void sf_c3_controlMCUSlugsMKII_get_check_sum(mxArray *plhs[]);
          sf_c3_controlMCUSlugsMKII_get_check_sum(plhs);
          break;
        }

       case 4:
        {
          extern void sf_c4_controlMCUSlugsMKII_get_check_sum(mxArray *plhs[]);
          sf_c4_controlMCUSlugsMKII_get_check_sum(plhs);
          break;
        }

       case 5:
        {
          extern void sf_c5_controlMCUSlugsMKII_get_check_sum(mxArray *plhs[]);
          sf_c5_controlMCUSlugsMKII_get_check_sum(plhs);
          break;
        }

       case 6:
        {
          extern void sf_c6_controlMCUSlugsMKII_get_check_sum(mxArray *plhs[]);
          sf_c6_controlMCUSlugsMKII_get_check_sum(plhs);
          break;
        }

       case 7:
        {
          extern void sf_c7_controlMCUSlugsMKII_get_check_sum(mxArray *plhs[]);
          sf_c7_controlMCUSlugsMKII_get_check_sum(plhs);
          break;
        }

       case 8:
        {
          extern void sf_c8_controlMCUSlugsMKII_get_check_sum(mxArray *plhs[]);
          sf_c8_controlMCUSlugsMKII_get_check_sum(plhs);
          break;
        }

       case 9:
        {
          extern void sf_c9_controlMCUSlugsMKII_get_check_sum(mxArray *plhs[]);
          sf_c9_controlMCUSlugsMKII_get_check_sum(plhs);
          break;
        }

       case 10:
        {
          extern void sf_c10_controlMCUSlugsMKII_get_check_sum(mxArray *plhs[]);
          sf_c10_controlMCUSlugsMKII_get_check_sum(plhs);
          break;
        }

       case 11:
        {
          extern void sf_c11_controlMCUSlugsMKII_get_check_sum(mxArray *plhs[]);
          sf_c11_controlMCUSlugsMKII_get_check_sum(plhs);
          break;
        }

       case 12:
        {
          extern void sf_c12_controlMCUSlugsMKII_get_check_sum(mxArray *plhs[]);
          sf_c12_controlMCUSlugsMKII_get_check_sum(plhs);
          break;
        }

       case 13:
        {
          extern void sf_c13_controlMCUSlugsMKII_get_check_sum(mxArray *plhs[]);
          sf_c13_controlMCUSlugsMKII_get_check_sum(plhs);
          break;
        }

       case 14:
        {
          extern void sf_c14_controlMCUSlugsMKII_get_check_sum(mxArray *plhs[]);
          sf_c14_controlMCUSlugsMKII_get_check_sum(plhs);
          break;
        }

       case 15:
        {
          extern void sf_c15_controlMCUSlugsMKII_get_check_sum(mxArray *plhs[]);
          sf_c15_controlMCUSlugsMKII_get_check_sum(plhs);
          break;
        }

       case 16:
        {
          extern void sf_c16_controlMCUSlugsMKII_get_check_sum(mxArray *plhs[]);
          sf_c16_controlMCUSlugsMKII_get_check_sum(plhs);
          break;
        }

       case 17:
        {
          extern void sf_c17_controlMCUSlugsMKII_get_check_sum(mxArray *plhs[]);
          sf_c17_controlMCUSlugsMKII_get_check_sum(plhs);
          break;
        }

       case 18:
        {
          extern void sf_c18_controlMCUSlugsMKII_get_check_sum(mxArray *plhs[]);
          sf_c18_controlMCUSlugsMKII_get_check_sum(plhs);
          break;
        }

       case 19:
        {
          extern void sf_c19_controlMCUSlugsMKII_get_check_sum(mxArray *plhs[]);
          sf_c19_controlMCUSlugsMKII_get_check_sum(plhs);
          break;
        }

       case 20:
        {
          extern void sf_c20_controlMCUSlugsMKII_get_check_sum(mxArray *plhs[]);
          sf_c20_controlMCUSlugsMKII_get_check_sum(plhs);
          break;
        }

       case 21:
        {
          extern void sf_c21_controlMCUSlugsMKII_get_check_sum(mxArray *plhs[]);
          sf_c21_controlMCUSlugsMKII_get_check_sum(plhs);
          break;
        }

       case 22:
        {
          extern void sf_c22_controlMCUSlugsMKII_get_check_sum(mxArray *plhs[]);
          sf_c22_controlMCUSlugsMKII_get_check_sum(plhs);
          break;
        }

       case 23:
        {
          extern void sf_c23_controlMCUSlugsMKII_get_check_sum(mxArray *plhs[]);
          sf_c23_controlMCUSlugsMKII_get_check_sum(plhs);
          break;
        }

       case 24:
        {
          extern void sf_c24_controlMCUSlugsMKII_get_check_sum(mxArray *plhs[]);
          sf_c24_controlMCUSlugsMKII_get_check_sum(plhs);
          break;
        }

       case 25:
        {
          extern void sf_c25_controlMCUSlugsMKII_get_check_sum(mxArray *plhs[]);
          sf_c25_controlMCUSlugsMKII_get_check_sum(plhs);
          break;
        }

       case 26:
        {
          extern void sf_c26_controlMCUSlugsMKII_get_check_sum(mxArray *plhs[]);
          sf_c26_controlMCUSlugsMKII_get_check_sum(plhs);
          break;
        }

       case 27:
        {
          extern void sf_c27_controlMCUSlugsMKII_get_check_sum(mxArray *plhs[]);
          sf_c27_controlMCUSlugsMKII_get_check_sum(plhs);
          break;
        }

       case 28:
        {
          extern void sf_c28_controlMCUSlugsMKII_get_check_sum(mxArray *plhs[]);
          sf_c28_controlMCUSlugsMKII_get_check_sum(plhs);
          break;
        }

       case 29:
        {
          extern void sf_c29_controlMCUSlugsMKII_get_check_sum(mxArray *plhs[]);
          sf_c29_controlMCUSlugsMKII_get_check_sum(plhs);
          break;
        }

       case 30:
        {
          extern void sf_c30_controlMCUSlugsMKII_get_check_sum(mxArray *plhs[]);
          sf_c30_controlMCUSlugsMKII_get_check_sum(plhs);
          break;
        }

       case 31:
        {
          extern void sf_c31_controlMCUSlugsMKII_get_check_sum(mxArray *plhs[]);
          sf_c31_controlMCUSlugsMKII_get_check_sum(plhs);
          break;
        }

       case 32:
        {
          extern void sf_c32_controlMCUSlugsMKII_get_check_sum(mxArray *plhs[]);
          sf_c32_controlMCUSlugsMKII_get_check_sum(plhs);
          break;
        }

       case 33:
        {
          extern void sf_c33_controlMCUSlugsMKII_get_check_sum(mxArray *plhs[]);
          sf_c33_controlMCUSlugsMKII_get_check_sum(plhs);
          break;
        }

       case 34:
        {
          extern void sf_c34_controlMCUSlugsMKII_get_check_sum(mxArray *plhs[]);
          sf_c34_controlMCUSlugsMKII_get_check_sum(plhs);
          break;
        }

       case 35:
        {
          extern void sf_c35_controlMCUSlugsMKII_get_check_sum(mxArray *plhs[]);
          sf_c35_controlMCUSlugsMKII_get_check_sum(plhs);
          break;
        }

       case 36:
        {
          extern void sf_c36_controlMCUSlugsMKII_get_check_sum(mxArray *plhs[]);
          sf_c36_controlMCUSlugsMKII_get_check_sum(plhs);
          break;
        }

       case 37:
        {
          extern void sf_c37_controlMCUSlugsMKII_get_check_sum(mxArray *plhs[]);
          sf_c37_controlMCUSlugsMKII_get_check_sum(plhs);
          break;
        }

       case 39:
        {
          extern void sf_c39_controlMCUSlugsMKII_get_check_sum(mxArray *plhs[]);
          sf_c39_controlMCUSlugsMKII_get_check_sum(plhs);
          break;
        }

       case 40:
        {
          extern void sf_c40_controlMCUSlugsMKII_get_check_sum(mxArray *plhs[]);
          sf_c40_controlMCUSlugsMKII_get_check_sum(plhs);
          break;
        }

       case 41:
        {
          extern void sf_c41_controlMCUSlugsMKII_get_check_sum(mxArray *plhs[]);
          sf_c41_controlMCUSlugsMKII_get_check_sum(plhs);
          break;
        }

       case 42:
        {
          extern void sf_c42_controlMCUSlugsMKII_get_check_sum(mxArray *plhs[]);
          sf_c42_controlMCUSlugsMKII_get_check_sum(plhs);
          break;
        }

       case 48:
        {
          extern void sf_c48_controlMCUSlugsMKII_get_check_sum(mxArray *plhs[]);
          sf_c48_controlMCUSlugsMKII_get_check_sum(plhs);
          break;
        }

       case 49:
        {
          extern void sf_c49_controlMCUSlugsMKII_get_check_sum(mxArray *plhs[]);
          sf_c49_controlMCUSlugsMKII_get_check_sum(plhs);
          break;
        }

       default:
        ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(0.0);
        ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(0.0);
        ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(0.0);
        ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(0.0);
      }
    } else if (!strcmp(commandName,"target")) {
      ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(914599612U);
      ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(3628059775U);
      ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(1257379232U);
      ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(1507793699U);
    } else {
      return 0;
    }
  } else {
    ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(3282767576U);
    ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(3613016041U);
    ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(1039219579U);
    ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(884733740U);
  }

  return 1;

#else

  return 0;

#endif

}

unsigned int sf_controlMCUSlugsMKII_autoinheritance_info( int nlhs, mxArray *
  plhs[], int nrhs, const mxArray * prhs[] )
{

#ifdef MATLAB_MEX_FILE

  char commandName[32];
  if (nrhs<2 || !mxIsChar(prhs[0]) )
    return 0;

  /* Possible call to get the autoinheritance_info */
  mxGetString(prhs[0], commandName,sizeof(commandName)/sizeof(char));
  commandName[(sizeof(commandName)/sizeof(char)-1)] = '\0';
  if (strcmp(commandName,"get_autoinheritance_info"))
    return 0;

  {
    unsigned int chartFileNumber;
    chartFileNumber = (unsigned int)mxGetScalar(prhs[1]);
    switch (chartFileNumber) {
     case 1:
      {
        extern mxArray *sf_c1_controlMCUSlugsMKII_get_autoinheritance_info(void);
        plhs[0] = sf_c1_controlMCUSlugsMKII_get_autoinheritance_info();
        break;
      }

     case 2:
      {
        extern mxArray *sf_c2_controlMCUSlugsMKII_get_autoinheritance_info(void);
        plhs[0] = sf_c2_controlMCUSlugsMKII_get_autoinheritance_info();
        break;
      }

     case 3:
      {
        extern mxArray *sf_c3_controlMCUSlugsMKII_get_autoinheritance_info(void);
        plhs[0] = sf_c3_controlMCUSlugsMKII_get_autoinheritance_info();
        break;
      }

     case 4:
      {
        extern mxArray *sf_c4_controlMCUSlugsMKII_get_autoinheritance_info(void);
        plhs[0] = sf_c4_controlMCUSlugsMKII_get_autoinheritance_info();
        break;
      }

     case 5:
      {
        extern mxArray *sf_c5_controlMCUSlugsMKII_get_autoinheritance_info(void);
        plhs[0] = sf_c5_controlMCUSlugsMKII_get_autoinheritance_info();
        break;
      }

     case 6:
      {
        extern mxArray *sf_c6_controlMCUSlugsMKII_get_autoinheritance_info(void);
        plhs[0] = sf_c6_controlMCUSlugsMKII_get_autoinheritance_info();
        break;
      }

     case 7:
      {
        extern mxArray *sf_c7_controlMCUSlugsMKII_get_autoinheritance_info(void);
        plhs[0] = sf_c7_controlMCUSlugsMKII_get_autoinheritance_info();
        break;
      }

     case 8:
      {
        extern mxArray *sf_c8_controlMCUSlugsMKII_get_autoinheritance_info(void);
        plhs[0] = sf_c8_controlMCUSlugsMKII_get_autoinheritance_info();
        break;
      }

     case 9:
      {
        extern mxArray *sf_c9_controlMCUSlugsMKII_get_autoinheritance_info(void);
        plhs[0] = sf_c9_controlMCUSlugsMKII_get_autoinheritance_info();
        break;
      }

     case 10:
      {
        extern mxArray *sf_c10_controlMCUSlugsMKII_get_autoinheritance_info(void);
        plhs[0] = sf_c10_controlMCUSlugsMKII_get_autoinheritance_info();
        break;
      }

     case 11:
      {
        extern mxArray *sf_c11_controlMCUSlugsMKII_get_autoinheritance_info(void);
        plhs[0] = sf_c11_controlMCUSlugsMKII_get_autoinheritance_info();
        break;
      }

     case 12:
      {
        extern mxArray *sf_c12_controlMCUSlugsMKII_get_autoinheritance_info(void);
        plhs[0] = sf_c12_controlMCUSlugsMKII_get_autoinheritance_info();
        break;
      }

     case 13:
      {
        extern mxArray *sf_c13_controlMCUSlugsMKII_get_autoinheritance_info(void);
        plhs[0] = sf_c13_controlMCUSlugsMKII_get_autoinheritance_info();
        break;
      }

     case 14:
      {
        extern mxArray *sf_c14_controlMCUSlugsMKII_get_autoinheritance_info(void);
        plhs[0] = sf_c14_controlMCUSlugsMKII_get_autoinheritance_info();
        break;
      }

     case 15:
      {
        extern mxArray *sf_c15_controlMCUSlugsMKII_get_autoinheritance_info(void);
        plhs[0] = sf_c15_controlMCUSlugsMKII_get_autoinheritance_info();
        break;
      }

     case 16:
      {
        extern mxArray *sf_c16_controlMCUSlugsMKII_get_autoinheritance_info(void);
        plhs[0] = sf_c16_controlMCUSlugsMKII_get_autoinheritance_info();
        break;
      }

     case 17:
      {
        extern mxArray *sf_c17_controlMCUSlugsMKII_get_autoinheritance_info(void);
        plhs[0] = sf_c17_controlMCUSlugsMKII_get_autoinheritance_info();
        break;
      }

     case 18:
      {
        extern mxArray *sf_c18_controlMCUSlugsMKII_get_autoinheritance_info(void);
        plhs[0] = sf_c18_controlMCUSlugsMKII_get_autoinheritance_info();
        break;
      }

     case 19:
      {
        extern mxArray *sf_c19_controlMCUSlugsMKII_get_autoinheritance_info(void);
        plhs[0] = sf_c19_controlMCUSlugsMKII_get_autoinheritance_info();
        break;
      }

     case 20:
      {
        extern mxArray *sf_c20_controlMCUSlugsMKII_get_autoinheritance_info(void);
        plhs[0] = sf_c20_controlMCUSlugsMKII_get_autoinheritance_info();
        break;
      }

     case 21:
      {
        extern mxArray *sf_c21_controlMCUSlugsMKII_get_autoinheritance_info(void);
        plhs[0] = sf_c21_controlMCUSlugsMKII_get_autoinheritance_info();
        break;
      }

     case 22:
      {
        extern mxArray *sf_c22_controlMCUSlugsMKII_get_autoinheritance_info(void);
        plhs[0] = sf_c22_controlMCUSlugsMKII_get_autoinheritance_info();
        break;
      }

     case 23:
      {
        extern mxArray *sf_c23_controlMCUSlugsMKII_get_autoinheritance_info(void);
        plhs[0] = sf_c23_controlMCUSlugsMKII_get_autoinheritance_info();
        break;
      }

     case 24:
      {
        extern mxArray *sf_c24_controlMCUSlugsMKII_get_autoinheritance_info(void);
        plhs[0] = sf_c24_controlMCUSlugsMKII_get_autoinheritance_info();
        break;
      }

     case 25:
      {
        extern mxArray *sf_c25_controlMCUSlugsMKII_get_autoinheritance_info(void);
        plhs[0] = sf_c25_controlMCUSlugsMKII_get_autoinheritance_info();
        break;
      }

     case 26:
      {
        extern mxArray *sf_c26_controlMCUSlugsMKII_get_autoinheritance_info(void);
        plhs[0] = sf_c26_controlMCUSlugsMKII_get_autoinheritance_info();
        break;
      }

     case 27:
      {
        extern mxArray *sf_c27_controlMCUSlugsMKII_get_autoinheritance_info(void);
        plhs[0] = sf_c27_controlMCUSlugsMKII_get_autoinheritance_info();
        break;
      }

     case 28:
      {
        extern mxArray *sf_c28_controlMCUSlugsMKII_get_autoinheritance_info(void);
        plhs[0] = sf_c28_controlMCUSlugsMKII_get_autoinheritance_info();
        break;
      }

     case 29:
      {
        extern mxArray *sf_c29_controlMCUSlugsMKII_get_autoinheritance_info(void);
        plhs[0] = sf_c29_controlMCUSlugsMKII_get_autoinheritance_info();
        break;
      }

     case 30:
      {
        extern mxArray *sf_c30_controlMCUSlugsMKII_get_autoinheritance_info(void);
        plhs[0] = sf_c30_controlMCUSlugsMKII_get_autoinheritance_info();
        break;
      }

     case 31:
      {
        extern mxArray *sf_c31_controlMCUSlugsMKII_get_autoinheritance_info(void);
        plhs[0] = sf_c31_controlMCUSlugsMKII_get_autoinheritance_info();
        break;
      }

     case 32:
      {
        extern mxArray *sf_c32_controlMCUSlugsMKII_get_autoinheritance_info(void);
        plhs[0] = sf_c32_controlMCUSlugsMKII_get_autoinheritance_info();
        break;
      }

     case 33:
      {
        extern mxArray *sf_c33_controlMCUSlugsMKII_get_autoinheritance_info(void);
        plhs[0] = sf_c33_controlMCUSlugsMKII_get_autoinheritance_info();
        break;
      }

     case 34:
      {
        extern mxArray *sf_c34_controlMCUSlugsMKII_get_autoinheritance_info(void);
        plhs[0] = sf_c34_controlMCUSlugsMKII_get_autoinheritance_info();
        break;
      }

     case 35:
      {
        extern mxArray *sf_c35_controlMCUSlugsMKII_get_autoinheritance_info(void);
        plhs[0] = sf_c35_controlMCUSlugsMKII_get_autoinheritance_info();
        break;
      }

     case 36:
      {
        extern mxArray *sf_c36_controlMCUSlugsMKII_get_autoinheritance_info(void);
        plhs[0] = sf_c36_controlMCUSlugsMKII_get_autoinheritance_info();
        break;
      }

     case 37:
      {
        extern mxArray *sf_c37_controlMCUSlugsMKII_get_autoinheritance_info(void);
        plhs[0] = sf_c37_controlMCUSlugsMKII_get_autoinheritance_info();
        break;
      }

     case 39:
      {
        extern mxArray *sf_c39_controlMCUSlugsMKII_get_autoinheritance_info(void);
        plhs[0] = sf_c39_controlMCUSlugsMKII_get_autoinheritance_info();
        break;
      }

     case 40:
      {
        extern mxArray *sf_c40_controlMCUSlugsMKII_get_autoinheritance_info(void);
        plhs[0] = sf_c40_controlMCUSlugsMKII_get_autoinheritance_info();
        break;
      }

     case 41:
      {
        extern mxArray *sf_c41_controlMCUSlugsMKII_get_autoinheritance_info(void);
        plhs[0] = sf_c41_controlMCUSlugsMKII_get_autoinheritance_info();
        break;
      }

     case 42:
      {
        extern mxArray *sf_c42_controlMCUSlugsMKII_get_autoinheritance_info(void);
        plhs[0] = sf_c42_controlMCUSlugsMKII_get_autoinheritance_info();
        break;
      }

     case 48:
      {
        extern mxArray *sf_c48_controlMCUSlugsMKII_get_autoinheritance_info(void);
        plhs[0] = sf_c48_controlMCUSlugsMKII_get_autoinheritance_info();
        break;
      }

     case 49:
      {
        extern mxArray *sf_c49_controlMCUSlugsMKII_get_autoinheritance_info(void);
        plhs[0] = sf_c49_controlMCUSlugsMKII_get_autoinheritance_info();
        break;
      }

     default:
      plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
    }
  }

  return 1;

#else

  return 0;

#endif

}

unsigned int sf_controlMCUSlugsMKII_get_eml_resolved_functions_info( int nlhs,
  mxArray * plhs[], int nrhs, const mxArray * prhs[] )
{

#ifdef MATLAB_MEX_FILE

  char commandName[64];
  if (nrhs<2 || !mxIsChar(prhs[0]))
    return 0;

  /* Possible call to get the get_eml_resolved_functions_info */
  mxGetString(prhs[0], commandName,sizeof(commandName)/sizeof(char));
  commandName[(sizeof(commandName)/sizeof(char)-1)] = '\0';
  if (strcmp(commandName,"get_eml_resolved_functions_info"))
    return 0;

  {
    unsigned int chartFileNumber;
    chartFileNumber = (unsigned int)mxGetScalar(prhs[1]);
    switch (chartFileNumber) {
     case 1:
      {
        extern const mxArray
          *sf_c1_controlMCUSlugsMKII_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c1_controlMCUSlugsMKII_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 2:
      {
        extern const mxArray
          *sf_c2_controlMCUSlugsMKII_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c2_controlMCUSlugsMKII_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 3:
      {
        extern const mxArray
          *sf_c3_controlMCUSlugsMKII_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c3_controlMCUSlugsMKII_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 4:
      {
        extern const mxArray
          *sf_c4_controlMCUSlugsMKII_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c4_controlMCUSlugsMKII_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 5:
      {
        extern const mxArray
          *sf_c5_controlMCUSlugsMKII_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c5_controlMCUSlugsMKII_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 6:
      {
        extern const mxArray
          *sf_c6_controlMCUSlugsMKII_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c6_controlMCUSlugsMKII_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 7:
      {
        extern const mxArray
          *sf_c7_controlMCUSlugsMKII_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c7_controlMCUSlugsMKII_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 8:
      {
        extern const mxArray
          *sf_c8_controlMCUSlugsMKII_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c8_controlMCUSlugsMKII_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 9:
      {
        extern const mxArray
          *sf_c9_controlMCUSlugsMKII_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c9_controlMCUSlugsMKII_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 10:
      {
        extern const mxArray
          *sf_c10_controlMCUSlugsMKII_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c10_controlMCUSlugsMKII_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 11:
      {
        extern const mxArray
          *sf_c11_controlMCUSlugsMKII_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c11_controlMCUSlugsMKII_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 12:
      {
        extern const mxArray
          *sf_c12_controlMCUSlugsMKII_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c12_controlMCUSlugsMKII_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 13:
      {
        extern const mxArray
          *sf_c13_controlMCUSlugsMKII_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c13_controlMCUSlugsMKII_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 14:
      {
        extern const mxArray
          *sf_c14_controlMCUSlugsMKII_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c14_controlMCUSlugsMKII_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 15:
      {
        extern const mxArray
          *sf_c15_controlMCUSlugsMKII_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c15_controlMCUSlugsMKII_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 16:
      {
        extern const mxArray
          *sf_c16_controlMCUSlugsMKII_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c16_controlMCUSlugsMKII_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 17:
      {
        extern const mxArray
          *sf_c17_controlMCUSlugsMKII_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c17_controlMCUSlugsMKII_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 18:
      {
        extern const mxArray
          *sf_c18_controlMCUSlugsMKII_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c18_controlMCUSlugsMKII_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 19:
      {
        extern const mxArray
          *sf_c19_controlMCUSlugsMKII_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c19_controlMCUSlugsMKII_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 20:
      {
        extern const mxArray
          *sf_c20_controlMCUSlugsMKII_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c20_controlMCUSlugsMKII_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 21:
      {
        extern const mxArray
          *sf_c21_controlMCUSlugsMKII_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c21_controlMCUSlugsMKII_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 22:
      {
        extern const mxArray
          *sf_c22_controlMCUSlugsMKII_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c22_controlMCUSlugsMKII_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 23:
      {
        extern const mxArray
          *sf_c23_controlMCUSlugsMKII_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c23_controlMCUSlugsMKII_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 24:
      {
        extern const mxArray
          *sf_c24_controlMCUSlugsMKII_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c24_controlMCUSlugsMKII_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 25:
      {
        extern const mxArray
          *sf_c25_controlMCUSlugsMKII_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c25_controlMCUSlugsMKII_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 26:
      {
        extern const mxArray
          *sf_c26_controlMCUSlugsMKII_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c26_controlMCUSlugsMKII_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 27:
      {
        extern const mxArray
          *sf_c27_controlMCUSlugsMKII_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c27_controlMCUSlugsMKII_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 28:
      {
        extern const mxArray
          *sf_c28_controlMCUSlugsMKII_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c28_controlMCUSlugsMKII_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 29:
      {
        extern const mxArray
          *sf_c29_controlMCUSlugsMKII_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c29_controlMCUSlugsMKII_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 30:
      {
        extern const mxArray
          *sf_c30_controlMCUSlugsMKII_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c30_controlMCUSlugsMKII_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 31:
      {
        extern const mxArray
          *sf_c31_controlMCUSlugsMKII_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c31_controlMCUSlugsMKII_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 32:
      {
        extern const mxArray
          *sf_c32_controlMCUSlugsMKII_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c32_controlMCUSlugsMKII_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 33:
      {
        extern const mxArray
          *sf_c33_controlMCUSlugsMKII_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c33_controlMCUSlugsMKII_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 34:
      {
        extern const mxArray
          *sf_c34_controlMCUSlugsMKII_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c34_controlMCUSlugsMKII_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 35:
      {
        extern const mxArray
          *sf_c35_controlMCUSlugsMKII_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c35_controlMCUSlugsMKII_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 36:
      {
        extern const mxArray
          *sf_c36_controlMCUSlugsMKII_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c36_controlMCUSlugsMKII_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 37:
      {
        extern const mxArray
          *sf_c37_controlMCUSlugsMKII_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c37_controlMCUSlugsMKII_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 39:
      {
        extern const mxArray
          *sf_c39_controlMCUSlugsMKII_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c39_controlMCUSlugsMKII_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 40:
      {
        extern const mxArray
          *sf_c40_controlMCUSlugsMKII_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c40_controlMCUSlugsMKII_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 41:
      {
        extern const mxArray
          *sf_c41_controlMCUSlugsMKII_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c41_controlMCUSlugsMKII_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 42:
      {
        extern const mxArray
          *sf_c42_controlMCUSlugsMKII_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c42_controlMCUSlugsMKII_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 48:
      {
        extern const mxArray
          *sf_c48_controlMCUSlugsMKII_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c48_controlMCUSlugsMKII_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     case 49:
      {
        extern const mxArray
          *sf_c49_controlMCUSlugsMKII_get_eml_resolved_functions_info(void);
        mxArray *persistentMxArray = (mxArray *)
          sf_c49_controlMCUSlugsMKII_get_eml_resolved_functions_info();
        plhs[0] = mxDuplicateArray(persistentMxArray);
        mxDestroyArray(persistentMxArray);
        break;
      }

     default:
      plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
    }
  }

  return 1;

#else

  return 0;

#endif

}

void controlMCUSlugsMKII_debug_initialize(void)
{
  _controlMCUSlugsMKIIMachineNumber_ = sf_debug_initialize_machine(
    "controlMCUSlugsMKII","sfun",0,43,0,0,0);
  sf_debug_set_machine_event_thresholds(_controlMCUSlugsMKIIMachineNumber_,0,0);
  sf_debug_set_machine_data_thresholds(_controlMCUSlugsMKIIMachineNumber_,0);
}

void controlMCUSlugsMKII_register_exported_symbols(SimStruct* S)
{
}
