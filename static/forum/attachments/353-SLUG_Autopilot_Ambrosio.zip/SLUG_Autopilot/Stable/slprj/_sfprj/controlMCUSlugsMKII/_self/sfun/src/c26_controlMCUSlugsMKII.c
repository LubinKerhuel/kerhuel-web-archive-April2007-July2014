/* Include files */

#include "blascompat32.h"
#include "controlMCUSlugsMKII_sfun.h"
#include "c26_controlMCUSlugsMKII.h"
#define CHARTINSTANCE_CHARTNUMBER      (chartInstance->chartNumber)
#define CHARTINSTANCE_INSTANCENUMBER   (chartInstance->instanceNumber)
#include "controlMCUSlugsMKII_sfun_debug_macros.h"

/* Type Definitions */

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */
static const char *c26_debug_family_names[6] = { "i", "nargin", "nargout",
  "latest", "history", "oldValues" };

/* Function Declarations */
static void initialize_c26_controlMCUSlugsMKII
  (SFc26_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void initialize_params_c26_controlMCUSlugsMKII
  (SFc26_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void enable_c26_controlMCUSlugsMKII
  (SFc26_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void disable_c26_controlMCUSlugsMKII
  (SFc26_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void c26_update_debugger_state_c26_controlMCUSlugsMKII
  (SFc26_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static const mxArray *get_sim_state_c26_controlMCUSlugsMKII
  (SFc26_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void set_sim_state_c26_controlMCUSlugsMKII
  (SFc26_controlMCUSlugsMKIIInstanceStruct *chartInstance, const mxArray *c26_st);
static void finalize_c26_controlMCUSlugsMKII
  (SFc26_controlMCUSlugsMKIIInstanceStruct *chartInstance);
static void sf_c26_controlMCUSlugsMKII(SFc26_controlMCUSlugsMKIIInstanceStruct
  *chartInstance);
static void init_script_number_translation(uint32_T c26_machineNumber, uint32_T
  c26_chartNumber);
static const mxArray *c26_sf_marshall(void *chartInstanceVoid, void *c26_u);
static const mxArray *c26_b_sf_marshall(void *chartInstanceVoid, void *c26_u);
static const mxArray *c26_c_sf_marshall(void *chartInstanceVoid, void *c26_u);
static const mxArray *c26_d_sf_marshall(void *chartInstanceVoid, void *c26_u);
static const mxArray *c26_e_sf_marshall(void *chartInstanceVoid, void *c26_u);
static void c26_emlrt_marshallIn(SFc26_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c26_history, const char_T *c26_name, uint16_T
  c26_y[7]);
static void c26_b_emlrt_marshallIn(SFc26_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c26_b_oldValues, const char_T *c26_name,
  uint16_T c26_y[7]);
static uint8_T c26_c_emlrt_marshallIn(SFc26_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c26_b_is_active_c26_controlMCUSlugsMKII, const
  char_T *c26_name);
static void init_dsm_address_info(SFc26_controlMCUSlugsMKIIInstanceStruct
  *chartInstance);

/* Function Definitions */
static void initialize_c26_controlMCUSlugsMKII
  (SFc26_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
  chartInstance->c26_oldValues_not_empty = FALSE;
  chartInstance->c26_is_active_c26_controlMCUSlugsMKII = 0U;
}

static void initialize_params_c26_controlMCUSlugsMKII
  (SFc26_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
}

static void enable_c26_controlMCUSlugsMKII
  (SFc26_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
}

static void disable_c26_controlMCUSlugsMKII
  (SFc26_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
}

static void c26_update_debugger_state_c26_controlMCUSlugsMKII
  (SFc26_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
}

static const mxArray *get_sim_state_c26_controlMCUSlugsMKII
  (SFc26_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
  const mxArray *c26_st = NULL;
  const mxArray *c26_y = NULL;
  int32_T c26_i0;
  uint16_T c26_hoistedGlobal[7];
  int32_T c26_i1;
  uint16_T c26_u[7];
  const mxArray *c26_b_y = NULL;
  int32_T c26_i2;
  uint16_T c26_b_hoistedGlobal[7];
  int32_T c26_i3;
  uint16_T c26_b_u[7];
  const mxArray *c26_c_y = NULL;
  uint8_T c26_c_hoistedGlobal;
  uint8_T c26_c_u;
  const mxArray *c26_d_y = NULL;
  uint16_T (*c26_history)[7];
  c26_history = (uint16_T (*)[7])ssGetOutputPortSignal(chartInstance->S, 1);
  c26_st = NULL;
  c26_y = NULL;
  sf_mex_assign(&c26_y, sf_mex_createcellarray(3));
  for (c26_i0 = 0; c26_i0 < 7; c26_i0 = c26_i0 + 1) {
    c26_hoistedGlobal[c26_i0] = (*c26_history)[c26_i0];
  }

  for (c26_i1 = 0; c26_i1 < 7; c26_i1 = c26_i1 + 1) {
    c26_u[c26_i1] = c26_hoistedGlobal[c26_i1];
  }

  c26_b_y = NULL;
  sf_mex_assign(&c26_b_y, sf_mex_create("y", &c26_u, 5, 0U, 1U, 0U, 2, 1, 7));
  sf_mex_setcell(c26_y, 0, c26_b_y);
  for (c26_i2 = 0; c26_i2 < 7; c26_i2 = c26_i2 + 1) {
    c26_b_hoistedGlobal[c26_i2] = chartInstance->c26_oldValues[c26_i2];
  }

  for (c26_i3 = 0; c26_i3 < 7; c26_i3 = c26_i3 + 1) {
    c26_b_u[c26_i3] = c26_b_hoistedGlobal[c26_i3];
  }

  c26_c_y = NULL;
  if (!chartInstance->c26_oldValues_not_empty) {
    sf_mex_assign(&c26_c_y, sf_mex_create("y", NULL, 0, 0U, 1U, 0U, 2, 0, 0));
  } else {
    sf_mex_assign(&c26_c_y, sf_mex_create("y", &c26_b_u, 5, 0U, 1U, 0U, 2, 1, 7));
  }

  sf_mex_setcell(c26_y, 1, c26_c_y);
  c26_c_hoistedGlobal = chartInstance->c26_is_active_c26_controlMCUSlugsMKII;
  c26_c_u = c26_c_hoistedGlobal;
  c26_d_y = NULL;
  sf_mex_assign(&c26_d_y, sf_mex_create("y", &c26_c_u, 3, 0U, 0U, 0U, 0));
  sf_mex_setcell(c26_y, 2, c26_d_y);
  sf_mex_assign(&c26_st, c26_y);
  return c26_st;
}

static void set_sim_state_c26_controlMCUSlugsMKII
  (SFc26_controlMCUSlugsMKIIInstanceStruct *chartInstance, const mxArray *c26_st)
{
  const mxArray *c26_u;
  uint16_T c26_uv0[7];
  int32_T c26_i4;
  uint16_T c26_uv1[7];
  int32_T c26_i5;
  uint16_T (*c26_history)[7];
  c26_history = (uint16_T (*)[7])ssGetOutputPortSignal(chartInstance->S, 1);
  chartInstance->c26_doneDoubleBufferReInit = TRUE;
  c26_u = sf_mex_dup(c26_st);
  c26_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(c26_u, 0)),
                       "history", c26_uv0);
  for (c26_i4 = 0; c26_i4 < 7; c26_i4 = c26_i4 + 1) {
    (*c26_history)[c26_i4] = c26_uv0[c26_i4];
  }

  c26_b_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(c26_u, 1)),
    "oldValues", c26_uv1);
  for (c26_i5 = 0; c26_i5 < 7; c26_i5 = c26_i5 + 1) {
    chartInstance->c26_oldValues[c26_i5] = c26_uv1[c26_i5];
  }

  chartInstance->c26_is_active_c26_controlMCUSlugsMKII = c26_c_emlrt_marshallIn
    (chartInstance, sf_mex_dup(sf_mex_getcell(c26_u, 2)),
     "is_active_c26_controlMCUSlugsMKII");
  sf_mex_destroy(&c26_u);
  c26_update_debugger_state_c26_controlMCUSlugsMKII(chartInstance);
  sf_mex_destroy(&c26_st);
}

static void finalize_c26_controlMCUSlugsMKII
  (SFc26_controlMCUSlugsMKIIInstanceStruct *chartInstance)
{
}

static void sf_c26_controlMCUSlugsMKII(SFc26_controlMCUSlugsMKIIInstanceStruct
  *chartInstance)
{
  int32_T c26_i6;
  int32_T c26_previousEvent;
  uint16_T c26_hoistedGlobal;
  uint16_T c26_latest;
  uint32_T c26_debug_family_var_map[6];
  static const char *c26_sv0[6] = { "i", "nargin", "nargout", "latest",
    "history", "oldValues" };

  real_T c26_i;
  real_T c26_nargin = 1.0;
  real_T c26_nargout = 1.0;
  uint16_T c26_history[7];
  int32_T c26_i7;
  int32_T c26_i8;
  real_T c26_b_i;
  int32_T c26_i9;
  uint16_T *c26_b_latest;
  uint16_T (*c26_b_history)[7];
  c26_b_history = (uint16_T (*)[7])ssGetOutputPortSignal(chartInstance->S, 1);
  c26_b_latest = (uint16_T *)ssGetInputPortSignal(chartInstance->S, 0);
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
  _SFD_CC_CALL(CHART_ENTER_SFUNCTION_TAG,25);
  _SFD_DATA_RANGE_CHECK((real_T)*c26_b_latest, 0U);
  for (c26_i6 = 0; c26_i6 < 7; c26_i6 = c26_i6 + 1) {
    _SFD_DATA_RANGE_CHECK((real_T)(*c26_b_history)[c26_i6], 1U);
  }

  c26_previousEvent = _sfEvent_;
  _sfEvent_ = CALL_EVENT;
  _SFD_CC_CALL(CHART_ENTER_DURING_FUNCTION_TAG,25);
  c26_hoistedGlobal = *c26_b_latest;
  c26_latest = c26_hoistedGlobal;
  sf_debug_symbol_scope_push_eml(0U, 6U, 6U, c26_sv0, c26_debug_family_var_map);
  sf_debug_symbol_scope_add_eml(&c26_i, c26_d_sf_marshall, 0U);
  sf_debug_symbol_scope_add_eml(&c26_nargin, c26_d_sf_marshall, 1U);
  sf_debug_symbol_scope_add_eml(&c26_nargout, c26_d_sf_marshall, 2U);
  sf_debug_symbol_scope_add_eml(&c26_latest, c26_c_sf_marshall, 3U);
  sf_debug_symbol_scope_add_eml(&c26_history, c26_b_sf_marshall, 4U);
  sf_debug_symbol_scope_add_eml(&chartInstance->c26_oldValues, c26_sf_marshall,
    5U);
  CV_EML_FCN(0, 0);

  /*  This block supports an embeddable subset of the MATLAB language. */
  /*  See the help menu for details.  */
  _SFD_EML_CALL(0,7);
  if (CV_EML_IF(0, 0, !chartInstance->c26_oldValues_not_empty)) {
    _SFD_EML_CALL(0,8);
    for (c26_i7 = 0; c26_i7 < 7; c26_i7 = c26_i7 + 1) {
      chartInstance->c26_oldValues[c26_i7] = 0U;
    }

    chartInstance->c26_oldValues_not_empty = TRUE;
  }

  _SFD_EML_CALL(0,11);
  for (c26_i8 = 0; c26_i8 < 7; c26_i8 = c26_i8 + 1) {
    c26_history[c26_i8] = 0U;
  }

  c26_i = 7.0;
  c26_b_i = 7.0;
  while (c26_b_i >= 2.0) {
    c26_i = c26_b_i;
    CV_EML_FOR(0, 0, 1);
    _SFD_EML_CALL(0,14);
    chartInstance->c26_oldValues[_SFD_EML_ARRAY_BOUNDS_CHECK("oldValues",
      (int32_T)_SFD_INTEGER_CHECK("i", c26_i), 1, 7, 1, 0) - 1] =
      chartInstance->c26_oldValues[_SFD_EML_ARRAY_BOUNDS_CHECK("oldValues",
      (int32_T)_SFD_INTEGER_CHECK("", c26_i - 1.0), 1, 7, 1, 0) - 1];
    _SFD_EML_CALL(0,15);
    c26_history[_SFD_EML_ARRAY_BOUNDS_CHECK("history", (int32_T)
      _SFD_INTEGER_CHECK("i", c26_i), 1, 7, 1, 0) - 1] = chartInstance->
      c26_oldValues[_SFD_EML_ARRAY_BOUNDS_CHECK("oldValues", (int32_T)
      _SFD_INTEGER_CHECK("", c26_i - 1.0), 1, 7, 1, 0) - 1];
    c26_b_i = c26_b_i + -1.0;
    sf_mex_listen_for_ctrl_c(chartInstance->S);
  }

  CV_EML_FOR(0, 0, 0);
  _SFD_EML_CALL(0,18);
  chartInstance->c26_oldValues[0] = c26_latest;
  _SFD_EML_CALL(0,19);
  c26_history[0] = c26_latest;
  _SFD_EML_CALL(0,-19);
  sf_debug_symbol_scope_pop();
  for (c26_i9 = 0; c26_i9 < 7; c26_i9 = c26_i9 + 1) {
    (*c26_b_history)[c26_i9] = c26_history[c26_i9];
  }

  _SFD_CC_CALL(EXIT_OUT_OF_FUNCTION_TAG,25);
  _sfEvent_ = c26_previousEvent;
  sf_debug_check_for_state_inconsistency(_controlMCUSlugsMKIIMachineNumber_,
    chartInstance->chartNumber, chartInstance->instanceNumber
    );
}

static void init_script_number_translation(uint32_T c26_machineNumber, uint32_T
  c26_chartNumber)
{
}

static const mxArray *c26_sf_marshall(void *chartInstanceVoid, void *c26_u)
{
  const mxArray *c26_y = NULL;
  int32_T c26_i10;
  uint16_T c26_b_u[7];
  const mxArray *c26_b_y = NULL;
  SFc26_controlMCUSlugsMKIIInstanceStruct *chartInstance;
  chartInstance = (SFc26_controlMCUSlugsMKIIInstanceStruct *)chartInstanceVoid;
  c26_y = NULL;
  for (c26_i10 = 0; c26_i10 < 7; c26_i10 = c26_i10 + 1) {
    c26_b_u[c26_i10] = (*((uint16_T (*)[7])c26_u))[c26_i10];
  }

  c26_b_y = NULL;
  if (!chartInstance->c26_oldValues_not_empty) {
    sf_mex_assign(&c26_b_y, sf_mex_create("y", NULL, 0, 0U, 1U, 0U, 2, 0, 0));
  } else {
    sf_mex_assign(&c26_b_y, sf_mex_create("y", &c26_b_u, 5, 0U, 1U, 0U, 2, 1, 7));
  }

  sf_mex_assign(&c26_y, c26_b_y);
  return c26_y;
}

static const mxArray *c26_b_sf_marshall(void *chartInstanceVoid, void *c26_u)
{
  const mxArray *c26_y = NULL;
  int32_T c26_i11;
  uint16_T c26_b_u[7];
  const mxArray *c26_b_y = NULL;
  SFc26_controlMCUSlugsMKIIInstanceStruct *chartInstance;
  chartInstance = (SFc26_controlMCUSlugsMKIIInstanceStruct *)chartInstanceVoid;
  c26_y = NULL;
  for (c26_i11 = 0; c26_i11 < 7; c26_i11 = c26_i11 + 1) {
    c26_b_u[c26_i11] = (*((uint16_T (*)[7])c26_u))[c26_i11];
  }

  c26_b_y = NULL;
  sf_mex_assign(&c26_b_y, sf_mex_create("y", &c26_b_u, 5, 0U, 1U, 0U, 2, 1, 7));
  sf_mex_assign(&c26_y, c26_b_y);
  return c26_y;
}

static const mxArray *c26_c_sf_marshall(void *chartInstanceVoid, void *c26_u)
{
  const mxArray *c26_y = NULL;
  uint16_T c26_b_u;
  const mxArray *c26_b_y = NULL;
  SFc26_controlMCUSlugsMKIIInstanceStruct *chartInstance;
  chartInstance = (SFc26_controlMCUSlugsMKIIInstanceStruct *)chartInstanceVoid;
  c26_y = NULL;
  c26_b_u = *((uint16_T *)c26_u);
  c26_b_y = NULL;
  sf_mex_assign(&c26_b_y, sf_mex_create("y", &c26_b_u, 5, 0U, 0U, 0U, 0));
  sf_mex_assign(&c26_y, c26_b_y);
  return c26_y;
}

static const mxArray *c26_d_sf_marshall(void *chartInstanceVoid, void *c26_u)
{
  const mxArray *c26_y = NULL;
  real_T c26_b_u;
  const mxArray *c26_b_y = NULL;
  SFc26_controlMCUSlugsMKIIInstanceStruct *chartInstance;
  chartInstance = (SFc26_controlMCUSlugsMKIIInstanceStruct *)chartInstanceVoid;
  c26_y = NULL;
  c26_b_u = *((real_T *)c26_u);
  c26_b_y = NULL;
  sf_mex_assign(&c26_b_y, sf_mex_create("y", &c26_b_u, 0, 0U, 0U, 0U, 0));
  sf_mex_assign(&c26_y, c26_b_y);
  return c26_y;
}

const mxArray *sf_c26_controlMCUSlugsMKII_get_eml_resolved_functions_info(void)
{
  const mxArray *c26_nameCaptureInfo = NULL;
  c26_ResolvedFunctionInfo c26_info[3];
  c26_ResolvedFunctionInfo (*c26_b_info)[3];
  const mxArray *c26_m0 = NULL;
  int32_T c26_i12;
  c26_ResolvedFunctionInfo *c26_r0;
  c26_nameCaptureInfo = NULL;
  c26_b_info = (c26_ResolvedFunctionInfo (*)[3])c26_info;
  (*c26_b_info)[0].context = "";
  (*c26_b_info)[0].name = "uint16";
  (*c26_b_info)[0].dominantType = "double";
  (*c26_b_info)[0].resolved = "[B]uint16";
  (*c26_b_info)[0].fileLength = 0U;
  (*c26_b_info)[0].fileTime1 = 0U;
  (*c26_b_info)[0].fileTime2 = 0U;
  (*c26_b_info)[1].context = "";
  (*c26_b_info)[1].name = "uminus";
  (*c26_b_info)[1].dominantType = "double";
  (*c26_b_info)[1].resolved = "[B]uminus";
  (*c26_b_info)[1].fileLength = 0U;
  (*c26_b_info)[1].fileTime1 = 0U;
  (*c26_b_info)[1].fileTime2 = 0U;
  (*c26_b_info)[2].context = "";
  (*c26_b_info)[2].name = "minus";
  (*c26_b_info)[2].dominantType = "double";
  (*c26_b_info)[2].resolved = "[B]minus";
  (*c26_b_info)[2].fileLength = 0U;
  (*c26_b_info)[2].fileTime1 = 0U;
  (*c26_b_info)[2].fileTime2 = 0U;
  sf_mex_assign(&c26_m0, sf_mex_createstruct("nameCaptureInfo", 1, 3));
  for (c26_i12 = 0; c26_i12 < 3; c26_i12 = c26_i12 + 1) {
    c26_r0 = &c26_info[c26_i12];
    sf_mex_addfield(c26_m0, sf_mex_create("nameCaptureInfo", c26_r0->context, 15,
      0U, 0U, 0U, 2, 1, strlen(c26_r0->context)), "context"
                    , "nameCaptureInfo", c26_i12);
    sf_mex_addfield(c26_m0, sf_mex_create("nameCaptureInfo", c26_r0->name, 15,
      0U, 0U, 0U, 2, 1, strlen(c26_r0->name)), "name",
                    "nameCaptureInfo", c26_i12);
    sf_mex_addfield(c26_m0, sf_mex_create("nameCaptureInfo",
      c26_r0->dominantType, 15, 0U, 0U, 0U, 2, 1, strlen(c26_r0->dominantType)),
                    "dominantType", "nameCaptureInfo", c26_i12);
    sf_mex_addfield(c26_m0, sf_mex_create("nameCaptureInfo", c26_r0->resolved,
      15, 0U, 0U, 0U, 2, 1, strlen(c26_r0->resolved)),
                    "resolved", "nameCaptureInfo", c26_i12);
    sf_mex_addfield(c26_m0, sf_mex_create("nameCaptureInfo", &c26_r0->fileLength,
      7, 0U, 0U, 0U, 0), "fileLength", "nameCaptureInfo",
                    c26_i12);
    sf_mex_addfield(c26_m0, sf_mex_create("nameCaptureInfo", &c26_r0->fileTime1,
      7, 0U, 0U, 0U, 0), "fileTime1", "nameCaptureInfo",
                    c26_i12);
    sf_mex_addfield(c26_m0, sf_mex_create("nameCaptureInfo", &c26_r0->fileTime2,
      7, 0U, 0U, 0U, 0), "fileTime2", "nameCaptureInfo",
                    c26_i12);
  }

  sf_mex_assign(&c26_nameCaptureInfo, c26_m0);
  return c26_nameCaptureInfo;
}

static const mxArray *c26_e_sf_marshall(void *chartInstanceVoid, void *c26_u)
{
  const mxArray *c26_y = NULL;
  boolean_T c26_b_u;
  const mxArray *c26_b_y = NULL;
  SFc26_controlMCUSlugsMKIIInstanceStruct *chartInstance;
  chartInstance = (SFc26_controlMCUSlugsMKIIInstanceStruct *)chartInstanceVoid;
  c26_y = NULL;
  c26_b_u = *((boolean_T *)c26_u);
  c26_b_y = NULL;
  sf_mex_assign(&c26_b_y, sf_mex_create("y", &c26_b_u, 11, 0U, 0U, 0U, 0));
  sf_mex_assign(&c26_y, c26_b_y);
  return c26_y;
}

static void c26_emlrt_marshallIn(SFc26_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c26_history, const char_T *
  c26_name, uint16_T c26_y[7])
{
  uint16_T c26_uv2[7];
  int32_T c26_i13;
  sf_mex_import(c26_name, sf_mex_dup(c26_history), &c26_uv2, 1, 5, 0U, 1, 0U, 2,
                1, 7);
  for (c26_i13 = 0; c26_i13 < 7; c26_i13 = c26_i13 + 1) {
    c26_y[c26_i13] = c26_uv2[c26_i13];
  }

  sf_mex_destroy(&c26_history);
}

static void c26_b_emlrt_marshallIn(SFc26_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *c26_b_oldValues, const
  char_T *c26_name, uint16_T c26_y[7])
{
  uint16_T c26_uv3[7];
  int32_T c26_i14;
  if (mxIsEmpty(c26_b_oldValues)) {
    chartInstance->c26_oldValues_not_empty = FALSE;
  } else {
    chartInstance->c26_oldValues_not_empty = TRUE;
    sf_mex_import(c26_name, sf_mex_dup(c26_b_oldValues), &c26_uv3, 1, 5, 0U, 1,
                  0U, 2, 1, 7);
    for (c26_i14 = 0; c26_i14 < 7; c26_i14 = c26_i14 + 1) {
      c26_y[c26_i14] = c26_uv3[c26_i14];
    }
  }

  sf_mex_destroy(&c26_b_oldValues);
}

static uint8_T c26_c_emlrt_marshallIn(SFc26_controlMCUSlugsMKIIInstanceStruct
  *chartInstance, const mxArray *
  c26_b_is_active_c26_controlMCUSlugsMKII, const char_T *c26_name)
{
  uint8_T c26_y;
  uint8_T c26_u0;
  sf_mex_import(c26_name, sf_mex_dup(c26_b_is_active_c26_controlMCUSlugsMKII),
                &c26_u0, 1, 3, 0U, 0, 0U, 0);
  c26_y = c26_u0;
  sf_mex_destroy(&c26_b_is_active_c26_controlMCUSlugsMKII);
  return c26_y;
}

static void init_dsm_address_info(SFc26_controlMCUSlugsMKIIInstanceStruct
  *chartInstance)
{
}

/* SFunction Glue Code */
void sf_c26_controlMCUSlugsMKII_get_check_sum(mxArray *plhs[])
{
  ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(3049553855U);
  ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(3855393594U);
  ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(2617099463U);
  ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(3712596425U);
}

mxArray *sf_c26_controlMCUSlugsMKII_get_autoinheritance_info(void)
{
  const char *autoinheritanceFields[] = { "checksum", "inputs", "parameters",
    "outputs" };

  mxArray *mxAutoinheritanceInfo = mxCreateStructMatrix(1,1,4,
    autoinheritanceFields);

  {
    mxArray *mxChecksum = mxCreateDoubleMatrix(4,1,mxREAL);
    double *pr = mxGetPr(mxChecksum);
    pr[0] = (double)(56377951U);
    pr[1] = (double)(3457466682U);
    pr[2] = (double)(3732190819U);
    pr[3] = (double)(462973925U);
    mxSetField(mxAutoinheritanceInfo,0,"checksum",mxChecksum);
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,1,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(5));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"inputs",mxData);
  }

  {
    mxSetField(mxAutoinheritanceInfo,0,"parameters",mxCreateDoubleMatrix(0,0,
                mxREAL));
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,1,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(7);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(5));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"outputs",mxData);
  }

  return(mxAutoinheritanceInfo);
}

static mxArray *sf_get_sim_state_info_c26_controlMCUSlugsMKII(void)
{
  const char *infoFields[] = { "chartChecksum", "varInfo" };

  mxArray *mxInfo = mxCreateStructMatrix(1, 1, 2, infoFields);
  const char *infoEncStr[] = {
    "100 S1x3'type','srcId','name','auxInfo'{{M[1],M[5],T\"history\",},{M[4],M[0],T\"oldValues\",S'l','i','p'{{M1x2[155 164],M[0],}}},{M[8],M[0],T\"is_active_c26_controlMCUSlugsMKII\",}}"
  };

  mxArray *mxVarInfo = sf_mex_decode_encoded_mx_struct_array(infoEncStr, 3, 10);
  mxArray *mxChecksum = mxCreateDoubleMatrix(1, 4, mxREAL);
  sf_c26_controlMCUSlugsMKII_get_check_sum(&mxChecksum);
  mxSetField(mxInfo, 0, infoFields[0], mxChecksum);
  mxSetField(mxInfo, 0, infoFields[1], mxVarInfo);
  return mxInfo;
}

static void chart_debug_initialization(SimStruct *S, unsigned int
  fullDebuggerInitialization)
{
  if (!sim_mode_is_rtw_gen(S)) {
    SFc26_controlMCUSlugsMKIIInstanceStruct *chartInstance;
    chartInstance = (SFc26_controlMCUSlugsMKIIInstanceStruct *)
      ((ChartInfoStruct *)(ssGetUserData(S)))->chartInstance;
    if (ssIsFirstInitCond(S) && fullDebuggerInitialization==1) {
      /* do this only if simulation is starting */
      {
        unsigned int chartAlreadyPresent;
        chartAlreadyPresent = sf_debug_initialize_chart
          (_controlMCUSlugsMKIIMachineNumber_,
           26,
           1,
           1,
           2,
           0,
           0,
           0,
           0,
           0,
           &(chartInstance->chartNumber),
           &(chartInstance->instanceNumber),
           ssGetPath(S),
           (void *)S);
        if (chartAlreadyPresent==0) {
          /* this is the first instance */
          init_script_number_translation(_controlMCUSlugsMKIIMachineNumber_,
            chartInstance->chartNumber);
          sf_debug_set_chart_disable_implicit_casting
            (_controlMCUSlugsMKIIMachineNumber_,chartInstance->chartNumber,1);
          sf_debug_set_chart_event_thresholds(_controlMCUSlugsMKIIMachineNumber_,
            chartInstance->chartNumber,
            0,
            0,
            0);
          _SFD_SET_DATA_PROPS(0,1,1,0,SF_UINT16,0,NULL,0,0,0,0.0,1.0,0,"latest",
                              0,(MexFcnForType)c26_c_sf_marshall);

          {
            unsigned int dimVector[2];
            dimVector[0]= 1;
            dimVector[1]= 7;
            _SFD_SET_DATA_PROPS(1,2,0,1,SF_UINT16,2,&(dimVector[0]),0,0,0,0.0,
                                1.0,0,"history",0,(MexFcnForType)
                                c26_b_sf_marshall);
          }

          _SFD_STATE_INFO(0,0,2);
          _SFD_CH_SUBSTATE_COUNT(0);
          _SFD_CH_SUBSTATE_DECOMP(0);
        }

        _SFD_CV_INIT_CHART(0,0,0,0);

        {
          _SFD_CV_INIT_STATE(0,0,0,0,0,0,NULL,NULL);
        }

        _SFD_CV_INIT_TRANS(0,0,NULL,NULL,0,NULL);

        /* Initialization of EML Model Coverage */
        _SFD_CV_INIT_EML(0,1,1,0,0,1,0,0,0);
        _SFD_CV_INIT_EML_FCN(0,0,"eML_blk_kernel",0,-1,398);
        _SFD_CV_INIT_EML_IF(0,0,167,188,-1,233);
        _SFD_CV_INIT_EML_FOR(0,0,271,284,352);
        _SFD_TRANS_COV_WTS(0,0,0,1,0);
        if (chartAlreadyPresent==0) {
          _SFD_TRANS_COV_MAPS(0,
                              0,NULL,NULL,
                              0,NULL,NULL,
                              1,NULL,NULL,
                              0,NULL,NULL);
        }

        {
          uint16_T *c26_latest;
          uint16_T (*c26_history)[7];
          c26_history = (uint16_T (*)[7])ssGetOutputPortSignal(chartInstance->S,
            1);
          c26_latest = (uint16_T *)ssGetInputPortSignal(chartInstance->S, 0);
          _SFD_SET_DATA_VALUE_PTR(0U, c26_latest);
          _SFD_SET_DATA_VALUE_PTR(1U, c26_history);
        }
      }
    } else {
      sf_debug_reset_current_state_configuration
        (_controlMCUSlugsMKIIMachineNumber_,chartInstance->chartNumber,
         chartInstance->instanceNumber);
    }
  }
}

static void sf_opaque_initialize_c26_controlMCUSlugsMKII(void *chartInstanceVar)
{
  chart_debug_initialization(((SFc26_controlMCUSlugsMKIIInstanceStruct*)
    chartInstanceVar)->S,0);
  initialize_params_c26_controlMCUSlugsMKII
    ((SFc26_controlMCUSlugsMKIIInstanceStruct*) chartInstanceVar);
  initialize_c26_controlMCUSlugsMKII((SFc26_controlMCUSlugsMKIIInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_enable_c26_controlMCUSlugsMKII(void *chartInstanceVar)
{
  enable_c26_controlMCUSlugsMKII((SFc26_controlMCUSlugsMKIIInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_disable_c26_controlMCUSlugsMKII(void *chartInstanceVar)
{
  disable_c26_controlMCUSlugsMKII((SFc26_controlMCUSlugsMKIIInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_gateway_c26_controlMCUSlugsMKII(void *chartInstanceVar)
{
  sf_c26_controlMCUSlugsMKII((SFc26_controlMCUSlugsMKIIInstanceStruct*)
    chartInstanceVar);
}

static mxArray* sf_internal_get_sim_state_c26_controlMCUSlugsMKII(SimStruct* S)
{
  ChartInfoStruct *chartInfo = (ChartInfoStruct*) ssGetUserData(S);
  mxArray *plhs[1] = { NULL };

  mxArray *prhs[4];
  int mxError = 0;
  prhs[0] = mxCreateString("chart_simctx_raw2high");
  prhs[1] = mxCreateDoubleScalar(ssGetSFuncBlockHandle(S));
  prhs[2] = (mxArray*) get_sim_state_c26_controlMCUSlugsMKII
    ((SFc26_controlMCUSlugsMKIIInstanceStruct*)chartInfo->chartInstance);/* raw sim ctx */
  prhs[3] = sf_get_sim_state_info_c26_controlMCUSlugsMKII();/* state var info */
  mxError = sf_mex_call_matlab(1, plhs, 4, prhs, "sfprivate");
  mxDestroyArray(prhs[0]);
  mxDestroyArray(prhs[1]);
  mxDestroyArray(prhs[2]);
  mxDestroyArray(prhs[3]);
  if (mxError || plhs[0] == NULL) {
    sf_mex_error_message("Stateflow Internal Error: \nError calling 'chart_simctx_raw2high'.\n");
  }

  return plhs[0];
}

static void sf_internal_set_sim_state_c26_controlMCUSlugsMKII(SimStruct* S,
  const mxArray *st)
{
  ChartInfoStruct *chartInfo = (ChartInfoStruct*) ssGetUserData(S);
  mxArray *plhs[1] = { NULL };

  mxArray *prhs[4];
  int mxError = 0;
  prhs[0] = mxCreateString("chart_simctx_high2raw");
  prhs[1] = mxCreateDoubleScalar(ssGetSFuncBlockHandle(S));
  prhs[2] = mxDuplicateArray(st);      /* high level simctx */
  prhs[3] = (mxArray*) sf_get_sim_state_info_c26_controlMCUSlugsMKII();/* state var info */
  mxError = sf_mex_call_matlab(1, plhs, 4, prhs, "sfprivate");
  mxDestroyArray(prhs[0]);
  mxDestroyArray(prhs[1]);
  mxDestroyArray(prhs[2]);
  mxDestroyArray(prhs[3]);
  if (mxError || plhs[0] == NULL) {
    sf_mex_error_message("Stateflow Internal Error: \nError calling 'chart_simctx_high2raw'.\n");
  }

  set_sim_state_c26_controlMCUSlugsMKII((SFc26_controlMCUSlugsMKIIInstanceStruct*)
    chartInfo->chartInstance, mxDuplicateArray(plhs[0]));
  mxDestroyArray(plhs[0]);
}

static mxArray* sf_opaque_get_sim_state_c26_controlMCUSlugsMKII(SimStruct* S)
{
  return sf_internal_get_sim_state_c26_controlMCUSlugsMKII(S);
}

static void sf_opaque_set_sim_state_c26_controlMCUSlugsMKII(SimStruct* S, const
  mxArray *st)
{
  sf_internal_set_sim_state_c26_controlMCUSlugsMKII(S, st);
}

static void sf_opaque_terminate_c26_controlMCUSlugsMKII(void *chartInstanceVar)
{
  if (chartInstanceVar!=NULL) {
    SimStruct *S = ((SFc26_controlMCUSlugsMKIIInstanceStruct*) chartInstanceVar
      )->S;
    if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
      sf_clear_rtw_identifier(S);
    }

    finalize_c26_controlMCUSlugsMKII((SFc26_controlMCUSlugsMKIIInstanceStruct*)
      chartInstanceVar);
    free((void *)chartInstanceVar);
    ssSetUserData(S,NULL);
  }
}

extern unsigned int sf_machine_global_initializer_called(void);
static void mdlProcessParameters_c26_controlMCUSlugsMKII(SimStruct *S)
{
  int i;
  for (i=0;i<ssGetNumRunTimeParams(S);i++) {
    if (ssGetSFcnParamTunable(S,i)) {
      ssUpdateDlgParamAsRunTimeParam(S,i);
    }
  }

  if (sf_machine_global_initializer_called()) {
    initialize_params_c26_controlMCUSlugsMKII
      ((SFc26_controlMCUSlugsMKIIInstanceStruct*)(((ChartInfoStruct *)
         ssGetUserData(S))->chartInstance));
  }
}

static void mdlSetWorkWidths_c26_controlMCUSlugsMKII(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
    int_T chartIsInlinable =
      (int_T)sf_is_chart_inlinable("controlMCUSlugsMKII","controlMCUSlugsMKII",
      26);
    ssSetStateflowIsInlinable(S,chartIsInlinable);
    ssSetRTWCG(S,sf_rtw_info_uint_prop("controlMCUSlugsMKII",
                "controlMCUSlugsMKII",26,"RTWCG"));
    ssSetEnableFcnIsTrivial(S,1);
    ssSetDisableFcnIsTrivial(S,1);
    ssSetNotMultipleInlinable(S,sf_rtw_info_uint_prop("controlMCUSlugsMKII",
      "controlMCUSlugsMKII",26,"gatewayCannotBeInlinedMultipleTimes"));
    if (chartIsInlinable) {
      ssSetInputPortOptimOpts(S, 0, SS_REUSABLE_AND_LOCAL);
      sf_mark_chart_expressionable_inputs(S,"controlMCUSlugsMKII",
        "controlMCUSlugsMKII",26,1);
      sf_mark_chart_reusable_outputs(S,"controlMCUSlugsMKII",
        "controlMCUSlugsMKII",26,1);
    }

    sf_set_rtw_dwork_info(S,"controlMCUSlugsMKII","controlMCUSlugsMKII",26);
    ssSetHasSubFunctions(S,!(chartIsInlinable));
    ssSetOptions(S,ssGetOptions(S)|SS_OPTION_WORKS_WITH_CODE_REUSE);
  }

  ssSetChecksum0(S,(3695902711U));
  ssSetChecksum1(S,(3275118431U));
  ssSetChecksum2(S,(1593227314U));
  ssSetChecksum3(S,(1624611914U));
  ssSetmdlDerivatives(S, NULL);
  ssSetExplicitFCSSCtrl(S,1);
}

static void mdlRTW_c26_controlMCUSlugsMKII(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S)) {
    sf_write_symbol_mapping(S, "controlMCUSlugsMKII", "controlMCUSlugsMKII",26);
    ssWriteRTWStrParam(S, "StateflowChartType", "Embedded MATLAB");
  }
}

static void mdlStart_c26_controlMCUSlugsMKII(SimStruct *S)
{
  SFc26_controlMCUSlugsMKIIInstanceStruct *chartInstance;
  chartInstance = (SFc26_controlMCUSlugsMKIIInstanceStruct *)malloc(sizeof
    (SFc26_controlMCUSlugsMKIIInstanceStruct));
  memset(chartInstance, 0, sizeof(SFc26_controlMCUSlugsMKIIInstanceStruct));
  if (chartInstance==NULL) {
    sf_mex_error_message("Could not allocate memory for chart instance.");
  }

  chartInstance->chartInfo.chartInstance = chartInstance;
  chartInstance->chartInfo.isEMLChart = 1;
  chartInstance->chartInfo.chartInitialized = 0;
  chartInstance->chartInfo.sFunctionGateway =
    sf_opaque_gateway_c26_controlMCUSlugsMKII;
  chartInstance->chartInfo.initializeChart =
    sf_opaque_initialize_c26_controlMCUSlugsMKII;
  chartInstance->chartInfo.terminateChart =
    sf_opaque_terminate_c26_controlMCUSlugsMKII;
  chartInstance->chartInfo.enableChart =
    sf_opaque_enable_c26_controlMCUSlugsMKII;
  chartInstance->chartInfo.disableChart =
    sf_opaque_disable_c26_controlMCUSlugsMKII;
  chartInstance->chartInfo.getSimState =
    sf_opaque_get_sim_state_c26_controlMCUSlugsMKII;
  chartInstance->chartInfo.setSimState =
    sf_opaque_set_sim_state_c26_controlMCUSlugsMKII;
  chartInstance->chartInfo.getSimStateInfo =
    sf_get_sim_state_info_c26_controlMCUSlugsMKII;
  chartInstance->chartInfo.zeroCrossings = NULL;
  chartInstance->chartInfo.outputs = NULL;
  chartInstance->chartInfo.derivatives = NULL;
  chartInstance->chartInfo.mdlRTW = mdlRTW_c26_controlMCUSlugsMKII;
  chartInstance->chartInfo.mdlStart = mdlStart_c26_controlMCUSlugsMKII;
  chartInstance->chartInfo.mdlSetWorkWidths =
    mdlSetWorkWidths_c26_controlMCUSlugsMKII;
  chartInstance->chartInfo.extModeExec = NULL;
  chartInstance->chartInfo.restoreLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.restoreBeforeLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.storeCurrentConfiguration = NULL;
  chartInstance->S = S;
  ssSetUserData(S,(void *)(&(chartInstance->chartInfo)));/* register the chart instance with simstruct */
  if (!sim_mode_is_rtw_gen(S)) {
    init_dsm_address_info(chartInstance);
  }

  chart_debug_initialization(S,1);
}

void c26_controlMCUSlugsMKII_method_dispatcher(SimStruct *S, int_T method, void *
  data)
{
  switch (method) {
   case SS_CALL_MDL_START:
    mdlStart_c26_controlMCUSlugsMKII(S);
    break;

   case SS_CALL_MDL_SET_WORK_WIDTHS:
    mdlSetWorkWidths_c26_controlMCUSlugsMKII(S);
    break;

   case SS_CALL_MDL_PROCESS_PARAMETERS:
    mdlProcessParameters_c26_controlMCUSlugsMKII(S);
    break;

   default:
    /* Unhandled method */
    sf_mex_error_message("Stateflow Internal Error:\n"
                         "Error calling c26_controlMCUSlugsMKII_method_dispatcher.\n"
                         "Can't handle method %d.\n", method);
    break;
  }
}
