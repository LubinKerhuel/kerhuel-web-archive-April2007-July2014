#ifndef __c10_controlMCUSlugsMKII_h__
#define __c10_controlMCUSlugsMKII_h__

/* Include files */
#include "sfc_sf.h"
#include "sfc_mex.h"
#include "rtwtypes.h"

/* Type Definitions */
typedef struct {
  const char *context;
  const char *name;
  const char *dominantType;
  const char *resolved;
  uint32_T fileLength;
  uint32_T fileTime1;
  uint32_T fileTime2;
} c10_ResolvedFunctionInfo;

typedef struct {
  SimStruct *S;
  boolean_T c10_fromWP_not_empty;
  boolean_T c10_toWP_not_empty;
  boolean_T c10_totoWP_not_empty;
  uint8_T c10_fromWP;
  uint8_T c10_is_active_c10_controlMCUSlugsMKII;
  uint8_T c10_toWP;
  uint8_T c10_totoWP;
  ChartInfoStruct chartInfo;
} SFc10_controlMCUSlugsMKIIInstanceStruct;

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */

/* Function Declarations */
extern const mxArray *sf_c10_controlMCUSlugsMKII_get_eml_resolved_functions_info
  (void);

/* Function Definitions */
extern void sf_c10_controlMCUSlugsMKII_get_check_sum(mxArray *plhs[]);
extern void c10_controlMCUSlugsMKII_method_dispatcher(SimStruct *S, int_T method,
  void *data);

#endif
