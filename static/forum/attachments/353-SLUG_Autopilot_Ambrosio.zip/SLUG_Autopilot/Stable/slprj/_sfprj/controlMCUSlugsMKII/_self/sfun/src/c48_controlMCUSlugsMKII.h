#ifndef __c48_controlMCUSlugsMKII_h__
#define __c48_controlMCUSlugsMKII_h__

/* Include files */
#include "sfc_sf.h"
#include "sfc_mex.h"
#include "rtwtypes.h"

/* Type Definitions */
typedef struct {
  const char *context;
  const char *name;
  const char *dominantType;
  const char *resolved;
  uint32_T fileLength;
  uint32_T fileTime1;
  uint32_T fileTime2;
} c48_ResolvedFunctionInfo;

typedef struct {
  real_T c48_a;
  real_T c48_b;
  SimStruct *S;
  real32_T c48_u_km1;
  real32_T c48_y_km1;
  uint32_T chartNumber;
  uint32_T instanceNumber;
  boolean_T c48_a_not_empty;
  boolean_T c48_b_not_empty;
  boolean_T c48_doneDoubleBufferReInit;
  boolean_T c48_isStable;
  boolean_T c48_u_km1_not_empty;
  boolean_T c48_y_km1_not_empty;
  uint8_T c48_is_active_c48_controlMCUSlugsMKII;
  ChartInfoStruct chartInfo;
} SFc48_controlMCUSlugsMKIIInstanceStruct;

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */

/* Function Declarations */
extern const mxArray *sf_c48_controlMCUSlugsMKII_get_eml_resolved_functions_info
  (void);

/* Function Definitions */
extern void sf_c48_controlMCUSlugsMKII_get_check_sum(mxArray *plhs[]);
extern void c48_controlMCUSlugsMKII_method_dispatcher(SimStruct *S, int_T method,
  void *data);

#endif
