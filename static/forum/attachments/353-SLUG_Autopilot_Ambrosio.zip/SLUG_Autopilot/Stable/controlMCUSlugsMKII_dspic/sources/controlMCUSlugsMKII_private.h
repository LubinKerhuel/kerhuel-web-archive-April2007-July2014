/*
 * File: controlMCUSlugsMKII_private.h
 *
 * Real-Time Workshop code generated for Simulink model controlMCUSlugsMKII.
 *
 * Model version                        : 1.714
 * Real-Time Workshop file version      : 7.5  (R2010a)  25-Jan-2010
 * Real-Time Workshop file generated on : Tue Nov 23 13:12:51 2010
 * TLC version                          : 7.5 (Jan 19 2010)
 * C source code generated on           : Tue Nov 23 13:12:52 2010
 *--------------------------------------------------------------
 *   Embedded Coder for Microchip dsPIC family.                 |
 *   Generate .c and .h files from your Matlab/simulink model   |
 *   and compile the diagram to .hex and .coff file that can be |
 *   downloaded directly into the microcontroller               |
 *                                                              |
 * Licence Accorded to Blake Mills                              |
 *                     University of Colorado-Boulder           |
 *                                                              |
 *   Written by Lubin KERHUEL -  http://www.kerhuel.eu          |
 *  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - |
 *   Version 3.3a                              22-Nov-2010      |
 *   For Matlab 7.10            R2010a                          |
 *--------------------------------------------------------------
 */

#ifndef RTW_HEADER_controlMCUSlugsMKII_private_h_
#define RTW_HEADER_controlMCUSlugsMKII_private_h_
#include "rtwtypes.h"

/* dsPIC library */
#include "p33fxxxx.h"
#include "timer.h"
#define fcy                            40000000

/* initialization Block: <S277>/Input Capture */
#include <incap.h>

/*initialization Block: <S8>/PWM Servo Output*/
#include "pwm.h"
#define CALL_EVENT                     (-1)

/* Private macros used by the generated code to access rtModel */
#ifndef rtmSetFirstInitCond
# define rtmSetFirstInitCond(rtm, val) ((rtm)->Timing.firstInitCondFlag = (val))
#endif

#ifndef rtmIsFirstInitCond
# define rtmIsFirstInitCond(rtm)       ((rtm)->Timing.firstInitCondFlag)
#endif

#ifndef UCHAR_MAX
#include <limits.h>
#endif

#if ( UCHAR_MAX != (0xFFU) ) || ( SCHAR_MAX != (0x7F) )
#error "Code was generated for compiler with different sized uchar/char. Consider adjusting Emulation Hardware word size settings on the Hardware Implementation pane to match your compiler word sizes as defined in the compiler's limits.h header file. Alternatively, you can select 'None' for Emulation Hardware and select the 'Enable portable word sizes' option for ERT based targets, which will disable the preprocessor word size checks."
#endif

#if ( USHRT_MAX != (0xFFFFU) ) || ( SHRT_MAX != (0x7FFF) )
#error "Code was generated for compiler with different sized ushort/short. Consider adjusting Emulation Hardware word size settings on the Hardware Implementation pane to match your compiler word sizes as defined in the compilers limits.h header file. Alternatively, you can select 'None' for Emulation Hardware and select the 'Enable portable word sizes' option for ERT based targets, this will disable the preprocessor word size checks."
#endif

#if ( UINT_MAX != (0xFFFFU) ) || ( INT_MAX != (0x7FFF) )
#error "Code was generated for compiler with different sized uint/int. Consider adjusting Emulation Hardware word size settings on the Hardware Implementation pane to match your compiler word sizes as defined in the compilers limits.h header file. Alternatively, you can select 'None' for Emulation Hardware and select the 'Enable portable word sizes' option for ERT based targets, this will disable the preprocessor word size checks."
#endif

#if ( ULONG_MAX != (0xFFFFFFFFUL) ) || ( LONG_MAX != (0x7FFFFFFFL) )
#error "Code was generated for compiler with different sized ulong/long. Consider adjusting Emulation Hardware word size settings on the Hardware Implementation pane to match your compiler word sizes as defined in the compilers limits.h header file. Alternatively, you can select 'None' for Emulation Hardware and select the 'Enable portable word sizes' option for ERT based targets, this will disable the preprocessor word size checks."
#endif

#ifndef __RTWTYPES_H__
#error This file requires rtwtypes.h to be included
#else
#ifdef TMWTYPES_PREVIOUSLY_INCLUDED
#error This file requires rtwtypes.h to be included before tmwtypes.h
#else

/* Check for inclusion of an incorrect version of rtwtypes.h */
#ifndef RTWTYPES_ID_C08S16I16L32N16F1
#error This code was generated with a different "rtwtypes.h" than the file included
#endif                                 /* RTWTYPES_ID_C08S16I16L32N16F1 */
#endif                                 /* TMWTYPES_PREVIOUSLY_INCLUDED */
#endif                                 /* __RTWTYPES_H__ */

#define _SPI1EN                        (SPI1STATbits.SPIEN)
#define _SPI2EN                        (SPI2STATbits.SPIEN)

extern uint16_T CalculusTimeStep;      /* Global Variable Used in <S11>/Calculus Time Step*/
extern volatile uint16_T ic2up;
extern volatile uint16_T ic3up;
extern volatile uint16_T ic4up;
extern volatile uint16_T ic5up;
extern volatile uint16_T ic8up;
extern uint8_T getApControlType();
extern void gsRead(uint8_T* y1);
extern void readIpc(uint8_T* y1);
extern void protParseDecode(uint8_T* u1);
extern void protParseDecodeGS(uint8_T* u1);
extern void updateLoad(uint8_T u1);
extern void getMidLevelCommands(real32_T* y1);
extern real32_T getDynamic();
extern void getPidIdx(uint8_T u1,real32_T* y1);
extern uint8_T isApManual();
extern uint16_T meanFilter5(uint16_T* u1);
extern uint16_T meanFilter5(uint16_T* u1);
extern uint16_T meanFilter5(uint16_T* u1);
extern uint16_T meanFilter5(uint16_T* u1);
extern void setCurrentCommands(real32_T u1);
extern void getXYZ(real32_T* y1);
extern void getPidIdx(uint8_T u1,real32_T* y1);
extern void getPidIdx(uint8_T u1,real32_T* y1);
extern real32_T myCos(real32_T u1);
extern real32_T myCos(real32_T u1);
extern real32_T myCos(real32_T u1);
extern real32_T mySin(real32_T u1);
extern real32_T mySin(real32_T u1);
extern real32_T mySin(real32_T u1);
extern void getAttitude(real32_T* y1);
extern real32_T myCos(real32_T u1);
extern real32_T myCos(real32_T u1);
extern real32_T myCos(real32_T u1);
extern real32_T mySin(real32_T u1);
extern real32_T mySin(real32_T u1);
extern real32_T mySin(real32_T u1);
extern real32_T myAtan2(real32_T u1, real32_T u2);
extern real32_T myAsin(real32_T u1);
extern real32_T myAtan2(real32_T u1, real32_T u2);
extern void getPidIdx(uint8_T u1,real32_T* y1);
extern uint8_T isWpFly();
extern uint8_T getMaxWp();
extern void getVned(real32_T* y1);
extern void getPidIdx(uint8_T u1,real32_T* y1);
extern real32_T mySqrt(real32_T u1);
extern void getWP(uint8_T u1,real32_T* y1);
extern void getWP(uint8_T u1,real32_T* y1);
extern void getWP(uint8_T u1,real32_T* y1);
extern real32_T mySqrt(real32_T u1);
extern real32_T mySqrt(real32_T u1);
extern real32_T myAbs(real32_T u1);
extern real32_T mySqrt(real32_T u1);
extern real32_T mySqrt(real32_T u1);
extern real32_T myAsin(real32_T u1);
extern real32_T mySin(real32_T u1);
extern void setLogFloat2(real32_T* u1);
extern real32_T myAbs(real32_T u1);
extern real32_T myAbs(real32_T u1);
extern real32_T myAbs(real32_T u1);
extern real32_T mySqrt(real32_T u1);
extern void setNavNav(real32_T* u1);
extern real32_T myAtan2(real32_T u1, real32_T u2);
extern real32_T mySqrt(real32_T u1);
extern real32_T myAtan2(real32_T u1, real32_T u2);
extern real32_T mySin(real32_T u1);
extern real32_T myCos(real32_T u1);
extern void getWP(uint8_T u1,real32_T* y1);
extern void setLogFloat1(real32_T* u1);
extern real32_T myAtan(real32_T u1);
extern void getPidIdx(uint8_T u1,real32_T* y1);
extern real32_T myPow(real32_T u1, real32_T u2);
extern real32_T mySqrt(real32_T u1);
extern void setNavLong(real32_T* u1);
extern real32_T myCos(real32_T u1);
extern void getPidIdx(uint8_T u1,real32_T* y1);
extern void getPidIdx(uint8_T u1,real32_T* y1);
extern real32_T myCos(real32_T u1);
extern real32_T mySin(real32_T u1);
extern void getPidIdx(uint8_T u1,real32_T* y1);
extern real32_T myExp(real32_T u1);
extern real32_T myExp(real32_T u1);
extern void getAccels(real32_T* y1);
extern void getAccBias(real32_T* y1);
extern real32_T myTan(real32_T u1);
extern real32_T myTan(real32_T u1);
extern real32_T myAtan(real32_T u1);
extern real32_T myAtan(real32_T u1);
extern void getPidIdx(uint8_T u1,real32_T* y1);
extern void setNavLat(real32_T* u1);
extern void setDiagnosticShort(int16_T* u1);
extern void getPassValues(uint8_T* y1);
extern void updatePWM(uint16_T* u1);
extern void updateEuler(real32_T* u1);
extern void updatePQR(real32_T* u1);
extern void prepareTelemetry(uint8_T* y1);
extern void send2GS(uint8_T* u1);
extern void setDiagnosticFloat(real32_T* u1);
extern void updatePWM2(uint16_T u1, uint8_T u2);
extern void updatePWM2(uint16_T u1, uint8_T u2);
extern void updatePWM2(uint16_T u1, uint8_T u2);
extern void updatePWM2(uint16_T u1, uint8_T u2);
extern void updatePWM2(uint16_T u1, uint8_T u2);
extern uint8_T getFilterOnOff();
extern void controlMCUInit();
extern void EmbeddedMATLABFunction_Init(rtDW_EmbeddedMATLABFunction_con *localDW);
extern void cont_EmbeddedMATLABFunction(real32_T rtu_u, real_T rtu_T, real_T
  rtu_f, rtB_EmbeddedMATLABFunction_cont *localB,
  rtDW_EmbeddedMATLABFunction_con *localDW);
extern void controlMCUSlugsM_negprotect(real32_T rtu_val,
  rtB_negprotect_controlMCUSlugsM *localB);
extern void controlMCUSlugsMK_myMuxFun1(real32_T rtu_u1, real32_T rtu_u2,
  real32_T rtu_u3, rtB_myMuxFun1_controlMCUSlugsMK *localB);
extern void co_EmbeddedMATLABFunction_m(const real32_T rtu_x[3], const real32_T
  rtu_y[3], rtB_EmbeddedMATLABFunction_co_p *localB);
extern void co_EmbeddedMATLABFunction_a(const real32_T rtu_x[3],
  rtB_EmbeddedMATLABFunction_co_e *localB);
extern void contro_BufferICChannel_Init(rtDW_BufferICChannel_controlMCU *localDW);
extern void controlMCUS_BufferICChannel(uint16_T rtu_latest,
  rtB_BufferICChannel_controlMCUS *localB, rtDW_BufferICChannel_controlMCU
  *localDW);
extern void controlMCUSlugs_myMuxFun1_a(uint16_T rtu_u1, uint16_T rtu_u2,
  uint16_T rtu_u3, uint16_T rtu_u4, uint16_T rty_y[4]);
extern void controlMCUSlugs_myMuxFun1_n(real32_T rtu_u1, real32_T rtu_u2,
  real32_T rtu_u3, real32_T rtu_u4, real32_T rtu_u5, real32_T rtu_u6, real32_T
  rtu_u7, real32_T rtu_u8, real32_T rtu_u9, rtB_myMuxFun1_controlMCUSlugs_p
  *localB);
extern void controlMCUSlugs_myMuxFun1_o(real32_T rtu_u1, real32_T rtu_u2,
  real32_T rtu_u3, rtB_myMuxFun1_controlMCUSlugs_b *localB);
void controlMCUSlugsMKII_step0(void);
void controlMCUSlugsMKII_step1(void);

#endif                                 /* RTW_HEADER_controlMCUSlugsMKII_private_h_ */

/* File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
