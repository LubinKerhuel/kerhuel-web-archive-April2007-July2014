/*
 * File: controlMCUSlugsMKII.c
 *
 * Real-Time Workshop code generated for Simulink model controlMCUSlugsMKII.
 *
 * Model version                        : 1.714
 * Real-Time Workshop file version      : 7.5  (R2010a)  25-Jan-2010
 * Real-Time Workshop file generated on : Tue Nov 23 13:12:51 2010
 * TLC version                          : 7.5 (Jan 19 2010)
 * C source code generated on           : Tue Nov 23 13:12:52 2010
 *--------------------------------------------------------------
 *   Embedded Coder for Microchip dsPIC family.                 |
 *   Generate .c and .h files from your Matlab/simulink model   |
 *   and compile the diagram to .hex and .coff file that can be |
 *   downloaded directly into the microcontroller               |
 *                                                              |
 * Licence Accorded to Blake Mills                              |
 *                     University of Colorado-Boulder           |
 *                                                              |
 *   Written by Lubin KERHUEL -  http://www.kerhuel.eu          |
 *  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - |
 *   Version 3.3a                              22-Nov-2010      |
 *   For Matlab 7.10            R2010a                          |
 *--------------------------------------------------------------
 */

#include "controlMCUSlugsMKII.h"
#include "controlMCUSlugsMKII_private.h"

/* Block signals (auto storage) */
BlockIO_controlMCUSlugsMKII controlMCUSlugsMKII_B;

/* Block states (auto storage) */
D_Work_controlMCUSlugsMKII controlMCUSlugsMKII_DWork;

/* Previous zero-crossings (trigger) states */
PrevZCSigStates_controlMCUSlugs controlMCUSlugsM_PrevZCSigState;

/* Real-time model */
RT_MODEL_controlMCUSlugsMKII controlMCUSlugsMKII_M_;
RT_MODEL_controlMCUSlugsMKII *controlMCUSlugsMKII_M = &controlMCUSlugsMKII_M_;
static void rate_monotonic_scheduler(void);

/*
 * Set which subrates need to run this base step (base rate always runs).
 * This function must be called prior to calling the model step function
 * in order to "remember" which rates need to run this base step.  The
 * buffering of events allows for overlapping preemption.
 */
void controlMCUSlugsMKII_SetEventsForThisBaseStep(boolean_T *eventFlags)
{
  /* Task runs when its counter is zero, computed via rtmStepTask macro */
  eventFlags[1] = ((boolean_T)rtmStepTask(controlMCUSlugsMKII_M, 1));
}

/*
 * This function updates active task flag for each subrate
 * and rate transition flags for tasks that exchagne data.
 * The function assumes rate-monotonic multitasking scheduler.
 * The function must be called at model base rate so that
 * the generated code self-manages all its subrates and rate
 * transition flags.
 */
static void rate_monotonic_scheduler(void)
{
  /* Compute which subrates run during the next base time step.  Subrates
   * are an integer multiple of the base rate counter.  Therefore, the subtask
   * counter is reset when it reaches its limit (zero means run).
   */
  (controlMCUSlugsMKII_M->Timing.TaskCounters.TID[1])++;
  if ((controlMCUSlugsMKII_M->Timing.TaskCounters.TID[1]) > 99) {/* Sample time: [1.0s, 0.0s] */
    controlMCUSlugsMKII_M->Timing.TaskCounters.TID[1] = 0;
  }
}

/*
 * Initial conditions for atomic system:
 *    '<S45>/Embedded MATLAB Function'
 *    '<S88>/Embedded MATLAB Function'
 *    '<S89>/Embedded MATLAB Function'
 *    '<S90>/Embedded MATLAB Function'
 */
void EmbeddedMATLABFunction_Init(rtDW_EmbeddedMATLABFunction_con *localDW)
{
  /* InitializeConditions for Embedded MATLAB: '<S45>/Embedded MATLAB Function' */
  localDW->a_not_empty = FALSE;
}

/*
 * Output and update for atomic system:
 *    '<S45>/Embedded MATLAB Function'
 *    '<S88>/Embedded MATLAB Function'
 *    '<S89>/Embedded MATLAB Function'
 *    '<S90>/Embedded MATLAB Function'
 */
void cont_EmbeddedMATLABFunction(real32_T rtu_u, real_T rtu_T, real_T rtu_f,
  rtB_EmbeddedMATLABFunction_cont *localB, rtDW_EmbeddedMATLABFunction_con
  *localDW)
{
  real_T eml_omega;

  /* Embedded MATLAB: '<S45>/Embedded MATLAB Function' */
  /* Embedded MATLAB Function 'Inner Loop/ Navigation/Lateral Channel/0.5 sec  tau/Embedded MATLAB Function': '<S61>:1' */
  /*  This block supports an embeddable subset of the MATLAB language. */
  /*  See the help menu for details.  */
  if (!localDW->a_not_empty) {
    /* '<S61>:1:9' */
    /* tf = [T*omega/(2+T*omega) T*omega/(2+T*omega)],[1 (T*omega-2)/(T*omega+2)] */
    /* tf = [a a],[1 -b] */
    /* '<S61>:1:12' */
    eml_omega = 6.2831853071795862E+000 * rtu_f;

    /* '<S61>:1:13' */
    localDW->a = rtu_T * eml_omega / (rtu_T * eml_omega + 2.0);
    localDW->a_not_empty = TRUE;

    /* '<S61>:1:14' */
    localDW->b = (-(rtu_T * eml_omega - 2.0)) / (rtu_T * eml_omega + 2.0);

    /* '<S61>:1:15' */
    localDW->y_km1 = rtu_u;

    /* '<S61>:1:16' */
    localDW->u_km1 = rtu_u;
  }

  /* '<S61>:1:19' */
  localB->y = (rtu_u + localDW->u_km1) * (real32_T)localDW->a + (real32_T)
    localDW->b * localDW->y_km1;

  /* '<S61>:1:20' */
  localDW->y_km1 = localB->y;

  /* '<S61>:1:21' */
  localDW->u_km1 = rtu_u;
}

/*
 * Output and update for atomic system:
 *    '<S70>/negprotect'
 *    '<S113>/negprotect'
 *    '<S149>/negprotect'
 *    '<S188>/negprotect'
 *    '<S214>/negprotect'
 *    '<S221>/negprotect'
 *    '<S247>/negprotect'
 *    '<S237>/negprotect'
 *    '<S255>/negprotect'
 *    '<S264>/negprotect'
 *    '<S239>/negprotect1'
 */
void controlMCUSlugsM_negprotect(real32_T rtu_val,
  rtB_negprotect_controlMCUSlugsM *localB)
{
  /* Embedded MATLAB: '<S70>/negprotect' */
  /* Embedded MATLAB Function 'Inner Loop/ Navigation/Lateral Channel/Sideslip Compensation/Bank to Psi Dot/negprotect': '<S75>:1' */
  /*  This block supports an embeddable subset of the MATLAB language. */
  /*  See the help menu for details.  */
  if (rtu_val >= 1.000000047E-003F) {
    /* '<S75>:1:5' */
    /* '<S75>:1:6' */
    localB->zpVal = rtu_val;
  } else {
    /* '<S75>:1:8' */
    localB->zpVal = 1.000000047E-003F;
  }
}

/*
 * Output and update for atomic system:
 *    '<S14>/myMux Fun1'
 *    '<S16>/myMux Fun1'
 *    '<S2>/myMux Fun2'
 */
void controlMCUSlugsMK_myMuxFun1(real32_T rtu_u1, real32_T rtu_u2, real32_T
  rtu_u3, rtB_myMuxFun1_controlMCUSlugsMK *localB)
{
  /* Embedded MATLAB: '<S14>/myMux Fun1' */
  /* Embedded MATLAB Function 'Inner Loop/ Navigation/Lateral Channel/myMux Fun1': '<S58>:1' */
  /*  This block supports an embeddable subset of the MATLAB language. */
  /*  See the help menu for details.  */
  /* '<S58>:1:5' */
  localB->y[0] = rtu_u1;
  localB->y[1] = rtu_u2;
  localB->y[2] = rtu_u3;
}

/*
 * Output and update for atomic system:
 *    '<S129>/Embedded MATLAB Function'
 *    '<S183>/Embedded MATLAB Function'
 */
void co_EmbeddedMATLABFunction_m(const real32_T rtu_x[3], const real32_T rtu_y[3],
  rtB_EmbeddedMATLABFunction_co_p *localB)
{
  /* Embedded MATLAB: '<S129>/Embedded MATLAB Function' */
  /* Embedded MATLAB Function 'Inner Loop/ Navigation/Navigation/Compute Lateral Error/Subsystem3/Embedded MATLAB Function': '<S130>:1' */
  /*  This block supports an embeddable subset of the MATLAB language. */
  /*  See the help menu for details.  */
  /* '<S130>:1:5' */
  localB->xDoty = (rtu_x[0] * rtu_y[0] + rtu_x[1] * rtu_y[1]) + rtu_x[2] *
    rtu_y[2];
}

/*
 * Output and update for atomic system:
 *    '<S150>/Embedded MATLAB Function'
 *    '<S189>/Embedded MATLAB Function'
 *    '<S215>/Embedded MATLAB Function'
 *    '<S222>/Embedded MATLAB Function'
 *    '<S248>/Embedded MATLAB Function'
 */
void co_EmbeddedMATLABFunction_a(const real32_T rtu_x[3],
  rtB_EmbeddedMATLABFunction_co_e *localB)
{
  /* Embedded MATLAB: '<S150>/Embedded MATLAB Function' */
  /* Embedded MATLAB Function 'Inner Loop/ Navigation/Navigation/Compute WP Index/Compute P/Compute T  in Frenet/Normalize Vector/Norm/Subsystem3/Embedded MATLAB Function': '<S153>:1' */
  /*  This block supports an embeddable subset of the MATLAB language. */
  /*  See the help menu for details.  */
  /* '<S153>:1:5' */
  localB->xDoty = (rtu_x[0] * rtu_x[0] + rtu_x[1] * rtu_x[1]) + rtu_x[2] *
    rtu_x[2];
}

/*
 * Initial conditions for atomic system:
 *    '<S276>/Buffer IC Channel'
 *    '<S276>/Buffer IC Channel1'
 *    '<S276>/Buffer IC Channel2'
 *    '<S276>/Buffer IC Channel3'
 */
void contro_BufferICChannel_Init(rtDW_BufferICChannel_controlMCU *localDW)
{
  int16_T tmp;

  /* InitializeConditions for Embedded MATLAB: '<S276>/Buffer IC Channel' */
  for (tmp = 0; tmp < 7; tmp++) {
    localDW->oldValues[tmp] = 0U;
  }
}

/*
 * Output and update for atomic system:
 *    '<S276>/Buffer IC Channel'
 *    '<S276>/Buffer IC Channel1'
 *    '<S276>/Buffer IC Channel2'
 *    '<S276>/Buffer IC Channel3'
 */
void controlMCUS_BufferICChannel(uint16_T rtu_latest,
  rtB_BufferICChannel_controlMCUS *localB, rtDW_BufferICChannel_controlMCU
  *localDW)
{
  int16_T eml_i;

  /* Embedded MATLAB: '<S276>/Buffer IC Channel' */
  /* Embedded MATLAB Function 'Trim Vals/Bufffer IC/Buffer IC Channel': '<S281>:1' */
  /*  This block supports an embeddable subset of the MATLAB language. */
  /*  See the help menu for details.  */
  /* '<S281>:1:11' */
  for (eml_i = 0; eml_i < 7; eml_i++) {
    localB->history[eml_i] = 0U;
  }

  /* '<S281>:1:13' */
  for (eml_i = 7; eml_i > 1; eml_i += -1) {
    /* '<S281>:1:13' */
    /* '<S281>:1:14' */
    localDW->oldValues[eml_i - 1] = localDW->oldValues[eml_i - 2];

    /* '<S281>:1:15' */
    localB->history[eml_i - 1] = localDW->oldValues[eml_i - 2];
  }

  /* '<S281>:1:18' */
  localDW->oldValues[0] = rtu_latest;

  /* '<S281>:1:19' */
  localB->history[0] = rtu_latest;
}

/*
 * Output and update for atomic system:
 *    '<S293>/myMux Fun1'
 *    '<S296>/myMux Fun1'
 *    '<S294>/myMux Fun1'
 *    '<S295>/myMux Fun1'
 */
void controlMCUSlugs_myMuxFun1_a(uint16_T rtu_u1, uint16_T rtu_u2, uint16_T
  rtu_u3, uint16_T rtu_u4, uint16_T rty_y[4])
{
  /* Embedded MATLAB: '<S293>/myMux Fun1' */
  /* Embedded MATLAB Function 'Update PWM Commands and Send Telemetry/Generate PWM Signals Based on the Control Type/If  Control Type Is Manual/myMux Fun1': '<S297>:1' */
  /*  This block supports an embeddable subset of the MATLAB language. */
  /*  See the help menu for details.  */
  /* '<S297>:1:5' */
  rty_y[0] = rtu_u1;
  rty_y[1] = rtu_u2;
  rty_y[2] = rtu_u3;
  rty_y[3] = rtu_u4;
}

/*
 * Output and update for atomic system:
 *    '<S333>/myMux Fun1'
 *    '<S350>/myMux Fun1'
 */
void controlMCUSlugs_myMuxFun1_n(real32_T rtu_u1, real32_T rtu_u2, real32_T
  rtu_u3, real32_T rtu_u4, real32_T rtu_u5, real32_T rtu_u6, real32_T rtu_u7,
  real32_T rtu_u8, real32_T rtu_u9, rtB_myMuxFun1_controlMCUSlugs_p *localB)
{
  /* Embedded MATLAB: '<S333>/myMux Fun1' */
  /* Embedded MATLAB Function 'get Nav Vars/Euler Angles to  Direction Cosine Matrix1/Create Transformation Matrix/myMux Fun1': '<S335>:1' */
  /*  This block supports an embeddable subset of the MATLAB language. */
  /*  See the help menu for details.  */
  /* '<S335>:1:5' */
  localB->y[0] = rtu_u1;
  localB->y[1] = rtu_u2;
  localB->y[2] = rtu_u3;
  localB->y[3] = rtu_u4;
  localB->y[4] = rtu_u5;
  localB->y[5] = rtu_u6;
  localB->y[6] = rtu_u7;
  localB->y[7] = rtu_u8;
  localB->y[8] = rtu_u9;
}

/*
 * Output and update for atomic system:
 *    '<S334>/myMux Fun1'
 *    '<S334>/myMux Fun2'
 *    '<S351>/myMux Fun1'
 *    '<S351>/myMux Fun2'
 *    '<S9>/myMux Fun1'
 */
void controlMCUSlugs_myMuxFun1_o(real32_T rtu_u1, real32_T rtu_u2, real32_T
  rtu_u3, rtB_myMuxFun1_controlMCUSlugs_b *localB)
{
  /* Embedded MATLAB: '<S334>/myMux Fun1' */
  /* Embedded MATLAB Function 'get Nav Vars/Euler Angles to  Direction Cosine Matrix1/Subsystem5/myMux Fun1': '<S339>:1' */
  /*  This block supports an embeddable subset of the MATLAB language. */
  /*  See the help menu for details.  */
  /* '<S339>:1:5' */
  localB->y[0] = rtu_u1;
  localB->y[1] = rtu_u2;
  localB->y[2] = rtu_u3;
}

/* Model step function for TID0 */
void controlMCUSlugsMKII_step0(void)   /* Sample time: [0.01s, 0.0s] */
{
  /* local block i/o variables */
  real32_T rtb_u5u6;
  real32_T rtb_Sum;
  real32_T rtb_Sum_o;
  real32_T rtb_u3u5;
  real32_T rtb_Sum_oz;
  real32_T rtb_Sum_m;
  real32_T rtb_Gain2;
  real32_T rtb_u1u3_g;
  real32_T rtb_u4u5;
  real32_T rtb_u5u6_l;
  real32_T rtb_Sum_od;
  real32_T rtb_Sum_i;
  real32_T rtb_u3u5_b;
  real32_T rtb_Sum_p;
  real32_T rtb_Sum_pu;
  real32_T rtb_Gain2_m;
  real32_T rtb_u1u3_l;
  real32_T rtb_u4u5_a;
  real32_T rtb_y_d;
  real32_T rtb_u45;
  real32_T rtb_Add_id[3];
  real32_T rtb_Product_c;
  real32_T rtb_Subtract[3];
  real32_T rtb_xDoty;
  real32_T rtb_Add_f[3];
  real32_T rtb_N[3];
  real32_T rtb_Add_d[3];
  real32_T rtb_Add_k[3];
  real32_T rtb_Divide2;
  real32_T rtb_Switch_d;
  real32_T rtb_BankLimitCommand;
  real32_T rtb_u020_g;
  uint16_T rtb_Switch_k;
  uint16_T rtb_Switch1_b;
  uint16_T rtb_Switch2_l;
  uint16_T rtb_Switch3;
  uint16_T rtb_Gain_pn;
  uint16_T rtb_Gain1_c;
  uint16_T rtb_Gain2_d;
  uint16_T rtb_Gain3_p;
  uint16_T rtb_DataTypeConversion_k;
  uint16_T rtb_DataTypeConversion_o;
  uint16_T rtb_DataTypeConversion_o5;
  uint16_T rtb_DataTypeConversion_j;
  uint16_T rtb_Gain_fi;
  uint16_T rtb_Gain1_cp;
  uint16_T rtb_Gain2_f;
  uint16_T rtb_Gain3_j;
  uint16_T rtb_y_n[5];
  ZCEventType zcEvent;
  real32_T rtb_Abs2;
  real_T rtb_DataTypeConversion;
  boolean_T rtb_IntegerDelay2_m;
  real32_T rtb_u020;
  real32_T rtb_Product2_cp[3];
  real32_T rtb_u525[3];
  real32_T rtb_Divide4_k;
  int16_T rtb_IC1;
  uint8_T rtb_Add1_i;
  real32_T rtb_cosphi;
  real32_T rtb_sinphi;
  real32_T rtb_Deg2R1;
  real32_T rtb_Sum2;
  real32_T rtb_Ze;
  real32_T rtb_Product1_m;
  real32_T rtb_MathFunction[9];
  int16_T tmp;
  real32_T tmp_0[9];
  real32_T tmp_1[3];
  real32_T rtb_Deg2R_o_idx;
  real32_T rtb_Deg2R_o_idx_0;
  uint16_T tmp_2;
  uint8_T tmp_3;
  uint32_T tmp_4;

  {                                    /* Sample time: [0.01s, 0.0s] */
    rate_monotonic_scheduler();
  }

  /* S-Function "dsPIC_PWM_IC" Block: <S277>/Input Capture */
  controlMCUSlugsMKII_B.InputCapture_o1 = ic2up;
  controlMCUSlugsMKII_B.InputCapture_o2 = ic3up;
  controlMCUSlugsMKII_B.InputCapture_o3 = ic4up;
  controlMCUSlugsMKII_B.InputCapture_o4 = ic5up;
  controlMCUSlugsMKII_B.InputCapture_o5 = ic8up;

  /* Embedded MATLAB: '<S277>/myMux Fun5' */
  /* Embedded MATLAB Function 'Trim Vals/Control Surface Input/myMux Fun5': '<S285>:1' */
  /*  This block supports an embeddable subset of the MATLAB language. */
  /*  See the help menu for details.  */
  /* '<S285>:1:5' */
  rtb_y_n[0] = controlMCUSlugsMKII_B.InputCapture_o1;
  rtb_y_n[1] = controlMCUSlugsMKII_B.InputCapture_o2;
  rtb_y_n[2] = controlMCUSlugsMKII_B.InputCapture_o3;
  rtb_y_n[3] = controlMCUSlugsMKII_B.InputCapture_o4;
  rtb_y_n[4] = controlMCUSlugsMKII_B.InputCapture_o5;

  /* S-Function "dsPIC_C_function_Call" Block: <S8>/Get Control Type [navSupport.c] */
  controlMCUSlugsMKII_B.GetControlTypenavSupportc = getApControlType();

  /* S-Function "UART_RX" Block: <S11>/Calculus Time Step */
  controlMCUSlugsMKII_B.CalculusTimeStep_o1 = CalculusTimeStep;
  controlMCUSlugsMKII_B.CalculusTimeStep_o2 = PR1;

  /* DataTypeConversion: '<S11>/Data Type Conversion12' incorporates:
   *  DataTypeConversion: '<S11>/Data Type Conversion3'
   *  DataTypeConversion: '<S11>/Data Type Conversion4'
   *  Gain: '<S11>/Gain'
   *  Product: '<S11>/Divide'
   *  Rounding: '<S11>/Rounding Function'
   */
  rtb_DataTypeConversion = floor((real_T)
    controlMCUSlugsMKII_B.CalculusTimeStep_o1 / (real_T)
    controlMCUSlugsMKII_B.CalculusTimeStep_o2 * 100.0);
  if (rtIsNaN(rtb_DataTypeConversion) || rtIsInf(rtb_DataTypeConversion)) {
    rtb_DataTypeConversion = 0.0;
  } else {
    rtb_DataTypeConversion = fmod(rtb_DataTypeConversion, 256.0);
  }

  controlMCUSlugsMKII_B.DataTypeConversion12 = (uint8_T)(rtb_DataTypeConversion <
    0.0 ? (int16_T)(uint8_T)(int8_T)(-((int8_T)(uint8_T)(-rtb_DataTypeConversion)))
    : (int16_T)(uint8_T)rtb_DataTypeConversion);

  /* S-Function "dsPIC_C_function_Call" Block: <S1>/Data from GS [groundStationDriver.c] */
  gsRead(&controlMCUSlugsMKII_B.DatafromGSgroundStationDriverc[0]);

  /* S-Function "dsPIC_C_function_Call" Block: <S1>/Data from IPC [interProcCommSlave.c] */
  readIpc(&controlMCUSlugsMKII_B.DatafromIPCinterProcCommSlavec[0]);

  /* S-Function "dsPIC_C_function_Call" Block: <S7>/Parser//Decoder [protDecoder.c] */
  protParseDecode(controlMCUSlugsMKII_B.DatafromIPCinterProcCommSlavec);

  /* S-Function "dsPIC_C_function_Call" Block: <S7>/GS Messages  Parser//Decoder [groundStationDriver.c] */
  protParseDecodeGS(controlMCUSlugsMKII_B.DatafromGSgroundStationDriverc);

  /* S-Function "dsPIC_C_function_Call" Block: <S7>/update Load of  Control MCU [groundStationDriver.c] */
  updateLoad(controlMCUSlugsMKII_B.DataTypeConversion12);

  /* S-Function "dsPIC_C_function_Call" Block: <Root>/Get MidLevel Commands [navSupport.c] */
  getMidLevelCommands(&controlMCUSlugsMKII_B.GetMidLevelCommandsnavSupportc[0]);

  /* S-Function "dsPIC_C_function_Call" Block: <Root>/Get Dynamic P [navSupport.c] */
  controlMCUSlugsMKII_B.GetDynamicPnavSupportc = getDynamic();

  /* S-Function "dsPIC_C_function_Call" Block: <S3>/Get Pid according to Index */
  getPidIdx(((uint8_T)0U),&controlMCUSlugsMKII_B.GetPidaccordingtoIndex[0]);

  /* Embedded MATLAB: '<S276>/Buffer IC Channel' */
  controlMCUS_BufferICChannel(rtb_y_n[0],
    &controlMCUSlugsMKII_B.sf_BufferICChannel,
    &controlMCUSlugsMKII_DWork.sf_BufferICChannel);

  /* Embedded MATLAB: '<S276>/Buffer IC Channel1' */
  controlMCUS_BufferICChannel(rtb_y_n[1],
    &controlMCUSlugsMKII_B.sf_BufferICChannel1,
    &controlMCUSlugsMKII_DWork.sf_BufferICChannel1);

  /* Embedded MATLAB: '<S276>/Buffer IC Channel2' */
  controlMCUS_BufferICChannel(rtb_y_n[3],
    &controlMCUSlugsMKII_B.sf_BufferICChannel2,
    &controlMCUSlugsMKII_DWork.sf_BufferICChannel2);

  /* Embedded MATLAB: '<S276>/Buffer IC Channel3' */
  controlMCUS_BufferICChannel(rtb_y_n[2],
    &controlMCUSlugsMKII_B.sf_BufferICChannel3,
    &controlMCUSlugsMKII_DWork.sf_BufferICChannel3);

  /* S-Function (sfix_udelay): '<S6>/Integer Delay' */
  controlMCUSlugsMKII_B.IntegerDelay =
    controlMCUSlugsMKII_DWork.IntegerDelay_X_p;

  /* S-Function (sfix_udelay): '<S278>/Integer Delay2' */
  rtb_IntegerDelay2_m = controlMCUSlugsMKII_DWork.IntegerDelay2_X_k;

  /* S-Function "dsPIC_C_function_Call" Block: <S6>/Manual or Auto? [navSupport.c] */
  controlMCUSlugsMKII_B.ManualorAutonavSupportc = isApManual();

  /* DataTypeConversion: '<S278>/Data Type Conversion' */
  rtb_DataTypeConversion = (real_T)controlMCUSlugsMKII_B.ManualorAutonavSupportc;

  /* HitCross: '<S278>/Hit  Crossing' */
  zcEvent = rt_ZCFcn(FALLING_ZERO_CROSSING,
                     &controlMCUSlugsM_PrevZCSigState.HitCrossing_Input_ZCE,
                     (rtb_DataTypeConversion - 0.5));
  if (controlMCUSlugsMKII_DWork.HitCrossing_MODE == 0) {
    if (zcEvent != NO_ZCEVENT) {
      controlMCUSlugsMKII_B.HitCrossing = !controlMCUSlugsMKII_B.HitCrossing;
      controlMCUSlugsMKII_DWork.HitCrossing_MODE = 1;
    } else {
      if (controlMCUSlugsMKII_B.HitCrossing && (rtb_DataTypeConversion != 0.5))
      {
        controlMCUSlugsMKII_B.HitCrossing = FALSE;
      }
    }
  } else {
    if (rtb_DataTypeConversion != 0.5) {
      controlMCUSlugsMKII_B.HitCrossing = FALSE;
    }

    controlMCUSlugsMKII_DWork.HitCrossing_MODE = 0;
  }

  /* InitialCondition: '<S278>/IC' */
  if (controlMCUSlugsMKII_DWork.IC_FirstOutputTime) {
    controlMCUSlugsMKII_DWork.IC_FirstOutputTime = FALSE;
    controlMCUSlugsMKII_B.IC_c = TRUE;
  } else {
    controlMCUSlugsMKII_B.IC_c = controlMCUSlugsMKII_B.HitCrossing;
  }

  /* Outputs for enable SubSystem: '<S6>/Grab I.C.' incorporates:
   *  EnablePort: '<S279>/Enable'
   *  Sum: '<S278>/Add'
   */
  if ((int16_T)rtb_IntegerDelay2_m + (int16_T)controlMCUSlugsMKII_B.IC_c > 0) {
    /* S-Function "dsPIC_C_function_Call" Block: <S279>/Choose the Median [navSupport.c] */
    controlMCUSlugsMKII_B.ChoosetheMediannavSupportc = meanFilter5
      (controlMCUSlugsMKII_B.sf_BufferICChannel.history);

    /* DataTypeConversion: '<S286>/Data Type Conversion' incorporates:
     *  Constant: '<S286>/Constant1'
     *  Constant: '<S286>/Constant2'
     *  Product: '<S286>/Divide'
     *  Sum: '<S286>/Add'
     */
    controlMCUSlugsMKII_B.DataTypeConversion = (real32_T)((real_T)
      controlMCUSlugsMKII_B.ChoosetheMediannavSupportc * 3.9246467817896354E-004
      + -2.4929356357927763E+000);

    /* S-Function "dsPIC_C_function_Call" Block: <S279>/Choose the Median [navSupport.c]1 */
    controlMCUSlugsMKII_B.ChoosetheMediannavSupportc1 = meanFilter5
      (controlMCUSlugsMKII_B.sf_BufferICChannel1.history);

    /* DataTypeConversion: '<S287>/Data Type Conversion' incorporates:
     *  Constant: '<S287>/Constant1'
     *  Constant: '<S287>/Constant2'
     *  Product: '<S287>/Divide'
     *  Sum: '<S287>/Add'
     */
    controlMCUSlugsMKII_B.DataTypeConversion_f = (real32_T)((real_T)
      controlMCUSlugsMKII_B.ChoosetheMediannavSupportc1 *
      1.4565320234764749E-004 + -1.0755448613356997E+000);

    /* S-Function "dsPIC_C_function_Call" Block: <S279>/Choose the Median [navSupport.c]2 */
    controlMCUSlugsMKII_B.ChoosetheMediannavSupportc2 = meanFilter5
      (controlMCUSlugsMKII_B.sf_BufferICChannel2.history);

    /* DataTypeConversion: '<S288>/Data Type Conversion' incorporates:
     *  Constant: '<S288>/Constant1'
     *  Constant: '<S288>/Constant2'
     *  Product: '<S288>/Divide'
     *  Sum: '<S288>/Add'
     */
    controlMCUSlugsMKII_B.DataTypeConversion_b = (real32_T)((real_T)
      controlMCUSlugsMKII_B.ChoosetheMediannavSupportc2 *
      1.7474741230625272E-004 + -1.3006200258793954E+000);

    /* S-Function "dsPIC_C_function_Call" Block: <S279>/Choose the Median [navSupport.c]3 */
    controlMCUSlugsMKII_B.ChoosetheMediannavSupportc3 = meanFilter5
      (controlMCUSlugsMKII_B.sf_BufferICChannel3.history);

    /* DataTypeConversion: '<S289>/Data Type Conversion' incorporates:
     *  Constant: '<S289>/Constant1'
     *  Constant: '<S289>/Constant2'
     *  Product: '<S289>/Divide'
     *  Sum: '<S289>/Add'
     */
    controlMCUSlugsMKII_B.DataTypeConversion_c = (real32_T)((real_T)
      controlMCUSlugsMKII_B.ChoosetheMediannavSupportc3 *
      1.2648319566552186E-004 + -9.5530950783373414E-001);

    /* S-Function "dsPIC_C_function_Call" Block: <S279>/Set Current Height and Airspeed as Commands [navSupport.c] */
    setCurrentCommands(controlMCUSlugsMKII_B.IntegerDelay);
  }

  /* end of Outputs for SubSystem: '<S6>/Grab I.C.' */
  /* S-Function "dsPIC_C_function_Call" Block: <Root>/Get XYZ [navSupport.c] */
  getXYZ(&controlMCUSlugsMKII_B.GetXYZnavSupportc[0]);

  /* Switch: '<S17>/Switch3' incorporates:
   *  RelationalOperator: '<S17>/Relational Operator2'
   *  S-Function (sfix_udelay): '<S17>/Integer Delay3'
   */
  if ((controlMCUSlugsMKII_B.GetXYZnavSupportc[2] ==
       controlMCUSlugsMKII_B.GetXYZnavSupportc[2]) > 0) {
    controlMCUSlugsMKII_B.Switch3_ov = controlMCUSlugsMKII_B.GetXYZnavSupportc[2];
  } else {
    controlMCUSlugsMKII_B.Switch3_ov =
      controlMCUSlugsMKII_DWork.IntegerDelay3_X_j5;
  }

  /* Saturate: '<S2>/[-20 20]' */
  rtb_u020 = rt_SATURATE(controlMCUSlugsMKII_B.Switch3_ov, 170.0F, 350.0F);

  /* S-Function "dsPIC_C_function_Call" Block: <S3>/Get Pid according to Index1 */
  getPidIdx(((uint8_T)1U),&controlMCUSlugsMKII_B.GetPidaccordingtoIndex1[0]);

  /* S-Function "dsPIC_C_function_Call" Block: <S9>/[navSupport.c]  */
  getPidIdx(((uint8_T)7U),&controlMCUSlugsMKII_B.navSupportc[0]);

  /* Gain: '<S309>/Unit Conversion' */
  controlMCUSlugsMKII_B.UnitConversion[0] = 1.745329238E-002F *
    controlMCUSlugsMKII_B.navSupportc[0];
  controlMCUSlugsMKII_B.UnitConversion[1] = 1.745329238E-002F *
    controlMCUSlugsMKII_B.navSupportc[1];
  controlMCUSlugsMKII_B.UnitConversion[2] = 1.745329238E-002F *
    controlMCUSlugsMKII_B.navSupportc[2];

  /* S-Function "dsPIC_C_function_Call" Block: <S334>/C Function Call1 */
  controlMCUSlugsMKII_B.CFunctionCall1 = myCos
    (controlMCUSlugsMKII_B.UnitConversion[0]);

  /* S-Function "dsPIC_C_function_Call" Block: <S334>/C Function Call4 */
  controlMCUSlugsMKII_B.CFunctionCall4 = myCos
    (controlMCUSlugsMKII_B.UnitConversion[1]);

  /* S-Function "dsPIC_C_function_Call" Block: <S334>/C Function Call5 */
  controlMCUSlugsMKII_B.CFunctionCall5 = myCos
    (controlMCUSlugsMKII_B.UnitConversion[2]);

  /* Embedded MATLAB: '<S334>/myMux Fun2' */
  controlMCUSlugs_myMuxFun1_o(controlMCUSlugsMKII_B.CFunctionCall1,
    controlMCUSlugsMKII_B.CFunctionCall4, controlMCUSlugsMKII_B.CFunctionCall5,
    &controlMCUSlugsMKII_B.sf_myMuxFun2);

  /* Product: '<S324>/u(5)*u(6)' */
  rtb_u5u6 = controlMCUSlugsMKII_B.sf_myMuxFun2.y[1] *
    controlMCUSlugsMKII_B.sf_myMuxFun2.y[2];

  /* S-Function "dsPIC_C_function_Call" Block: <S334>/C Function Call */
  controlMCUSlugsMKII_B.CFunctionCall = mySin
    (controlMCUSlugsMKII_B.UnitConversion[0]);

  /* S-Function "dsPIC_C_function_Call" Block: <S334>/C Function Call2 */
  controlMCUSlugsMKII_B.CFunctionCall2 = mySin
    (controlMCUSlugsMKII_B.UnitConversion[1]);

  /* S-Function "dsPIC_C_function_Call" Block: <S334>/C Function Call3 */
  controlMCUSlugsMKII_B.CFunctionCall3 = mySin
    (controlMCUSlugsMKII_B.UnitConversion[2]);

  /* Embedded MATLAB: '<S334>/myMux Fun1' */
  controlMCUSlugs_myMuxFun1_o(controlMCUSlugsMKII_B.CFunctionCall,
    controlMCUSlugsMKII_B.CFunctionCall2, controlMCUSlugsMKII_B.CFunctionCall3,
    &controlMCUSlugsMKII_B.sf_myMuxFun1);

  /* Sum: '<S327>/Sum' incorporates:
   *  Product: '<S327>/u(3)*u(4)'
   *  Product: '<S327>/u(6)*u(1)*u(2)'
   */
  rtb_Sum = controlMCUSlugsMKII_B.sf_myMuxFun2.y[2] *
    controlMCUSlugsMKII_B.sf_myMuxFun1.y[0] *
    controlMCUSlugsMKII_B.sf_myMuxFun1.y[1] -
    controlMCUSlugsMKII_B.sf_myMuxFun1.y[2] *
    controlMCUSlugsMKII_B.sf_myMuxFun2.y[0];

  /* Sum: '<S330>/Sum' incorporates:
   *  Product: '<S330>/u(1)*u(3)'
   *  Product: '<S330>/u(2)*u(4)*u(6)'
   */
  rtb_Sum_o = controlMCUSlugsMKII_B.sf_myMuxFun1.y[1] *
    controlMCUSlugsMKII_B.sf_myMuxFun2.y[0] *
    controlMCUSlugsMKII_B.sf_myMuxFun2.y[2] +
    controlMCUSlugsMKII_B.sf_myMuxFun1.y[0] *
    controlMCUSlugsMKII_B.sf_myMuxFun1.y[2];

  /* Product: '<S325>/u(3)*u(5)' */
  rtb_u3u5 = controlMCUSlugsMKII_B.sf_myMuxFun1.y[2] *
    controlMCUSlugsMKII_B.sf_myMuxFun2.y[1];

  /* Sum: '<S328>/Sum' incorporates:
   *  Product: '<S328>/u(1)*u(2)*u(3)'
   *  Product: '<S328>/u(4)*u(6)'
   */
  rtb_Sum_oz = controlMCUSlugsMKII_B.sf_myMuxFun1.y[0] *
    controlMCUSlugsMKII_B.sf_myMuxFun1.y[1] *
    controlMCUSlugsMKII_B.sf_myMuxFun1.y[2] +
    controlMCUSlugsMKII_B.sf_myMuxFun2.y[0] *
    controlMCUSlugsMKII_B.sf_myMuxFun2.y[2];

  /* Sum: '<S331>/Sum' incorporates:
   *  Product: '<S331>/u(1)*u(6)'
   *  Product: '<S331>/u(2)*u(3)*u(4)'
   */
  rtb_Sum_m = controlMCUSlugsMKII_B.sf_myMuxFun1.y[1] *
    controlMCUSlugsMKII_B.sf_myMuxFun1.y[2] *
    controlMCUSlugsMKII_B.sf_myMuxFun2.y[0] -
    controlMCUSlugsMKII_B.sf_myMuxFun2.y[2] *
    controlMCUSlugsMKII_B.sf_myMuxFun1.y[0];

  /* Gain: '<S326>/Gain2' */
  rtb_Gain2 = -1.0F * controlMCUSlugsMKII_B.sf_myMuxFun1.y[1];

  /* Product: '<S329>/u(1)*u(3)' */
  rtb_u1u3_g = controlMCUSlugsMKII_B.sf_myMuxFun1.y[0] *
    controlMCUSlugsMKII_B.sf_myMuxFun2.y[1];

  /* Product: '<S332>/u(4)*u(5)' */
  rtb_u4u5 = controlMCUSlugsMKII_B.sf_myMuxFun2.y[0] *
    controlMCUSlugsMKII_B.sf_myMuxFun2.y[1];

  /* Embedded MATLAB: '<S333>/myMux Fun1' */
  controlMCUSlugs_myMuxFun1_n(rtb_u5u6, rtb_Sum, rtb_Sum_o, rtb_u3u5, rtb_Sum_oz,
    rtb_Sum_m, rtb_Gain2, rtb_u1u3_g, rtb_u4u5,
    &controlMCUSlugsMKII_B.sf_myMuxFun1_n);

  /* Math: '<S9>/Math Function' */
  for (rtb_IC1 = 0; rtb_IC1 < 3; rtb_IC1++) {
    rtb_MathFunction[3 * rtb_IC1] =
      controlMCUSlugsMKII_B.sf_myMuxFun1_n.y[rtb_IC1];
    rtb_MathFunction[1 + 3 * rtb_IC1] =
      controlMCUSlugsMKII_B.sf_myMuxFun1_n.y[rtb_IC1 + 3];
    rtb_MathFunction[2 + 3 * rtb_IC1] =
      controlMCUSlugsMKII_B.sf_myMuxFun1_n.y[rtb_IC1 + 6];
  }

  /* S-Function "dsPIC_C_function_Call" Block: <S9>/Get Attitude [navSupport.c] */
  getAttitude(&controlMCUSlugsMKII_B.GetAttitudenavSupportc[0]);

  /* S-Function "dsPIC_C_function_Call" Block: <S351>/C Function Call1 */
  controlMCUSlugsMKII_B.CFunctionCall1_g = myCos
    (controlMCUSlugsMKII_B.GetAttitudenavSupportc[0]);

  /* S-Function "dsPIC_C_function_Call" Block: <S351>/C Function Call4 */
  controlMCUSlugsMKII_B.CFunctionCall4_a = myCos
    (controlMCUSlugsMKII_B.GetAttitudenavSupportc[1]);

  /* S-Function "dsPIC_C_function_Call" Block: <S351>/C Function Call5 */
  controlMCUSlugsMKII_B.CFunctionCall5_d = myCos
    (controlMCUSlugsMKII_B.GetAttitudenavSupportc[2]);

  /* Embedded MATLAB: '<S351>/myMux Fun2' */
  controlMCUSlugs_myMuxFun1_o(controlMCUSlugsMKII_B.CFunctionCall1_g,
    controlMCUSlugsMKII_B.CFunctionCall4_a,
    controlMCUSlugsMKII_B.CFunctionCall5_d,
    &controlMCUSlugsMKII_B.sf_myMuxFun2_c);

  /* Product: '<S341>/u(5)*u(6)' */
  rtb_u5u6_l = controlMCUSlugsMKII_B.sf_myMuxFun2_c.y[1] *
    controlMCUSlugsMKII_B.sf_myMuxFun2_c.y[2];

  /* S-Function "dsPIC_C_function_Call" Block: <S351>/C Function Call */
  controlMCUSlugsMKII_B.CFunctionCall_i = mySin
    (controlMCUSlugsMKII_B.GetAttitudenavSupportc[0]);

  /* S-Function "dsPIC_C_function_Call" Block: <S351>/C Function Call2 */
  controlMCUSlugsMKII_B.CFunctionCall2_e = mySin
    (controlMCUSlugsMKII_B.GetAttitudenavSupportc[1]);

  /* S-Function "dsPIC_C_function_Call" Block: <S351>/C Function Call3 */
  controlMCUSlugsMKII_B.CFunctionCall3_i = mySin
    (controlMCUSlugsMKII_B.GetAttitudenavSupportc[2]);

  /* Embedded MATLAB: '<S351>/myMux Fun1' */
  controlMCUSlugs_myMuxFun1_o(controlMCUSlugsMKII_B.CFunctionCall_i,
    controlMCUSlugsMKII_B.CFunctionCall2_e,
    controlMCUSlugsMKII_B.CFunctionCall3_i,
    &controlMCUSlugsMKII_B.sf_myMuxFun1_a);

  /* Sum: '<S344>/Sum' incorporates:
   *  Product: '<S344>/u(3)*u(4)'
   *  Product: '<S344>/u(6)*u(1)*u(2)'
   */
  rtb_Sum_od = controlMCUSlugsMKII_B.sf_myMuxFun2_c.y[2] *
    controlMCUSlugsMKII_B.sf_myMuxFun1_a.y[0] *
    controlMCUSlugsMKII_B.sf_myMuxFun1_a.y[1] -
    controlMCUSlugsMKII_B.sf_myMuxFun1_a.y[2] *
    controlMCUSlugsMKII_B.sf_myMuxFun2_c.y[0];

  /* Sum: '<S347>/Sum' incorporates:
   *  Product: '<S347>/u(1)*u(3)'
   *  Product: '<S347>/u(2)*u(4)*u(6)'
   */
  rtb_Sum_i = controlMCUSlugsMKII_B.sf_myMuxFun1_a.y[1] *
    controlMCUSlugsMKII_B.sf_myMuxFun2_c.y[0] *
    controlMCUSlugsMKII_B.sf_myMuxFun2_c.y[2] +
    controlMCUSlugsMKII_B.sf_myMuxFun1_a.y[0] *
    controlMCUSlugsMKII_B.sf_myMuxFun1_a.y[2];

  /* Product: '<S342>/u(3)*u(5)' */
  rtb_u3u5_b = controlMCUSlugsMKII_B.sf_myMuxFun1_a.y[2] *
    controlMCUSlugsMKII_B.sf_myMuxFun2_c.y[1];

  /* Sum: '<S345>/Sum' incorporates:
   *  Product: '<S345>/u(1)*u(2)*u(3)'
   *  Product: '<S345>/u(4)*u(6)'
   */
  rtb_Sum_p = controlMCUSlugsMKII_B.sf_myMuxFun1_a.y[0] *
    controlMCUSlugsMKII_B.sf_myMuxFun1_a.y[1] *
    controlMCUSlugsMKII_B.sf_myMuxFun1_a.y[2] +
    controlMCUSlugsMKII_B.sf_myMuxFun2_c.y[0] *
    controlMCUSlugsMKII_B.sf_myMuxFun2_c.y[2];

  /* Sum: '<S348>/Sum' incorporates:
   *  Product: '<S348>/u(1)*u(6)'
   *  Product: '<S348>/u(2)*u(3)*u(4)'
   */
  rtb_Sum_pu = controlMCUSlugsMKII_B.sf_myMuxFun1_a.y[1] *
    controlMCUSlugsMKII_B.sf_myMuxFun1_a.y[2] *
    controlMCUSlugsMKII_B.sf_myMuxFun2_c.y[0] -
    controlMCUSlugsMKII_B.sf_myMuxFun2_c.y[2] *
    controlMCUSlugsMKII_B.sf_myMuxFun1_a.y[0];

  /* Gain: '<S343>/Gain2' */
  rtb_Gain2_m = -1.0F * controlMCUSlugsMKII_B.sf_myMuxFun1_a.y[1];

  /* Product: '<S346>/u(1)*u(3)' */
  rtb_u1u3_l = controlMCUSlugsMKII_B.sf_myMuxFun1_a.y[0] *
    controlMCUSlugsMKII_B.sf_myMuxFun2_c.y[1];

  /* Product: '<S349>/u(4)*u(5)' */
  rtb_u4u5_a = controlMCUSlugsMKII_B.sf_myMuxFun2_c.y[0] *
    controlMCUSlugsMKII_B.sf_myMuxFun2_c.y[1];

  /* Embedded MATLAB: '<S350>/myMux Fun1' */
  controlMCUSlugs_myMuxFun1_n(rtb_u5u6_l, rtb_Sum_od, rtb_Sum_i, rtb_u3u5_b,
    rtb_Sum_p, rtb_Sum_pu, rtb_Gain2_m, rtb_u1u3_l, rtb_u4u5_a,
    &controlMCUSlugsMKII_B.sf_myMuxFun1_m);

  /* Product: '<S9>/Product' */
  for (rtb_IC1 = 0; rtb_IC1 < 3; rtb_IC1++) {
    for (tmp = 0; tmp < 3; tmp++) {
      controlMCUSlugsMKII_B.Product[rtb_IC1 + 3 * tmp] = 0.0F;
      controlMCUSlugsMKII_B.Product[rtb_IC1 + 3 * tmp] =
        controlMCUSlugsMKII_B.Product[3 * tmp + rtb_IC1] +
        controlMCUSlugsMKII_B.sf_myMuxFun1_m.y[3 * tmp] *
        rtb_MathFunction[rtb_IC1];
      controlMCUSlugsMKII_B.Product[rtb_IC1 + 3 * tmp] =
        controlMCUSlugsMKII_B.sf_myMuxFun1_m.y[3 * tmp + 1] *
        rtb_MathFunction[rtb_IC1 + 3] + controlMCUSlugsMKII_B.Product[3 * tmp +
        rtb_IC1];
      controlMCUSlugsMKII_B.Product[rtb_IC1 + 3 * tmp] =
        controlMCUSlugsMKII_B.sf_myMuxFun1_m.y[3 * tmp + 2] *
        rtb_MathFunction[rtb_IC1 + 6] + controlMCUSlugsMKII_B.Product[3 * tmp +
        rtb_IC1];
    }
  }

  /* S-Function "dsPIC_C_function_Call" Block: <S317>/C Function Call */
  controlMCUSlugsMKII_B.CFunctionCall_i0 = myAtan2
    (controlMCUSlugsMKII_B.Product[7],controlMCUSlugsMKII_B.Product[8]);

  /* Gain: '<S323>/Gain2' */
  rtb_Abs2 = -1.0F * controlMCUSlugsMKII_B.Product[6];

  /* Saturate: '<S318>/[-1,1]' */
  controlMCUSlugsMKII_B.u1 = rt_SATURATE(rtb_Abs2, -9.990000129E-001F,
    9.998999834E-001F);

  /* S-Function "dsPIC_C_function_Call" Block: <S318>/C Function Call */
  controlMCUSlugsMKII_B.CFunctionCall_c = myAsin(controlMCUSlugsMKII_B.u1);

  /* S-Function "dsPIC_C_function_Call" Block: <S316>/C Function Call */
  controlMCUSlugsMKII_B.CFunctionCall_c5 = myAtan2
    (controlMCUSlugsMKII_B.Product[3],controlMCUSlugsMKII_B.Product[0]);

  /* Embedded MATLAB: '<S9>/Embedded MATLAB Function' */
  /* Embedded MATLAB Function 'get Nav Vars/Embedded MATLAB Function': '<S311>:1' */
  /*  This block supports an embeddable subset of the MATLAB language. */
  /*  See the help menu for details.  */
  if ((real_T)controlMCUSlugsMKII_B.CFunctionCall_c5 < 0.0) {
    /* '<S311>:1:5' */
    /* '<S311>:1:6' */
    rtb_y_d = controlMCUSlugsMKII_B.CFunctionCall_c5 + 6.283185482E+000F;
  } else {
    /* '<S311>:1:8' */
    rtb_y_d = controlMCUSlugsMKII_B.CFunctionCall_c5;
  }

  /* Embedded MATLAB: '<S9>/myMux Fun1' */
  controlMCUSlugs_myMuxFun1_o(controlMCUSlugsMKII_B.CFunctionCall_i0,
    controlMCUSlugsMKII_B.CFunctionCall_c, rtb_y_d,
    &controlMCUSlugsMKII_B.sf_myMuxFun1_e);

  /* Embedded MATLAB: '<S9>/myMux Fun2' */
  /* Embedded MATLAB Function 'get Nav Vars/myMux Fun2': '<S315>:1' */
  /*  This block supports an embeddable subset of the MATLAB language. */
  /*  See the help menu for details.  */
  /* '<S315>:1:5' */
  for (rtb_IC1 = 0; rtb_IC1 < 3; rtb_IC1++) {
    /* Product: '<S9>/Product1' */
    controlMCUSlugsMKII_B.Product1[rtb_IC1] = 0.0F;
    controlMCUSlugsMKII_B.Product1[rtb_IC1] = rtb_MathFunction[rtb_IC1] *
      controlMCUSlugsMKII_B.GetAttitudenavSupportc[3] +
      controlMCUSlugsMKII_B.Product1[rtb_IC1];
    controlMCUSlugsMKII_B.Product1[rtb_IC1] = rtb_MathFunction[rtb_IC1 + 3] *
      controlMCUSlugsMKII_B.GetAttitudenavSupportc[4] +
      controlMCUSlugsMKII_B.Product1[rtb_IC1];
    controlMCUSlugsMKII_B.Product1[rtb_IC1] = rtb_MathFunction[rtb_IC1 + 6] *
      controlMCUSlugsMKII_B.GetAttitudenavSupportc[5] +
      controlMCUSlugsMKII_B.Product1[rtb_IC1];
    controlMCUSlugsMKII_B.y[rtb_IC1] =
      controlMCUSlugsMKII_B.sf_myMuxFun1_e.y[rtb_IC1];
  }

  controlMCUSlugsMKII_B.y[3] = controlMCUSlugsMKII_B.Product1[0];
  controlMCUSlugsMKII_B.y[4] = controlMCUSlugsMKII_B.Product1[1];
  controlMCUSlugsMKII_B.y[5] = controlMCUSlugsMKII_B.Product1[2];

  /* S-Function "dsPIC_C_function_Call" Block: <S3>/Get Pid according to Index2 */
  getPidIdx(((uint8_T)2U),&controlMCUSlugsMKII_B.GetPidaccordingtoIndex2[0]);

  /* S-Function "dsPIC_C_function_Call" Block: <Root>/wp Fly? [navSupport.c] */
  controlMCUSlugsMKII_B.wpFlynavSupportc = isWpFly();

  /* S-Function "dsPIC_C_function_Call" Block: <Root>/Get Max WP [navSupport.c] */
  controlMCUSlugsMKII_B.GetMaxWPnavSupportc = getMaxWp();

  /* S-Function "dsPIC_C_function_Call" Block: <Root>/Get Vned [navSupport.c] */
  getVned(&controlMCUSlugsMKII_B.GetVnednavSupportc[0]);

  /* S-Function "dsPIC_C_function_Call" Block: <Root>/[navSupport.c] */
  getPidIdx(((uint8_T)5U),&controlMCUSlugsMKII_B.navSupportc_o[0]);

  /* Outputs for atomic SubSystem: '<S2>/Navigation' */

  /* Saturate: '<S260>/[-25 25]' */
  rtb_u525[0] = rt_SATURATE(controlMCUSlugsMKII_B.GetVnednavSupportc[0], -25.0F,
    25.0F);
  rtb_u525[1] = rt_SATURATE(controlMCUSlugsMKII_B.GetVnednavSupportc[1], -25.0F,
    25.0F);
  rtb_u525[2] = rt_SATURATE(controlMCUSlugsMKII_B.GetVnednavSupportc[2], -25.0F,
    25.0F);

  /* Embedded MATLAB: '<S263>/Embedded MATLAB Function' */
  /* Embedded MATLAB Function 'Inner Loop/ Navigation/Navigation/Park, Deyst & How Lat Accel Cmd/GainSchedule L2 and Get Groundspeed/Norm /Square Vx and Vy  Only. Vz is not considered CAREFUL/Embedded MATLAB Function': '<S265>:1' */
  /*  This block supports an embeddable subset of the MATLAB language. */
  /*  See the help menu for details.  */
  /* '<S265>:1:5' */
  rtb_xDoty = rtb_u525[0] * rtb_u525[0] + rtb_u525[1] * rtb_u525[1];

  /* Embedded MATLAB: '<S264>/negprotect' */
  controlMCUSlugsM_negprotect(rtb_xDoty, &controlMCUSlugsMKII_B.sf_negprotect_h);

  /* S-Function "dsPIC_C_function_Call" Block: <S264>/C Function Call */
  controlMCUSlugsMKII_B.CFunctionCall_a = mySqrt
    (controlMCUSlugsMKII_B.sf_negprotect_h.zpVal);

  /* Embedded MATLAB: '<S239>/negprotect1' */
  controlMCUSlugsM_negprotect(controlMCUSlugsMKII_B.CFunctionCall_a,
    &controlMCUSlugsMKII_B.sf_negprotect1);

  /* Switch: '<S261>/Switch3' incorporates:
   *  RelationalOperator: '<S261>/Relational Operator2'
   *  S-Function (sfix_udelay): '<S261>/Integer Delay3'
   */
  if ((controlMCUSlugsMKII_B.sf_negprotect1.zpVal ==
       controlMCUSlugsMKII_B.sf_negprotect1.zpVal) > 0) {
    controlMCUSlugsMKII_B.Switch3_h = controlMCUSlugsMKII_B.sf_negprotect1.zpVal;
  } else {
    controlMCUSlugsMKII_B.Switch3_h =
      controlMCUSlugsMKII_DWork.IntegerDelay3_X_lj;
  }

  /* Saturate: '<S239>/[0 45]' */
  rtb_u45 = rt_SATURATE(controlMCUSlugsMKII_B.Switch3_h, 0.0F, 45.0F);

  /* Product: '<S239>/Divide4' */
  rtb_Divide4_k = controlMCUSlugsMKII_B.navSupportc_o[0] * rtb_u45;

  /* Saturate: '<S237>/[-25 25]' */
  rtb_u525[0] = rt_SATURATE(controlMCUSlugsMKII_B.GetVnednavSupportc[0], -25.0F,
    25.0F);
  rtb_u525[1] = rt_SATURATE(controlMCUSlugsMKII_B.GetVnednavSupportc[1], -25.0F,
    25.0F);
  rtb_u525[2] = rt_SATURATE(controlMCUSlugsMKII_B.GetVnednavSupportc[2], -25.0F,
    25.0F);

  /* S-Function (sfix_udelay): '<S124>/Integer Delay2' */
  rtb_DataTypeConversion = controlMCUSlugsMKII_DWork.IntegerDelay2_X;

  /* S-Function (sfix_udelay): '<S138>/Integer Delay1' */
  rtb_IntegerDelay2_m = controlMCUSlugsMKII_DWork.IntegerDelay1_X_p;

  /* InitialCondition: '<S124>/IC1' incorporates:
   *  DataTypeConversion: '<S124>/Data Type Conversion1'
   */
  if (controlMCUSlugsMKII_DWork.IC1_FirstOutputTime) {
    controlMCUSlugsMKII_DWork.IC1_FirstOutputTime = FALSE;
    rtb_IC1 = 0;
  } else {
    rtb_IC1 = controlMCUSlugsMKII_B.wpFlynavSupportc;
  }

  /* HitCross: '<S138>/Hit  Crossing1' */
  zcEvent = rt_ZCFcn(RISING_ZERO_CROSSING,
                     &controlMCUSlugsM_PrevZCSigState.HitCrossing1_Input_ZCE,
                     ((real_T)rtb_IC1 - 0.3));
  if (controlMCUSlugsMKII_DWork.HitCrossing1_MODE == 0) {
    if (zcEvent != NO_ZCEVENT) {
      controlMCUSlugsMKII_B.HitCrossing1 = !controlMCUSlugsMKII_B.HitCrossing1;
      controlMCUSlugsMKII_DWork.HitCrossing1_MODE = 1;
    } else {
      if (controlMCUSlugsMKII_B.HitCrossing1 && ((real_T)rtb_IC1 != 0.3)) {
        controlMCUSlugsMKII_B.HitCrossing1 = FALSE;
      }
    }
  } else {
    if ((real_T)rtb_IC1 != 0.3) {
      controlMCUSlugsMKII_B.HitCrossing1 = FALSE;
    }

    controlMCUSlugsMKII_DWork.HitCrossing1_MODE = 0;
  }

  /* Sum: '<S138>/Add1' */
  rtb_Add1_i = (uint8_T)((int16_T)rtb_IntegerDelay2_m + (int16_T)
    controlMCUSlugsMKII_B.HitCrossing1);

  /* Embedded MATLAB: '<S124>/Embedded MATLAB Function' incorporates:
   *  Constant: '<Root>/Constant1'
   */
  /* Embedded MATLAB Function 'Inner Loop/ Navigation/Navigation/Compute WP Index/Embedded MATLAB Function': '<S134>:1' */
  /*  Declare static variables */
  /* initialize the static variables */
  if (!controlMCUSlugsMKII_DWork.fromWP_not_empty) {
    /* '<S134>:1:9' */
    /* '<S134>:1:10' */
    controlMCUSlugsMKII_DWork.fromWP = 1U;
    controlMCUSlugsMKII_DWork.fromWP_not_empty = TRUE;

    /* '<S134>:1:11' */
    tmp_2 = (uint16_T)(controlMCUSlugsMKII_DWork.fromWP + 1);
    if (tmp_2 > 255U) {
      controlMCUSlugsMKII_DWork.toWP = MAX_uint8_T;
    } else {
      controlMCUSlugsMKII_DWork.toWP = (uint8_T)tmp_2;
    }

    /*  check if there are more than 2 WPs */
    tmp_2 = (uint16_T)(controlMCUSlugsMKII_DWork.toWP + 1);
    if (tmp_2 > 255U) {
      tmp_3 = MAX_uint8_T;
    } else {
      tmp_3 = (uint8_T)tmp_2;
    }

    if (controlMCUSlugsMKII_B.GetMaxWPnavSupportc > tmp_3) {
      /* '<S134>:1:13' */
      /* '<S134>:1:14' */
      tmp_2 = (uint16_T)(controlMCUSlugsMKII_DWork.toWP + 1);
      if (tmp_2 > 255U) {
        controlMCUSlugsMKII_DWork.totoWP = MAX_uint8_T;
      } else {
        controlMCUSlugsMKII_DWork.totoWP = (uint8_T)tmp_2;
      }
    } else {
      /* '<S134>:1:16' */
      controlMCUSlugsMKII_DWork.totoWP = controlMCUSlugsMKII_DWork.fromWP;
    }
  }

  /* if WP Nav was just enabled */
  if (rtb_Add1_i == 1) {
    /* '<S134>:1:21' */
    /* '<S134>:1:22' */
    controlMCUSlugsMKII_DWork.fromWP = 0U;

    /* '<S134>:1:23' */
    controlMCUSlugsMKII_DWork.toWP = 1U;

    /* '<S134>:1:24' */
    controlMCUSlugsMKII_DWork.totoWP = 2U;
  }

  /*  if there is a change of wp */
  if (rtb_DataTypeConversion == 1.0) {
    /* '<S134>:1:28' */
    /* '<S134>:1:29' */
    controlMCUSlugsMKII_DWork.fromWP = controlMCUSlugsMKII_DWork.toWP;

    /* '<S134>:1:30' */
    controlMCUSlugsMKII_DWork.toWP = controlMCUSlugsMKII_DWork.totoWP;

    /* '<S134>:1:31' */
    tmp_2 = (uint16_T)(controlMCUSlugsMKII_DWork.totoWP + 1);
    if (tmp_2 > 255U) {
      controlMCUSlugsMKII_DWork.totoWP = MAX_uint8_T;
    } else {
      controlMCUSlugsMKII_DWork.totoWP = (uint8_T)tmp_2;
    }

    if (controlMCUSlugsMKII_DWork.totoWP >
        controlMCUSlugsMKII_B.GetMaxWPnavSupportc) {
      /* '<S134>:1:32' */
      /* '<S134>:1:33' */
      controlMCUSlugsMKII_DWork.totoWP = 1U;
    }
  }

  /* '<S134>:1:37' */
  controlMCUSlugsMKII_B.wp0 = controlMCUSlugsMKII_DWork.fromWP;

  /* '<S134>:1:38' */
  controlMCUSlugsMKII_B.wp1 = controlMCUSlugsMKII_DWork.toWP;

  /* '<S134>:1:39' */
  controlMCUSlugsMKII_B.wp2 = controlMCUSlugsMKII_DWork.totoWP;

  /* Outputs for enable SubSystem: '<S124>/Grab IC' incorporates:
   *  EnablePort: '<S136>/Enable'
   */
  if (rtb_Add1_i > 0) {
    /* Inport: '<S136>/UAV Pos' */
    controlMCUSlugsMKII_B.UAVPos[0] = controlMCUSlugsMKII_B.GetXYZnavSupportc[0];
    controlMCUSlugsMKII_B.UAVPos[1] = controlMCUSlugsMKII_B.GetXYZnavSupportc[1];
    controlMCUSlugsMKII_B.UAVPos[2] = controlMCUSlugsMKII_B.GetXYZnavSupportc[2];

    /* S-Function "dsPIC_C_function_Call" Block: <S174>/C Function Call */
    getWP(((uint8_T)11U),&controlMCUSlugsMKII_B.CFunctionCall_aj[0]);

    /* Gain: '<S175>/Deg2R' */
    rtb_cosphi = 1.745329238E-002F * controlMCUSlugsMKII_B.CFunctionCall_aj[0];

    /* Trigonometry: '<S175>/sin(phi)' */
    rtb_sinphi = (real32_T)sin(rtb_cosphi);

    /* Sum: '<S175>/Sum1' incorporates:
     *  Constant: '<S175>/const'
     *  Product: '<S175>/Product1'
     *  Product: '<S175>/sin(phi)^2'
     */
    rtb_Abs2 = 1.0F - rtb_sinphi * rtb_sinphi *
      controlMCUSlugsMKII_ConstB.Sum5_lj;

    /* Fcn: '<S175>/f' */
    if (rtb_Abs2 < 0.0F) {
      rtb_Abs2 = -((real32_T)sqrt(-rtb_Abs2));
    } else {
      rtb_Abs2 = (real32_T)sqrt(rtb_Abs2);
    }

    /* Product: '<S175>/Rh' incorporates:
     *  Constant: '<S175>/Re=equatorial radius'
     */
    rtb_Abs2 = 6.378137E+006F / rtb_Abs2;

    /* Sum: '<S175>/Sum2' */
    rtb_Sum2 = controlMCUSlugsMKII_B.CFunctionCall_aj[2] + rtb_Abs2;

    /* Trigonometry: '<S175>/cos(phi)' */
    rtb_cosphi = (real32_T)cos(rtb_cosphi);

    /* Gain: '<S175>/Deg2R1' */
    rtb_Deg2R1 = 1.745329238E-002F * controlMCUSlugsMKII_B.CFunctionCall_aj[1];

    /* Product: '<S175>/(Rh+h)cos(phi)*cos(lamb)=Xe' incorporates:
     *  Trigonometry: '<S175>/cos(lamb)'
     */
    controlMCUSlugsMKII_B.RhhcosphicoslambXe = rtb_Sum2 * rtb_cosphi * (real32_T)
      cos(rtb_Deg2R1);

    /* Product: '<S175>/(Rh+h)cos(phi)*sin(lamb)=Ye' incorporates:
     *  Trigonometry: '<S175>/sin(lamb)'
     */
    controlMCUSlugsMKII_B.RhhcosphisinlambYe = rtb_Sum2 * rtb_cosphi * (real32_T)
      sin(rtb_Deg2R1);

    /* Product: '<S175>/Ze' incorporates:
     *  Product: '<S175>/Rh(1-e^2)'
     *  Sum: '<S175>/Sum4'
     */
    controlMCUSlugsMKII_B.Ze = (controlMCUSlugsMKII_ConstB.e2_i * rtb_Abs2 +
      controlMCUSlugsMKII_B.CFunctionCall_aj[2]) * rtb_sinphi;
  }

  /* end of Outputs for SubSystem: '<S124>/Grab IC' */

  /* InitialCondition: '<S139>/IC' */
  if (controlMCUSlugsMKII_DWork.IC_FirstOutputTime_i) {
    controlMCUSlugsMKII_DWork.IC_FirstOutputTime_i = FALSE;
    controlMCUSlugsMKII_B.IC = 1.0;
  } else {
    controlMCUSlugsMKII_B.IC = rtb_DataTypeConversion;
  }

  /* Logic: '<S124>/Logical Operator' incorporates:
   *  S-Function (sfix_udelay): '<S139>/Integer Delay2'
   *  Sum: '<S139>/Add'
   */
  rtb_IntegerDelay2_m = ((controlMCUSlugsMKII_DWork.IntegerDelay2_X_l +
    controlMCUSlugsMKII_B.IC != 0.0) || (rtb_Add1_i != 0));

  /* Outputs for enable SubSystem: '<S16>/Get Wps Compute Frenet' incorporates:
   *  EnablePort: '<S125>/Enable'
   */
  if (rtb_IntegerDelay2_m) {
    /* S-Function "dsPIC_C_function_Call" Block: <S208>/C Function Call */
    getWP(controlMCUSlugsMKII_B.wp0,&controlMCUSlugsMKII_B.CFunctionCall_d[0]);

    /* Switch: '<S125>/Switch' incorporates:
     *  Fcn: '<S235>/11'
     *  Fcn: '<S235>/12'
     *  Fcn: '<S235>/13'
     *  Fcn: '<S235>/21'
     *  Fcn: '<S235>/22'
     *  Fcn: '<S235>/23'
     *  Fcn: '<S235>/31'
     *  Fcn: '<S235>/32'
     *  Fcn: '<S235>/33'
     *  Gain: '<S207>/UEN 2 NEU'
     *  Product: '<S232>/Product1'
     *  SignalConversion: '<S232>/TmpSignal ConversionAtProduct1Inport1'
     *  Sum: '<S207>/Sum1'
     */
    if (controlMCUSlugsMKII_B.wp0 > 0) {
      /* Gain: '<S233>/Deg2R' */
      rtb_cosphi = 1.745329238E-002F * controlMCUSlugsMKII_B.CFunctionCall_d[0];

      /* Trigonometry: '<S233>/sin(phi)' */
      rtb_sinphi = (real32_T)sin(rtb_cosphi);

      /* Sum: '<S233>/Sum1' incorporates:
       *  Constant: '<S233>/const'
       *  Product: '<S233>/Product1'
       *  Product: '<S233>/sin(phi)^2'
       */
      rtb_Abs2 = 1.0F - rtb_sinphi * rtb_sinphi *
        controlMCUSlugsMKII_ConstB.Sum5;

      /* Fcn: '<S233>/f' */
      if (rtb_Abs2 < 0.0F) {
        rtb_Abs2 = -((real32_T)sqrt(-rtb_Abs2));
      } else {
        rtb_Abs2 = (real32_T)sqrt(rtb_Abs2);
      }

      /* Product: '<S233>/Rh' incorporates:
       *  Constant: '<S233>/Re=equatorial radius'
       */
      rtb_Abs2 = 6.378137E+006F / rtb_Abs2;

      /* Product: '<S233>/Ze' incorporates:
       *  Product: '<S233>/Rh(1-e^2)'
       *  Sum: '<S233>/Sum4'
       */
      rtb_sinphi *= controlMCUSlugsMKII_ConstB.e2 * rtb_Abs2 +
        controlMCUSlugsMKII_B.CFunctionCall_d[2];

      /* Gain: '<S233>/Deg2R1' */
      rtb_Sum2 = 1.745329238E-002F * controlMCUSlugsMKII_B.CFunctionCall_d[1];

      /* Trigonometry: '<S233>/cos(phi)' */
      rtb_cosphi = (real32_T)cos(rtb_cosphi);

      /* Sum: '<S233>/Sum2' */
      rtb_Abs2 += controlMCUSlugsMKII_B.CFunctionCall_d[2];

      /* Product: '<S233>/(Rh+h)cos(phi)*sin(lamb)=Ye' incorporates:
       *  Trigonometry: '<S233>/sin(lamb)'
       */
      rtb_Deg2R1 = rtb_Abs2 * rtb_cosphi * (real32_T)sin(rtb_Sum2);

      /* Product: '<S233>/(Rh+h)cos(phi)*cos(lamb)=Xe' incorporates:
       *  Trigonometry: '<S233>/cos(lamb)'
       */
      rtb_Abs2 = rtb_Abs2 * rtb_cosphi * (real32_T)cos(rtb_Sum2);

      /* Gain: '<S232>/Deg2R' */
      rtb_Deg2R_o_idx = 1.745329238E-002F *
        controlMCUSlugsMKII_B.CFunctionCall_aj[1];
      rtb_Deg2R_o_idx_0 = 1.745329238E-002F *
        controlMCUSlugsMKII_B.CFunctionCall_aj[0];
      tmp_0[0L] = (real32_T)cos(rtb_Deg2R_o_idx) * (real32_T)cos
        (rtb_Deg2R_o_idx_0);
      tmp_0[1L] = -((real32_T)sin(rtb_Deg2R_o_idx));
      tmp_0[2L] = (-((real32_T)sin(rtb_Deg2R_o_idx_0))) * (real32_T)cos
        (rtb_Deg2R_o_idx);
      tmp_0[3L] = (real32_T)sin(rtb_Deg2R_o_idx) * (real32_T)cos
        (rtb_Deg2R_o_idx_0);
      tmp_0[4L] = (real32_T)cos(rtb_Deg2R_o_idx);
      tmp_0[5L] = (-((real32_T)sin(rtb_Deg2R_o_idx))) * (real32_T)sin
        (rtb_Deg2R_o_idx_0);
      tmp_0[6L] = (real32_T)sin(rtb_Deg2R_o_idx_0);
      tmp_0[7L] = 0.0F;
      tmp_0[8L] = (real32_T)cos(rtb_Deg2R_o_idx_0);
      rtb_Deg2R_o_idx_0 = rtb_Abs2 - controlMCUSlugsMKII_B.RhhcosphicoslambXe;
      rtb_Deg2R_o_idx = rtb_Deg2R1 - controlMCUSlugsMKII_B.RhhcosphisinlambYe;
      rtb_cosphi = rtb_sinphi - controlMCUSlugsMKII_B.Ze;
      for (rtb_IC1 = 0; rtb_IC1 < 3; rtb_IC1++) {
        tmp_1[rtb_IC1] = tmp_0[rtb_IC1 + 6] * rtb_cosphi + (tmp_0[rtb_IC1 + 3] *
          rtb_Deg2R_o_idx + tmp_0[rtb_IC1] * rtb_Deg2R_o_idx_0);
      }

      for (rtb_IC1 = 0; rtb_IC1 < 3; rtb_IC1++) {
        controlMCUSlugsMKII_B.Switch[rtb_IC1] = 0.0F;
        controlMCUSlugsMKII_B.Switch[rtb_IC1] =
          controlMCUSlugsMKII_ConstP.pooled49[rtb_IC1] * tmp_1[0] +
          controlMCUSlugsMKII_B.Switch[rtb_IC1];
        controlMCUSlugsMKII_B.Switch[rtb_IC1] =
          controlMCUSlugsMKII_ConstP.pooled49[rtb_IC1 + 3] * tmp_1[1] +
          controlMCUSlugsMKII_B.Switch[rtb_IC1];
        controlMCUSlugsMKII_B.Switch[rtb_IC1] =
          controlMCUSlugsMKII_ConstP.pooled49[rtb_IC1 + 6] * tmp_1[2] +
          controlMCUSlugsMKII_B.Switch[rtb_IC1];
      }
    } else {
      controlMCUSlugsMKII_B.Switch[0] = controlMCUSlugsMKII_B.UAVPos[0];
      controlMCUSlugsMKII_B.Switch[1] = controlMCUSlugsMKII_B.UAVPos[1];
      controlMCUSlugsMKII_B.Switch[2] = controlMCUSlugsMKII_B.UAVPos[2];
    }

    /* Gain: '<S227>/Deg2R' */
    rtb_Deg2R_o_idx = 1.745329238E-002F *
      controlMCUSlugsMKII_B.CFunctionCall_aj[1];
    rtb_Deg2R_o_idx_0 = 1.745329238E-002F *
      controlMCUSlugsMKII_B.CFunctionCall_aj[0];

    /* S-Function "dsPIC_C_function_Call" Block: <S209>/C Function Call */
    getWP(controlMCUSlugsMKII_B.wp1,&controlMCUSlugsMKII_B.CFunctionCall_a1[0]);

    /* Gain: '<S228>/Deg2R' */
    rtb_sinphi = 1.745329238E-002F * controlMCUSlugsMKII_B.CFunctionCall_a1[0];

    /* Trigonometry: '<S228>/sin(phi)' */
    rtb_Ze = (real32_T)sin(rtb_sinphi);

    /* Sum: '<S228>/Sum1' incorporates:
     *  Constant: '<S228>/const'
     *  Product: '<S228>/Product1'
     *  Product: '<S228>/sin(phi)^2'
     */
    rtb_Abs2 = 1.0F - rtb_Ze * rtb_Ze * controlMCUSlugsMKII_ConstB.Sum5_l;

    /* Fcn: '<S228>/f' */
    if (rtb_Abs2 < 0.0F) {
      rtb_Abs2 = -((real32_T)sqrt(-rtb_Abs2));
    } else {
      rtb_Abs2 = (real32_T)sqrt(rtb_Abs2);
    }

    /* Product: '<S228>/Rh' incorporates:
     *  Constant: '<S228>/Re=equatorial radius'
     */
    rtb_Abs2 = 6.378137E+006F / rtb_Abs2;

    /* Sum: '<S228>/Sum2' */
    rtb_Sum2 = controlMCUSlugsMKII_B.CFunctionCall_a1[2] + rtb_Abs2;

    /* Trigonometry: '<S228>/cos(phi)' */
    rtb_sinphi = (real32_T)cos(rtb_sinphi);

    /* Gain: '<S228>/Deg2R1' */
    rtb_Deg2R1 = 1.745329238E-002F * controlMCUSlugsMKII_B.CFunctionCall_a1[1];

    /* Product: '<S228>/(Rh+h)cos(phi)*cos(lamb)=Xe' incorporates:
     *  Trigonometry: '<S228>/cos(lamb)'
     */
    rtb_cosphi = rtb_Sum2 * rtb_sinphi * (real32_T)cos(rtb_Deg2R1);

    /* Product: '<S228>/(Rh+h)cos(phi)*sin(lamb)=Ye' incorporates:
     *  Trigonometry: '<S228>/sin(lamb)'
     */
    rtb_Sum2 = rtb_Sum2 * rtb_sinphi * (real32_T)sin(rtb_Deg2R1);

    /* Product: '<S228>/Ze' incorporates:
     *  Product: '<S228>/Rh(1-e^2)'
     *  Sum: '<S228>/Sum4'
     */
    rtb_Ze *= controlMCUSlugsMKII_ConstB.e2_c * rtb_Abs2 +
      controlMCUSlugsMKII_B.CFunctionCall_a1[2];

    /* Reshape: '<S206>/Reshape1' incorporates:
     *  Fcn: '<S230>/11'
     *  Fcn: '<S230>/12'
     *  Fcn: '<S230>/13'
     *  Fcn: '<S230>/21'
     *  Fcn: '<S230>/22'
     *  Fcn: '<S230>/23'
     *  Fcn: '<S230>/31'
     *  Fcn: '<S230>/32'
     *  Fcn: '<S230>/33'
     *  Gain: '<S206>/UEN 2 NEU'
     *  Product: '<S227>/Product1'
     *  SignalConversion: '<S227>/TmpSignal ConversionAtProduct1Inport1'
     *  Sum: '<S206>/Sum1'
     */
    tmp_0[0L] = (real32_T)cos(rtb_Deg2R_o_idx) * (real32_T)cos(rtb_Deg2R_o_idx_0);
    tmp_0[1L] = -((real32_T)sin(rtb_Deg2R_o_idx));
    tmp_0[2L] = (-((real32_T)sin(rtb_Deg2R_o_idx_0))) * (real32_T)cos
      (rtb_Deg2R_o_idx);
    tmp_0[3L] = (real32_T)sin(rtb_Deg2R_o_idx) * (real32_T)cos(rtb_Deg2R_o_idx_0);
    tmp_0[4L] = (real32_T)cos(rtb_Deg2R_o_idx);
    tmp_0[5L] = (-((real32_T)sin(rtb_Deg2R_o_idx))) * (real32_T)sin
      (rtb_Deg2R_o_idx_0);
    tmp_0[6L] = (real32_T)sin(rtb_Deg2R_o_idx_0);
    tmp_0[7L] = 0.0F;
    tmp_0[8L] = (real32_T)cos(rtb_Deg2R_o_idx_0);
    rtb_Deg2R_o_idx_0 = rtb_cosphi - controlMCUSlugsMKII_B.RhhcosphicoslambXe;
    rtb_Deg2R_o_idx = rtb_Sum2 - controlMCUSlugsMKII_B.RhhcosphisinlambYe;
    rtb_cosphi = rtb_Ze - controlMCUSlugsMKII_B.Ze;
    for (rtb_IC1 = 0; rtb_IC1 < 3; rtb_IC1++) {
      tmp_1[rtb_IC1] = tmp_0[rtb_IC1 + 6] * rtb_cosphi + (tmp_0[rtb_IC1 + 3] *
        rtb_Deg2R_o_idx + tmp_0[rtb_IC1] * rtb_Deg2R_o_idx_0);
    }

    for (rtb_IC1 = 0; rtb_IC1 < 3; rtb_IC1++) {
      controlMCUSlugsMKII_B.Reshape1[rtb_IC1] = 0.0F;
      controlMCUSlugsMKII_B.Reshape1[rtb_IC1] =
        controlMCUSlugsMKII_ConstP.pooled49[rtb_IC1] * tmp_1[0] +
        controlMCUSlugsMKII_B.Reshape1[rtb_IC1];
      controlMCUSlugsMKII_B.Reshape1[rtb_IC1] =
        controlMCUSlugsMKII_ConstP.pooled49[rtb_IC1 + 3] * tmp_1[1] +
        controlMCUSlugsMKII_B.Reshape1[rtb_IC1];
      controlMCUSlugsMKII_B.Reshape1[rtb_IC1] =
        controlMCUSlugsMKII_ConstP.pooled49[rtb_IC1 + 6] * tmp_1[2] +
        controlMCUSlugsMKII_B.Reshape1[rtb_IC1];

      /* Sum: '<S205>/Add' */
      rtb_Add_f[rtb_IC1] = controlMCUSlugsMKII_B.Reshape1[rtb_IC1] -
        controlMCUSlugsMKII_B.Switch[rtb_IC1];
    }

    /* Embedded MATLAB: '<S215>/Embedded MATLAB Function' */
    co_EmbeddedMATLABFunction_a(rtb_Add_f,
      &controlMCUSlugsMKII_B.sf_EmbeddedMATLABFunction_hk);

    /* Embedded MATLAB: '<S214>/negprotect' */
    controlMCUSlugsM_negprotect
      (controlMCUSlugsMKII_B.sf_EmbeddedMATLABFunction_hk.xDoty,
       &controlMCUSlugsMKII_B.sf_negprotect_g);

    /* S-Function "dsPIC_C_function_Call" Block: <S214>/C Function Call */
    controlMCUSlugsMKII_B.CFunctionCall_b = mySqrt
      (controlMCUSlugsMKII_B.sf_negprotect_g.zpVal);

    /* Saturate: '<S210>/Zero Bound' */
    rtb_Abs2 = rt_MAXf_snf(controlMCUSlugsMKII_B.CFunctionCall_b,
      1.000000047E-003F);

    /* Product: '<S210>/Divide' */
    controlMCUSlugsMKII_B.Divide_n[0] = rtb_Add_f[0] / rtb_Abs2;
    controlMCUSlugsMKII_B.Divide_n[1] = rtb_Add_f[1] / rtb_Abs2;
    controlMCUSlugsMKII_B.Divide_n[2] = rtb_Add_f[2] / rtb_Abs2;

    /* Embedded MATLAB: '<S205>/Select N  Terms' */
    /* Embedded MATLAB Function 'Navigation/Compute Frenet/Select N  Terms': '<S212>:1' */
    /*  This block supports an embeddable subset of the MATLAB language. */
    /*  See the help menu for details.  */
    /* '<S212>:1:5' */
    rtb_N[0] = -controlMCUSlugsMKII_B.Divide_n[1];
    rtb_N[1] = controlMCUSlugsMKII_B.Divide_n[0];
    rtb_N[2] = 0.0F;

    /* Embedded MATLAB: '<S222>/Embedded MATLAB Function' */
    co_EmbeddedMATLABFunction_a(rtb_N,
      &controlMCUSlugsMKII_B.sf_EmbeddedMATLABFunction_or);

    /* Embedded MATLAB: '<S221>/negprotect' */
    controlMCUSlugsM_negprotect
      (controlMCUSlugsMKII_B.sf_EmbeddedMATLABFunction_or.xDoty,
       &controlMCUSlugsMKII_B.sf_negprotect_bp);

    /* S-Function "dsPIC_C_function_Call" Block: <S221>/C Function Call */
    controlMCUSlugsMKII_B.CFunctionCall_c0 = mySqrt
      (controlMCUSlugsMKII_B.sf_negprotect_bp.zpVal);

    /* Saturate: '<S211>/Zero Bound' */
    rtb_Abs2 = rt_MAXf_snf(controlMCUSlugsMKII_B.CFunctionCall_c0,
      1.000000047E-003F);

    /* Product: '<S211>/Divide' */
    controlMCUSlugsMKII_B.Divide_p[0] = rtb_N[0] / rtb_Abs2;
    controlMCUSlugsMKII_B.Divide_p[1] = rtb_N[1] / rtb_Abs2;
    controlMCUSlugsMKII_B.Divide_p[2] = rtb_N[2] / rtb_Abs2;
  }

  /* end of Outputs for SubSystem: '<S16>/Get Wps Compute Frenet' */

  /* Sum: '<S123>/Add' */
  rtb_Add_id[0] = controlMCUSlugsMKII_B.Reshape1[0] -
    controlMCUSlugsMKII_B.GetXYZnavSupportc[0];
  rtb_Add_id[1] = controlMCUSlugsMKII_B.Reshape1[1] -
    controlMCUSlugsMKII_B.GetXYZnavSupportc[1];
  rtb_Add_id[2] = controlMCUSlugsMKII_B.Reshape1[2] -
    controlMCUSlugsMKII_B.GetXYZnavSupportc[2];

  /* Embedded MATLAB: '<S129>/Embedded MATLAB Function' */
  co_EmbeddedMATLABFunction_m(controlMCUSlugsMKII_B.Divide_p, rtb_Add_id,
    &controlMCUSlugsMKII_B.sf_EmbeddedMATLABFunction_m);

  /* Switch: '<S132>/Switch3' incorporates:
   *  RelationalOperator: '<S132>/Relational Operator2'
   *  S-Function (sfix_udelay): '<S132>/Integer Delay3'
   */
  if ((controlMCUSlugsMKII_B.sf_EmbeddedMATLABFunction_m.xDoty ==
       controlMCUSlugsMKII_B.sf_EmbeddedMATLABFunction_m.xDoty) > 0) {
    controlMCUSlugsMKII_B.Switch3_nn =
      controlMCUSlugsMKII_B.sf_EmbeddedMATLABFunction_m.xDoty;
  } else {
    controlMCUSlugsMKII_B.Switch3_nn =
      controlMCUSlugsMKII_DWork.IntegerDelay3_X_b3;
  }

  /* Gain: '<S238>/Gain' */
  rtb_Abs2 = -controlMCUSlugsMKII_B.Switch3_nn;

  /* Product: '<S238>/Divide2' */
  rtb_Deg2R_o_idx = controlMCUSlugsMKII_B.Divide_p[0] * rtb_Abs2;
  rtb_Deg2R_o_idx_0 = controlMCUSlugsMKII_B.Divide_p[1] * rtb_Abs2;
  rtb_cosphi = controlMCUSlugsMKII_B.Divide_p[2] * rtb_Abs2;

  /* Sum: '<S238>/Add' incorporates:
   *  Product: '<S238>/Divide'
   *  Product: '<S238>/Divide1'
   */
  controlMCUSlugsMKII_B.Add = rtb_Divide4_k * rtb_Divide4_k -
    controlMCUSlugsMKII_B.Switch3_nn * controlMCUSlugsMKII_B.Switch3_nn;

  /* S-Function "dsPIC_C_function_Call" Block: <S256>/C Function Call */
  controlMCUSlugsMKII_B.CFunctionCall_o = myAbs(controlMCUSlugsMKII_B.Add);

  /* Embedded MATLAB: '<S255>/negprotect' */
  controlMCUSlugsM_negprotect(controlMCUSlugsMKII_B.CFunctionCall_o,
    &controlMCUSlugsMKII_B.sf_negprotect_f);

  /* S-Function "dsPIC_C_function_Call" Block: <S255>/C Function Call */
  controlMCUSlugsMKII_B.CFunctionCall_f = mySqrt
    (controlMCUSlugsMKII_B.sf_negprotect_f.zpVal);

  /* Sum: '<S238>/Add2' incorporates:
   *  Product: '<S238>/Divide3'
   */
  controlMCUSlugsMKII_B.L1_vec[0] = controlMCUSlugsMKII_B.Divide_n[0] *
    controlMCUSlugsMKII_B.CFunctionCall_f - rtb_Deg2R_o_idx;
  controlMCUSlugsMKII_B.L1_vec[1] = controlMCUSlugsMKII_B.Divide_n[1] *
    controlMCUSlugsMKII_B.CFunctionCall_f - rtb_Deg2R_o_idx_0;
  controlMCUSlugsMKII_B.L1_vec[2] = controlMCUSlugsMKII_B.Divide_n[2] *
    controlMCUSlugsMKII_B.CFunctionCall_f - rtb_cosphi;

  /* Product: '<S245>/j x k' */
  rtb_Abs2 = rtb_u525[1] * controlMCUSlugsMKII_B.L1_vec[2];

  /* Product: '<S245>/k x i' */
  rtb_Sum2 = rtb_u525[2] * controlMCUSlugsMKII_B.L1_vec[0];

  /* Product: '<S245>/i x j' */
  rtb_Deg2R1 = rtb_u525[0] * controlMCUSlugsMKII_B.L1_vec[1];

  /* Product: '<S246>/k x j' */
  rtb_cosphi = rtb_u525[2] * controlMCUSlugsMKII_B.L1_vec[1];

  /* Product: '<S246>/i x k' */
  rtb_sinphi = rtb_u525[0] * controlMCUSlugsMKII_B.L1_vec[2];

  /* Product: '<S246>/j x i' */
  rtb_Ze = rtb_u525[1] * controlMCUSlugsMKII_B.L1_vec[0];

  /* Embedded MATLAB: '<S248>/Embedded MATLAB Function' */
  co_EmbeddedMATLABFunction_a(controlMCUSlugsMKII_B.L1_vec,
    &controlMCUSlugsMKII_B.sf_EmbeddedMATLABFunction_d);

  /* Embedded MATLAB: '<S247>/negprotect' */
  controlMCUSlugsM_negprotect
    (controlMCUSlugsMKII_B.sf_EmbeddedMATLABFunction_d.xDoty,
     &controlMCUSlugsMKII_B.sf_negprotect_b);

  /* S-Function "dsPIC_C_function_Call" Block: <S247>/C Function Call */
  controlMCUSlugsMKII_B.CFunctionCall_m = mySqrt
    (controlMCUSlugsMKII_B.sf_negprotect_b.zpVal);

  /* Embedded MATLAB: '<S237>/negprotect' */
  controlMCUSlugsM_negprotect(controlMCUSlugsMKII_B.CFunctionCall_m,
    &controlMCUSlugsMKII_B.sf_negprotect_fm);

  /* Product: '<S237>/Divide5' incorporates:
   *  Sum: '<S241>/Sum'
   */
  rtb_u525[0] = (rtb_Abs2 - rtb_cosphi) /
    controlMCUSlugsMKII_B.sf_negprotect_fm.zpVal / rtb_u45;
  rtb_u525[1] = (rtb_Sum2 - rtb_sinphi) /
    controlMCUSlugsMKII_B.sf_negprotect_fm.zpVal / rtb_u45;
  rtb_u525[2] = (rtb_Deg2R1 - rtb_Ze) /
    controlMCUSlugsMKII_B.sf_negprotect_fm.zpVal / rtb_u45;

  /* Switch: '<S254>/Switch3' incorporates:
   *  RelationalOperator: '<S254>/Relational Operator2'
   *  S-Function (sfix_udelay): '<S254>/Integer Delay3'
   */
  if ((rtb_u525[2] == rtb_u525[2]) > 0) {
    controlMCUSlugsMKII_B.Switch3_a = rtb_u525[2];
  } else {
    controlMCUSlugsMKII_B.Switch3_a =
      controlMCUSlugsMKII_DWork.IntegerDelay3_X_g;
  }

  /* Saturate: '<S243>/[-1,1]' */
  controlMCUSlugsMKII_B.u1_h = rt_SATURATE(controlMCUSlugsMKII_B.Switch3_a,
    -9.990000129E-001F, 9.998999834E-001F);

  /* S-Function "dsPIC_C_function_Call" Block: <S243>/C Function Call */
  controlMCUSlugsMKII_B.CFunctionCall_h = myAsin(controlMCUSlugsMKII_B.u1_h);

  /* S-Function "dsPIC_C_function_Call" Block: <S269>/C Function Call */
  controlMCUSlugsMKII_B.CFunctionCall_e = mySin
    (controlMCUSlugsMKII_B.CFunctionCall_h);

  /* Product: '<S240>/Product' incorporates:
   *  Constant: '<S240>/Constant'
   */
  rtb_Ze = (real32_T)((real_T)(rtb_u45 * rtb_u45) * 2.0) / rtb_Divide4_k *
    controlMCUSlugsMKII_B.CFunctionCall_e;

  /* Switch: '<S268>/Switch3' incorporates:
   *  RelationalOperator: '<S268>/Relational Operator2'
   *  S-Function (sfix_udelay): '<S268>/Integer Delay3'
   */
  if ((rtb_Ze == rtb_Ze) > 0) {
    controlMCUSlugsMKII_B.Switch3_m = rtb_Ze;
  } else {
    controlMCUSlugsMKII_B.Switch3_m =
      controlMCUSlugsMKII_DWork.IntegerDelay3_X_f;
  }

  /* Product: '<S126>/Product' incorporates:
   *  Saturate: '<S240>/[-25,25]'
   */
  rtb_Product_c = controlMCUSlugsMKII_B.navSupportc_o[2] * rt_SATURATE
    (controlMCUSlugsMKII_B.Switch3_m, -25.0F, 25.0F);

  /* Embedded MATLAB: '<S16>/myMux Fun1' */
  controlMCUSlugsMK_myMuxFun1(rtb_Product_c, rtb_u45,
    controlMCUSlugsMKII_B.Switch3_nn, &controlMCUSlugsMKII_B.sf_myMuxFun1_o);

  /* S-Function "dsPIC_C_function_Call" Block: <S16>/Set Log Floats 4-6 [navSupport.c] */
  setLogFloat2(controlMCUSlugsMKII_B.sf_myMuxFun1_o.y);

  /* Switch: '<S140>/1st WP' incorporates:
   *  Constant: '<S140>/Switch Distance WP0'
   *  Constant: '<S177>/Constant'
   *  RelationalOperator: '<S177>/Compare'
   *  S-Function (sfix_udelay): '<S124>/Integer Delay3'
   *  S-Function (sfix_udelay): '<S140>/Integer Delay1'
   */
  if ((controlMCUSlugsMKII_DWork.IntegerDelay1_X_fi > 0) > 0) {
    rtb_Sum2 = controlMCUSlugsMKII_DWork.IntegerDelay3_X_a;
  } else {
    rtb_Sum2 = 100.0F;
  }

  /* S-Function (sfix_udelay): '<S180>/Integer Delay1' */
  rtb_Ze = controlMCUSlugsMKII_DWork.IntegerDelay1_X_i;

  /* S-Function (sfix_udelay): '<S180>/Integer Delay2' */
  rtb_sinphi = controlMCUSlugsMKII_DWork.IntegerDelay2_X_e[0];

  /* Sum: '<S196>/Diff' incorporates:
   *  UnitDelay: '<S196>/UD'
   */
  controlMCUSlugsMKII_B.Diff = controlMCUSlugsMKII_B.Switch[0] -
    controlMCUSlugsMKII_DWork.UD_DSTATE;

  /* S-Function "dsPIC_C_function_Call" Block: <S197>/C Function Call */
  controlMCUSlugsMKII_B.CFunctionCall_j = myAbs(controlMCUSlugsMKII_B.Diff);

  /* Saturate: '<S193>/Saturation1' */
  rtb_Abs2 = rt_SATURATE(controlMCUSlugsMKII_B.CFunctionCall_j, 0.0F, 1.0F);

  /* Sum: '<S199>/Diff' incorporates:
   *  UnitDelay: '<S199>/UD'
   */
  controlMCUSlugsMKII_B.Diff_o = controlMCUSlugsMKII_B.Switch[1] -
    controlMCUSlugsMKII_DWork.UD_DSTATE_e;

  /* S-Function "dsPIC_C_function_Call" Block: <S200>/C Function Call */
  controlMCUSlugsMKII_B.CFunctionCall_l = myAbs(controlMCUSlugsMKII_B.Diff_o);

  /* Saturate: '<S194>/Saturation1' */
  rtb_Deg2R1 = rt_SATURATE(controlMCUSlugsMKII_B.CFunctionCall_l, 0.0F, 1.0F);

  /* Sum: '<S202>/Diff' incorporates:
   *  UnitDelay: '<S202>/UD'
   */
  controlMCUSlugsMKII_B.Diff_a = controlMCUSlugsMKII_B.Switch[2] -
    controlMCUSlugsMKII_DWork.UD_DSTATE_h;

  /* S-Function "dsPIC_C_function_Call" Block: <S203>/C Function Call */
  controlMCUSlugsMKII_B.CFunctionCall_ep = myAbs(controlMCUSlugsMKII_B.Diff_a);

  /* Sum: '<S181>/Sum' incorporates:
   *  Saturate: '<S195>/Saturation1'
   */
  rtb_cosphi = (rtb_Abs2 + rtb_Deg2R1) + rt_SATURATE
    (controlMCUSlugsMKII_B.CFunctionCall_ep, 0.0F, 1.0F);

  /* Saturate: '<S181>/Saturation1' */
  rtb_cosphi = rt_SATURATE(rtb_cosphi, 0.0F, 1.0F);

  /* InitialCondition: '<S180>/IC' */
  if (controlMCUSlugsMKII_DWork.IC_FirstOutputTime_b) {
    controlMCUSlugsMKII_DWork.IC_FirstOutputTime_b = FALSE;
    controlMCUSlugsMKII_B.IC_e = 1.0F;
  } else {
    controlMCUSlugsMKII_B.IC_e = rtb_cosphi;
  }

  /* Sum: '<S180>/Add' */
  rtb_Ze = (rtb_Ze + rtb_sinphi) + controlMCUSlugsMKII_B.IC_e;

  /* InitialCondition: '<S140>/IC' */
  if (controlMCUSlugsMKII_DWork.IC_FirstOutputTime_d) {
    controlMCUSlugsMKII_DWork.IC_FirstOutputTime_d = FALSE;
    rtb_Ze = 1.0F;
  }

  /* Outputs for enable SubSystem: '<S140>/Compute Total Run' incorporates:
   *  EnablePort: '<S179>/Enable'
   */
  if (rtb_Ze > 0.0F) {
    /* Sum: '<S185>/Add' */
    rtb_Add_d[0] = controlMCUSlugsMKII_B.Switch[0] -
      controlMCUSlugsMKII_B.Reshape1[0];
    rtb_Add_d[1] = controlMCUSlugsMKII_B.Switch[1] -
      controlMCUSlugsMKII_B.Reshape1[1];
    rtb_Add_d[2] = controlMCUSlugsMKII_B.Switch[2] -
      controlMCUSlugsMKII_B.Reshape1[2];

    /* Embedded MATLAB: '<S189>/Embedded MATLAB Function' */
    co_EmbeddedMATLABFunction_a(rtb_Add_d,
      &controlMCUSlugsMKII_B.sf_EmbeddedMATLABFunction_mg);

    /* Embedded MATLAB: '<S188>/negprotect' */
    controlMCUSlugsM_negprotect
      (controlMCUSlugsMKII_B.sf_EmbeddedMATLABFunction_mg.xDoty,
       &controlMCUSlugsMKII_B.sf_negprotect_l);

    /* S-Function "dsPIC_C_function_Call" Block: <S188>/C Function Call */
    controlMCUSlugsMKII_B.CFunctionCall_fg = mySqrt
      (controlMCUSlugsMKII_B.sf_negprotect_l.zpVal);

    /* Sum: '<S179>/Subtract1' */
    rtb_Abs2 = controlMCUSlugsMKII_B.CFunctionCall_fg - rtb_Sum2;

    /* Switch: '<S186>/Switch3' incorporates:
     *  RelationalOperator: '<S186>/Relational Operator2'
     *  S-Function (sfix_udelay): '<S186>/Integer Delay3'
     */
    if ((rtb_Abs2 == rtb_Abs2) > 0) {
      controlMCUSlugsMKII_B.Switch3_mv = rtb_Abs2;
    } else {
      controlMCUSlugsMKII_B.Switch3_mv =
        controlMCUSlugsMKII_DWork.IntegerDelay3_X_ft;
    }

    /* Update for S-Function (sfix_udelay): '<S186>/Integer Delay3' */
    controlMCUSlugsMKII_DWork.IntegerDelay3_X_ft =
      controlMCUSlugsMKII_B.Switch3_mv;
  }

  /* end of Outputs for SubSystem: '<S140>/Compute Total Run' */

  /* Sum: '<S178>/Subtract' */
  rtb_Subtract[0] = controlMCUSlugsMKII_B.GetXYZnavSupportc[0] -
    controlMCUSlugsMKII_B.Switch[0];
  rtb_Subtract[1] = controlMCUSlugsMKII_B.GetXYZnavSupportc[1] -
    controlMCUSlugsMKII_B.Switch[1];
  rtb_Subtract[2] = controlMCUSlugsMKII_B.GetXYZnavSupportc[2] -
    controlMCUSlugsMKII_B.Switch[2];

  /* Embedded MATLAB: '<S183>/Embedded MATLAB Function' */
  co_EmbeddedMATLABFunction_m(rtb_Subtract, controlMCUSlugsMKII_B.Divide_n,
    &controlMCUSlugsMKII_B.sf_EmbeddedMATLABFunction_n);

  /* Switch: '<S182>/Switch3' incorporates:
   *  RelationalOperator: '<S182>/Relational Operator2'
   *  S-Function (sfix_udelay): '<S182>/Integer Delay3'
   */
  if ((controlMCUSlugsMKII_B.sf_EmbeddedMATLABFunction_n.xDoty ==
       controlMCUSlugsMKII_B.sf_EmbeddedMATLABFunction_n.xDoty) > 0) {
    controlMCUSlugsMKII_B.Switch3 =
      controlMCUSlugsMKII_B.sf_EmbeddedMATLABFunction_n.xDoty;
  } else {
    controlMCUSlugsMKII_B.Switch3 = controlMCUSlugsMKII_DWork.IntegerDelay3_X;
  }

  /* Embedded MATLAB: '<S124>/myMux Fun2' incorporates:
   *  DataTypeConversion: '<S124>/Data Type Conversion'
   *  DataTypeConversion: '<S124>/Data Type Conversion2'
   */
  /* Embedded MATLAB Function 'Inner Loop/ Navigation/Navigation/Compute WP Index/myMux Fun2': '<S141>:1' */
  /*  This block supports an embeddable subset of the MATLAB language. */
  /*  See the help menu for details.  */
  /* '<S141>:1:5' */
  controlMCUSlugsMKII_B.y_e[0] = controlMCUSlugsMKII_B.Switch3_mv;
  controlMCUSlugsMKII_B.y_e[1] = (real32_T)controlMCUSlugsMKII_B.Switch3;
  controlMCUSlugsMKII_B.y_e[2] = (real32_T)controlMCUSlugsMKII_B.wp0;
  controlMCUSlugsMKII_B.y_e[3] = (real32_T)controlMCUSlugsMKII_B.wp1;

  /* S-Function "dsPIC_C_function_Call" Block: <S124>/Set The Nav Vals [navSupport.c] */
  setNavNav(controlMCUSlugsMKII_B.y_e);

  /* Outputs for enable SubSystem: '<S124>/Compute P' incorporates:
   *  EnablePort: '<S133>/Enable'
   */
  if (rtb_IntegerDelay2_m) {
    /* Product: '<S133>/Product1' */
    rtb_Product1_m = controlMCUSlugsMKII_B.navSupportc_o[1] * rtb_u45;

    /* S-Function (sfix_udelay): '<S133>/Integer Delay1' */
    controlMCUSlugsMKII_B.IntegerDelay1[0] =
      controlMCUSlugsMKII_DWork.IntegerDelay1_X_k[0];
    controlMCUSlugsMKII_B.IntegerDelay1[1] =
      controlMCUSlugsMKII_DWork.IntegerDelay1_X_k[1];
    controlMCUSlugsMKII_B.IntegerDelay1[2] =
      controlMCUSlugsMKII_DWork.IntegerDelay1_X_k[2];

    /* S-Function "dsPIC_C_function_Call" Block: <S167>/C Function Call */
    controlMCUSlugsMKII_B.CFunctionCall_l0 = myAtan2
      (controlMCUSlugsMKII_B.IntegerDelay1[1],
       controlMCUSlugsMKII_B.IntegerDelay1[0]);

    /* Sum: '<S143>/Add' incorporates:
     *  S-Function (sfix_udelay): '<S133>/Integer Delay2'
     */
    rtb_Add_k[0] = controlMCUSlugsMKII_DWork.IntegerDelay2_X_e3[0] -
      controlMCUSlugsMKII_B.Reshape1[0];
    rtb_Add_k[1] = controlMCUSlugsMKII_DWork.IntegerDelay2_X_e3[1] -
      controlMCUSlugsMKII_B.Reshape1[1];
    rtb_Add_k[2] = controlMCUSlugsMKII_DWork.IntegerDelay2_X_e3[2] -
      controlMCUSlugsMKII_B.Reshape1[2];

    /* Embedded MATLAB: '<S150>/Embedded MATLAB Function' */
    co_EmbeddedMATLABFunction_a(rtb_Add_k,
      &controlMCUSlugsMKII_B.sf_EmbeddedMATLABFunction_a);

    /* Embedded MATLAB: '<S149>/negprotect' */
    controlMCUSlugsM_negprotect
      (controlMCUSlugsMKII_B.sf_EmbeddedMATLABFunction_a.xDoty,
       &controlMCUSlugsMKII_B.sf_negprotect_e);

    /* S-Function "dsPIC_C_function_Call" Block: <S149>/C Function Call */
    controlMCUSlugsMKII_B.CFunctionCall_mb = mySqrt
      (controlMCUSlugsMKII_B.sf_negprotect_e.zpVal);

    /* Saturate: '<S147>/Zero Bound' */
    rtb_Abs2 = rt_MAXf_snf(controlMCUSlugsMKII_B.CFunctionCall_mb,
      1.000000047E-003F);

    /* Product: '<S147>/Divide' */
    controlMCUSlugsMKII_B.Divide_l[0] = rtb_Add_k[0] / rtb_Abs2;
    controlMCUSlugsMKII_B.Divide_l[1] = rtb_Add_k[1] / rtb_Abs2;
    controlMCUSlugsMKII_B.Divide_l[2] = rtb_Add_k[2] / rtb_Abs2;

    /* S-Function "dsPIC_C_function_Call" Block: <S166>/C Function Call */
    controlMCUSlugsMKII_B.CFunctionCall_ir = myAtan2
      (controlMCUSlugsMKII_B.Divide_l[1],controlMCUSlugsMKII_B.Divide_l[0]);

    /* Sum: '<S161>/Add' */
    rtb_Abs2 = controlMCUSlugsMKII_B.CFunctionCall_l0 -
      controlMCUSlugsMKII_B.CFunctionCall_ir;

    /* Embedded MATLAB: '<S161>/Embedded MATLAB Function1' */
    /* Embedded MATLAB Function 'Inner Loop/ Navigation/Navigation/Compute WP Index/Compute P/Get Circles/Compute CCW Angle From 2 Vectors/Embedded MATLAB Function1': '<S165>:1' */
    if ((real_T)rtb_Abs2 < 0.0) {
      /* '<S165>:1:3' */
      /* '<S165>:1:4' */
      rtb_Abs2 += 6.283185482E+000F;
    } else {
      /* '<S165>:1:6' */
    }

    /* RelationalOperator: '<S145>/Larger than 180?' incorporates:
     *  Constant: '<S145>/Constant5'
     */
    rtb_IntegerDelay2_m = (rtb_Abs2 >= 3.141592741E+000F);

    /* Outputs for enable SubSystem: '<S145>/compute delta Right Turn' incorporates:
     *  EnablePort: '<S164>/Enable'
     */
    if (rtb_IntegerDelay2_m) {
      /* Product: '<S164>/Divide' incorporates:
       *  Constant: '<S164>/Constant1'
       *  Constant: '<S164>/Constant5'
       *  Sum: '<S164>/Add'
       */
      controlMCUSlugsMKII_B.Merge4 = (rtb_Abs2 - 3.141592741E+000F) / 2.0F;
    }

    /* end of Outputs for SubSystem: '<S145>/compute delta Right Turn' */

    /* Outputs for enable SubSystem: '<S145>/Compute delta Left Turn' incorporates:
     *  EnablePort: '<S162>/Enable'
     *  Logic: '<S145>/Logical Operator'
     */
    if (!rtb_IntegerDelay2_m) {
      /* Gain: '<S162>/Gain' incorporates:
       *  Constant: '<S162>/Constant1'
       *  Constant: '<S162>/Constant5'
       *  Product: '<S162>/Divide'
       *  Sum: '<S162>/Add'
       */
      controlMCUSlugsMKII_B.Merge4 = (3.141592741E+000F - rtb_Abs2) / 2.0F *
        -1.0F;
    }

    /* end of Outputs for SubSystem: '<S145>/Compute delta Left Turn' */
    /* S-Function "dsPIC_C_function_Call" Block: <S163>/C Function Call */
    controlMCUSlugsMKII_B.CFunctionCall_hb = mySin(controlMCUSlugsMKII_B.Merge4);

    /* S-Function "dsPIC_C_function_Call" Block: <S163>/C Function Call1 */
    controlMCUSlugsMKII_B.CFunctionCall1_i = myCos(controlMCUSlugsMKII_B.Merge4);

    /* Embedded MATLAB: '<S145>/Compute  Circles' incorporates:
     *  Constant: '<S142>/gravity1'
     *  Product: '<S142>/Product'
     *  Product: '<S142>/Product1'
     */
    /* Embedded MATLAB Function 'Inner Loop/ Navigation/Navigation/Compute WP Index/Compute P/Get Circles/Compute  Circles': '<S160>:1' */
    /*  This block supports an embeddable subset of the MATLAB language. */
    /*  See the help menu for details. */
    /*  rotate the vector delta degrees */
    /* '<S160>:1:6' */
    /* '<S160>:1:7' */
    /* '<S160>:1:8' */
    /* compute M */
    if ((real_T)controlMCUSlugsMKII_B.CFunctionCall_hb < 0.0) {
      /* '<S160>:1:29' */
      /* '<S160>:1:30' */
      rtb_Abs2 = -controlMCUSlugsMKII_B.CFunctionCall_hb;
    } else {
      /* '<S160>:1:32' */
      rtb_Abs2 = controlMCUSlugsMKII_B.CFunctionCall_hb;
    }

    if ((real_T)rtb_Abs2 > 0.01) {
      /* '<S160>:1:11' */
      /* '<S160>:1:12' */
      rtb_Abs2 = controlMCUSlugsMKII_B.GetMidLevelCommandsnavSupportc[0] *
        controlMCUSlugsMKII_B.GetMidLevelCommandsnavSupportc[0] /
        9.814999580E+000F / controlMCUSlugsMKII_B.CFunctionCall_hb;
      if ((real_T)rtb_Abs2 < 0.0) {
        /* '<S160>:1:29' */
        /* '<S160>:1:30' */
        rtb_Abs2 = -rtb_Abs2;
      } else {
        /* '<S160>:1:32' */
      }
    } else {
      /* '<S160>:1:14' */
      rtb_Abs2 = 0.0F;
    }

    /* find the distance from WP */
    /* '<S160>:1:18' */
    rtb_sinphi = rtb_Abs2 * controlMCUSlugsMKII_B.CFunctionCall1_i;

    /*  find the center of the circle */
    /* '<S160>:1:21' */
    /*  find the tangent points */
    /* '<S160>:1:24' */
    /* '<S160>:1:25' */

    /* Gain: '<S155>/Deg2R' */
    rtb_Deg2R_o_idx = 1.745329238E-002F *
      controlMCUSlugsMKII_B.CFunctionCall_aj[1];
    rtb_Deg2R_o_idx_0 = 1.745329238E-002F *
      controlMCUSlugsMKII_B.CFunctionCall_aj[0];

    /* S-Function "dsPIC_C_function_Call" Block: <S146>/C Function Call */
    getWP(controlMCUSlugsMKII_B.wp2,&controlMCUSlugsMKII_B.CFunctionCall_ap[0]);

    /* Gain: '<S156>/Deg2R' */
    rtb_Ze = 1.745329238E-002F * controlMCUSlugsMKII_B.CFunctionCall_ap[0];

    /* Trigonometry: '<S156>/sin(phi)' */
    rtb_Divide4_k = (real32_T)sin(rtb_Ze);

    /* Sum: '<S156>/Sum1' incorporates:
     *  Constant: '<S156>/const'
     *  Product: '<S156>/Product1'
     *  Product: '<S156>/sin(phi)^2'
     */
    rtb_Abs2 = 1.0F - rtb_Divide4_k * rtb_Divide4_k *
      controlMCUSlugsMKII_ConstB.Sum5_c;

    /* Fcn: '<S156>/f' */
    if (rtb_Abs2 < 0.0F) {
      rtb_Abs2 = -((real32_T)sqrt(-rtb_Abs2));
    } else {
      rtb_Abs2 = (real32_T)sqrt(rtb_Abs2);
    }

    /* Product: '<S156>/Rh' incorporates:
     *  Constant: '<S156>/Re=equatorial radius'
     */
    rtb_Abs2 = 6.378137E+006F / rtb_Abs2;

    /* Sum: '<S156>/Sum2' */
    rtb_Sum2 = controlMCUSlugsMKII_B.CFunctionCall_ap[2] + rtb_Abs2;

    /* Trigonometry: '<S156>/cos(phi)' */
    rtb_Ze = (real32_T)cos(rtb_Ze);

    /* Gain: '<S156>/Deg2R1' */
    rtb_Deg2R1 = 1.745329238E-002F * controlMCUSlugsMKII_B.CFunctionCall_ap[1];

    /* Product: '<S156>/(Rh+h)cos(phi)*cos(lamb)=Xe' incorporates:
     *  Trigonometry: '<S156>/cos(lamb)'
     */
    rtb_cosphi = rtb_Sum2 * rtb_Ze * (real32_T)cos(rtb_Deg2R1);

    /* Product: '<S156>/(Rh+h)cos(phi)*sin(lamb)=Ye' incorporates:
     *  Trigonometry: '<S156>/sin(lamb)'
     */
    rtb_Sum2 = rtb_Sum2 * rtb_Ze * (real32_T)sin(rtb_Deg2R1);

    /* Product: '<S156>/Ze' incorporates:
     *  Product: '<S156>/Rh(1-e^2)'
     *  Sum: '<S156>/Sum4'
     */
    rtb_Divide4_k *= controlMCUSlugsMKII_ConstB.e2_f * rtb_Abs2 +
      controlMCUSlugsMKII_B.CFunctionCall_ap[2];

    /* Gain: '<S144>/UEN 2 NEU' incorporates:
     *  Fcn: '<S158>/11'
     *  Fcn: '<S158>/12'
     *  Fcn: '<S158>/13'
     *  Fcn: '<S158>/21'
     *  Fcn: '<S158>/22'
     *  Fcn: '<S158>/23'
     *  Fcn: '<S158>/31'
     *  Fcn: '<S158>/32'
     *  Fcn: '<S158>/33'
     *  Product: '<S155>/Product1'
     *  SignalConversion: '<S155>/TmpSignal ConversionAtProduct1Inport1'
     *  Sum: '<S144>/Sum1'
     */
    tmp_0[0L] = (real32_T)cos(rtb_Deg2R_o_idx) * (real32_T)cos(rtb_Deg2R_o_idx_0);
    tmp_0[1L] = -((real32_T)sin(rtb_Deg2R_o_idx));
    tmp_0[2L] = (-((real32_T)sin(rtb_Deg2R_o_idx_0))) * (real32_T)cos
      (rtb_Deg2R_o_idx);
    tmp_0[3L] = (real32_T)sin(rtb_Deg2R_o_idx) * (real32_T)cos(rtb_Deg2R_o_idx_0);
    tmp_0[4L] = (real32_T)cos(rtb_Deg2R_o_idx);
    tmp_0[5L] = (-((real32_T)sin(rtb_Deg2R_o_idx))) * (real32_T)sin
      (rtb_Deg2R_o_idx_0);
    tmp_0[6L] = (real32_T)sin(rtb_Deg2R_o_idx_0);
    tmp_0[7L] = 0.0F;
    tmp_0[8L] = (real32_T)cos(rtb_Deg2R_o_idx_0);
    rtb_Deg2R_o_idx_0 = rtb_cosphi - controlMCUSlugsMKII_B.RhhcosphicoslambXe;
    rtb_Deg2R_o_idx = rtb_Sum2 - controlMCUSlugsMKII_B.RhhcosphisinlambYe;
    rtb_cosphi = rtb_Divide4_k - controlMCUSlugsMKII_B.Ze;
    for (rtb_IC1 = 0; rtb_IC1 < 3; rtb_IC1++) {
      tmp_1[rtb_IC1] = tmp_0[rtb_IC1 + 6] * rtb_cosphi + (tmp_0[rtb_IC1 + 3] *
        rtb_Deg2R_o_idx + tmp_0[rtb_IC1] * rtb_Deg2R_o_idx_0);
    }

    for (rtb_IC1 = 0; rtb_IC1 < 3; rtb_IC1++) {
      controlMCUSlugsMKII_B.UEN2NEU[rtb_IC1] = 0.0F;
      controlMCUSlugsMKII_B.UEN2NEU[rtb_IC1] =
        controlMCUSlugsMKII_ConstP.pooled49[rtb_IC1] * tmp_1[0] +
        controlMCUSlugsMKII_B.UEN2NEU[rtb_IC1];
      controlMCUSlugsMKII_B.UEN2NEU[rtb_IC1] =
        controlMCUSlugsMKII_ConstP.pooled49[rtb_IC1 + 3] * tmp_1[1] +
        controlMCUSlugsMKII_B.UEN2NEU[rtb_IC1];
      controlMCUSlugsMKII_B.UEN2NEU[rtb_IC1] =
        controlMCUSlugsMKII_ConstP.pooled49[rtb_IC1 + 6] * tmp_1[2] +
        controlMCUSlugsMKII_B.UEN2NEU[rtb_IC1];
    }

    /* InitialCondition: '<S133>/IC' incorporates:
     *  Sum: '<S133>/Add'
     */
    if (controlMCUSlugsMKII_DWork.IC_FirstOutputTime_k) {
      controlMCUSlugsMKII_DWork.IC_FirstOutputTime_k = FALSE;
      controlMCUSlugsMKII_B.IC_l = 50.0F;
    } else {
      controlMCUSlugsMKII_B.IC_l = rtb_Product1_m + rtb_sinphi;
    }

    /* Update for S-Function (sfix_udelay): '<S133>/Integer Delay1' */
    controlMCUSlugsMKII_DWork.IntegerDelay1_X_k[0] =
      controlMCUSlugsMKII_B.Divide_n[0];

    /* Update for S-Function (sfix_udelay): '<S133>/Integer Delay2' */
    controlMCUSlugsMKII_DWork.IntegerDelay2_X_e3[0] =
      controlMCUSlugsMKII_B.UEN2NEU[0];

    /* Update for S-Function (sfix_udelay): '<S133>/Integer Delay1' */
    controlMCUSlugsMKII_DWork.IntegerDelay1_X_k[1] =
      controlMCUSlugsMKII_B.Divide_n[1];

    /* Update for S-Function (sfix_udelay): '<S133>/Integer Delay2' */
    controlMCUSlugsMKII_DWork.IntegerDelay2_X_e3[1] =
      controlMCUSlugsMKII_B.UEN2NEU[1];

    /* Update for S-Function (sfix_udelay): '<S133>/Integer Delay1' */
    controlMCUSlugsMKII_DWork.IntegerDelay1_X_k[2] =
      controlMCUSlugsMKII_B.Divide_n[2];

    /* Update for S-Function (sfix_udelay): '<S133>/Integer Delay2' */
    controlMCUSlugsMKII_DWork.IntegerDelay2_X_e3[2] =
      controlMCUSlugsMKII_B.UEN2NEU[2];
  }

  /* end of Outputs for SubSystem: '<S124>/Compute P' */

  /* RelationalOperator: '<S140>/Switch Distance Less than?' */
  rtb_Add1_i = (controlMCUSlugsMKII_B.Switch3 >= (real_T)
                controlMCUSlugsMKII_B.Switch3_mv);

  /* Embedded MATLAB: '<S124>/Embedded MATLAB Function1' incorporates:
   *  Constant: '<S124>/Switch Time Limit (in Samples)'
   */
  /* Embedded MATLAB Function 'Inner Loop/ Navigation/Navigation/Compute WP Index/Embedded MATLAB Function1': '<S135>:1' */
  /*  Declare static variables */
  /* initialize the static variables */
  /* '<S135>:1:14' */
  controlMCUSlugsMKII_B.swIncrement = 0.0;

  /* if we just had a flip */
  if ((rtb_Add1_i == 1) && (controlMCUSlugsMKII_DWork.oldSw == 0) &&
      (controlMCUSlugsMKII_DWork.internalTimer > 300U)) {
    /* '<S135>:1:17' */
    /*  if enough time has passed that another switch is valid */
    /* '<S135>:1:19' */
    /* '<S135>:1:20' */
    controlMCUSlugsMKII_B.swIncrement = 1.0;

    /* '<S135>:1:21' */
    controlMCUSlugsMKII_DWork.internalTimer = 0U;
  }

  /* '<S135>:1:25' */
  tmp_4 = (uint32_T)((int32_T)controlMCUSlugsMKII_DWork.internalTimer + 1L);
  if ((int32_T)tmp_4 > 65535L) {
    controlMCUSlugsMKII_DWork.internalTimer = MAX_uint16_T;
  } else {
    controlMCUSlugsMKII_DWork.internalTimer = (uint16_T)tmp_4;
  }

  /* '<S135>:1:26' */
  controlMCUSlugsMKII_DWork.oldSw = rtb_Add1_i;

  /* Switch: '<S137>/Switch3' incorporates:
   *  RelationalOperator: '<S137>/Relational Operator2'
   *  S-Function (sfix_udelay): '<S137>/Integer Delay3'
   */
  if ((controlMCUSlugsMKII_B.IC_l == controlMCUSlugsMKII_B.IC_l) > 0) {
    controlMCUSlugsMKII_B.Switch3_e = controlMCUSlugsMKII_B.IC_l;
  } else {
    controlMCUSlugsMKII_B.Switch3_e =
      controlMCUSlugsMKII_DWork.IntegerDelay3_X_n;
  }

  /* S-Function "dsPIC_C_function_Call" Block: <S126>/Set Log Floats 1-3 [navSupport.c] */
  setLogFloat1(controlMCUSlugsMKII_B.L1_vec);

  /* Product: '<S127>/Divide' incorporates:
   *  Constant: '<S16>/Gravity'
   */
  controlMCUSlugsMKII_B.Divide = rtb_Product_c / 9.814999580E+000F;

  /* S-Function (sfix_udelay): '<S271>/Integer Delay3' */
  rtb_Ze = controlMCUSlugsMKII_DWork.IntegerDelay3_X_ch;

  /* S-Function "dsPIC_C_function_Call" Block: <S272>/C Function Call */
  controlMCUSlugsMKII_B.CFunctionCall_g = myAtan(controlMCUSlugsMKII_B.Divide);

  /* Switch: '<S271>/Switch3' incorporates:
   *  RelationalOperator: '<S271>/Relational Operator2'
   */
  if ((controlMCUSlugsMKII_B.CFunctionCall_g ==
       controlMCUSlugsMKII_B.CFunctionCall_g) > 0) {
    controlMCUSlugsMKII_B.Switch3_c = controlMCUSlugsMKII_B.CFunctionCall_g;
  } else {
    controlMCUSlugsMKII_B.Switch3_c = rtb_Ze;
  }

  /* Update for S-Function (sfix_udelay): '<S261>/Integer Delay3' */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_lj = controlMCUSlugsMKII_B.Switch3_h;

  /* Update for S-Function (sfix_udelay): '<S124>/Integer Delay2' */
  controlMCUSlugsMKII_DWork.IntegerDelay2_X = controlMCUSlugsMKII_B.swIncrement;

  /* Update for S-Function (sfix_udelay): '<S138>/Integer Delay1' */
  controlMCUSlugsMKII_DWork.IntegerDelay1_X_p =
    controlMCUSlugsMKII_B.HitCrossing1;

  /* Update for S-Function (sfix_udelay): '<S139>/Integer Delay2' */
  controlMCUSlugsMKII_DWork.IntegerDelay2_X_l = controlMCUSlugsMKII_B.IC;

  /* Update for S-Function (sfix_udelay): '<S132>/Integer Delay3' */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_b3 =
    controlMCUSlugsMKII_B.Switch3_nn;

  /* Update for S-Function (sfix_udelay): '<S254>/Integer Delay3' */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_g = controlMCUSlugsMKII_B.Switch3_a;

  /* Update for S-Function (sfix_udelay): '<S268>/Integer Delay3' */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_f = controlMCUSlugsMKII_B.Switch3_m;

  /* Update for S-Function (sfix_udelay): '<S124>/Integer Delay3' */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_a = controlMCUSlugsMKII_B.Switch3_e;

  /* Update for S-Function (sfix_udelay): '<S140>/Integer Delay1' */
  controlMCUSlugsMKII_DWork.IntegerDelay1_X_fi = controlMCUSlugsMKII_B.wp0;

  /* Update for S-Function (sfix_udelay): '<S180>/Integer Delay1' */
  controlMCUSlugsMKII_DWork.IntegerDelay1_X_i = controlMCUSlugsMKII_B.IC_e;

  /* Update for S-Function (sfix_udelay): '<S180>/Integer Delay2' */
  controlMCUSlugsMKII_DWork.IntegerDelay2_X_e[0] =
    controlMCUSlugsMKII_DWork.IntegerDelay2_X_e[1];
  controlMCUSlugsMKII_DWork.IntegerDelay2_X_e[1] = controlMCUSlugsMKII_B.IC_e;

  /* Update for UnitDelay: '<S196>/UD' */
  controlMCUSlugsMKII_DWork.UD_DSTATE = controlMCUSlugsMKII_B.Switch[0];

  /* Update for UnitDelay: '<S199>/UD' */
  controlMCUSlugsMKII_DWork.UD_DSTATE_e = controlMCUSlugsMKII_B.Switch[1];

  /* Update for UnitDelay: '<S202>/UD' */
  controlMCUSlugsMKII_DWork.UD_DSTATE_h = controlMCUSlugsMKII_B.Switch[2];

  /* Update for S-Function (sfix_udelay): '<S182>/Integer Delay3' */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X = controlMCUSlugsMKII_B.Switch3;

  /* Update for S-Function (sfix_udelay): '<S137>/Integer Delay3' */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_n = controlMCUSlugsMKII_B.Switch3_e;

  /* Update for S-Function (sfix_udelay): '<S271>/Integer Delay3' */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_ch = controlMCUSlugsMKII_B.Switch3_c;

  /* end of Outputs for SubSystem: '<S2>/Navigation' */
  /* S-Function "dsPIC_C_function_Call" Block: <Root>/[navSupport.c]    */
  getPidIdx(((uint8_T)8U),&controlMCUSlugsMKII_B.navSupportc_n[0]);

  /* Outputs for atomic SubSystem: '<S2>/Longitudinal Channel' */

  /* Sum: '<S91>/Add' incorporates:
   *  Constant: '<S91>/Constant from Model'
   *  Constant: '<S91>/Constant'
   *  Gain: '<S107>/Unit Conversion'
   *  Product: '<S91>/Divide'
   *  Saturate: '<S91>/[0 1000]'
   */
  controlMCUSlugsMKII_B.Add_g = 1.0F - 3.280839920E+000F * rt_SATURATE(rtb_u020,
    0.0F, 1000.0F) / 145442.0F;

  /* S-Function "dsPIC_C_function_Call" Block: <S108>/C Function Call */
  controlMCUSlugsMKII_B.CFunctionCall_ab = myPow(controlMCUSlugsMKII_B.Add_g,
    4.255876064F);

  /* Product: '<S91>/Divide1' incorporates:
   *  Constant: '<S91>/Rho_0 (Kg//m^3)'
   */
  rtb_cosphi = controlMCUSlugsMKII_B.CFunctionCall_ab * 1.225000024E+000F;

  /* Product: '<S93>/Divide2' incorporates:
   *  Constant: '<S93>/a'
   *  Saturate: '<S93>/[ 0.01 50000]'
   */
  rtb_Divide2 = 2.0F * controlMCUSlugsMKII_B.GetDynamicPnavSupportc /
    rt_SATURATE(rtb_cosphi, 9.999999776E-003F, 50000.0F);

  /* Embedded MATLAB: '<S113>/negprotect' */
  controlMCUSlugsM_negprotect(rtb_Divide2,
    &controlMCUSlugsMKII_B.sf_negprotect_c);

  /* S-Function "dsPIC_C_function_Call" Block: <S113>/C Function Call */
  controlMCUSlugsMKII_B.CFunctionCall_m4 = mySqrt
    (controlMCUSlugsMKII_B.sf_negprotect_c.zpVal);

  /* Switch: '<S99>/Switch3' incorporates:
   *  RelationalOperator: '<S99>/Relational Operator2'
   *  S-Function (sfix_udelay): '<S99>/Integer Delay3'
   */
  if ((controlMCUSlugsMKII_B.CFunctionCall_m4 ==
       controlMCUSlugsMKII_B.CFunctionCall_m4) > 0) {
    controlMCUSlugsMKII_B.Switch3_f = controlMCUSlugsMKII_B.CFunctionCall_m4;
  } else {
    controlMCUSlugsMKII_B.Switch3_f =
      controlMCUSlugsMKII_DWork.IntegerDelay3_X_i;
  }

  /* Embedded MATLAB: '<S88>/Embedded MATLAB Function' */
  cont_EmbeddedMATLABFunction(controlMCUSlugsMKII_B.Switch3_f, 0.01, 0.5,
    &controlMCUSlugsMKII_B.sf_EmbeddedMATLABFunction_p,
    &controlMCUSlugsMKII_DWork.sf_EmbeddedMATLABFunction_p);

  /* RelationalOperator: '<S102>/Compare' incorporates:
   *  Constant: '<S102>/Constant'
   */
  rtb_Add1_i = (controlMCUSlugsMKII_B.Switch3_f <= 10.0F);

  /* Embedded MATLAB: '<S90>/Embedded MATLAB Function' */
  cont_EmbeddedMATLABFunction(controlMCUSlugsMKII_B.Switch3_f, 0.01, 0.032,
    &controlMCUSlugsMKII_B.sf_EmbeddedMATLABFunction_i,
    &controlMCUSlugsMKII_DWork.sf_EmbeddedMATLABFunction_i);

  /* Switch: '<S15>/Schedule LPF' */
  if (rtb_Add1_i > 0) {
    controlMCUSlugsMKII_B.ScheduleLPF =
      controlMCUSlugsMKII_B.sf_EmbeddedMATLABFunction_p.y;
  } else {
    controlMCUSlugsMKII_B.ScheduleLPF =
      controlMCUSlugsMKII_B.sf_EmbeddedMATLABFunction_i.y;
  }

  /* Switch: '<S15>/Switch' incorporates:
   *  Saturate: '<S2>/[-20 20]1'
   */
  if (controlMCUSlugsMKII_B.wpFlynavSupportc > 0) {
    rtb_cosphi = rt_SATURATE(controlMCUSlugsMKII_B.Reshape1[2], 170.0F, 350.0F);
  } else {
    rtb_cosphi = controlMCUSlugsMKII_B.GetMidLevelCommandsnavSupportc[1];
  }

  /* RateLimiter: '<S15>/Rate Limiter' */
  rtb_Abs2 = rtb_cosphi - controlMCUSlugsMKII_DWork.PrevY;
  if (rtb_Abs2 > 7.000000030E-002F) {
    rtb_cosphi = controlMCUSlugsMKII_DWork.PrevY + 7.000000030E-002F;
  } else {
    if (rtb_Abs2 < -5.000000075E-002F) {
      rtb_cosphi = controlMCUSlugsMKII_DWork.PrevY + -5.000000075E-002F;
    }
  }

  controlMCUSlugsMKII_DWork.PrevY = rtb_cosphi;

  /* Sum: '<S15>/Add2' */
  rtb_cosphi -= rtb_u020;

  /* Switch: '<S97>/Switch3' incorporates:
   *  RelationalOperator: '<S97>/Relational Operator2'
   *  S-Function (sfix_udelay): '<S97>/Integer Delay3'
   */
  if ((rtb_cosphi == rtb_cosphi) > 0) {
    controlMCUSlugsMKII_B.Switch3_c1 = rtb_cosphi;
  } else {
    controlMCUSlugsMKII_B.Switch3_c1 =
      controlMCUSlugsMKII_DWork.IntegerDelay3_X_m;
  }

  /* Product: '<S94>/Product1' */
  rtb_sinphi = controlMCUSlugsMKII_B.Switch3_c1 *
    controlMCUSlugsMKII_B.GetPidaccordingtoIndex1[0];

  /* Sum: '<S94>/Sum2' incorporates:
   *  Gain: '<S94>/Gain'
   *  Memory: '<S94>/Memory1'
   *  Product: '<S94>/Product4'
   */
  rtb_cosphi = (9.999999776E-003F * controlMCUSlugsMKII_B.Switch3_c1 *
                controlMCUSlugsMKII_B.GetPidaccordingtoIndex1[1] +
                controlMCUSlugsMKII_DWork.Memory1_PreviousInput) + rtb_sinphi;

  /* Switch: '<S94>/AntiWindup' incorporates:
   *  Constant: '<S94>/Constant5'
   *  Logic: '<S94>/Logical Operator'
   *  RelationalOperator: '<S94>/Relational Operator'
   *  RelationalOperator: '<S94>/Relational Operator1'
   */
  if ((rtb_cosphi > controlMCUSlugsMKII_ConstB.Add4) && (rtb_cosphi <
       controlMCUSlugsMKII_ConstB.Add3)) {
    rtb_DataTypeConversion = controlMCUSlugsMKII_B.Switch3_c1;
  } else {
    rtb_DataTypeConversion = 0.0;
  }

  /* Switch: '<S118>/Switch3' incorporates:
   *  RelationalOperator: '<S118>/Relational Operator2'
   *  S-Function (sfix_udelay): '<S118>/Integer Delay3'
   */
  if ((rtb_DataTypeConversion == rtb_DataTypeConversion) > 0) {
    controlMCUSlugsMKII_B.Switch3_n = rtb_DataTypeConversion;
  } else {
    controlMCUSlugsMKII_B.Switch3_n =
      controlMCUSlugsMKII_DWork.IntegerDelay3_X_c;
  }

  /* Switch: '<S116>/Switch1' incorporates:
   *  Constant: '<S116>/Constant'
   *  Constant: '<S116>/Constant1'
   *  Constant: '<S116>/Constant2'
   *  Constant: '<S116>/Constant3'
   *  Constant: '<S116>/Constant5'
   *  Product: '<S116>/Product'
   *  Product: '<S116>/Product1'
   *  Product: '<S116>/Product2'
   *  Product: '<S116>/Product3'
   *  S-Function (sfix_udelay): '<S116>/Integer Delay'
   *  S-Function (sfix_udelay): '<S116>/Integer Delay1'
   *  S-Function (sfix_udelay): '<S116>/Integer Delay2'
   *  Sum: '<S116>/Subtract'
   *  Sum: '<S116>/Subtract1'
   */
  if (controlMCUSlugsMKII_B.ManualorAutonavSupportc > 0) {
    rtb_cosphi = 0.0F;
  } else {
    rtb_cosphi = (((real32_T)(controlMCUSlugsMKII_B.Switch3_n *
      3.3333334326744080E-001) + (real32_T)
                   (controlMCUSlugsMKII_DWork.IntegerDelay_X *
                    1.3333333730697632E+000)) + (real32_T)
                  (controlMCUSlugsMKII_DWork.IntegerDelay1_X[0] *
                   3.3333334326744080E-001)) * 4.999999888E-003F +
      controlMCUSlugsMKII_DWork.IntegerDelay2_X_lq;
  }

  /* Switch: '<S117>/Switch3' incorporates:
   *  RelationalOperator: '<S117>/Relational Operator2'
   *  S-Function (sfix_udelay): '<S117>/Integer Delay3'
   */
  if ((rtb_cosphi == rtb_cosphi) > 0) {
    controlMCUSlugsMKII_B.Switch3_b = rtb_cosphi;
  } else {
    controlMCUSlugsMKII_B.Switch3_b =
      controlMCUSlugsMKII_DWork.IntegerDelay3_X_at;
  }

  /* Sum: '<S94>/Add2' incorporates:
   *  Product: '<S94>/Product'
   */
  rtb_Ze = controlMCUSlugsMKII_B.Switch3_b *
    controlMCUSlugsMKII_B.GetPidaccordingtoIndex1[1] + rtb_sinphi;

  /* Switch: '<S115>/Switch2' incorporates:
   *  RelationalOperator: '<S115>/LowerRelop1'
   */
  if (rtb_Ze > controlMCUSlugsMKII_ConstB.Add3) {
    rtb_Deg2R1 = controlMCUSlugsMKII_ConstB.Add3;
  } else {
    /* Switch: '<S115>/Switch' incorporates:
     *  RelationalOperator: '<S115>/UpperRelop'
     */
    if (rtb_Ze < controlMCUSlugsMKII_ConstB.Add4) {
      rtb_Deg2R1 = controlMCUSlugsMKII_ConstB.Add4;
    } else {
      rtb_Deg2R1 = rtb_Ze;
    }
  }

  /* Saturate: '<S15>/Theta_c Limit' */
  rtb_Abs2 = rt_SATURATE(rtb_Deg2R1, -3.490658402E-001F, 3.490658402E-001F);

  /* Embedded MATLAB: '<S15>/myMux Fun1' */
  /* Embedded MATLAB Function 'Inner Loop/ Navigation/Longitudinal Channel/myMux Fun1': '<S103>:1' */
  /*  This block supports an embeddable subset of the MATLAB language. */
  /*  See the help menu for details.  */
  /* '<S103>:1:5' */
  controlMCUSlugsMKII_B.y_j[0] = controlMCUSlugsMKII_B.ScheduleLPF;
  controlMCUSlugsMKII_B.y_j[1] = rtb_Abs2;

  /* S-Function "dsPIC_C_function_Call" Block: <S15>/Get XYZ [navSupport.c] */
  setNavLong(controlMCUSlugsMKII_B.y_j);

  /* Switch: '<S100>/Switch3' incorporates:
   *  RelationalOperator: '<S100>/Relational Operator2'
   *  S-Function (sfix_udelay): '<S100>/Integer Delay3'
   */
  if ((controlMCUSlugsMKII_B.y[0] == controlMCUSlugsMKII_B.y[0]) > 0) {
    controlMCUSlugsMKII_B.Switch3_mx = controlMCUSlugsMKII_B.y[0];
  } else {
    controlMCUSlugsMKII_B.Switch3_mx =
      controlMCUSlugsMKII_DWork.IntegerDelay3_X_fk;
  }

  /* Embedded MATLAB: '<S89>/Embedded MATLAB Function' */
  cont_EmbeddedMATLABFunction(controlMCUSlugsMKII_B.Switch3_mx, 0.01, 0.32,
    &controlMCUSlugsMKII_B.sf_EmbeddedMATLABFunction_l,
    &controlMCUSlugsMKII_DWork.sf_EmbeddedMATLABFunction_l);

  /* Sum: '<S15>/Add' */
  rtb_Deg2R1 = controlMCUSlugsMKII_B.GetMidLevelCommandsnavSupportc[0] -
    controlMCUSlugsMKII_B.ScheduleLPF;

  /* Sum: '<S92>/Add3' incorporates:
   *  Constant: '<S92>/SaturationLimit'
   */
  rtb_sinphi = 1.0F - controlMCUSlugsMKII_B.DataTypeConversion;

  /* Switch: '<S96>/Switch3' incorporates:
   *  RelationalOperator: '<S96>/Relational Operator2'
   *  S-Function (sfix_udelay): '<S96>/Integer Delay3'
   */
  if ((rtb_Deg2R1 == rtb_Deg2R1) > 0) {
    controlMCUSlugsMKII_B.Switch3_kr = rtb_Deg2R1;
  } else {
    controlMCUSlugsMKII_B.Switch3_kr =
      controlMCUSlugsMKII_DWork.IntegerDelay3_X_e;
  }

  /* Sum: '<S92>/Add1' incorporates:
   *  Constant: '<S92>/delayTime'
   *  Product: '<S92>/Product1'
   *  Product: '<S92>/Product2'
   *  Product: '<S92>/Product3'
   *  S-Function (sfix_udelay): '<S92>/NDelays'
   *  Sum: '<S92>/Sum'
   */
  rtb_Deg2R1 = (controlMCUSlugsMKII_B.Switch3_kr -
                controlMCUSlugsMKII_DWork.NDelays_X[0]) / 5.000000075E-002F *
    controlMCUSlugsMKII_B.GetPidaccordingtoIndex[2] +
    controlMCUSlugsMKII_B.Switch3_kr *
    controlMCUSlugsMKII_B.GetPidaccordingtoIndex[0];

  /* Sum: '<S92>/Sum2' incorporates:
   *  Gain: '<S92>/Gain'
   *  Memory: '<S92>/Memory1'
   *  Product: '<S92>/Product4'
   */
  rtb_cosphi = (9.999999776E-003F * controlMCUSlugsMKII_B.Switch3_kr *
                controlMCUSlugsMKII_B.GetPidaccordingtoIndex[1] +
                controlMCUSlugsMKII_DWork.Memory1_PreviousInput_e) + rtb_Deg2R1;

  /* Sum: '<S92>/Add4' incorporates:
   *  Constant: '<S92>/SaturationLimit1'
   */
  rtb_Sum2 = 0.0F - controlMCUSlugsMKII_B.DataTypeConversion;

  /* Switch: '<S92>/AntiWindup' incorporates:
   *  Constant: '<S92>/Constant5'
   *  Logic: '<S92>/Logical Operator'
   *  RelationalOperator: '<S92>/Relational Operator'
   *  RelationalOperator: '<S92>/Relational Operator1'
   */
  if ((rtb_cosphi > rtb_Sum2) && (rtb_cosphi < rtb_sinphi)) {
    rtb_DataTypeConversion = controlMCUSlugsMKII_B.Switch3_kr;
  } else {
    rtb_DataTypeConversion = 0.0;
  }

  /* Switch: '<S111>/Switch3' incorporates:
   *  RelationalOperator: '<S111>/Relational Operator2'
   *  S-Function (sfix_udelay): '<S111>/Integer Delay3'
   */
  if ((rtb_DataTypeConversion == rtb_DataTypeConversion) > 0) {
    controlMCUSlugsMKII_B.Switch3_k = rtb_DataTypeConversion;
  } else {
    controlMCUSlugsMKII_B.Switch3_k =
      controlMCUSlugsMKII_DWork.IntegerDelay3_X_l;
  }

  /* Switch: '<S110>/Switch1' incorporates:
   *  Constant: '<S110>/Constant'
   *  Constant: '<S110>/Constant1'
   *  Constant: '<S110>/Constant2'
   *  Constant: '<S110>/Constant3'
   *  Constant: '<S110>/Constant5'
   *  Product: '<S110>/Product'
   *  Product: '<S110>/Product1'
   *  Product: '<S110>/Product2'
   *  Product: '<S110>/Product3'
   *  S-Function (sfix_udelay): '<S110>/Integer Delay'
   *  S-Function (sfix_udelay): '<S110>/Integer Delay1'
   *  S-Function (sfix_udelay): '<S110>/Integer Delay2'
   *  Sum: '<S110>/Subtract'
   *  Sum: '<S110>/Subtract1'
   */
  if (controlMCUSlugsMKII_B.ManualorAutonavSupportc > 0) {
    rtb_cosphi = 0.0F;
  } else {
    rtb_cosphi = (((real32_T)(controlMCUSlugsMKII_B.Switch3_k *
      3.3333334326744080E-001) + (real32_T)
                   (controlMCUSlugsMKII_DWork.IntegerDelay_X_i *
                    1.3333333730697632E+000)) + (real32_T)
                  (controlMCUSlugsMKII_DWork.IntegerDelay1_X_o[0] *
                   3.3333334326744080E-001)) * 4.999999888E-003F +
      controlMCUSlugsMKII_DWork.IntegerDelay2_X_d;
  }

  /* Switch: '<S112>/Switch3' incorporates:
   *  RelationalOperator: '<S112>/Relational Operator2'
   *  S-Function (sfix_udelay): '<S112>/Integer Delay3'
   */
  if ((rtb_cosphi == rtb_cosphi) > 0) {
    controlMCUSlugsMKII_B.Switch3_p = rtb_cosphi;
  } else {
    controlMCUSlugsMKII_B.Switch3_p =
      controlMCUSlugsMKII_DWork.IntegerDelay3_X_ex;
  }

  /* Sum: '<S92>/Add2' incorporates:
   *  Product: '<S92>/Product'
   */
  rtb_Divide4_k = controlMCUSlugsMKII_B.Switch3_p *
    controlMCUSlugsMKII_B.GetPidaccordingtoIndex[1] + rtb_Deg2R1;

  /* Switch: '<S109>/Switch2' incorporates:
   *  RelationalOperator: '<S109>/LowerRelop1'
   */
  if (!(rtb_Divide4_k > rtb_sinphi)) {
    /* Switch: '<S109>/Switch' incorporates:
     *  RelationalOperator: '<S109>/UpperRelop'
     */
    if (!(rtb_Divide4_k < rtb_Sum2)) {
      rtb_Sum2 = rtb_Divide4_k;
    }

    rtb_sinphi = rtb_Sum2;
  }

  /* Sum: '<S15>/Add1' incorporates:
   *  Product: '<S15>/Product2'
   */
  rtb_sinphi = (rtb_sinphi + controlMCUSlugsMKII_B.DataTypeConversion) +
    controlMCUSlugsMKII_B.navSupportc_n[0] * controlMCUSlugsMKII_B.y[1];

  /* Sum: '<S15>/Add3' */
  rtb_Abs2 -= controlMCUSlugsMKII_B.y[1];

  /* Sum: '<S95>/Add3' incorporates:
   *  Constant: '<S95>/SaturationLimit'
   */
  rtb_Deg2R1 = 2.617993951E-001F - controlMCUSlugsMKII_B.DataTypeConversion_c;

  /* Switch: '<S98>/Switch3' incorporates:
   *  RelationalOperator: '<S98>/Relational Operator2'
   *  S-Function (sfix_udelay): '<S98>/Integer Delay3'
   */
  if ((rtb_Abs2 == rtb_Abs2) > 0) {
    controlMCUSlugsMKII_B.Switch3_f3 = rtb_Abs2;
  } else {
    controlMCUSlugsMKII_B.Switch3_f3 =
      controlMCUSlugsMKII_DWork.IntegerDelay3_X_nv;
  }

  /* Sum: '<S95>/Add1' incorporates:
   *  Constant: '<S95>/delayTime'
   *  Product: '<S95>/Product1'
   *  Product: '<S95>/Product2'
   *  Product: '<S95>/Product3'
   *  S-Function (sfix_udelay): '<S95>/NDelays'
   *  Sum: '<S95>/Sum'
   */
  rtb_Abs2 = (controlMCUSlugsMKII_B.Switch3_f3 -
              controlMCUSlugsMKII_DWork.NDelays_X_c[0]) / 5.000000075E-002F *
    controlMCUSlugsMKII_B.GetPidaccordingtoIndex2[2] +
    controlMCUSlugsMKII_B.Switch3_f3 *
    controlMCUSlugsMKII_B.GetPidaccordingtoIndex2[0];

  /* Sum: '<S95>/Sum2' incorporates:
   *  Gain: '<S95>/Gain'
   *  Memory: '<S95>/Memory1'
   *  Product: '<S95>/Product4'
   */
  rtb_cosphi = (9.999999776E-003F * controlMCUSlugsMKII_B.Switch3_f3 *
                controlMCUSlugsMKII_B.GetPidaccordingtoIndex2[1] +
                controlMCUSlugsMKII_DWork.Memory1_PreviousInput_f) + rtb_Abs2;

  /* Sum: '<S95>/Add4' incorporates:
   *  Constant: '<S95>/SaturationLimit1'
   */
  rtb_Sum2 = -2.617993951E-001F - controlMCUSlugsMKII_B.DataTypeConversion_c;

  /* Switch: '<S95>/AntiWindup' incorporates:
   *  Constant: '<S95>/Constant5'
   *  Logic: '<S95>/Logical Operator'
   *  RelationalOperator: '<S95>/Relational Operator'
   *  RelationalOperator: '<S95>/Relational Operator1'
   */
  if ((rtb_cosphi > rtb_Sum2) && (rtb_cosphi < rtb_Deg2R1)) {
    rtb_DataTypeConversion = controlMCUSlugsMKII_B.Switch3_f3;
  } else {
    rtb_DataTypeConversion = 0.0;
  }

  /* Switch: '<S121>/Switch3' incorporates:
   *  RelationalOperator: '<S121>/Relational Operator2'
   *  S-Function (sfix_udelay): '<S121>/Integer Delay3'
   */
  if ((rtb_DataTypeConversion == rtb_DataTypeConversion) > 0) {
    controlMCUSlugsMKII_B.Switch3_o = rtb_DataTypeConversion;
  } else {
    controlMCUSlugsMKII_B.Switch3_o =
      controlMCUSlugsMKII_DWork.IntegerDelay3_X_k;
  }

  /* Switch: '<S120>/Switch1' incorporates:
   *  Constant: '<S120>/Constant'
   *  Constant: '<S120>/Constant1'
   *  Constant: '<S120>/Constant2'
   *  Constant: '<S120>/Constant3'
   *  Constant: '<S120>/Constant5'
   *  Product: '<S120>/Product'
   *  Product: '<S120>/Product1'
   *  Product: '<S120>/Product2'
   *  Product: '<S120>/Product3'
   *  S-Function (sfix_udelay): '<S120>/Integer Delay'
   *  S-Function (sfix_udelay): '<S120>/Integer Delay1'
   *  S-Function (sfix_udelay): '<S120>/Integer Delay2'
   *  Sum: '<S120>/Subtract'
   *  Sum: '<S120>/Subtract1'
   */
  if (controlMCUSlugsMKII_B.ManualorAutonavSupportc > 0) {
    rtb_cosphi = 0.0F;
  } else {
    rtb_cosphi = (((real32_T)(controlMCUSlugsMKII_B.Switch3_o *
      3.3333334326744080E-001) + (real32_T)
                   (controlMCUSlugsMKII_DWork.IntegerDelay_X_g *
                    1.3333333730697632E+000)) + (real32_T)
                  (controlMCUSlugsMKII_DWork.IntegerDelay1_X_oa[0] *
                   3.3333334326744080E-001)) * 4.999999888E-003F +
      controlMCUSlugsMKII_DWork.IntegerDelay2_X_n;
  }

  /* Switch: '<S122>/Switch3' incorporates:
   *  RelationalOperator: '<S122>/Relational Operator2'
   *  S-Function (sfix_udelay): '<S122>/Integer Delay3'
   */
  if ((rtb_cosphi == rtb_cosphi) > 0) {
    controlMCUSlugsMKII_B.Switch3_el = rtb_cosphi;
  } else {
    controlMCUSlugsMKII_B.Switch3_el =
      controlMCUSlugsMKII_DWork.IntegerDelay3_X_p;
  }

  /* Sum: '<S95>/Add2' incorporates:
   *  Product: '<S95>/Product'
   */
  rtb_Abs2 += controlMCUSlugsMKII_B.Switch3_el *
    controlMCUSlugsMKII_B.GetPidaccordingtoIndex2[1];

  /* Switch: '<S119>/Switch2' incorporates:
   *  RelationalOperator: '<S119>/LowerRelop1'
   */
  if (!(rtb_Abs2 > rtb_Deg2R1)) {
    /* Switch: '<S119>/Switch' incorporates:
     *  RelationalOperator: '<S119>/UpperRelop'
     */
    if (!(rtb_Abs2 < rtb_Sum2)) {
      rtb_Sum2 = rtb_Abs2;
    }

    rtb_Deg2R1 = rtb_Sum2;
  }

  /* Saturate: '<S15>/[-60 60]' */
  controlMCUSlugsMKII_B.u060 = rt_SATURATE
    (controlMCUSlugsMKII_B.sf_EmbeddedMATLABFunction_l.y, -60.0F, 60.0F);

  /* S-Function "dsPIC_C_function_Call" Block: <S101>/C Function Call1 */
  controlMCUSlugsMKII_B.CFunctionCall1_b = myCos(controlMCUSlugsMKII_B.u060);

  /* Sum: '<S15>/Add4' incorporates:
   *  Constant: '<S15>/Constant2'
   *  Constant: '<S15>/Constant4'
   *  Product: '<S15>/Product'
   *  Product: '<S15>/Product1'
   *  Sum: '<S15>/Add5'
   */
  rtb_Deg2R1 = (1.0F / controlMCUSlugsMKII_B.CFunctionCall1_b - 1.0F) *
    controlMCUSlugsMKII_B.GetPidaccordingtoIndex1[2] + (rtb_Deg2R1 +
    controlMCUSlugsMKII_B.DataTypeConversion_c);

  /* Saturate: '<S15>/Elevator  Limit' */
  rtb_u020 = rt_SATURATE(rtb_Deg2R1, -2.617993951E-001F, 2.617993951E-001F);

  /* Saturate: '<S15>/Throttle  Limit' */
  rtb_Product1_m = rt_SATURATE(rtb_sinphi, 0.0F, 1.0F);

  /* Update for S-Function (sfix_udelay): '<S99>/Integer Delay3' */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_i = controlMCUSlugsMKII_B.Switch3_f;

  /* Update for S-Function (sfix_udelay): '<S97>/Integer Delay3' */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_m = controlMCUSlugsMKII_B.Switch3_c1;

  /* Update for S-Function (sfix_udelay): '<S116>/Integer Delay2' */
  controlMCUSlugsMKII_DWork.IntegerDelay2_X_lq = controlMCUSlugsMKII_B.Switch3_b;

  /* Update for Memory: '<S94>/Memory1' */
  controlMCUSlugsMKII_DWork.Memory1_PreviousInput = rtb_Ze;

  /* Update for S-Function (sfix_udelay): '<S118>/Integer Delay3' */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_c = controlMCUSlugsMKII_B.Switch3_n;

  /* Update for S-Function (sfix_udelay): '<S116>/Integer Delay' */
  controlMCUSlugsMKII_DWork.IntegerDelay_X = controlMCUSlugsMKII_B.Switch3_n;

  /* Update for S-Function (sfix_udelay): '<S116>/Integer Delay1' */
  controlMCUSlugsMKII_DWork.IntegerDelay1_X[0] =
    controlMCUSlugsMKII_DWork.IntegerDelay1_X[1];
  controlMCUSlugsMKII_DWork.IntegerDelay1_X[1] = controlMCUSlugsMKII_B.Switch3_n;

  /* Update for S-Function (sfix_udelay): '<S117>/Integer Delay3' */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_at = controlMCUSlugsMKII_B.Switch3_b;

  /* Update for S-Function (sfix_udelay): '<S100>/Integer Delay3' */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_fk =
    controlMCUSlugsMKII_B.Switch3_mx;

  /* Update for S-Function (sfix_udelay): '<S96>/Integer Delay3' */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_e = controlMCUSlugsMKII_B.Switch3_kr;

  /* Update for S-Function (sfix_udelay): '<S92>/NDelays' */
  controlMCUSlugsMKII_DWork.NDelays_X[0] = controlMCUSlugsMKII_DWork.NDelays_X[1];
  controlMCUSlugsMKII_DWork.NDelays_X[1] = controlMCUSlugsMKII_DWork.NDelays_X[2];
  controlMCUSlugsMKII_DWork.NDelays_X[2] = controlMCUSlugsMKII_DWork.NDelays_X[3];
  controlMCUSlugsMKII_DWork.NDelays_X[3] = controlMCUSlugsMKII_DWork.NDelays_X[4];
  controlMCUSlugsMKII_DWork.NDelays_X[4] = controlMCUSlugsMKII_B.Switch3_kr;

  /* Update for S-Function (sfix_udelay): '<S110>/Integer Delay2' */
  controlMCUSlugsMKII_DWork.IntegerDelay2_X_d = controlMCUSlugsMKII_B.Switch3_p;

  /* Update for Memory: '<S92>/Memory1' */
  controlMCUSlugsMKII_DWork.Memory1_PreviousInput_e = rtb_Divide4_k;

  /* Update for S-Function (sfix_udelay): '<S111>/Integer Delay3' */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_l = controlMCUSlugsMKII_B.Switch3_k;

  /* Update for S-Function (sfix_udelay): '<S110>/Integer Delay' */
  controlMCUSlugsMKII_DWork.IntegerDelay_X_i = controlMCUSlugsMKII_B.Switch3_k;

  /* Update for S-Function (sfix_udelay): '<S110>/Integer Delay1' */
  controlMCUSlugsMKII_DWork.IntegerDelay1_X_o[0] =
    controlMCUSlugsMKII_DWork.IntegerDelay1_X_o[1];
  controlMCUSlugsMKII_DWork.IntegerDelay1_X_o[1] =
    controlMCUSlugsMKII_B.Switch3_k;

  /* Update for S-Function (sfix_udelay): '<S112>/Integer Delay3' */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_ex = controlMCUSlugsMKII_B.Switch3_p;

  /* Update for S-Function (sfix_udelay): '<S98>/Integer Delay3' */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_nv =
    controlMCUSlugsMKII_B.Switch3_f3;

  /* Update for S-Function (sfix_udelay): '<S95>/NDelays' */
  controlMCUSlugsMKII_DWork.NDelays_X_c[0] =
    controlMCUSlugsMKII_DWork.NDelays_X_c[1];
  controlMCUSlugsMKII_DWork.NDelays_X_c[1] =
    controlMCUSlugsMKII_DWork.NDelays_X_c[2];
  controlMCUSlugsMKII_DWork.NDelays_X_c[2] =
    controlMCUSlugsMKII_DWork.NDelays_X_c[3];
  controlMCUSlugsMKII_DWork.NDelays_X_c[3] =
    controlMCUSlugsMKII_DWork.NDelays_X_c[4];
  controlMCUSlugsMKII_DWork.NDelays_X_c[4] = controlMCUSlugsMKII_B.Switch3_f3;

  /* Update for S-Function (sfix_udelay): '<S120>/Integer Delay2' */
  controlMCUSlugsMKII_DWork.IntegerDelay2_X_n = controlMCUSlugsMKII_B.Switch3_el;

  /* Update for Memory: '<S95>/Memory1' */
  controlMCUSlugsMKII_DWork.Memory1_PreviousInput_f = rtb_Abs2;

  /* Update for S-Function (sfix_udelay): '<S121>/Integer Delay3' */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_k = controlMCUSlugsMKII_B.Switch3_o;

  /* Update for S-Function (sfix_udelay): '<S120>/Integer Delay' */
  controlMCUSlugsMKII_DWork.IntegerDelay_X_g = controlMCUSlugsMKII_B.Switch3_o;

  /* Update for S-Function (sfix_udelay): '<S120>/Integer Delay1' */
  controlMCUSlugsMKII_DWork.IntegerDelay1_X_oa[0] =
    controlMCUSlugsMKII_DWork.IntegerDelay1_X_oa[1];
  controlMCUSlugsMKII_DWork.IntegerDelay1_X_oa[1] =
    controlMCUSlugsMKII_B.Switch3_o;

  /* Update for S-Function (sfix_udelay): '<S122>/Integer Delay3' */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_p = controlMCUSlugsMKII_B.Switch3_el;

  /* end of Outputs for SubSystem: '<S2>/Longitudinal Channel' */
  /* S-Function "dsPIC_C_function_Call" Block: <S3>/Get Pid according to Index3 */
  getPidIdx(((uint8_T)3U),&controlMCUSlugsMKII_B.GetPidaccordingtoIndex3[0]);

  /* S-Function "dsPIC_C_function_Call" Block: <S3>/[navSupport.c] */
  getPidIdx(((uint8_T)4U),&controlMCUSlugsMKII_B.navSupportc_k[0]);

  /* S-Function "dsPIC_C_function_Call" Block: <S20>/[apUtils.c] */
  controlMCUSlugsMKII_B.apUtilsc = myCos(controlMCUSlugsMKII_B.y[0]);

  /* Product: '<S12>/Product' */
  rtb_Abs2 = controlMCUSlugsMKII_B.y[5] * controlMCUSlugsMKII_B.apUtilsc;

  /* S-Function "dsPIC_C_function_Call" Block: <S21>/[apUtils.c] */
  controlMCUSlugsMKII_B.apUtilsc_p = mySin(controlMCUSlugsMKII_B.y[0]);

  /* Sum: '<S12>/Subtract' incorporates:
   *  Product: '<S12>/Product1'
   */
  rtb_Abs2 += controlMCUSlugsMKII_B.y[4] * controlMCUSlugsMKII_B.apUtilsc_p;

  /* Switch: '<S19>/Switch3' incorporates:
   *  RelationalOperator: '<S19>/Relational Operator2'
   *  S-Function (sfix_udelay): '<S19>/Integer Delay3'
   */
  if ((rtb_Abs2 == rtb_Abs2) > 0) {
    controlMCUSlugsMKII_B.Switch3_oe = rtb_Abs2;
  } else {
    controlMCUSlugsMKII_B.Switch3_oe =
      controlMCUSlugsMKII_DWork.IntegerDelay3_X_b;
  }

  /* S-Function "dsPIC_C_function_Call" Block: <Root>/[navSupport.c]  */
  getPidIdx(((uint8_T)6U),&controlMCUSlugsMKII_B.navSupportc_g[0]);

  /* Outputs for enable SubSystem: '<S2>/L1 Output Feedback Controller With  Projection Operator' incorporates:
   *  EnablePort: '<S13>/Enable'
   */
  if (controlMCUSlugsMKII_B.navSupportc_g[2] > 0.0F) {
    if (!((int16_T)controlMCUSlugsMKII_DWork.L1OutputFeedbackControllerWithP !=
          0)) {
      /* InitializeConditions for UnitDelay: '<S33>/UD' */
      controlMCUSlugsMKII_DWork.UD_DSTATE_l = 0.0F;

      /* InitializeConditions for S-Function (sfix_udelay): '<S24>/Integer Delay' */
      controlMCUSlugsMKII_DWork.IntegerDelay_X_d = 0.0F;

      /* InitializeConditions for S-Function (sfix_udelay): '<S24>/Integer Delay1' */
      controlMCUSlugsMKII_DWork.IntegerDelay1_X_nc = 0.0F;

      /* InitializeConditions for S-Function (sfix_udelay): '<S26>/Integer Delay3' */
      controlMCUSlugsMKII_DWork.IntegerDelay3_X_cw = 0.0F;

      /* InitializeConditions for UnitDelay: '<S42>/UD' */
      controlMCUSlugsMKII_DWork.UD_DSTATE_ld = 0.0F;

      /* InitializeConditions for S-Function (sfix_udelay): '<S28>/Integer Delay' */
      controlMCUSlugsMKII_DWork.IntegerDelay_X_c = 0.0F;

      /* InitializeConditions for S-Function (sfix_udelay): '<S28>/Integer Delay1' */
      controlMCUSlugsMKII_DWork.IntegerDelay1_X_a = 0.0F;

      /* InitializeConditions for S-Function (sfix_udelay): '<S13>/Integer Delay' */
      controlMCUSlugsMKII_DWork.IntegerDelay_X_no = 0.0F;

      /* InitializeConditions for S-Function (sfix_udelay): '<S13>/Integer Delay1' */
      controlMCUSlugsMKII_DWork.IntegerDelay1_X_b = 0.0F;

      /* InitializeConditions for Merge: '<S25>/Merge' */
      if (rtmIsFirstInitCond(controlMCUSlugsMKII_M)) {
        controlMCUSlugsMKII_B.Merge = 0.0F;
      }

      /* InitializeConditions for S-Function (sfix_udelay): '<S27>/Integer Delay3' */
      controlMCUSlugsMKII_DWork.IntegerDelay3_X_gww = 0.0F;

      /* InitializeConditions for S-Function (sfix_udelay): '<S29>/Integer Delay' */
      controlMCUSlugsMKII_DWork.IntegerDelay_X_f = 0.0F;

      /* InitializeConditions for S-Function (sfix_udelay): '<S29>/Integer Delay1' */
      controlMCUSlugsMKII_DWork.IntegerDelay1_X_ny[0] = 0.0F;
      controlMCUSlugsMKII_DWork.IntegerDelay1_X_ny[1] = 0.0F;

      /* InitializeConditions for S-Function (sfix_udelay): '<S29>/Integer Delay2' */
      controlMCUSlugsMKII_DWork.IntegerDelay2_X_m = 0.0F;

      /* InitializeConditions for S-Function (sfix_udelay): '<S43>/Integer Delay3' */
      controlMCUSlugsMKII_DWork.IntegerDelay3_X_oe = 0.0F;

      /* InitializeConditions for S-Function (sfix_udelay): '<S44>/Integer Delay3' */
      controlMCUSlugsMKII_DWork.IntegerDelay3_X_oe1 = 0.0F;
      controlMCUSlugsMKII_DWork.L1OutputFeedbackControllerWithP = TRUE;
    }

    /* Abs: '<S31>/Abs1' incorporates:
     *  Sum: '<S33>/Diff'
     *  UnitDelay: '<S33>/UD'
     */
    rtb_Abs2 = (real32_T)fabs(controlMCUSlugsMKII_B.navSupportc_g[0] -
      controlMCUSlugsMKII_DWork.UD_DSTATE_l);

    /* InitialCondition: '<S24>/IC' incorporates:
     *  Saturate: '<S31>/Saturation1'
     */
    if (controlMCUSlugsMKII_DWork.IC_FirstOutputTime_g) {
      controlMCUSlugsMKII_DWork.IC_FirstOutputTime_g = FALSE;
      rtb_Abs2 = 1.0F;
    } else {
      rtb_Abs2 = rt_SATURATE(rtb_Abs2, 0.0F, 1.0F);
    }

    /* Outputs for enable SubSystem: '<S24>/Compute Coef' incorporates:
     *  EnablePort: '<S30>/Enable'
     */
    if (rtb_Abs2 > 0.0F) {
      /* Gain: '<S30>/-T' */
      controlMCUSlugsMKII_B.T_i = -9.999999776E-003F *
        controlMCUSlugsMKII_B.navSupportc_g[0];

      /* S-Function "dsPIC_C_function_Call" Block: <S32>/C Function Call */
      controlMCUSlugsMKII_B.CFunctionCall_p = myExp(controlMCUSlugsMKII_B.T_i);

      /* Sum: '<S30>/1-c' incorporates:
       *  Constant: '<S30>/Constant'
       */
      controlMCUSlugsMKII_B.c_kt = (real32_T)(1.0 - (real_T)
        controlMCUSlugsMKII_B.CFunctionCall_p);
    }

    /* end of Outputs for SubSystem: '<S24>/Compute Coef' */

    /* Sum: '<S24>/Subtract' incorporates:
     *  Product: '<S24>/Divide'
     *  Product: '<S24>/Divide1'
     *  S-Function (sfix_udelay): '<S24>/Integer Delay'
     *  S-Function (sfix_udelay): '<S24>/Integer Delay1'
     */
    controlMCUSlugsMKII_B.Subtract_b = controlMCUSlugsMKII_B.c_kt *
      controlMCUSlugsMKII_DWork.IntegerDelay_X_d +
      controlMCUSlugsMKII_B.CFunctionCall_p *
      controlMCUSlugsMKII_DWork.IntegerDelay1_X_nc;

    /* Switch: '<S26>/Switch3' incorporates:
     *  RelationalOperator: '<S26>/Relational Operator2'
     *  S-Function (sfix_udelay): '<S26>/Integer Delay3'
     */
    if ((controlMCUSlugsMKII_B.Switch3_oe == controlMCUSlugsMKII_B.Switch3_oe) >
        0) {
      controlMCUSlugsMKII_B.Switch3_cj = controlMCUSlugsMKII_B.Switch3_oe;
    } else {
      controlMCUSlugsMKII_B.Switch3_cj =
        controlMCUSlugsMKII_DWork.IntegerDelay3_X_cw;
    }

    /* Abs: '<S40>/Abs1' incorporates:
     *  Sum: '<S42>/Diff'
     *  UnitDelay: '<S42>/UD'
     */
    rtb_Abs2 = (real32_T)fabs(controlMCUSlugsMKII_B.navSupportc_g[1] -
      controlMCUSlugsMKII_DWork.UD_DSTATE_ld);

    /* InitialCondition: '<S28>/IC' incorporates:
     *  Saturate: '<S40>/Saturation1'
     */
    if (controlMCUSlugsMKII_DWork.IC_FirstOutputTime_p) {
      controlMCUSlugsMKII_DWork.IC_FirstOutputTime_p = FALSE;
      rtb_Abs2 = 1.0F;
    } else {
      rtb_Abs2 = rt_SATURATE(rtb_Abs2, 0.0F, 1.0F);
    }

    /* Outputs for enable SubSystem: '<S28>/Compute Coef' incorporates:
     *  EnablePort: '<S39>/Enable'
     */
    if (rtb_Abs2 > 0.0F) {
      /* Gain: '<S39>/-T' */
      controlMCUSlugsMKII_B.T = -9.999999776E-003F *
        controlMCUSlugsMKII_B.navSupportc_g[1];

      /* S-Function "dsPIC_C_function_Call" Block: <S41>/C Function Call */
      controlMCUSlugsMKII_B.CFunctionCall_dr = myExp(controlMCUSlugsMKII_B.T);

      /* Sum: '<S39>/1-c' incorporates:
       *  Constant: '<S39>/Constant'
       */
      controlMCUSlugsMKII_B.c_i = (real32_T)(1.0 - (real_T)
        controlMCUSlugsMKII_B.CFunctionCall_dr);
    }

    /* end of Outputs for SubSystem: '<S28>/Compute Coef' */

    /* Sum: '<S28>/Subtract' incorporates:
     *  Product: '<S28>/Divide'
     *  Product: '<S28>/Divide1'
     *  S-Function (sfix_udelay): '<S28>/Integer Delay'
     *  S-Function (sfix_udelay): '<S28>/Integer Delay1'
     */
    controlMCUSlugsMKII_B.Subtract_c = controlMCUSlugsMKII_B.c_i *
      controlMCUSlugsMKII_DWork.IntegerDelay_X_c +
      controlMCUSlugsMKII_B.CFunctionCall_dr *
      controlMCUSlugsMKII_DWork.IntegerDelay1_X_a;

    /* Gain: '<S13>/Gain' incorporates:
     *  Sum: '<S13>/Sum3'
     */
    rtb_Abs2 = (controlMCUSlugsMKII_B.Subtract_c -
                controlMCUSlugsMKII_B.Switch3_cj) * -1.0F;

    /* Product: '<S38>/Divide4' incorporates:
     *  Constant: '<S38>/Constant'
     *  S-Function (sfix_udelay): '<S13>/Integer Delay1'
     */
    rtb_Deg2R1 = 1.0F / controlMCUSlugsMKII_ConstB.Divide2 *
      controlMCUSlugsMKII_DWork.IntegerDelay1_X_b * 2.0F;

    /* Product: '<S38>/Divide3' incorporates:
     *  Product: '<S38>/Divide'
     *  S-Function (sfix_udelay): '<S13>/Integer Delay1'
     *  Sum: '<S38>/Subtract'
     */
    rtb_Sum2 = (controlMCUSlugsMKII_DWork.IntegerDelay1_X_b *
                controlMCUSlugsMKII_DWork.IntegerDelay1_X_b -
                controlMCUSlugsMKII_ConstB.Divide1) /
      controlMCUSlugsMKII_ConstB.Divide2;

    /* Logic: '<S25>/Logical Operator2' incorporates:
     *  Constant: '<S34>/Constant'
     *  Constant: '<S35>/Constant'
     *  Product: '<S25>/Divide2'
     *  RelationalOperator: '<S34>/Compare'
     *  RelationalOperator: '<S35>/Compare'
     */
    rtb_Add1_i = ((rtb_Deg2R1 * rtb_Abs2 > 0.0F) && (rtb_Sum2 >= 0.0F));

    /* Outputs for enable SubSystem: '<S25>/Enabled Subsystem' incorporates:
     *  EnablePort: '<S36>/Enable'
     *  Logic: '<S25>/Logical Operator'
     */
    if (!(rtb_Add1_i != 0) > 0) {
      /* Inport: '<S36>/In1' */
      controlMCUSlugsMKII_B.Merge = rtb_Abs2;
    }

    /* end of Outputs for SubSystem: '<S25>/Enabled Subsystem' */

    /* Outputs for enable SubSystem: '<S25>/Enabled Subsystem1' incorporates:
     *  EnablePort: '<S37>/Enable'
     */
    if (rtb_Add1_i > 0) {
      /* Product: '<S37>/Divide2' incorporates:
       *  Constant: '<S37>/Constant'
       *  Product: '<S37>/Divide1'
       *  Signum: '<S37>/Sign'
       *  Sum: '<S37>/Subtract'
       */
      controlMCUSlugsMKII_B.Merge = (1.0F - rtb_Sum2 * rt_SIGNf_snf(rtb_Deg2R1))
        * rtb_Abs2;
    }

    /* end of Outputs for SubSystem: '<S25>/Enabled Subsystem1' */

    /* Product: '<S13>/Projection' */
    rtb_Abs2 = controlMCUSlugsMKII_B.navSupportc_n[1] *
      controlMCUSlugsMKII_B.Merge;

    /* Sum: '<S13>/Sum4' incorporates:
     *  S-Function (sfix_udelay): '<S13>/Integer Delay'
     */
    rtb_Deg2R1 = controlMCUSlugsMKII_DWork.IntegerDelay_X_no -
      controlMCUSlugsMKII_B.Subtract_b;

    /* Saturate: '<S13>/Psi Dot  Limit' */
    controlMCUSlugsMKII_B.PsiDotLimit_g = rt_SATURATE(rtb_Deg2R1, -1.0F, 1.0F);

    /* Sum: '<S13>/Sum2' incorporates:
     *  S-Function (sfix_udelay): '<S13>/Integer Delay1'
     */
    rtb_Deg2R1 = controlMCUSlugsMKII_B.PsiDotLimit_g +
      controlMCUSlugsMKII_DWork.IntegerDelay1_X_b;

    /* Switch: '<S27>/Switch3' incorporates:
     *  RelationalOperator: '<S27>/Relational Operator2'
     *  S-Function (sfix_udelay): '<S27>/Integer Delay3'
     */
    if ((rtb_Deg2R1 == rtb_Deg2R1) > 0) {
      controlMCUSlugsMKII_B.Switch3_ae = rtb_Deg2R1;
    } else {
      controlMCUSlugsMKII_B.Switch3_ae =
        controlMCUSlugsMKII_DWork.IntegerDelay3_X_gww;
    }

    /* Switch: '<S43>/Switch3' incorporates:
     *  RelationalOperator: '<S43>/Relational Operator2'
     *  S-Function (sfix_udelay): '<S43>/Integer Delay3'
     */
    if ((rtb_Abs2 == rtb_Abs2) > 0) {
      controlMCUSlugsMKII_B.Switch3_gq = rtb_Abs2;
    } else {
      controlMCUSlugsMKII_B.Switch3_gq =
        controlMCUSlugsMKII_DWork.IntegerDelay3_X_oe;
    }

    /* Sum: '<S29>/Subtract1' incorporates:
     *  Constant: '<S29>/Constant'
     *  Constant: '<S29>/Constant1'
     *  Constant: '<S29>/Constant2'
     *  Constant: '<S29>/Constant3'
     *  Product: '<S29>/Product'
     *  Product: '<S29>/Product1'
     *  Product: '<S29>/Product2'
     *  Product: '<S29>/Product3'
     *  S-Function (sfix_udelay): '<S29>/Integer Delay'
     *  S-Function (sfix_udelay): '<S29>/Integer Delay1'
     *  S-Function (sfix_udelay): '<S29>/Integer Delay2'
     *  Sum: '<S29>/Subtract'
     */
    rtb_Deg2R1 = ((controlMCUSlugsMKII_B.Switch3_gq * 3.333333433E-001F +
                   controlMCUSlugsMKII_DWork.IntegerDelay_X_f *
                   1.333333373E+000F) +
                  controlMCUSlugsMKII_DWork.IntegerDelay1_X_ny[0] *
                  3.333333433E-001F) * 4.999999888E-003F +
      controlMCUSlugsMKII_DWork.IntegerDelay2_X_m;

    /* Switch: '<S29>/Switch1' incorporates:
     *  Constant: '<S29>/Constant5'
     *  Logic: '<S13>/Logical Operator'
     *  Saturate: '<S29>/[min max]'
     */
    if (!(controlMCUSlugsMKII_B.navSupportc_g[2] != 0.0F) > 0) {
      rtb_Deg2R1 = 0.0F;
    } else {
      rtb_Deg2R1 = rt_SATURATE(rtb_Deg2R1, -2.0F, 2.0F);
    }

    /* Switch: '<S44>/Switch3' incorporates:
     *  RelationalOperator: '<S44>/Relational Operator2'
     *  S-Function (sfix_udelay): '<S44>/Integer Delay3'
     */
    if ((rtb_Deg2R1 == rtb_Deg2R1) > 0) {
      controlMCUSlugsMKII_B.Switch3_im = rtb_Deg2R1;
    } else {
      controlMCUSlugsMKII_B.Switch3_im =
        controlMCUSlugsMKII_DWork.IntegerDelay3_X_oe1;
    }
  } else {
    if ((int16_T)controlMCUSlugsMKII_DWork.L1OutputFeedbackControllerWithP) {
      controlMCUSlugsMKII_DWork.L1OutputFeedbackControllerWithP = FALSE;
    }
  }

  /* end of Outputs for SubSystem: '<S2>/L1 Output Feedback Controller With  Projection Operator' */
  /* S-Function "dsPIC_C_function_Call" Block: <S9>/Get the Accelerometers [navSupport.c] */
  getAccels(&controlMCUSlugsMKII_B.GettheAccelerometersnavSupportc[0]);

  /* Product: '<S9>/Product2' */
  for (rtb_IC1 = 0; rtb_IC1 < 3; rtb_IC1++) {
    rtb_Product2_cp[rtb_IC1] = rtb_MathFunction[rtb_IC1 + 6] *
      controlMCUSlugsMKII_B.GettheAccelerometersnavSupportc[2] +
      (rtb_MathFunction[rtb_IC1 + 3] *
       controlMCUSlugsMKII_B.GettheAccelerometersnavSupportc[1] +
       rtb_MathFunction[rtb_IC1] *
       controlMCUSlugsMKII_B.GettheAccelerometersnavSupportc[0]);
  }

  /* S-Function "dsPIC_C_function_Call" Block: <S9>/Get the Accel Bias [navSupport.c] */
  getAccBias(&controlMCUSlugsMKII_B.GettheAccelBiasnavSupportc[0]);

  /* Sum: '<S9>/Sum' incorporates:
   *  Product: '<S9>/Product3'
   */
  for (rtb_IC1 = 0; rtb_IC1 < 3; rtb_IC1++) {
    rtb_u525[rtb_IC1] = rtb_Product2_cp[rtb_IC1] + (rtb_MathFunction[rtb_IC1 + 6]
      * controlMCUSlugsMKII_B.GettheAccelBiasnavSupportc[2] +
      (rtb_MathFunction[rtb_IC1 + 3] *
       controlMCUSlugsMKII_B.GettheAccelBiasnavSupportc[1] +
       rtb_MathFunction[rtb_IC1] *
       controlMCUSlugsMKII_B.GettheAccelBiasnavSupportc[0]));
  }

  /* Outputs for atomic SubSystem: '<S2>/Lateral Channel' */

  /* Switch: '<S62>/Switch3' incorporates:
   *  RelationalOperator: '<S62>/Relational Operator2'
   *  S-Function (sfix_udelay): '<S62>/Integer Delay3'
   */
  if ((controlMCUSlugsMKII_B.Switch3_c == controlMCUSlugsMKII_B.Switch3_c) > 0)
  {
    controlMCUSlugsMKII_B.Switch3_gn = controlMCUSlugsMKII_B.Switch3_c;
  } else {
    controlMCUSlugsMKII_B.Switch3_gn =
      controlMCUSlugsMKII_DWork.IntegerDelay3_X_nc;
  }

  /* Saturate: '<S49>/bank Limit' */
  controlMCUSlugsMKII_B.bankLimit = rt_SATURATE(controlMCUSlugsMKII_B.Switch3_gn,
    -7.853981853E-001F, 7.853981853E-001F);

  /* S-Function "dsPIC_C_function_Call" Block: <S64>/C Function Call */
  controlMCUSlugsMKII_B.CFunctionCall_in = myTan(controlMCUSlugsMKII_B.bankLimit);

  /* Switch: '<S63>/Switch3' incorporates:
   *  RelationalOperator: '<S63>/Relational Operator2'
   *  S-Function (sfix_udelay): '<S63>/Integer Delay3'
   */
  if ((controlMCUSlugsMKII_B.ScheduleLPF == controlMCUSlugsMKII_B.ScheduleLPF) >
      0) {
    controlMCUSlugsMKII_B.Switch3_h4 = controlMCUSlugsMKII_B.ScheduleLPF;
  } else {
    controlMCUSlugsMKII_B.Switch3_h4 =
      controlMCUSlugsMKII_DWork.IntegerDelay3_X_gw;
  }

  /* Switch: '<S14>/Switch1' incorporates:
   *  Constant: '<S49>/Constant1'
   *  Product: '<S49>/Divide'
   *  Product: '<S49>/Divide1'
   *  Saturate: '<S49>/[0 40]'
   */
  if (controlMCUSlugsMKII_B.wpFlynavSupportc > 0) {
    rtb_cosphi = 1.0F / rt_SATURATE(controlMCUSlugsMKII_B.Switch3_h4, 0.0F,
      40.0F) * 9.806650162E+000F * controlMCUSlugsMKII_B.CFunctionCall_in;
  } else {
    rtb_cosphi = controlMCUSlugsMKII_B.GetMidLevelCommandsnavSupportc[2];
  }

  /* Saturate: '<S14>/Psi Dot  Limit' */
  controlMCUSlugsMKII_B.PsiDotLimit = rt_SATURATE(rtb_cosphi, -1.0F, 1.0F);

  /* Switch: '<S14>/Switch' */
  if (controlMCUSlugsMKII_B.navSupportc_g[2] > 3.000000119E-001F) {
    rtb_Switch_d = controlMCUSlugsMKII_B.PsiDotLimit_g;
  } else {
    rtb_Switch_d = controlMCUSlugsMKII_B.PsiDotLimit;
  }

  /* Outputs for enable SubSystem: '<S14>/Sideslip Compensation' incorporates:
   *  EnablePort: '<S56>/Enable'
   */
  if (controlMCUSlugsMKII_B.navSupportc_n[2] > 0.0F) {
    if (!((int16_T)controlMCUSlugsMKII_DWork.SideslipCompensation_MODE != 0)) {
      /* InitializeConditions for UnitDelay: '<S79>/UD' */
      controlMCUSlugsMKII_DWork.UD_DSTATE_o = 0.0F;

      /* InitializeConditions for S-Function (sfix_udelay): '<S71>/Integer Delay' */
      controlMCUSlugsMKII_DWork.IntegerDelay_X_b = 0.0F;

      /* InitializeConditions for S-Function (sfix_udelay): '<S71>/Integer Delay1' */
      controlMCUSlugsMKII_DWork.IntegerDelay1_X_f5 = 0.0;

      /* InitializeConditions for S-Function (sfix_udelay): '<S72>/Integer Delay3' */
      controlMCUSlugsMKII_DWork.IntegerDelay3_X_hc = 0.0F;
      controlMCUSlugsMKII_DWork.SideslipCompensation_MODE = TRUE;
    }

    /* Embedded MATLAB: '<S70>/negprotect' */
    controlMCUSlugsM_negprotect(controlMCUSlugsMKII_B.ScheduleLPF,
      &controlMCUSlugsMKII_B.sf_negprotect);

    /* Product: '<S70>/Divide' incorporates:
     *  Constant: '<S70>/Constant1'
     */
    rtb_Sum2 = 1.0F / controlMCUSlugsMKII_B.sf_negprotect.zpVal *
      9.806650162E+000F;

    /* Saturate: '<S70>/bank Limit' */
    controlMCUSlugsMKII_B.bankLimit_a = rt_SATURATE(controlMCUSlugsMKII_B.y[0],
      -7.853981853E-001F, 7.853981853E-001F);

    /* S-Function "dsPIC_C_function_Call" Block: <S74>/C Function Call */
    controlMCUSlugsMKII_B.CFunctionCall_gd = myTan
      (controlMCUSlugsMKII_B.bankLimit_a);

    /* Abs: '<S78>/Abs1' incorporates:
     *  Constant: '<S56>/Constant'
     *  Sum: '<S79>/Diff'
     *  UnitDelay: '<S79>/UD'
     */
    rtb_Abs2 = (real32_T)fabs(3.000000119E-001F -
      controlMCUSlugsMKII_DWork.UD_DSTATE_o);

    /* InitialCondition: '<S71>/IC' incorporates:
     *  Saturate: '<S78>/Saturation1'
     */
    if (controlMCUSlugsMKII_DWork.IC_FirstOutputTime_e) {
      controlMCUSlugsMKII_DWork.IC_FirstOutputTime_e = FALSE;
      rtb_Abs2 = 1.0F;
    } else {
      rtb_Abs2 = rt_SATURATE(rtb_Abs2, 0.0F, 1.0F);
    }

    /* Outputs for enable SubSystem: '<S71>/Compute Coef' incorporates:
     *  EnablePort: '<S77>/Enable'
     */
    if (rtb_Abs2 > 0.0F) {
      /* Math: '<S77>/Math Function' incorporates:
       *  Constant: '<S56>/Constant'
       *  Gain: '<S77>/-T'
       *
       * About '<S77>/Math Function':
       *  Operator: exp
       */
      controlMCUSlugsMKII_B.c = 9.970045090E-001F;

      /* Sum: '<S77>/1-c' incorporates:
       *  Constant: '<S77>/Constant'
       */
      controlMCUSlugsMKII_B.c_k = (real32_T)(1.0 - (real_T)
        controlMCUSlugsMKII_B.c);
    }

    /* end of Outputs for SubSystem: '<S71>/Compute Coef' */

    /* Sum: '<S71>/Subtract' incorporates:
     *  Product: '<S71>/Divide'
     *  Product: '<S71>/Divide1'
     *  S-Function (sfix_udelay): '<S71>/Integer Delay'
     *  S-Function (sfix_udelay): '<S71>/Integer Delay1'
     */
    controlMCUSlugsMKII_B.Subtract = (real_T)(controlMCUSlugsMKII_B.c_k *
      controlMCUSlugsMKII_DWork.IntegerDelay_X_b) + (real_T)
      controlMCUSlugsMKII_B.c * controlMCUSlugsMKII_DWork.IntegerDelay1_X_f5;

    /* S-Function (sfix_udelay): '<S72>/Integer Delay3' */
    rtb_Abs2 = controlMCUSlugsMKII_DWork.IntegerDelay3_X_hc;

    /* Product: '<S73>/Divide' incorporates:
     *  Constant: '<S73>/Constant1'
     *  Product: '<S70>/Divide1'
     *  Sum: '<S56>/Subtract'
     */
    controlMCUSlugsMKII_B.Divide_a = (controlMCUSlugsMKII_B.CFunctionCall_gd *
      rtb_Sum2 - controlMCUSlugsMKII_B.y[5]) * controlMCUSlugsMKII_B.ScheduleLPF
      / 9.806650162E+000F;

    /* S-Function "dsPIC_C_function_Call" Block: <S80>/C Function Call */
    controlMCUSlugsMKII_B.CFunctionCall_id = myAtan
      (controlMCUSlugsMKII_B.Divide_a);

    /* Switch: '<S72>/Switch3' incorporates:
     *  RelationalOperator: '<S72>/Relational Operator2'
     */
    if ((controlMCUSlugsMKII_B.CFunctionCall_id ==
         controlMCUSlugsMKII_B.CFunctionCall_id) > 0) {
      controlMCUSlugsMKII_B.Switch3_pq = controlMCUSlugsMKII_B.CFunctionCall_id;
    } else {
      controlMCUSlugsMKII_B.Switch3_pq = rtb_Abs2;
    }

    /* Update for UnitDelay: '<S79>/UD' incorporates:
     *  Constant: '<S56>/Constant'
     */
    controlMCUSlugsMKII_DWork.UD_DSTATE_o = 3.000000119E-001F;

    /* Update for S-Function (sfix_udelay): '<S71>/Integer Delay' */
    controlMCUSlugsMKII_DWork.IntegerDelay_X_b =
      controlMCUSlugsMKII_B.Switch3_pq;

    /* Update for S-Function (sfix_udelay): '<S71>/Integer Delay1' */
    controlMCUSlugsMKII_DWork.IntegerDelay1_X_f5 =
      controlMCUSlugsMKII_B.Subtract;

    /* Update for S-Function (sfix_udelay): '<S72>/Integer Delay3' */
    controlMCUSlugsMKII_DWork.IntegerDelay3_X_hc =
      controlMCUSlugsMKII_B.Switch3_pq;
  } else {
    if ((int16_T)controlMCUSlugsMKII_DWork.SideslipCompensation_MODE) {
      /* Disable for Outport: '<S56>/bankComp' */
      controlMCUSlugsMKII_B.Subtract = 0.0;
      controlMCUSlugsMKII_DWork.SideslipCompensation_MODE = FALSE;
    }
  }

  /* end of Outputs for SubSystem: '<S14>/Sideslip Compensation' */

  /* Product: '<S60>/Divide' incorporates:
   *  Constant: '<S60>/Constant1'
   */
  controlMCUSlugsMKII_B.Divide_m = rtb_Switch_d *
    controlMCUSlugsMKII_B.ScheduleLPF / 9.806650162E+000F;

  /* S-Function "dsPIC_C_function_Call" Block: <S86>/C Function Call */
  controlMCUSlugsMKII_B.CFunctionCall_i4 = myAtan(controlMCUSlugsMKII_B.Divide_m);

  /* Sum: '<S14>/Add2' */
  rtb_cosphi = (real32_T)(controlMCUSlugsMKII_B.Subtract + (real_T)
    controlMCUSlugsMKII_B.CFunctionCall_i4);

  /* Saturate: '<S14>/Bank  Limit Command' */
  rtb_BankLimitCommand = rt_SATURATE(rtb_cosphi, -7.853981853E-001F,
    7.853981853E-001F);

  /* Switch: '<S53>/Switch3' incorporates:
   *  RelationalOperator: '<S53>/Relational Operator2'
   *  S-Function (sfix_udelay): '<S53>/Integer Delay3'
   */
  if ((rtb_u525[1] == rtb_u525[1]) > 0) {
    controlMCUSlugsMKII_B.Switch3_pa = rtb_u525[1];
  } else {
    controlMCUSlugsMKII_B.Switch3_pa =
      controlMCUSlugsMKII_DWork.IntegerDelay3_X_h;
  }

  /* Saturate: '<S14>/[-20 20]' */
  rtb_u020_g = rt_SATURATE(controlMCUSlugsMKII_B.Switch3_pa, -20.0F, 20.0F);

  /* Embedded MATLAB: '<S45>/Embedded MATLAB Function' */
  cont_EmbeddedMATLABFunction(rtb_u020_g, 0.01, 0.3183,
    &controlMCUSlugsMKII_B.sf_EmbeddedMATLABFunction_h,
    &controlMCUSlugsMKII_DWork.sf_EmbeddedMATLABFunction_h);

  /* S-Function "dsPIC_C_function_Call" Block: <S14>/[navSupport.c]    */
  getPidIdx(((uint8_T)9U),&controlMCUSlugsMKII_B.navSupportc_l[0]);

  /* Switch: '<S54>/Switch3' incorporates:
   *  RelationalOperator: '<S54>/Relational Operator2'
   *  S-Function (sfix_udelay): '<S54>/Integer Delay3'
   */
  if ((controlMCUSlugsMKII_B.y[5] == controlMCUSlugsMKII_B.y[5]) > 0) {
    controlMCUSlugsMKII_B.Switch3_fx = controlMCUSlugsMKII_B.y[5];
  } else {
    controlMCUSlugsMKII_B.Switch3_fx =
      controlMCUSlugsMKII_DWork.IntegerDelay3_X_ae;
  }

  /* Saturate: '<S14>/[-2 2]' */
  controlMCUSlugsMKII_B.u2 = rt_SATURATE(controlMCUSlugsMKII_B.Switch3_fx, -2.0F,
    2.0F);

  /* Outputs for atomic SubSystem: '<S14>/High Pass (Washout) Filter' */

  /* Sum: '<S50>/Subtract' incorporates:
   *  Constant: '<S50>/Constant1'
   *  Constant: '<S50>/Constant2'
   *  Constant: '<S50>/Constant3'
   *  Product: '<S50>/Product'
   *  Product: '<S50>/Product1'
   *  Product: '<S50>/Product2'
   *  S-Function (sfix_udelay): '<S50>/Integer Delay'
   *  S-Function (sfix_udelay): '<S50>/Integer Delay1'
   */
  rtb_Abs2 = (9.991999865E-001F * controlMCUSlugsMKII_B.u2 -
              controlMCUSlugsMKII_DWork.IntegerDelay_X_nm * 9.991999865E-001F) +
    controlMCUSlugsMKII_DWork.IntegerDelay1_X_l * 9.983000159E-001F;

  /* Saturate: '<S50>/[-2 2]' */
  controlMCUSlugsMKII_B.u2_o = rt_SATURATE(rtb_Abs2, -2.0F, 2.0F);

  /* Update for S-Function (sfix_udelay): '<S50>/Integer Delay' */
  controlMCUSlugsMKII_DWork.IntegerDelay_X_nm = controlMCUSlugsMKII_B.u2;

  /* Update for S-Function (sfix_udelay): '<S50>/Integer Delay1' */
  controlMCUSlugsMKII_DWork.IntegerDelay1_X_l = controlMCUSlugsMKII_B.u2_o;

  /* end of Outputs for SubSystem: '<S14>/High Pass (Washout) Filter' */

  /* Switch: '<S14>/Switch2' incorporates:
   *  Gain: '<S14>/Neg Feedback '
   *  Gain: '<S14>/Neg Feedback'
   */
  if (controlMCUSlugsMKII_B.navSupportc_l[0] > 3.000000119E-001F) {
    rtb_cosphi = -controlMCUSlugsMKII_B.sf_EmbeddedMATLABFunction_h.y;
  } else {
    rtb_cosphi = -controlMCUSlugsMKII_B.u2_o;
  }

  /* Switch: '<S52>/Switch3' incorporates:
   *  RelationalOperator: '<S52>/Relational Operator2'
   *  S-Function (sfix_udelay): '<S52>/Integer Delay3'
   */
  if ((rtb_cosphi == rtb_cosphi) > 0) {
    controlMCUSlugsMKII_B.Switch3_my = rtb_cosphi;
  } else {
    controlMCUSlugsMKII_B.Switch3_my =
      controlMCUSlugsMKII_DWork.IntegerDelay3_X_b5;
  }

  /* Embedded MATLAB: '<S14>/myMux Fun1' */
  controlMCUSlugsMK_myMuxFun1(rtb_Switch_d, rtb_BankLimitCommand,
    controlMCUSlugsMKII_B.Switch3_my, &controlMCUSlugsMKII_B.sf_myMuxFun1_h);

  /* S-Function "dsPIC_C_function_Call" Block: <S14>/Get XYZ [navSupport.c] */
  setNavLat(controlMCUSlugsMKII_B.sf_myMuxFun1_h.y);

  /* Sum: '<S57>/Add3' incorporates:
   *  Constant: '<S57>/SaturationLimit'
   */
  rtb_Abs2 = 1.745329201E-001F - controlMCUSlugsMKII_B.DataTypeConversion_b;

  /* Sum: '<S57>/Add1' incorporates:
   *  Constant: '<S57>/delayTime'
   *  Product: '<S57>/Product1'
   *  Product: '<S57>/Product2'
   *  Product: '<S57>/Product3'
   *  S-Function (sfix_udelay): '<S57>/NDelays'
   *  Sum: '<S57>/Sum'
   */
  rtb_sinphi = (controlMCUSlugsMKII_B.Switch3_my -
                controlMCUSlugsMKII_DWork.NDelays_X_e[0]) / 5.000000075E-002F *
    controlMCUSlugsMKII_B.GetPidaccordingtoIndex3[2] +
    controlMCUSlugsMKII_B.Switch3_my *
    controlMCUSlugsMKII_B.GetPidaccordingtoIndex3[0];

  /* Sum: '<S57>/Sum2' incorporates:
   *  Gain: '<S57>/Gain'
   *  Memory: '<S57>/Memory1'
   *  Product: '<S57>/Product4'
   */
  rtb_cosphi = (9.999999776E-003F * controlMCUSlugsMKII_B.Switch3_my *
                controlMCUSlugsMKII_B.GetPidaccordingtoIndex3[1] +
                controlMCUSlugsMKII_DWork.Memory1_PreviousInput_a) + rtb_sinphi;

  /* Sum: '<S57>/Add4' incorporates:
   *  Constant: '<S57>/SaturationLimit1'
   */
  rtb_Sum2 = -1.745329201E-001F - controlMCUSlugsMKII_B.DataTypeConversion_b;

  /* Switch: '<S57>/AntiWindup' incorporates:
   *  Constant: '<S57>/Constant5'
   *  Logic: '<S57>/Logical Operator'
   *  RelationalOperator: '<S57>/Relational Operator'
   *  RelationalOperator: '<S57>/Relational Operator1'
   */
  if ((rtb_cosphi > rtb_Sum2) && (rtb_cosphi < rtb_Abs2)) {
    rtb_DataTypeConversion = controlMCUSlugsMKII_B.Switch3_my;
  } else {
    rtb_DataTypeConversion = 0.0;
  }

  /* Switch: '<S84>/Switch3' incorporates:
   *  RelationalOperator: '<S84>/Relational Operator2'
   *  S-Function (sfix_udelay): '<S84>/Integer Delay3'
   */
  if ((rtb_DataTypeConversion == rtb_DataTypeConversion) > 0) {
    controlMCUSlugsMKII_B.Switch3_g = rtb_DataTypeConversion;
  } else {
    controlMCUSlugsMKII_B.Switch3_g =
      controlMCUSlugsMKII_DWork.IntegerDelay3_X_o;
  }

  /* Switch: '<S83>/Switch1' incorporates:
   *  Constant: '<S83>/Constant'
   *  Constant: '<S83>/Constant1'
   *  Constant: '<S83>/Constant2'
   *  Constant: '<S83>/Constant3'
   *  Constant: '<S83>/Constant5'
   *  Product: '<S83>/Product'
   *  Product: '<S83>/Product1'
   *  Product: '<S83>/Product2'
   *  Product: '<S83>/Product3'
   *  S-Function (sfix_udelay): '<S83>/Integer Delay'
   *  S-Function (sfix_udelay): '<S83>/Integer Delay1'
   *  S-Function (sfix_udelay): '<S83>/Integer Delay2'
   *  Sum: '<S83>/Subtract'
   *  Sum: '<S83>/Subtract1'
   */
  if (controlMCUSlugsMKII_B.ManualorAutonavSupportc > 0) {
    rtb_cosphi = 0.0F;
  } else {
    rtb_cosphi = (((real32_T)(controlMCUSlugsMKII_B.Switch3_g *
      3.3333334326744080E-001) + (real32_T)
                   (controlMCUSlugsMKII_DWork.IntegerDelay_X_i0 *
                    1.3333333730697632E+000)) + (real32_T)
                  (controlMCUSlugsMKII_DWork.IntegerDelay1_X_f[0] *
                   3.3333334326744080E-001)) * 4.999999888E-003F +
      controlMCUSlugsMKII_DWork.IntegerDelay2_X_g;
  }

  /* Switch: '<S85>/Switch3' incorporates:
   *  RelationalOperator: '<S85>/Relational Operator2'
   *  S-Function (sfix_udelay): '<S85>/Integer Delay3'
   */
  if ((rtb_cosphi == rtb_cosphi) > 0) {
    controlMCUSlugsMKII_B.Switch3_pf = rtb_cosphi;
  } else {
    controlMCUSlugsMKII_B.Switch3_pf =
      controlMCUSlugsMKII_DWork.IntegerDelay3_X_cn;
  }

  /* Sum: '<S57>/Add2' incorporates:
   *  Product: '<S57>/Product'
   */
  rtb_Ze = controlMCUSlugsMKII_B.Switch3_pf *
    controlMCUSlugsMKII_B.GetPidaccordingtoIndex3[1] + rtb_sinphi;

  /* Switch: '<S14>/Switch3' incorporates:
   *  Gain: '<S46>/Unit Conversion'
   *  Sum: '<S14>/Add'
   */
  if (controlMCUSlugsMKII_B.navSupportc_l[1] > 3.000000119E-001F) {
    rtb_Abs2 = 1.745329238E-002F * controlMCUSlugsMKII_B.navSupportc_l[2];
  } else {
    /* Switch: '<S82>/Switch2' incorporates:
     *  RelationalOperator: '<S82>/LowerRelop1'
     */
    if (rtb_Ze > rtb_Abs2) {
      rtb_Sum2 = rtb_Abs2;
    } else {
      /* Switch: '<S82>/Switch' incorporates:
       *  RelationalOperator: '<S82>/UpperRelop'
       */
      if (!(rtb_Ze < rtb_Sum2)) {
        rtb_Sum2 = rtb_Ze;
      }
    }

    rtb_Abs2 = rtb_Sum2 + controlMCUSlugsMKII_B.DataTypeConversion_b;
  }

  /* Saturate: '<S14>/Rudder Limit' */
  rtb_Sum2 = rt_SATURATE(rtb_Abs2, -1.745329201E-001F, 1.745329201E-001F);

  /* Embedded MATLAB: '<S14>/myMux Fun3' */
  /* Embedded MATLAB Function 'Inner Loop/ Navigation/Lateral Channel/myMux Fun3': '<S59>:1' */
  /*  This block supports an embeddable subset of the MATLAB language. */
  /*  See the help menu for details.  */
  /* '<S59>:1:5' */

  /* DataTypeConversion: '<S14>/Data Type Conversion2' incorporates:
   *  Gain: '<S14>/Gain3'
   *  Gain: '<S47>/Unit Conversion'
   *  Gain: '<S48>/Unit Conversion'
   */
  rtb_cosphi = 5.729578018E+001F * rtb_Sum2 * 100.0F;
  if (rtIsNaNF(rtb_cosphi) || rtIsInfF(rtb_cosphi)) {
    rtb_cosphi = 0.0F;
  } else {
    rtb_cosphi = (real32_T)fmod((real32_T)floor(rtb_cosphi), 65536.0F);
  }

  controlMCUSlugsMKII_B.DataTypeConversion2[0] = rtb_cosphi < 0.0F ? -((int16_T)
    (uint16_T)(-rtb_cosphi)) : (int16_T)(uint16_T)rtb_cosphi;
  rtb_cosphi = 100.0F * controlMCUSlugsMKII_B.navSupportc_l[1];
  if (rtIsNaNF(rtb_cosphi) || rtIsInfF(rtb_cosphi)) {
    rtb_cosphi = 0.0F;
  } else {
    rtb_cosphi = (real32_T)fmod((real32_T)floor(rtb_cosphi), 65536.0F);
  }

  controlMCUSlugsMKII_B.DataTypeConversion2[1] = rtb_cosphi < 0.0F ? -((int16_T)
    (uint16_T)(-rtb_cosphi)) : (int16_T)(uint16_T)rtb_cosphi;
  rtb_cosphi = (real32_T)(5.7295779513082323E+001 *
    controlMCUSlugsMKII_B.Subtract) * 100.0F;
  if (rtIsNaNF(rtb_cosphi) || rtIsInfF(rtb_cosphi)) {
    rtb_cosphi = 0.0F;
  } else {
    rtb_cosphi = (real32_T)fmod((real32_T)floor(rtb_cosphi), 65536.0F);
  }

  controlMCUSlugsMKII_B.DataTypeConversion2[2] = rtb_cosphi < 0.0F ? -((int16_T)
    (uint16_T)(-rtb_cosphi)) : (int16_T)(uint16_T)rtb_cosphi;

  /* S-Function "dsPIC_C_function_Call" Block: <S14>/Get XYZ [navSupport.c]2 */
  setDiagnosticShort(controlMCUSlugsMKII_B.DataTypeConversion2);

  /* Sum: '<S14>/Add1' */
  rtb_Abs2 = rtb_BankLimitCommand - controlMCUSlugsMKII_B.y[0];

  /* Sum: '<S55>/Add3' incorporates:
   *  Constant: '<S55>/SaturationLimit'
   */
  rtb_sinphi = 2.792526782E-001F - controlMCUSlugsMKII_B.DataTypeConversion_f;

  /* Switch: '<S51>/Switch3' incorporates:
   *  RelationalOperator: '<S51>/Relational Operator2'
   *  S-Function (sfix_udelay): '<S51>/Integer Delay3'
   */
  if ((rtb_Abs2 == rtb_Abs2) > 0) {
    controlMCUSlugsMKII_B.Switch3_i = rtb_Abs2;
  } else {
    controlMCUSlugsMKII_B.Switch3_i =
      controlMCUSlugsMKII_DWork.IntegerDelay3_X_mk;
  }

  /* Sum: '<S55>/Add1' incorporates:
   *  Constant: '<S55>/delayTime'
   *  Product: '<S55>/Product1'
   *  Product: '<S55>/Product2'
   *  Product: '<S55>/Product3'
   *  S-Function (sfix_udelay): '<S55>/NDelays'
   *  Sum: '<S55>/Sum'
   */
  rtb_Abs2 = (controlMCUSlugsMKII_B.Switch3_i -
              controlMCUSlugsMKII_DWork.NDelays_X_m[0]) / 5.000000075E-002F *
    controlMCUSlugsMKII_B.navSupportc_k[2] + controlMCUSlugsMKII_B.Switch3_i *
    controlMCUSlugsMKII_B.navSupportc_k[0];

  /* Sum: '<S55>/Sum2' incorporates:
   *  Gain: '<S55>/Gain'
   *  Memory: '<S55>/Memory1'
   *  Product: '<S55>/Product4'
   */
  rtb_cosphi = (9.999999776E-003F * controlMCUSlugsMKII_B.Switch3_i *
                controlMCUSlugsMKII_B.navSupportc_k[1] +
                controlMCUSlugsMKII_DWork.Memory1_PreviousInput_l) + rtb_Abs2;

  /* Sum: '<S55>/Add4' incorporates:
   *  Constant: '<S55>/SaturationLimit1'
   */
  rtb_Deg2R1 = -2.792526782E-001F - controlMCUSlugsMKII_B.DataTypeConversion_f;

  /* Switch: '<S55>/AntiWindup' incorporates:
   *  Constant: '<S55>/Constant5'
   *  Logic: '<S55>/Logical Operator'
   *  RelationalOperator: '<S55>/Relational Operator'
   *  RelationalOperator: '<S55>/Relational Operator1'
   */
  if ((rtb_cosphi > rtb_Deg2R1) && (rtb_cosphi < rtb_sinphi)) {
    rtb_DataTypeConversion = controlMCUSlugsMKII_B.Switch3_i;
  } else {
    rtb_DataTypeConversion = 0.0;
  }

  /* Switch: '<S68>/Switch3' incorporates:
   *  RelationalOperator: '<S68>/Relational Operator2'
   *  S-Function (sfix_udelay): '<S68>/Integer Delay3'
   */
  if ((rtb_DataTypeConversion == rtb_DataTypeConversion) > 0) {
    controlMCUSlugsMKII_B.Switch3_na = rtb_DataTypeConversion;
  } else {
    controlMCUSlugsMKII_B.Switch3_na =
      controlMCUSlugsMKII_DWork.IntegerDelay3_X_j;
  }

  /* Switch: '<S67>/Switch1' incorporates:
   *  Constant: '<S67>/Constant'
   *  Constant: '<S67>/Constant1'
   *  Constant: '<S67>/Constant2'
   *  Constant: '<S67>/Constant3'
   *  Constant: '<S67>/Constant5'
   *  Product: '<S67>/Product'
   *  Product: '<S67>/Product1'
   *  Product: '<S67>/Product2'
   *  Product: '<S67>/Product3'
   *  S-Function (sfix_udelay): '<S67>/Integer Delay'
   *  S-Function (sfix_udelay): '<S67>/Integer Delay1'
   *  S-Function (sfix_udelay): '<S67>/Integer Delay2'
   *  Sum: '<S67>/Subtract'
   *  Sum: '<S67>/Subtract1'
   */
  if (controlMCUSlugsMKII_B.ManualorAutonavSupportc > 0) {
    rtb_cosphi = 0.0F;
  } else {
    rtb_cosphi = (((real32_T)(controlMCUSlugsMKII_B.Switch3_na *
      3.3333334326744080E-001) + (real32_T)
                   (controlMCUSlugsMKII_DWork.IntegerDelay_X_n *
                    1.3333333730697632E+000)) + (real32_T)
                  (controlMCUSlugsMKII_DWork.IntegerDelay1_X_n[0] *
                   3.3333334326744080E-001)) * 4.999999888E-003F +
      controlMCUSlugsMKII_DWork.IntegerDelay2_X_j;
  }

  /* Switch: '<S69>/Switch3' incorporates:
   *  RelationalOperator: '<S69>/Relational Operator2'
   *  S-Function (sfix_udelay): '<S69>/Integer Delay3'
   */
  if ((rtb_cosphi == rtb_cosphi) > 0) {
    controlMCUSlugsMKII_B.Switch3_cv = rtb_cosphi;
  } else {
    controlMCUSlugsMKII_B.Switch3_cv =
      controlMCUSlugsMKII_DWork.IntegerDelay3_X_hp;
  }

  /* Sum: '<S55>/Add2' incorporates:
   *  Product: '<S55>/Product'
   */
  rtb_Abs2 += controlMCUSlugsMKII_B.Switch3_cv *
    controlMCUSlugsMKII_B.navSupportc_k[1];

  /* Switch: '<S66>/Switch2' incorporates:
   *  RelationalOperator: '<S66>/LowerRelop1'
   */
  if (!(rtb_Abs2 > rtb_sinphi)) {
    /* Switch: '<S66>/Switch' incorporates:
     *  RelationalOperator: '<S66>/UpperRelop'
     */
    if (!(rtb_Abs2 < rtb_Deg2R1)) {
      rtb_Deg2R1 = rtb_Abs2;
    }

    rtb_sinphi = rtb_Deg2R1;
  }

  /* Sum: '<S14>/Add3' */
  rtb_sinphi += controlMCUSlugsMKII_B.DataTypeConversion_f;

  /* Update for S-Function (sfix_udelay): '<S62>/Integer Delay3' */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_nc =
    controlMCUSlugsMKII_B.Switch3_gn;

  /* Update for S-Function (sfix_udelay): '<S63>/Integer Delay3' */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_gw =
    controlMCUSlugsMKII_B.Switch3_h4;

  /* Update for S-Function (sfix_udelay): '<S53>/Integer Delay3' */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_h = controlMCUSlugsMKII_B.Switch3_pa;

  /* Update for S-Function (sfix_udelay): '<S54>/Integer Delay3' */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_ae =
    controlMCUSlugsMKII_B.Switch3_fx;

  /* Update for S-Function (sfix_udelay): '<S52>/Integer Delay3' */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_b5 =
    controlMCUSlugsMKII_B.Switch3_my;

  /* Update for S-Function (sfix_udelay): '<S57>/NDelays' */
  controlMCUSlugsMKII_DWork.NDelays_X_e[0] =
    controlMCUSlugsMKII_DWork.NDelays_X_e[1];
  controlMCUSlugsMKII_DWork.NDelays_X_e[1] =
    controlMCUSlugsMKII_DWork.NDelays_X_e[2];
  controlMCUSlugsMKII_DWork.NDelays_X_e[2] =
    controlMCUSlugsMKII_DWork.NDelays_X_e[3];
  controlMCUSlugsMKII_DWork.NDelays_X_e[3] =
    controlMCUSlugsMKII_DWork.NDelays_X_e[4];
  controlMCUSlugsMKII_DWork.NDelays_X_e[4] = controlMCUSlugsMKII_B.Switch3_my;

  /* Update for S-Function (sfix_udelay): '<S83>/Integer Delay2' */
  controlMCUSlugsMKII_DWork.IntegerDelay2_X_g = controlMCUSlugsMKII_B.Switch3_pf;

  /* Update for Memory: '<S57>/Memory1' */
  controlMCUSlugsMKII_DWork.Memory1_PreviousInput_a = rtb_Ze;

  /* Update for S-Function (sfix_udelay): '<S84>/Integer Delay3' */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_o = controlMCUSlugsMKII_B.Switch3_g;

  /* Update for S-Function (sfix_udelay): '<S83>/Integer Delay' */
  controlMCUSlugsMKII_DWork.IntegerDelay_X_i0 = controlMCUSlugsMKII_B.Switch3_g;

  /* Update for S-Function (sfix_udelay): '<S83>/Integer Delay1' */
  controlMCUSlugsMKII_DWork.IntegerDelay1_X_f[0] =
    controlMCUSlugsMKII_DWork.IntegerDelay1_X_f[1];
  controlMCUSlugsMKII_DWork.IntegerDelay1_X_f[1] =
    controlMCUSlugsMKII_B.Switch3_g;

  /* Update for S-Function (sfix_udelay): '<S85>/Integer Delay3' */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_cn =
    controlMCUSlugsMKII_B.Switch3_pf;

  /* Update for S-Function (sfix_udelay): '<S51>/Integer Delay3' */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_mk = controlMCUSlugsMKII_B.Switch3_i;

  /* Update for S-Function (sfix_udelay): '<S55>/NDelays' */
  controlMCUSlugsMKII_DWork.NDelays_X_m[0] =
    controlMCUSlugsMKII_DWork.NDelays_X_m[1];
  controlMCUSlugsMKII_DWork.NDelays_X_m[1] =
    controlMCUSlugsMKII_DWork.NDelays_X_m[2];
  controlMCUSlugsMKII_DWork.NDelays_X_m[2] =
    controlMCUSlugsMKII_DWork.NDelays_X_m[3];
  controlMCUSlugsMKII_DWork.NDelays_X_m[3] =
    controlMCUSlugsMKII_DWork.NDelays_X_m[4];
  controlMCUSlugsMKII_DWork.NDelays_X_m[4] = controlMCUSlugsMKII_B.Switch3_i;

  /* Update for S-Function (sfix_udelay): '<S67>/Integer Delay2' */
  controlMCUSlugsMKII_DWork.IntegerDelay2_X_j = controlMCUSlugsMKII_B.Switch3_cv;

  /* Update for Memory: '<S55>/Memory1' */
  controlMCUSlugsMKII_DWork.Memory1_PreviousInput_l = rtb_Abs2;

  /* Update for S-Function (sfix_udelay): '<S68>/Integer Delay3' */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_j = controlMCUSlugsMKII_B.Switch3_na;

  /* Update for S-Function (sfix_udelay): '<S67>/Integer Delay' */
  controlMCUSlugsMKII_DWork.IntegerDelay_X_n = controlMCUSlugsMKII_B.Switch3_na;

  /* Update for S-Function (sfix_udelay): '<S67>/Integer Delay1' */
  controlMCUSlugsMKII_DWork.IntegerDelay1_X_n[0] =
    controlMCUSlugsMKII_DWork.IntegerDelay1_X_n[1];
  controlMCUSlugsMKII_DWork.IntegerDelay1_X_n[1] =
    controlMCUSlugsMKII_B.Switch3_na;

  /* Update for S-Function (sfix_udelay): '<S69>/Integer Delay3' */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_hp =
    controlMCUSlugsMKII_B.Switch3_cv;

  /* end of Outputs for SubSystem: '<S2>/Lateral Channel' */

  /* Embedded MATLAB: '<Root>/myMux Fun1' incorporates:
   *  Saturate: '<S14>/Aileron Limit'
   */
  /* Embedded MATLAB Function 'myMux Fun1': '<S10>:1' */
  /*  This block supports an embeddable subset of the MATLAB language. */
  /*  See the help menu for details.  */
  /* '<S10>:1:5' */
  rtb_cosphi = rt_SATURATE(rtb_sinphi, -2.792526782E-001F, 2.792526782E-001F);

  /* If: '<S291>/If' incorporates:
   *  ActionPort: '<S293>/Action Port'
   *  ActionPort: '<S294>/Action Port'
   *  ActionPort: '<S295>/Action Port'
   *  ActionPort: '<S296>/Action Port'
   *  SubSystem: '<S291>/If  Control Type Is Manual'
   *  SubSystem: '<S291>/If  Control Type Is Passthrough'
   *  SubSystem: '<S291>/If  Control Type Is Selective Passthrough'
   *  SubSystem: '<S291>/If  Control Type Is Wp Follow  or Inner Cmds'
   */
  if (controlMCUSlugsMKII_B.GetControlTypenavSupportc == 1) {
    /* Gain: '<S293>/Gain' */
    rtb_Gain_fi = rtb_y_n[0] >> 1;

    /* Gain: '<S293>/Gain1' */
    rtb_Gain1_cp = rtb_y_n[1] >> 1;

    /* Gain: '<S293>/Gain2' */
    rtb_Gain2_f = rtb_y_n[3] >> 1;

    /* Gain: '<S293>/Gain3' */
    rtb_Gain3_j = rtb_y_n[2] >> 1;

    /* Embedded MATLAB: '<S293>/myMux Fun1' */
    controlMCUSlugs_myMuxFun1_a(rtb_Gain_fi, rtb_Gain1_cp, rtb_Gain2_f,
      rtb_Gain3_j, controlMCUSlugsMKII_B.Merge_n);
  } else if ((controlMCUSlugsMKII_B.GetControlTypenavSupportc == 2) ||
             (controlMCUSlugsMKII_B.GetControlTypenavSupportc == 3)) {
    /* DataTypeConversion: '<S304>/Data Type Conversion' incorporates:
     *  Constant: '<S304>/Constant1'
     *  Constant: '<S304>/Constant2'
     *  Product: '<S304>/Divide'
     *  Sum: '<S304>/Add'
     */
    rtb_DataTypeConversion = (real_T)rtb_u020 * 3.9411311193641609E+003 +
      3.7764285714285716E+003;
    if (rtIsNaN(rtb_DataTypeConversion) || rtIsInf(rtb_DataTypeConversion)) {
      rtb_DataTypeConversion = 0.0;
    } else {
      rtb_DataTypeConversion = fmod(floor(rtb_DataTypeConversion), 65536.0);
    }

    rtb_DataTypeConversion_k = rtb_DataTypeConversion < 0.0 ? (uint16_T)
      (-((int16_T)(uint16_T)(-rtb_DataTypeConversion))) : (uint16_T)
      rtb_DataTypeConversion;

    /* DataTypeConversion: '<S305>/Data Type Conversion' incorporates:
     *  Constant: '<S305>/Constant1'
     *  Constant: '<S305>/Constant2'
     *  Product: '<S305>/Divide'
     *  Sum: '<S305>/Add'
     */
    rtb_DataTypeConversion = (real_T)rtb_Product1_m * 1274.0 + 3176.0;
    if (rtIsNaN(rtb_DataTypeConversion) || rtIsInf(rtb_DataTypeConversion)) {
      rtb_DataTypeConversion = 0.0;
    } else {
      rtb_DataTypeConversion = fmod(floor(rtb_DataTypeConversion), 65536.0);
    }

    rtb_DataTypeConversion_o = rtb_DataTypeConversion < 0.0 ? (uint16_T)
      (-((int16_T)(uint16_T)(-rtb_DataTypeConversion))) : (uint16_T)
      rtb_DataTypeConversion;

    /* DataTypeConversion: '<S306>/Data Type Conversion' incorporates:
     *  Constant: '<S306>/Constant1'
     *  Constant: '<S306>/Constant2'
     *  Product: '<S306>/Divide'
     *  Sum: '<S306>/Add'
     */
    rtb_DataTypeConversion = (real_T)rtb_cosphi * 3.4254691037464213E+003 +
      3.6921428571428564E+003;
    if (rtIsNaN(rtb_DataTypeConversion) || rtIsInf(rtb_DataTypeConversion)) {
      rtb_DataTypeConversion = 0.0;
    } else {
      rtb_DataTypeConversion = fmod(floor(rtb_DataTypeConversion), 65536.0);
    }

    rtb_DataTypeConversion_o5 = rtb_DataTypeConversion < 0.0 ? (uint16_T)
      (-((int16_T)(uint16_T)(-rtb_DataTypeConversion))) : (uint16_T)
      rtb_DataTypeConversion;

    /* DataTypeConversion: '<S307>/Data Type Conversion' incorporates:
     *  Constant: '<S307>/Constant1'
     *  Constant: '<S307>/Constant2'
     *  Product: '<S307>/Divide'
     *  Sum: '<S307>/Add'
     */
    rtb_DataTypeConversion = (real_T)rtb_Sum2 * 2.8579680495216057E+003 +
      3.7214285714285706E+003;
    if (rtIsNaN(rtb_DataTypeConversion) || rtIsInf(rtb_DataTypeConversion)) {
      rtb_DataTypeConversion = 0.0;
    } else {
      rtb_DataTypeConversion = fmod(floor(rtb_DataTypeConversion), 65536.0);
    }

    rtb_DataTypeConversion_j = rtb_DataTypeConversion < 0.0 ? (uint16_T)
      (-((int16_T)(uint16_T)(-rtb_DataTypeConversion))) : (uint16_T)
      rtb_DataTypeConversion;

    /* Embedded MATLAB: '<S296>/myMux Fun1' */
    controlMCUSlugs_myMuxFun1_a(rtb_DataTypeConversion_o,
      rtb_DataTypeConversion_o5, rtb_DataTypeConversion_j,
      rtb_DataTypeConversion_k, controlMCUSlugsMKII_B.Merge_n);
  } else if (controlMCUSlugsMKII_B.GetControlTypenavSupportc == 4) {
    /* Gain: '<S294>/Gain' */
    rtb_Gain_pn = rtb_y_n[0] >> 1;

    /* Gain: '<S294>/Gain1' */
    rtb_Gain1_c = rtb_y_n[1] >> 1;

    /* Gain: '<S294>/Gain2' */
    rtb_Gain2_d = rtb_y_n[3] >> 1;

    /* Gain: '<S294>/Gain3' */
    rtb_Gain3_p = rtb_y_n[2] >> 1;

    /* Embedded MATLAB: '<S294>/myMux Fun1' */
    controlMCUSlugs_myMuxFun1_a(rtb_Gain_pn, rtb_Gain1_c, rtb_Gain2_d,
      rtb_Gain3_p, controlMCUSlugsMKII_B.Merge_n);
  } else {
    if (controlMCUSlugsMKII_B.GetControlTypenavSupportc == 5) {
      /* S-Function "dsPIC_C_function_Call" Block: <S295>/Get Pass Switches [navSupport.c] */
      getPassValues(&controlMCUSlugsMKII_B.GetPassSwitchesnavSupportc[0]);

      /* Switch: '<S295>/Switch' incorporates:
       *  Constant: '<S300>/Constant1'
       *  Constant: '<S300>/Constant2'
       *  DataTypeConversion: '<S300>/Data Type Conversion'
       *  Gain: '<S295>/Gain'
       *  Product: '<S300>/Divide'
       *  Sum: '<S300>/Add'
       */
      if (controlMCUSlugsMKII_B.GetPassSwitchesnavSupportc[3] >= 1) {
        rtb_Switch_k = rtb_y_n[0] >> 1;
      } else {
        rtb_DataTypeConversion = (real_T)rtb_Product1_m * 1274.0 + 3176.0;
        if (rtIsNaN(rtb_DataTypeConversion) || rtIsInf(rtb_DataTypeConversion))
        {
          rtb_DataTypeConversion = 0.0;
        } else {
          rtb_DataTypeConversion = fmod(floor(rtb_DataTypeConversion), 65536.0);
        }

        rtb_Switch_k = rtb_DataTypeConversion < 0.0 ? (uint16_T)(-((int16_T)
          (uint16_T)(-rtb_DataTypeConversion))) : (uint16_T)
          rtb_DataTypeConversion;
      }

      /* Switch: '<S295>/Switch1' incorporates:
       *  Constant: '<S301>/Constant1'
       *  Constant: '<S301>/Constant2'
       *  DataTypeConversion: '<S301>/Data Type Conversion'
       *  Gain: '<S295>/Gain1'
       *  Product: '<S301>/Divide'
       *  Sum: '<S301>/Add'
       */
      if (controlMCUSlugsMKII_B.GetPassSwitchesnavSupportc[2] >= 1) {
        rtb_Switch1_b = rtb_y_n[1] >> 1;
      } else {
        rtb_DataTypeConversion = (real_T)rtb_cosphi * 3.4254691037464213E+003 +
          3.6921428571428564E+003;
        if (rtIsNaN(rtb_DataTypeConversion) || rtIsInf(rtb_DataTypeConversion))
        {
          rtb_DataTypeConversion = 0.0;
        } else {
          rtb_DataTypeConversion = fmod(floor(rtb_DataTypeConversion), 65536.0);
        }

        rtb_Switch1_b = rtb_DataTypeConversion < 0.0 ? (uint16_T)(-((int16_T)
          (uint16_T)(-rtb_DataTypeConversion))) : (uint16_T)
          rtb_DataTypeConversion;
      }

      /* Switch: '<S295>/Switch2' incorporates:
       *  Constant: '<S302>/Constant1'
       *  Constant: '<S302>/Constant2'
       *  DataTypeConversion: '<S302>/Data Type Conversion'
       *  Gain: '<S295>/Gain2'
       *  Product: '<S302>/Divide'
       *  Sum: '<S302>/Add'
       */
      if (controlMCUSlugsMKII_B.GetPassSwitchesnavSupportc[1] >= 1) {
        rtb_Switch2_l = rtb_y_n[3] >> 1;
      } else {
        rtb_DataTypeConversion = (real_T)rtb_Sum2 * 2.8579680495216057E+003 +
          3.7214285714285706E+003;
        if (rtIsNaN(rtb_DataTypeConversion) || rtIsInf(rtb_DataTypeConversion))
        {
          rtb_DataTypeConversion = 0.0;
        } else {
          rtb_DataTypeConversion = fmod(floor(rtb_DataTypeConversion), 65536.0);
        }

        rtb_Switch2_l = rtb_DataTypeConversion < 0.0 ? (uint16_T)(-((int16_T)
          (uint16_T)(-rtb_DataTypeConversion))) : (uint16_T)
          rtb_DataTypeConversion;
      }

      /* Switch: '<S295>/Switch3' incorporates:
       *  Constant: '<S299>/Constant1'
       *  Constant: '<S299>/Constant2'
       *  DataTypeConversion: '<S299>/Data Type Conversion'
       *  Gain: '<S295>/Gain3'
       *  Product: '<S299>/Divide'
       *  Sum: '<S299>/Add'
       */
      if (controlMCUSlugsMKII_B.GetPassSwitchesnavSupportc[0] >= 1) {
        rtb_Switch3 = rtb_y_n[2] >> 1;
      } else {
        rtb_DataTypeConversion = (real_T)rtb_u020 * 3.9411311193641609E+003 +
          3.7764285714285716E+003;
        if (rtIsNaN(rtb_DataTypeConversion) || rtIsInf(rtb_DataTypeConversion))
        {
          rtb_DataTypeConversion = 0.0;
        } else {
          rtb_DataTypeConversion = fmod(floor(rtb_DataTypeConversion), 65536.0);
        }

        rtb_Switch3 = rtb_DataTypeConversion < 0.0 ? (uint16_T)(-((int16_T)
          (uint16_T)(-rtb_DataTypeConversion))) : (uint16_T)
          rtb_DataTypeConversion;
      }

      /* Embedded MATLAB: '<S295>/myMux Fun1' */
      controlMCUSlugs_myMuxFun1_a(rtb_Switch_k, rtb_Switch1_b, rtb_Switch2_l,
        rtb_Switch3, controlMCUSlugsMKII_B.Merge_n);
    }
  }

  /* S-Function "dsPIC_PWM_motor" Block: <S8>/PWM Servo Output */
  PDC1 = controlMCUSlugsMKII_B.Merge_n[2] ;
  PDC2 = controlMCUSlugsMKII_B.Merge_n[3] ;
  PDC3 = controlMCUSlugsMKII_B.Merge_n[1] ;
  PDC4 = controlMCUSlugsMKII_B.Merge_n[0] ;

  /* Embedded MATLAB: '<S8>/myMux Fun1' incorporates:
   *  SignalConversion: '<S292>/TmpSignal ConversionAt SFunction Inport1'
   */
  /* Embedded MATLAB Function 'Update PWM Commands and Send Telemetry/myMux Fun1': '<S292>:1' */
  /*  This block supports an embeddable subset of the MATLAB language. */
  /*  See the help menu for details.  */
  /* '<S292>:1:5' */
  controlMCUSlugsMKII_B.y_d[0] = controlMCUSlugsMKII_B.Merge_n[0];
  controlMCUSlugsMKII_B.y_d[1] = controlMCUSlugsMKII_B.Merge_n[1];
  controlMCUSlugsMKII_B.y_d[2] = controlMCUSlugsMKII_B.Merge_n[3];
  controlMCUSlugsMKII_B.y_d[3] = controlMCUSlugsMKII_B.Merge_n[2];
  controlMCUSlugsMKII_B.y_d[4] = rtb_y_n[4];

  /* S-Function "dsPIC_C_function_Call" Block: <S8>/Update PWM  Commands [groundStationDriver.c] */
  updatePWM(controlMCUSlugsMKII_B.y_d);

  /* S-Function "dsPIC_C_function_Call" Block: <S8>/Update the Euler Angles [groundStationDriver.c]  */
  updateEuler(controlMCUSlugsMKII_B.sf_myMuxFun1_e.y);

  /* S-Function "dsPIC_C_function_Call" Block: <S8>/Update PQR [groundStationDriver.c]  */
  updatePQR(controlMCUSlugsMKII_B.Product1);

  /* S-Function "dsPIC_C_function_Call" Block: <S8>/Create Telemetry  Sentence [groundStationDriver.c] */
  prepareTelemetry(&controlMCUSlugsMKII_B.CreateTelemetrySentencegroundSt[0]);

  /* S-Function "dsPIC_C_function_Call" Block: <S8>/Send Data to Radio Modem [groundStationDriver.c] */
  send2GS(controlMCUSlugsMKII_B.CreateTelemetrySentencegroundSt);

  /* Embedded MATLAB: '<S2>/myMux Fun2' */
  controlMCUSlugsMK_myMuxFun1(controlMCUSlugsMKII_B.Switch3_oe,
    controlMCUSlugsMKII_B.PsiDotLimit, controlMCUSlugsMKII_B.PsiDotLimit_g,
    &controlMCUSlugsMKII_B.sf_myMuxFun2_l);

  /* S-Function "dsPIC_C_function_Call" Block: <S2>/Diagnostics [navSupport.c] */
  setDiagnosticFloat(controlMCUSlugsMKII_B.sf_myMuxFun2_l.y);

  /* DataTypeConversion: '<S290>/Data Type Conversion4' */
  if (controlMCUSlugsMKII_ConstB.Gain4 < 65536.0) {
    if (controlMCUSlugsMKII_ConstB.Gain4 >= 0.0) {
      controlMCUSlugsMKII_B.DataTypeConversion4 = (uint16_T)
        controlMCUSlugsMKII_ConstB.Gain4;
    } else {
      controlMCUSlugsMKII_B.DataTypeConversion4 = 0U;
    }
  } else {
    controlMCUSlugsMKII_B.DataTypeConversion4 = MAX_uint16_T;
  }

  /* S-Function "dsPIC_C_function_Call" Block: <S290>/Update PWM  Commands4 */
  updatePWM2(controlMCUSlugsMKII_B.DataTypeConversion4,((uint8_T)4U));

  /* DataTypeConversion: '<S280>/Data Type Conversion2' incorporates:
   *  Abs: '<S6>/Abs4'
   *  Gain: '<S6>/Gain4'
   */
  rtb_cosphi = (real32_T)fabs(100.0F * controlMCUSlugsMKII_B.DataTypeConversion);
  if (rtIsNaNF(rtb_cosphi) || rtIsInfF(rtb_cosphi)) {
    rtb_cosphi = 0.0F;
  } else {
    rtb_cosphi = (real32_T)fmod((real32_T)floor(rtb_cosphi), 65536.0F);
  }

  controlMCUSlugsMKII_B.DataTypeConversion2_e = rtb_cosphi < 0.0F ? (uint16_T)
    (-((int16_T)(uint16_T)(-rtb_cosphi))) : (uint16_T)rtb_cosphi;

  /* S-Function "dsPIC_C_function_Call" Block: <S280>/Update PWM  Commands1 */
  updatePWM2(controlMCUSlugsMKII_B.DataTypeConversion2_e,((uint8_T)0U));

  /* DataTypeConversion: '<S280>/Data Type Conversion3' incorporates:
   *  Abs: '<S6>/Abs'
   *  Gain: '<S6>/Gain1'
   */
  rtb_cosphi = (real32_T)fabs(5729.578125F *
    controlMCUSlugsMKII_B.DataTypeConversion_f);
  if (rtIsNaNF(rtb_cosphi) || rtIsInfF(rtb_cosphi)) {
    rtb_cosphi = 0.0F;
  } else {
    rtb_cosphi = (real32_T)fmod((real32_T)floor(rtb_cosphi), 65536.0F);
  }

  controlMCUSlugsMKII_B.DataTypeConversion3 = rtb_cosphi < 0.0F ? (uint16_T)
    (-((int16_T)(uint16_T)(-rtb_cosphi))) : (uint16_T)rtb_cosphi;

  /* S-Function "dsPIC_C_function_Call" Block: <S280>/Update PWM  Commands2 */
  updatePWM2(controlMCUSlugsMKII_B.DataTypeConversion3,((uint8_T)1U));

  /* DataTypeConversion: '<S280>/Data Type Conversion1' incorporates:
   *  Abs: '<S6>/Abs1'
   *  Gain: '<S6>/Gain3'
   */
  rtb_cosphi = (real32_T)fabs(5729.578125F *
    controlMCUSlugsMKII_B.DataTypeConversion_c);
  if (rtIsNaNF(rtb_cosphi) || rtIsInfF(rtb_cosphi)) {
    rtb_cosphi = 0.0F;
  } else {
    rtb_cosphi = (real32_T)fmod((real32_T)floor(rtb_cosphi), 65536.0F);
  }

  controlMCUSlugsMKII_B.DataTypeConversion1 = rtb_cosphi < 0.0F ? (uint16_T)
    (-((int16_T)(uint16_T)(-rtb_cosphi))) : (uint16_T)rtb_cosphi;

  /* S-Function "dsPIC_C_function_Call" Block: <S280>/Update PWM  Commands3 */
  updatePWM2(controlMCUSlugsMKII_B.DataTypeConversion1,((uint8_T)2U));

  /* DataTypeConversion: '<S280>/Data Type Conversion4' incorporates:
   *  Abs: '<S6>/Abs2'
   *  Gain: '<S6>/Gain2'
   */
  rtb_cosphi = (real32_T)fabs(5729.578125F *
    controlMCUSlugsMKII_B.DataTypeConversion_b);
  if (rtIsNaNF(rtb_cosphi) || rtIsInfF(rtb_cosphi)) {
    rtb_cosphi = 0.0F;
  } else {
    rtb_cosphi = (real32_T)fmod((real32_T)floor(rtb_cosphi), 65536.0F);
  }

  controlMCUSlugsMKII_B.DataTypeConversion4_p = rtb_cosphi < 0.0F ? (uint16_T)
    (-((int16_T)(uint16_T)(-rtb_cosphi))) : (uint16_T)rtb_cosphi;

  /* S-Function "dsPIC_C_function_Call" Block: <S280>/Update PWM  Commands4 */
  updatePWM2(controlMCUSlugsMKII_B.DataTypeConversion4_p,((uint8_T)3U));

  /* S-Function "dsPIC_C_function_Call" Block: <S5>/GetFilterOnOff */
  controlMCUSlugsMKII_B.GetFilterOnOff = getFilterOnOff();

  /* DataTypeConversion: '<S5>/Data Type Conversion1' */
  controlMCUSlugsMKII_B.DataTypeConversion1_e =
    (controlMCUSlugsMKII_B.GetFilterOnOff != 0);

  /* S-Function "dsPIC_Digital_OutputWrite" Block: <S5>/HIL Attitude  On//Off Switch */
  LATBbits.LATB6 = controlMCUSlugsMKII_B.DataTypeConversion1_e;

  /* S-Function "dsPIC_Digital_OutputWrite" Block: <S5>/HIL On//Off Switch */
  LATEbits.LATE9 = controlMCUSlugsMKII_B.DataTypeConversion1_e;

  /* Update for S-Function (sfix_udelay): '<S6>/Integer Delay' */
  controlMCUSlugsMKII_DWork.IntegerDelay_X_p = controlMCUSlugsMKII_B.ScheduleLPF;

  /* Update for S-Function (sfix_udelay): '<S278>/Integer Delay2' */
  controlMCUSlugsMKII_DWork.IntegerDelay2_X_k = controlMCUSlugsMKII_B.IC_c;

  /* Update for S-Function (sfix_udelay): '<S17>/Integer Delay3' */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_j5 =
    controlMCUSlugsMKII_B.Switch3_ov;

  /* Update for S-Function (sfix_udelay): '<S19>/Integer Delay3' */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_b = controlMCUSlugsMKII_B.Switch3_oe;

  /* Update for enable SubSystem: '<S2>/L1 Output Feedback Controller With  Projection Operator' incorporates:
   *  Update for EnablePort: '<S13>/Enable'
   */
  if ((int16_T)controlMCUSlugsMKII_DWork.L1OutputFeedbackControllerWithP) {
    /* Update for UnitDelay: '<S33>/UD' */
    controlMCUSlugsMKII_DWork.UD_DSTATE_l = controlMCUSlugsMKII_B.navSupportc_g
      [0];

    /* Update for S-Function (sfix_udelay): '<S24>/Integer Delay' */
    controlMCUSlugsMKII_DWork.IntegerDelay_X_d =
      controlMCUSlugsMKII_B.Switch3_im;

    /* Update for S-Function (sfix_udelay): '<S24>/Integer Delay1' */
    controlMCUSlugsMKII_DWork.IntegerDelay1_X_nc =
      controlMCUSlugsMKII_B.Subtract_b;

    /* Update for S-Function (sfix_udelay): '<S26>/Integer Delay3' */
    controlMCUSlugsMKII_DWork.IntegerDelay3_X_cw =
      controlMCUSlugsMKII_B.Switch3_cj;

    /* Update for UnitDelay: '<S42>/UD' */
    controlMCUSlugsMKII_DWork.UD_DSTATE_ld =
      controlMCUSlugsMKII_B.navSupportc_g[1];

    /* Update for S-Function (sfix_udelay): '<S28>/Integer Delay' */
    controlMCUSlugsMKII_DWork.IntegerDelay_X_c =
      controlMCUSlugsMKII_B.Switch3_ae;

    /* Update for S-Function (sfix_udelay): '<S28>/Integer Delay1' */
    controlMCUSlugsMKII_DWork.IntegerDelay1_X_a =
      controlMCUSlugsMKII_B.Subtract_c;

    /* Update for S-Function (sfix_udelay): '<S13>/Integer Delay' */
    controlMCUSlugsMKII_DWork.IntegerDelay_X_no =
      controlMCUSlugsMKII_B.PsiDotLimit;

    /* Update for S-Function (sfix_udelay): '<S13>/Integer Delay1' */
    controlMCUSlugsMKII_DWork.IntegerDelay1_X_b =
      controlMCUSlugsMKII_B.Switch3_im;

    /* Update for S-Function (sfix_udelay): '<S27>/Integer Delay3' */
    controlMCUSlugsMKII_DWork.IntegerDelay3_X_gww =
      controlMCUSlugsMKII_B.Switch3_ae;

    /* Update for S-Function (sfix_udelay): '<S29>/Integer Delay' */
    controlMCUSlugsMKII_DWork.IntegerDelay_X_f =
      controlMCUSlugsMKII_B.Switch3_gq;

    /* Update for S-Function (sfix_udelay): '<S29>/Integer Delay1' */
    controlMCUSlugsMKII_DWork.IntegerDelay1_X_ny[0] =
      controlMCUSlugsMKII_DWork.IntegerDelay1_X_ny[1];
    controlMCUSlugsMKII_DWork.IntegerDelay1_X_ny[1] =
      controlMCUSlugsMKII_B.Switch3_gq;

    /* Update for S-Function (sfix_udelay): '<S29>/Integer Delay2' */
    controlMCUSlugsMKII_DWork.IntegerDelay2_X_m =
      controlMCUSlugsMKII_B.Switch3_im;

    /* Update for S-Function (sfix_udelay): '<S43>/Integer Delay3' */
    controlMCUSlugsMKII_DWork.IntegerDelay3_X_oe =
      controlMCUSlugsMKII_B.Switch3_gq;

    /* Update for S-Function (sfix_udelay): '<S44>/Integer Delay3' */
    controlMCUSlugsMKII_DWork.IntegerDelay3_X_oe1 =
      controlMCUSlugsMKII_B.Switch3_im;
  }

  /* end of Update for SubSystem: '<S2>/L1 Output Feedback Controller With  Projection Operator' */

  /* Update absolute time */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The resolution of this integer timer is 0.01, which is the step size
   * of the task. Size of "clockTick0" ensures timer will not overflow during the
   * application lifespan selected.
   */
  controlMCUSlugsMKII_M->Timing.clockTick0++;
}

/* Model step function for TID1 */
void controlMCUSlugsMKII_step1(void)   /* Sample time: [1.0s, 0.0s] */
{
  /* (no output/update code required) */
}

void controlMCUSlugsMKII_step(int_T tid)
{
  switch (tid) {
   case 0 :
    controlMCUSlugsMKII_step0();
    break;

   case 1 :
    controlMCUSlugsMKII_step1();
    break;

   default :
    break;
  }
}

/* Model initialize function */
void controlMCUSlugsMKII_initialize(boolean_T firstTime)
{
  (void)firstTime;

  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)controlMCUSlugsMKII_M, 0,
                sizeof(RT_MODEL_controlMCUSlugsMKII));
  rtmSetFirstInitCond(controlMCUSlugsMKII_M, 1);

  /* block I/O */
  (void) memset(((void *) &controlMCUSlugsMKII_B), 0,
                sizeof(BlockIO_controlMCUSlugsMKII));

  {
    int_T i;
    for (i = 0; i < 6; i++) {
      controlMCUSlugsMKII_B.GetAttitudenavSupportc[i] = 0.0F;
    }

    for (i = 0; i < 9; i++) {
      controlMCUSlugsMKII_B.Product[i] = 0.0F;
    }

    for (i = 0; i < 6; i++) {
      controlMCUSlugsMKII_B.y[i] = 0.0F;
    }

    for (i = 0; i < 9; i++) {
      controlMCUSlugsMKII_B.sf_myMuxFun1_m.y[i] = 0.0F;
    }

    for (i = 0; i < 9; i++) {
      controlMCUSlugsMKII_B.sf_myMuxFun1_n.y[i] = 0.0F;
    }

    controlMCUSlugsMKII_B.IC = 0.0;
    controlMCUSlugsMKII_B.Switch3 = 0.0;
    controlMCUSlugsMKII_B.swIncrement = 0.0;
    controlMCUSlugsMKII_B.Switch3_n = 0.0;
    controlMCUSlugsMKII_B.Switch3_k = 0.0;
    controlMCUSlugsMKII_B.Switch3_o = 0.0;
    controlMCUSlugsMKII_B.Switch3_g = 0.0;
    controlMCUSlugsMKII_B.Switch3_na = 0.0;
    controlMCUSlugsMKII_B.Subtract = 0.0;
    controlMCUSlugsMKII_B.GetMidLevelCommandsnavSupportc[0] = 0.0F;
    controlMCUSlugsMKII_B.GetMidLevelCommandsnavSupportc[1] = 0.0F;
    controlMCUSlugsMKII_B.GetMidLevelCommandsnavSupportc[2] = 0.0F;
    controlMCUSlugsMKII_B.GetDynamicPnavSupportc = 0.0F;
    controlMCUSlugsMKII_B.GetPidaccordingtoIndex[0] = 0.0F;
    controlMCUSlugsMKII_B.GetPidaccordingtoIndex[1] = 0.0F;
    controlMCUSlugsMKII_B.GetPidaccordingtoIndex[2] = 0.0F;
    controlMCUSlugsMKII_B.IntegerDelay = 0.0F;
    controlMCUSlugsMKII_B.GetXYZnavSupportc[0] = 0.0F;
    controlMCUSlugsMKII_B.GetXYZnavSupportc[1] = 0.0F;
    controlMCUSlugsMKII_B.GetXYZnavSupportc[2] = 0.0F;
    controlMCUSlugsMKII_B.Switch3_ov = 0.0F;
    controlMCUSlugsMKII_B.GetPidaccordingtoIndex1[0] = 0.0F;
    controlMCUSlugsMKII_B.GetPidaccordingtoIndex1[1] = 0.0F;
    controlMCUSlugsMKII_B.GetPidaccordingtoIndex1[2] = 0.0F;
    controlMCUSlugsMKII_B.navSupportc[0] = 0.0F;
    controlMCUSlugsMKII_B.navSupportc[1] = 0.0F;
    controlMCUSlugsMKII_B.navSupportc[2] = 0.0F;
    controlMCUSlugsMKII_B.UnitConversion[0] = 0.0F;
    controlMCUSlugsMKII_B.UnitConversion[1] = 0.0F;
    controlMCUSlugsMKII_B.UnitConversion[2] = 0.0F;
    controlMCUSlugsMKII_B.CFunctionCall1 = 0.0F;
    controlMCUSlugsMKII_B.CFunctionCall4 = 0.0F;
    controlMCUSlugsMKII_B.CFunctionCall5 = 0.0F;
    controlMCUSlugsMKII_B.CFunctionCall = 0.0F;
    controlMCUSlugsMKII_B.CFunctionCall2 = 0.0F;
    controlMCUSlugsMKII_B.CFunctionCall3 = 0.0F;
    controlMCUSlugsMKII_B.CFunctionCall1_g = 0.0F;
    controlMCUSlugsMKII_B.CFunctionCall4_a = 0.0F;
    controlMCUSlugsMKII_B.CFunctionCall5_d = 0.0F;
    controlMCUSlugsMKII_B.CFunctionCall_i = 0.0F;
    controlMCUSlugsMKII_B.CFunctionCall2_e = 0.0F;
    controlMCUSlugsMKII_B.CFunctionCall3_i = 0.0F;
    controlMCUSlugsMKII_B.CFunctionCall_i0 = 0.0F;
    controlMCUSlugsMKII_B.u1 = 0.0F;
    controlMCUSlugsMKII_B.CFunctionCall_c = 0.0F;
    controlMCUSlugsMKII_B.CFunctionCall_c5 = 0.0F;
    controlMCUSlugsMKII_B.Product1[0] = 0.0F;
    controlMCUSlugsMKII_B.Product1[1] = 0.0F;
    controlMCUSlugsMKII_B.Product1[2] = 0.0F;
    controlMCUSlugsMKII_B.GetPidaccordingtoIndex2[0] = 0.0F;
    controlMCUSlugsMKII_B.GetPidaccordingtoIndex2[1] = 0.0F;
    controlMCUSlugsMKII_B.GetPidaccordingtoIndex2[2] = 0.0F;
    controlMCUSlugsMKII_B.GetVnednavSupportc[0] = 0.0F;
    controlMCUSlugsMKII_B.GetVnednavSupportc[1] = 0.0F;
    controlMCUSlugsMKII_B.GetVnednavSupportc[2] = 0.0F;
    controlMCUSlugsMKII_B.navSupportc_o[0] = 0.0F;
    controlMCUSlugsMKII_B.navSupportc_o[1] = 0.0F;
    controlMCUSlugsMKII_B.navSupportc_o[2] = 0.0F;
    controlMCUSlugsMKII_B.navSupportc_n[0] = 0.0F;
    controlMCUSlugsMKII_B.navSupportc_n[1] = 0.0F;
    controlMCUSlugsMKII_B.navSupportc_n[2] = 0.0F;
    controlMCUSlugsMKII_B.GetPidaccordingtoIndex3[0] = 0.0F;
    controlMCUSlugsMKII_B.GetPidaccordingtoIndex3[1] = 0.0F;
    controlMCUSlugsMKII_B.GetPidaccordingtoIndex3[2] = 0.0F;
    controlMCUSlugsMKII_B.navSupportc_k[0] = 0.0F;
    controlMCUSlugsMKII_B.navSupportc_k[1] = 0.0F;
    controlMCUSlugsMKII_B.navSupportc_k[2] = 0.0F;
    controlMCUSlugsMKII_B.apUtilsc = 0.0F;
    controlMCUSlugsMKII_B.apUtilsc_p = 0.0F;
    controlMCUSlugsMKII_B.Switch3_oe = 0.0F;
    controlMCUSlugsMKII_B.navSupportc_g[0] = 0.0F;
    controlMCUSlugsMKII_B.navSupportc_g[1] = 0.0F;
    controlMCUSlugsMKII_B.navSupportc_g[2] = 0.0F;
    controlMCUSlugsMKII_B.GettheAccelerometersnavSupportc[0] = 0.0F;
    controlMCUSlugsMKII_B.GettheAccelerometersnavSupportc[1] = 0.0F;
    controlMCUSlugsMKII_B.GettheAccelerometersnavSupportc[2] = 0.0F;
    controlMCUSlugsMKII_B.GettheAccelBiasnavSupportc[0] = 0.0F;
    controlMCUSlugsMKII_B.GettheAccelBiasnavSupportc[1] = 0.0F;
    controlMCUSlugsMKII_B.GettheAccelBiasnavSupportc[2] = 0.0F;
    controlMCUSlugsMKII_B.DataTypeConversion = 0.0F;
    controlMCUSlugsMKII_B.DataTypeConversion_f = 0.0F;
    controlMCUSlugsMKII_B.DataTypeConversion_b = 0.0F;
    controlMCUSlugsMKII_B.DataTypeConversion_c = 0.0F;
    controlMCUSlugsMKII_B.CFunctionCall_a = 0.0F;
    controlMCUSlugsMKII_B.Switch3_h = 0.0F;
    controlMCUSlugsMKII_B.Switch3_nn = 0.0F;
    controlMCUSlugsMKII_B.Add = 0.0F;
    controlMCUSlugsMKII_B.CFunctionCall_o = 0.0F;
    controlMCUSlugsMKII_B.CFunctionCall_f = 0.0F;
    controlMCUSlugsMKII_B.L1_vec[0] = 0.0F;
    controlMCUSlugsMKII_B.L1_vec[1] = 0.0F;
    controlMCUSlugsMKII_B.L1_vec[2] = 0.0F;
    controlMCUSlugsMKII_B.CFunctionCall_m = 0.0F;
    controlMCUSlugsMKII_B.Switch3_a = 0.0F;
    controlMCUSlugsMKII_B.u1_h = 0.0F;
    controlMCUSlugsMKII_B.CFunctionCall_h = 0.0F;
    controlMCUSlugsMKII_B.CFunctionCall_e = 0.0F;
    controlMCUSlugsMKII_B.Switch3_m = 0.0F;
    controlMCUSlugsMKII_B.Diff = 0.0F;
    controlMCUSlugsMKII_B.CFunctionCall_j = 0.0F;
    controlMCUSlugsMKII_B.Diff_o = 0.0F;
    controlMCUSlugsMKII_B.CFunctionCall_l = 0.0F;
    controlMCUSlugsMKII_B.Diff_a = 0.0F;
    controlMCUSlugsMKII_B.CFunctionCall_ep = 0.0F;
    controlMCUSlugsMKII_B.IC_e = 0.0F;
    controlMCUSlugsMKII_B.Switch3_e = 0.0F;
    controlMCUSlugsMKII_B.Divide = 0.0F;
    controlMCUSlugsMKII_B.CFunctionCall_g = 0.0F;
    controlMCUSlugsMKII_B.Switch3_c = 0.0F;
    controlMCUSlugsMKII_B.CFunctionCall_d[0] = 0.0F;
    controlMCUSlugsMKII_B.CFunctionCall_d[1] = 0.0F;
    controlMCUSlugsMKII_B.CFunctionCall_d[2] = 0.0F;
    controlMCUSlugsMKII_B.Switch[0] = 0.0F;
    controlMCUSlugsMKII_B.Switch[1] = 0.0F;
    controlMCUSlugsMKII_B.Switch[2] = 0.0F;
    controlMCUSlugsMKII_B.CFunctionCall_a1[0] = 0.0F;
    controlMCUSlugsMKII_B.CFunctionCall_a1[1] = 0.0F;
    controlMCUSlugsMKII_B.CFunctionCall_a1[2] = 0.0F;
    controlMCUSlugsMKII_B.Reshape1[0] = 0.0F;
    controlMCUSlugsMKII_B.Reshape1[1] = 0.0F;
    controlMCUSlugsMKII_B.Reshape1[2] = 0.0F;
    controlMCUSlugsMKII_B.CFunctionCall_b = 0.0F;
    controlMCUSlugsMKII_B.Divide_n[0] = 0.0F;
    controlMCUSlugsMKII_B.Divide_n[1] = 0.0F;
    controlMCUSlugsMKII_B.Divide_n[2] = 0.0F;
    controlMCUSlugsMKII_B.CFunctionCall_c0 = 0.0F;
    controlMCUSlugsMKII_B.Divide_p[0] = 0.0F;
    controlMCUSlugsMKII_B.Divide_p[1] = 0.0F;
    controlMCUSlugsMKII_B.Divide_p[2] = 0.0F;
    controlMCUSlugsMKII_B.y_e[0] = 0.0F;
    controlMCUSlugsMKII_B.y_e[1] = 0.0F;
    controlMCUSlugsMKII_B.y_e[2] = 0.0F;
    controlMCUSlugsMKII_B.y_e[3] = 0.0F;
    controlMCUSlugsMKII_B.CFunctionCall_fg = 0.0F;
    controlMCUSlugsMKII_B.Switch3_mv = 0.0F;
    controlMCUSlugsMKII_B.UAVPos[0] = 0.0F;
    controlMCUSlugsMKII_B.UAVPos[1] = 0.0F;
    controlMCUSlugsMKII_B.UAVPos[2] = 0.0F;
    controlMCUSlugsMKII_B.CFunctionCall_aj[0] = 0.0F;
    controlMCUSlugsMKII_B.CFunctionCall_aj[1] = 0.0F;
    controlMCUSlugsMKII_B.CFunctionCall_aj[2] = 0.0F;
    controlMCUSlugsMKII_B.RhhcosphicoslambXe = 0.0F;
    controlMCUSlugsMKII_B.RhhcosphisinlambYe = 0.0F;
    controlMCUSlugsMKII_B.Ze = 0.0F;
    controlMCUSlugsMKII_B.IntegerDelay1[0] = 0.0F;
    controlMCUSlugsMKII_B.IntegerDelay1[1] = 0.0F;
    controlMCUSlugsMKII_B.IntegerDelay1[2] = 0.0F;
    controlMCUSlugsMKII_B.CFunctionCall_l0 = 0.0F;
    controlMCUSlugsMKII_B.CFunctionCall_mb = 0.0F;
    controlMCUSlugsMKII_B.Divide_l[0] = 0.0F;
    controlMCUSlugsMKII_B.Divide_l[1] = 0.0F;
    controlMCUSlugsMKII_B.Divide_l[2] = 0.0F;
    controlMCUSlugsMKII_B.CFunctionCall_ir = 0.0F;
    controlMCUSlugsMKII_B.Merge4 = 0.0F;
    controlMCUSlugsMKII_B.CFunctionCall_hb = 0.0F;
    controlMCUSlugsMKII_B.CFunctionCall1_i = 0.0F;
    controlMCUSlugsMKII_B.CFunctionCall_ap[0] = 0.0F;
    controlMCUSlugsMKII_B.CFunctionCall_ap[1] = 0.0F;
    controlMCUSlugsMKII_B.CFunctionCall_ap[2] = 0.0F;
    controlMCUSlugsMKII_B.UEN2NEU[0] = 0.0F;
    controlMCUSlugsMKII_B.UEN2NEU[1] = 0.0F;
    controlMCUSlugsMKII_B.UEN2NEU[2] = 0.0F;
    controlMCUSlugsMKII_B.IC_l = 0.0F;
    controlMCUSlugsMKII_B.Add_g = 0.0F;
    controlMCUSlugsMKII_B.CFunctionCall_ab = 0.0F;
    controlMCUSlugsMKII_B.CFunctionCall_m4 = 0.0F;
    controlMCUSlugsMKII_B.Switch3_f = 0.0F;
    controlMCUSlugsMKII_B.ScheduleLPF = 0.0F;
    controlMCUSlugsMKII_B.Switch3_c1 = 0.0F;
    controlMCUSlugsMKII_B.Switch3_b = 0.0F;
    controlMCUSlugsMKII_B.Switch3_mx = 0.0F;
    controlMCUSlugsMKII_B.Switch3_kr = 0.0F;
    controlMCUSlugsMKII_B.Switch3_p = 0.0F;
    controlMCUSlugsMKII_B.Switch3_f3 = 0.0F;
    controlMCUSlugsMKII_B.Switch3_el = 0.0F;
    controlMCUSlugsMKII_B.u060 = 0.0F;
    controlMCUSlugsMKII_B.CFunctionCall1_b = 0.0F;
    controlMCUSlugsMKII_B.y_j[0] = 0.0F;
    controlMCUSlugsMKII_B.y_j[1] = 0.0F;
    controlMCUSlugsMKII_B.Switch3_gn = 0.0F;
    controlMCUSlugsMKII_B.bankLimit = 0.0F;
    controlMCUSlugsMKII_B.CFunctionCall_in = 0.0F;
    controlMCUSlugsMKII_B.Switch3_h4 = 0.0F;
    controlMCUSlugsMKII_B.PsiDotLimit = 0.0F;
    controlMCUSlugsMKII_B.Divide_m = 0.0F;
    controlMCUSlugsMKII_B.CFunctionCall_i4 = 0.0F;
    controlMCUSlugsMKII_B.Switch3_pa = 0.0F;
    controlMCUSlugsMKII_B.navSupportc_l[0] = 0.0F;
    controlMCUSlugsMKII_B.navSupportc_l[1] = 0.0F;
    controlMCUSlugsMKII_B.navSupportc_l[2] = 0.0F;
    controlMCUSlugsMKII_B.Switch3_fx = 0.0F;
    controlMCUSlugsMKII_B.u2 = 0.0F;
    controlMCUSlugsMKII_B.Switch3_my = 0.0F;
    controlMCUSlugsMKII_B.Switch3_pf = 0.0F;
    controlMCUSlugsMKII_B.Switch3_i = 0.0F;
    controlMCUSlugsMKII_B.Switch3_cv = 0.0F;
    controlMCUSlugsMKII_B.bankLimit_a = 0.0F;
    controlMCUSlugsMKII_B.CFunctionCall_gd = 0.0F;
    controlMCUSlugsMKII_B.Divide_a = 0.0F;
    controlMCUSlugsMKII_B.CFunctionCall_id = 0.0F;
    controlMCUSlugsMKII_B.Switch3_pq = 0.0F;
    controlMCUSlugsMKII_B.c = 0.0F;
    controlMCUSlugsMKII_B.c_k = 0.0F;
    controlMCUSlugsMKII_B.u2_o = 0.0F;
    controlMCUSlugsMKII_B.Subtract_b = 0.0F;
    controlMCUSlugsMKII_B.Switch3_cj = 0.0F;
    controlMCUSlugsMKII_B.Subtract_c = 0.0F;
    controlMCUSlugsMKII_B.Merge = 0.0F;
    controlMCUSlugsMKII_B.PsiDotLimit_g = 0.0F;
    controlMCUSlugsMKII_B.Switch3_ae = 0.0F;
    controlMCUSlugsMKII_B.Switch3_gq = 0.0F;
    controlMCUSlugsMKII_B.Switch3_im = 0.0F;
    controlMCUSlugsMKII_B.T = 0.0F;
    controlMCUSlugsMKII_B.CFunctionCall_dr = 0.0F;
    controlMCUSlugsMKII_B.c_i = 0.0F;
    controlMCUSlugsMKII_B.T_i = 0.0F;
    controlMCUSlugsMKII_B.CFunctionCall_p = 0.0F;
    controlMCUSlugsMKII_B.c_kt = 0.0F;
    controlMCUSlugsMKII_B.sf_myMuxFun1_e.y[0] = 0.0F;
    controlMCUSlugsMKII_B.sf_myMuxFun1_e.y[1] = 0.0F;
    controlMCUSlugsMKII_B.sf_myMuxFun1_e.y[2] = 0.0F;
    controlMCUSlugsMKII_B.sf_myMuxFun2_c.y[0] = 0.0F;
    controlMCUSlugsMKII_B.sf_myMuxFun2_c.y[1] = 0.0F;
    controlMCUSlugsMKII_B.sf_myMuxFun2_c.y[2] = 0.0F;
    controlMCUSlugsMKII_B.sf_myMuxFun1_a.y[0] = 0.0F;
    controlMCUSlugsMKII_B.sf_myMuxFun1_a.y[1] = 0.0F;
    controlMCUSlugsMKII_B.sf_myMuxFun1_a.y[2] = 0.0F;
    controlMCUSlugsMKII_B.sf_myMuxFun2.y[0] = 0.0F;
    controlMCUSlugsMKII_B.sf_myMuxFun2.y[1] = 0.0F;
    controlMCUSlugsMKII_B.sf_myMuxFun2.y[2] = 0.0F;
    controlMCUSlugsMKII_B.sf_myMuxFun1.y[0] = 0.0F;
    controlMCUSlugsMKII_B.sf_myMuxFun1.y[1] = 0.0F;
    controlMCUSlugsMKII_B.sf_myMuxFun1.y[2] = 0.0F;
    controlMCUSlugsMKII_B.sf_myMuxFun2_l.y[0] = 0.0F;
    controlMCUSlugsMKII_B.sf_myMuxFun2_l.y[1] = 0.0F;
    controlMCUSlugsMKII_B.sf_myMuxFun2_l.y[2] = 0.0F;
    controlMCUSlugsMKII_B.sf_myMuxFun1_o.y[0] = 0.0F;
    controlMCUSlugsMKII_B.sf_myMuxFun1_o.y[1] = 0.0F;
    controlMCUSlugsMKII_B.sf_myMuxFun1_o.y[2] = 0.0F;
    controlMCUSlugsMKII_B.sf_negprotect1.zpVal = 0.0F;
    controlMCUSlugsMKII_B.sf_negprotect_h.zpVal = 0.0F;
    controlMCUSlugsMKII_B.sf_negprotect_f.zpVal = 0.0F;
    controlMCUSlugsMKII_B.sf_negprotect_fm.zpVal = 0.0F;
    controlMCUSlugsMKII_B.sf_EmbeddedMATLABFunction_d.xDoty = 0.0F;
    controlMCUSlugsMKII_B.sf_negprotect_b.zpVal = 0.0F;
    controlMCUSlugsMKII_B.sf_EmbeddedMATLABFunction_or.xDoty = 0.0F;
    controlMCUSlugsMKII_B.sf_negprotect_bp.zpVal = 0.0F;
    controlMCUSlugsMKII_B.sf_EmbeddedMATLABFunction_hk.xDoty = 0.0F;
    controlMCUSlugsMKII_B.sf_negprotect_g.zpVal = 0.0F;
    controlMCUSlugsMKII_B.sf_EmbeddedMATLABFunction_mg.xDoty = 0.0F;
    controlMCUSlugsMKII_B.sf_negprotect_l.zpVal = 0.0F;
    controlMCUSlugsMKII_B.sf_EmbeddedMATLABFunction_n.xDoty = 0.0F;
    controlMCUSlugsMKII_B.sf_EmbeddedMATLABFunction_a.xDoty = 0.0F;
    controlMCUSlugsMKII_B.sf_negprotect_e.zpVal = 0.0F;
    controlMCUSlugsMKII_B.sf_EmbeddedMATLABFunction_m.xDoty = 0.0F;
    controlMCUSlugsMKII_B.sf_negprotect_c.zpVal = 0.0F;
    controlMCUSlugsMKII_B.sf_EmbeddedMATLABFunction_i.y = 0.0F;
    controlMCUSlugsMKII_B.sf_EmbeddedMATLABFunction_l.y = 0.0F;
    controlMCUSlugsMKII_B.sf_EmbeddedMATLABFunction_p.y = 0.0F;
    controlMCUSlugsMKII_B.sf_myMuxFun1_h.y[0] = 0.0F;
    controlMCUSlugsMKII_B.sf_myMuxFun1_h.y[1] = 0.0F;
    controlMCUSlugsMKII_B.sf_myMuxFun1_h.y[2] = 0.0F;
    controlMCUSlugsMKII_B.sf_negprotect.zpVal = 0.0F;
    controlMCUSlugsMKII_B.sf_EmbeddedMATLABFunction_h.y = 0.0F;
  }

  /* states (dwork) */
  (void) memset((void *)&controlMCUSlugsMKII_DWork, 0,
                sizeof(D_Work_controlMCUSlugsMKII));
  controlMCUSlugsMKII_DWork.IntegerDelay2_X = 0.0;
  controlMCUSlugsMKII_DWork.IntegerDelay2_X_l = 0.0;
  controlMCUSlugsMKII_DWork.IntegerDelay3_X = 0.0;
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_c = 0.0;
  controlMCUSlugsMKII_DWork.IntegerDelay_X = 0.0;
  controlMCUSlugsMKII_DWork.IntegerDelay1_X[0] = 0.0;
  controlMCUSlugsMKII_DWork.IntegerDelay1_X[1] = 0.0;
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_l = 0.0;
  controlMCUSlugsMKII_DWork.IntegerDelay_X_i = 0.0;
  controlMCUSlugsMKII_DWork.IntegerDelay1_X_o[0] = 0.0;
  controlMCUSlugsMKII_DWork.IntegerDelay1_X_o[1] = 0.0;
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_k = 0.0;
  controlMCUSlugsMKII_DWork.IntegerDelay_X_g = 0.0;
  controlMCUSlugsMKII_DWork.IntegerDelay1_X_oa[0] = 0.0;
  controlMCUSlugsMKII_DWork.IntegerDelay1_X_oa[1] = 0.0;
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_o = 0.0;
  controlMCUSlugsMKII_DWork.IntegerDelay_X_i0 = 0.0;
  controlMCUSlugsMKII_DWork.IntegerDelay1_X_f[0] = 0.0;
  controlMCUSlugsMKII_DWork.IntegerDelay1_X_f[1] = 0.0;
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_j = 0.0;
  controlMCUSlugsMKII_DWork.IntegerDelay_X_n = 0.0;
  controlMCUSlugsMKII_DWork.IntegerDelay1_X_n[0] = 0.0;
  controlMCUSlugsMKII_DWork.IntegerDelay1_X_n[1] = 0.0;
  controlMCUSlugsMKII_DWork.IntegerDelay1_X_f5 = 0.0;
  controlMCUSlugsMKII_DWork.Add3_DWORK1 = 0.0;
  controlMCUSlugsMKII_DWork.IntegerDelay_X_p = 0.0F;
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_j5 = 0.0F;
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_b = 0.0F;
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_lj = 0.0F;
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_b3 = 0.0F;
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_g = 0.0F;
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_f = 0.0F;
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_a = 0.0F;
  controlMCUSlugsMKII_DWork.IntegerDelay1_X_i = 0.0F;
  controlMCUSlugsMKII_DWork.IntegerDelay2_X_e[0] = 0.0F;
  controlMCUSlugsMKII_DWork.IntegerDelay2_X_e[1] = 0.0F;
  controlMCUSlugsMKII_DWork.UD_DSTATE = 0.0F;
  controlMCUSlugsMKII_DWork.UD_DSTATE_e = 0.0F;
  controlMCUSlugsMKII_DWork.UD_DSTATE_h = 0.0F;
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_n = 0.0F;
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_ch = 0.0F;
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_ft = 0.0F;
  controlMCUSlugsMKII_DWork.IntegerDelay1_X_k[0] = 0.0F;
  controlMCUSlugsMKII_DWork.IntegerDelay1_X_k[1] = 0.0F;
  controlMCUSlugsMKII_DWork.IntegerDelay1_X_k[2] = 0.0F;
  controlMCUSlugsMKII_DWork.IntegerDelay2_X_e3[0] = 0.0F;
  controlMCUSlugsMKII_DWork.IntegerDelay2_X_e3[1] = 0.0F;
  controlMCUSlugsMKII_DWork.IntegerDelay2_X_e3[2] = 0.0F;
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_i = 0.0F;
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_m = 0.0F;
  controlMCUSlugsMKII_DWork.IntegerDelay2_X_lq = 0.0F;
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_at = 0.0F;
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_fk = 0.0F;
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_e = 0.0F;

  {
    int_T i;
    for (i = 0; i < 5; i++) {
      controlMCUSlugsMKII_DWork.NDelays_X[i] = 0.0F;
    }
  }

  controlMCUSlugsMKII_DWork.IntegerDelay2_X_d = 0.0F;
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_ex = 0.0F;
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_nv = 0.0F;

  {
    int_T i;
    for (i = 0; i < 5; i++) {
      controlMCUSlugsMKII_DWork.NDelays_X_c[i] = 0.0F;
    }
  }

  controlMCUSlugsMKII_DWork.IntegerDelay2_X_n = 0.0F;
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_p = 0.0F;
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_nc = 0.0F;
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_gw = 0.0F;
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_h = 0.0F;
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_ae = 0.0F;
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_b5 = 0.0F;

  {
    int_T i;
    for (i = 0; i < 5; i++) {
      controlMCUSlugsMKII_DWork.NDelays_X_e[i] = 0.0F;
    }
  }

  controlMCUSlugsMKII_DWork.IntegerDelay2_X_g = 0.0F;
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_cn = 0.0F;
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_mk = 0.0F;

  {
    int_T i;
    for (i = 0; i < 5; i++) {
      controlMCUSlugsMKII_DWork.NDelays_X_m[i] = 0.0F;
    }
  }

  controlMCUSlugsMKII_DWork.IntegerDelay2_X_j = 0.0F;
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_hp = 0.0F;
  controlMCUSlugsMKII_DWork.UD_DSTATE_o = 0.0F;
  controlMCUSlugsMKII_DWork.IntegerDelay_X_b = 0.0F;
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_hc = 0.0F;
  controlMCUSlugsMKII_DWork.IntegerDelay_X_nm = 0.0F;
  controlMCUSlugsMKII_DWork.IntegerDelay1_X_l = 0.0F;
  controlMCUSlugsMKII_DWork.UD_DSTATE_l = 0.0F;
  controlMCUSlugsMKII_DWork.IntegerDelay_X_d = 0.0F;
  controlMCUSlugsMKII_DWork.IntegerDelay1_X_nc = 0.0F;
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_cw = 0.0F;
  controlMCUSlugsMKII_DWork.UD_DSTATE_ld = 0.0F;
  controlMCUSlugsMKII_DWork.IntegerDelay_X_c = 0.0F;
  controlMCUSlugsMKII_DWork.IntegerDelay1_X_a = 0.0F;
  controlMCUSlugsMKII_DWork.IntegerDelay_X_no = 0.0F;
  controlMCUSlugsMKII_DWork.IntegerDelay1_X_b = 0.0F;
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_gww = 0.0F;
  controlMCUSlugsMKII_DWork.IntegerDelay_X_f = 0.0F;
  controlMCUSlugsMKII_DWork.IntegerDelay1_X_ny[0] = 0.0F;
  controlMCUSlugsMKII_DWork.IntegerDelay1_X_ny[1] = 0.0F;
  controlMCUSlugsMKII_DWork.IntegerDelay2_X_m = 0.0F;
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_oe = 0.0F;
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_oe1 = 0.0F;
  controlMCUSlugsMKII_DWork.PrevY = 0.0F;
  controlMCUSlugsMKII_DWork.Memory1_PreviousInput = 0.0F;
  controlMCUSlugsMKII_DWork.Memory1_PreviousInput_e = 0.0F;
  controlMCUSlugsMKII_DWork.Memory1_PreviousInput_f = 0.0F;
  controlMCUSlugsMKII_DWork.Memory1_PreviousInput_a = 0.0F;
  controlMCUSlugsMKII_DWork.Memory1_PreviousInput_l = 0.0F;
  controlMCUSlugsMKII_DWork.sf_EmbeddedMATLABFunction_i.a = 0.0;
  controlMCUSlugsMKII_DWork.sf_EmbeddedMATLABFunction_i.b = 0.0;
  controlMCUSlugsMKII_DWork.sf_EmbeddedMATLABFunction_i.y_km1 = 0.0F;
  controlMCUSlugsMKII_DWork.sf_EmbeddedMATLABFunction_i.u_km1 = 0.0F;
  controlMCUSlugsMKII_DWork.sf_EmbeddedMATLABFunction_l.a = 0.0;
  controlMCUSlugsMKII_DWork.sf_EmbeddedMATLABFunction_l.b = 0.0;
  controlMCUSlugsMKII_DWork.sf_EmbeddedMATLABFunction_l.y_km1 = 0.0F;
  controlMCUSlugsMKII_DWork.sf_EmbeddedMATLABFunction_l.u_km1 = 0.0F;
  controlMCUSlugsMKII_DWork.sf_EmbeddedMATLABFunction_p.a = 0.0;
  controlMCUSlugsMKII_DWork.sf_EmbeddedMATLABFunction_p.b = 0.0;
  controlMCUSlugsMKII_DWork.sf_EmbeddedMATLABFunction_p.y_km1 = 0.0F;
  controlMCUSlugsMKII_DWork.sf_EmbeddedMATLABFunction_p.u_km1 = 0.0F;
  controlMCUSlugsMKII_DWork.sf_EmbeddedMATLABFunction_h.a = 0.0;
  controlMCUSlugsMKII_DWork.sf_EmbeddedMATLABFunction_h.b = 0.0;
  controlMCUSlugsMKII_DWork.sf_EmbeddedMATLABFunction_h.y_km1 = 0.0F;
  controlMCUSlugsMKII_DWork.sf_EmbeddedMATLABFunction_h.u_km1 = 0.0F;

  /* S-Function "dsPIC_MASTER" initialization Block: <Root>/Master */
  /* 1 testfcy 	*/
  /*  4.0E+007	*/
  /* CONFIG TIMER 1 for scheduling steps 	*/
  ConfigIntTimer1(T1_INT_PRIOR_0 & T1_INT_OFF);
  T1CON = 0x8010 ;                     /* T1_PS_1_8	*/
  PR1 = 49999;

  /* Configuration TIMER 2 */
  ConfigIntTimer2(T2_INT_PRIOR_0 & T2_INT_OFF);
  OpenTimer2(T2_ON & T2_GATE_OFF &
             T2_PS_1_8 & T2_SOURCE_INT , 65535);

  /* Configuration TRIS */
  TRISB = 65471;
  TRISE = 65023;

  /* Configuration ADCHS */
  AD1PCFGL = (68U);
  AD2PCFGL = (68U);
  AD1PCFGH = ((32U) & 65535);

  /* S-Function "dsPIC_PWM_IC" initialization Block: <S277>/Input Capture */
  /* Initialise Input Capture */
  /* config capture */
  OpenCapture2(IC_IDLE_CON & IC_TIMER2_SRC & IC_INT_1CAPTURE &
               IC_EVERY_RISE_EDGE);
  ConfigIntCapture2(IC_INT_ON & IC_INT_PRIOR_6);

  /* config capture */
  OpenCapture3(IC_IDLE_CON & IC_TIMER2_SRC & IC_INT_1CAPTURE &
               IC_EVERY_RISE_EDGE);
  ConfigIntCapture3(IC_INT_ON & IC_INT_PRIOR_6);

  /* config capture */
  OpenCapture4(IC_IDLE_CON & IC_TIMER2_SRC & IC_INT_1CAPTURE &
               IC_EVERY_RISE_EDGE);
  ConfigIntCapture4(IC_INT_ON & IC_INT_PRIOR_6);

  /* config capture */
  OpenCapture5(IC_IDLE_CON & IC_TIMER2_SRC & IC_INT_1CAPTURE &
               IC_EVERY_RISE_EDGE);
  ConfigIntCapture5(IC_INT_ON & IC_INT_PRIOR_6);

  /* config capture */
  OpenCapture8(IC_IDLE_CON & IC_TIMER2_SRC & IC_INT_1CAPTURE &
               IC_EVERY_RISE_EDGE);
  ConfigIntCapture8(IC_INT_ON & IC_INT_PRIOR_6);

  /* Start for InitialCondition: '<S278>/IC' */
  controlMCUSlugsMKII_B.IC_c = TRUE;
  controlMCUSlugsMKII_DWork.IC_FirstOutputTime = TRUE;

  /* Start for atomic SubSystem: '<S2>/Navigation' */

  /* Start for InitialCondition: '<S124>/IC1' */
  controlMCUSlugsMKII_DWork.IC1_FirstOutputTime = TRUE;

  /* Start for InitialCondition: '<S139>/IC' */
  controlMCUSlugsMKII_B.IC = 1.0;
  controlMCUSlugsMKII_DWork.IC_FirstOutputTime_i = TRUE;

  /* Start for InitialCondition: '<S180>/IC' */
  controlMCUSlugsMKII_B.IC_e = 1.0F;
  controlMCUSlugsMKII_DWork.IC_FirstOutputTime_b = TRUE;

  /* Start for InitialCondition: '<S140>/IC' */
  controlMCUSlugsMKII_DWork.IC_FirstOutputTime_d = TRUE;

  /* Start for enable SubSystem: '<S140>/Compute Total Run' */

  /* InitializeConditions for S-Function (sfix_udelay): '<S186>/Integer Delay3' */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_ft = 0.0F;

  /* VirtualOutportStart for Outport: '<S179>/Tot Run' */
  controlMCUSlugsMKII_B.Switch3_mv = 150.0F;

  /* end of Start for SubSystem: '<S140>/Compute Total Run' */

  /* Start for enable SubSystem: '<S124>/Compute P' */

  /* Start for InitialCondition: '<S133>/IC' */
  controlMCUSlugsMKII_DWork.IC_FirstOutputTime_k = TRUE;

  /* InitializeConditions for S-Function (sfix_udelay): '<S133>/Integer Delay1' */
  controlMCUSlugsMKII_DWork.IntegerDelay1_X_k[0] = 0.0F;

  /* InitializeConditions for S-Function (sfix_udelay): '<S133>/Integer Delay2' */
  controlMCUSlugsMKII_DWork.IntegerDelay2_X_e3[0] = 0.0F;

  /* InitializeConditions for S-Function (sfix_udelay): '<S133>/Integer Delay1' */
  controlMCUSlugsMKII_DWork.IntegerDelay1_X_k[1] = 0.0F;

  /* InitializeConditions for S-Function (sfix_udelay): '<S133>/Integer Delay2' */
  controlMCUSlugsMKII_DWork.IntegerDelay2_X_e3[1] = 0.0F;

  /* InitializeConditions for S-Function (sfix_udelay): '<S133>/Integer Delay1' */
  controlMCUSlugsMKII_DWork.IntegerDelay1_X_k[2] = 0.0F;

  /* InitializeConditions for S-Function (sfix_udelay): '<S133>/Integer Delay2' */
  controlMCUSlugsMKII_DWork.IntegerDelay2_X_e3[2] = 0.0F;

  /* VirtualOutportStart for Outport: '<S133>/P' */
  controlMCUSlugsMKII_B.IC_l = 50.0F;

  /* end of Start for SubSystem: '<S124>/Compute P' */

  /* end of Start for SubSystem: '<S2>/Navigation' */

  /* Start for enable SubSystem: '<S2>/L1 Output Feedback Controller With  Projection Operator' */

  /* Start for InitialCondition: '<S24>/IC' */
  controlMCUSlugsMKII_DWork.IC_FirstOutputTime_g = TRUE;

  /* Start for InitialCondition: '<S28>/IC' */
  controlMCUSlugsMKII_DWork.IC_FirstOutputTime_p = TRUE;

  /* InitializeConditions for UnitDelay: '<S33>/UD' */
  controlMCUSlugsMKII_DWork.UD_DSTATE_l = 0.0F;

  /* InitializeConditions for S-Function (sfix_udelay): '<S24>/Integer Delay' */
  controlMCUSlugsMKII_DWork.IntegerDelay_X_d = 0.0F;

  /* InitializeConditions for S-Function (sfix_udelay): '<S24>/Integer Delay1' */
  controlMCUSlugsMKII_DWork.IntegerDelay1_X_nc = 0.0F;

  /* InitializeConditions for S-Function (sfix_udelay): '<S26>/Integer Delay3' */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_cw = 0.0F;

  /* InitializeConditions for UnitDelay: '<S42>/UD' */
  controlMCUSlugsMKII_DWork.UD_DSTATE_ld = 0.0F;

  /* InitializeConditions for S-Function (sfix_udelay): '<S28>/Integer Delay' */
  controlMCUSlugsMKII_DWork.IntegerDelay_X_c = 0.0F;

  /* InitializeConditions for S-Function (sfix_udelay): '<S28>/Integer Delay1' */
  controlMCUSlugsMKII_DWork.IntegerDelay1_X_a = 0.0F;

  /* InitializeConditions for S-Function (sfix_udelay): '<S13>/Integer Delay' */
  controlMCUSlugsMKII_DWork.IntegerDelay_X_no = 0.0F;

  /* InitializeConditions for S-Function (sfix_udelay): '<S13>/Integer Delay1' */
  controlMCUSlugsMKII_DWork.IntegerDelay1_X_b = 0.0F;

  /* InitializeConditions for Merge: '<S25>/Merge' */
  if (rtmIsFirstInitCond(controlMCUSlugsMKII_M)) {
    controlMCUSlugsMKII_B.Merge = 0.0F;
  }

  /* InitializeConditions for S-Function (sfix_udelay): '<S27>/Integer Delay3' */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_gww = 0.0F;

  /* InitializeConditions for S-Function (sfix_udelay): '<S29>/Integer Delay' */
  controlMCUSlugsMKII_DWork.IntegerDelay_X_f = 0.0F;

  /* InitializeConditions for S-Function (sfix_udelay): '<S29>/Integer Delay1' */
  controlMCUSlugsMKII_DWork.IntegerDelay1_X_ny[0] = 0.0F;
  controlMCUSlugsMKII_DWork.IntegerDelay1_X_ny[1] = 0.0F;

  /* InitializeConditions for S-Function (sfix_udelay): '<S29>/Integer Delay2' */
  controlMCUSlugsMKII_DWork.IntegerDelay2_X_m = 0.0F;

  /* InitializeConditions for S-Function (sfix_udelay): '<S43>/Integer Delay3' */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_oe = 0.0F;

  /* InitializeConditions for S-Function (sfix_udelay): '<S44>/Integer Delay3' */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_oe1 = 0.0F;

  /* end of Start for SubSystem: '<S2>/L1 Output Feedback Controller With  Projection Operator' */

  /* Start for atomic SubSystem: '<S2>/Lateral Channel' */

  /* Start for enable SubSystem: '<S14>/Sideslip Compensation' */

  /* Start for InitialCondition: '<S71>/IC' */
  controlMCUSlugsMKII_DWork.IC_FirstOutputTime_e = TRUE;

  /* InitializeConditions for UnitDelay: '<S79>/UD' */
  controlMCUSlugsMKII_DWork.UD_DSTATE_o = 0.0F;

  /* InitializeConditions for S-Function (sfix_udelay): '<S71>/Integer Delay' */
  controlMCUSlugsMKII_DWork.IntegerDelay_X_b = 0.0F;

  /* InitializeConditions for S-Function (sfix_udelay): '<S71>/Integer Delay1' */
  controlMCUSlugsMKII_DWork.IntegerDelay1_X_f5 = 0.0;

  /* InitializeConditions for S-Function (sfix_udelay): '<S72>/Integer Delay3' */
  controlMCUSlugsMKII_DWork.IntegerDelay3_X_hc = 0.0F;

  /* end of Start for SubSystem: '<S14>/Sideslip Compensation' */

  /* end of Start for SubSystem: '<S2>/Lateral Channel' */

  /* S-Function "dsPIC_PWM_motor" initialization Block: <S8>/PWM Servo Output */
  /* Initialise Output Capture */
  SetDCMCPWM(1,0,0);
  SetDCMCPWM(2,0,0);
  SetDCMCPWM(3,0,0);
  SetDCMCPWM(4,0,0);

#define config                         (PWM_INT_DIS & PWM_FLTA_DIS_INT & PWM_INT_PR1 & PWM_FLTA_INT_PR0)

  ConfigIntMCPWM( config );

#define config1                        (PWM_EN & 0xDFFF & PWM_OP_SCALE1 & PWM_IPCLK_SCALE16 & PWM_MOD_UPDN)
#define config2                        (0xffff & PWM_PEN1L & PWM_MOD1_IND & PWM_PDIS1H & PWM_PEN2L & PWM_MOD2_IND & PWM_PDIS2H & PWM_PEN3L & PWM_MOD3_IND & PWM_PDIS3H & PWM_PEN4L & PWM_MOD4_IND & PWM_PDIS4H)
#define config3                        (PWM_SEVOPS1 & PWM_OSYNC_TCY & PWM_UEN)

  OpenMCPWM(25000,0,config1,config2,config3);

  /* S-Function "dsPIC_C_function_Call" Block: <Root>/Initialize the MCU [groundStationDriver.c] */
  controlMCUInit();
  controlMCUSlugsM_PrevZCSigState.HitCrossing_Input_ZCE = UNINITIALIZED_ZCSIG;
  controlMCUSlugsM_PrevZCSigState.HitCrossing1_Input_ZCE = UNINITIALIZED_ZCSIG;

  {
    int16_T i;

    /* InitializeConditions for Embedded MATLAB: '<S276>/Buffer IC Channel' */
    contro_BufferICChannel_Init(&controlMCUSlugsMKII_DWork.sf_BufferICChannel);

    /* InitializeConditions for Embedded MATLAB: '<S276>/Buffer IC Channel1' */
    contro_BufferICChannel_Init(&controlMCUSlugsMKII_DWork.sf_BufferICChannel1);

    /* InitializeConditions for Embedded MATLAB: '<S276>/Buffer IC Channel2' */
    contro_BufferICChannel_Init(&controlMCUSlugsMKII_DWork.sf_BufferICChannel2);

    /* InitializeConditions for Embedded MATLAB: '<S276>/Buffer IC Channel3' */
    contro_BufferICChannel_Init(&controlMCUSlugsMKII_DWork.sf_BufferICChannel3);

    /* InitializeConditions for S-Function (sfix_udelay): '<S6>/Integer Delay' */
    controlMCUSlugsMKII_DWork.IntegerDelay_X_p = 0.0F;

    /* InitializeConditions for S-Function (sfix_udelay): '<S278>/Integer Delay2' */
    controlMCUSlugsMKII_DWork.IntegerDelay2_X_k = FALSE;

    /* InitializeConditions for S-Function (sfix_udelay): '<S17>/Integer Delay3' */
    controlMCUSlugsMKII_DWork.IntegerDelay3_X_j5 = 0.0F;

    /* InitializeConditions for atomic SubSystem: '<S2>/Navigation' */

    /* InitializeConditions for S-Function (sfix_udelay): '<S261>/Integer Delay3' */
    controlMCUSlugsMKII_DWork.IntegerDelay3_X_lj = 0.0F;

    /* InitializeConditions for S-Function (sfix_udelay): '<S124>/Integer Delay2' */
    controlMCUSlugsMKII_DWork.IntegerDelay2_X = 1.0;

    /* InitializeConditions for S-Function (sfix_udelay): '<S138>/Integer Delay1' */
    controlMCUSlugsMKII_DWork.IntegerDelay1_X_p = FALSE;

    /* InitializeConditions for Embedded MATLAB: '<S124>/Embedded MATLAB Function' */
    controlMCUSlugsMKII_DWork.fromWP_not_empty = FALSE;

    /* InitializeConditions for S-Function (sfix_udelay): '<S139>/Integer Delay2' */
    controlMCUSlugsMKII_DWork.IntegerDelay2_X_l = 0.0;

    /* InitializeConditions for S-Function (sfix_udelay): '<S132>/Integer Delay3' */
    controlMCUSlugsMKII_DWork.IntegerDelay3_X_b3 = 0.0F;

    /* InitializeConditions for S-Function (sfix_udelay): '<S254>/Integer Delay3' */
    controlMCUSlugsMKII_DWork.IntegerDelay3_X_g = 0.0F;

    /* InitializeConditions for S-Function (sfix_udelay): '<S268>/Integer Delay3' */
    controlMCUSlugsMKII_DWork.IntegerDelay3_X_f = 0.0F;

    /* InitializeConditions for S-Function (sfix_udelay): '<S124>/Integer Delay3' */
    controlMCUSlugsMKII_DWork.IntegerDelay3_X_a = 50.0F;

    /* InitializeConditions for S-Function (sfix_udelay): '<S140>/Integer Delay1' */
    controlMCUSlugsMKII_DWork.IntegerDelay1_X_fi = 0U;

    /* InitializeConditions for S-Function (sfix_udelay): '<S180>/Integer Delay1' */
    controlMCUSlugsMKII_DWork.IntegerDelay1_X_i = 1.0F;

    /* InitializeConditions for S-Function (sfix_udelay): '<S180>/Integer Delay2' */
    controlMCUSlugsMKII_DWork.IntegerDelay2_X_e[0] = 1.0F;
    controlMCUSlugsMKII_DWork.IntegerDelay2_X_e[1] = 1.0F;

    /* InitializeConditions for S-Function (sfix_udelay): '<S182>/Integer Delay3' */
    controlMCUSlugsMKII_DWork.IntegerDelay3_X = 0.0;

    /* InitializeConditions for Embedded MATLAB: '<S124>/Embedded MATLAB Function1' */
    controlMCUSlugsMKII_DWork.oldSw = 0U;
    controlMCUSlugsMKII_DWork.internalTimer = 0U;

    /* InitializeConditions for S-Function (sfix_udelay): '<S137>/Integer Delay3' */
    controlMCUSlugsMKII_DWork.IntegerDelay3_X_n = 0.0F;

    /* InitializeConditions for S-Function (sfix_udelay): '<S271>/Integer Delay3' */
    controlMCUSlugsMKII_DWork.IntegerDelay3_X_ch = 0.0F;

    /* end of InitializeConditions for SubSystem: '<S2>/Navigation' */

    /* InitializeConditions for atomic SubSystem: '<S2>/Longitudinal Channel' */

    /* InitializeConditions for S-Function (sfix_udelay): '<S99>/Integer Delay3' */
    controlMCUSlugsMKII_DWork.IntegerDelay3_X_i = 0.0F;

    /* InitializeConditions for Embedded MATLAB: '<S88>/Embedded MATLAB Function' */
    EmbeddedMATLABFunction_Init
      (&controlMCUSlugsMKII_DWork.sf_EmbeddedMATLABFunction_p);

    /* InitializeConditions for Embedded MATLAB: '<S90>/Embedded MATLAB Function' */
    EmbeddedMATLABFunction_Init
      (&controlMCUSlugsMKII_DWork.sf_EmbeddedMATLABFunction_i);

    /* InitializeConditions for RateLimiter: '<S15>/Rate Limiter' */
    controlMCUSlugsMKII_DWork.PrevY = 180.0F;

    /* InitializeConditions for S-Function (sfix_udelay): '<S97>/Integer Delay3' */
    controlMCUSlugsMKII_DWork.IntegerDelay3_X_m = 0.0F;

    /* InitializeConditions for S-Function (sfix_udelay): '<S116>/Integer Delay2' */
    controlMCUSlugsMKII_DWork.IntegerDelay2_X_lq = 0.0F;

    /* InitializeConditions for Memory: '<S94>/Memory1' */
    controlMCUSlugsMKII_DWork.Memory1_PreviousInput = 0.0F;

    /* InitializeConditions for S-Function (sfix_udelay): '<S118>/Integer Delay3' */
    controlMCUSlugsMKII_DWork.IntegerDelay3_X_c = 0.0;

    /* InitializeConditions for S-Function (sfix_udelay): '<S116>/Integer Delay' */
    controlMCUSlugsMKII_DWork.IntegerDelay_X = 0.0;

    /* InitializeConditions for S-Function (sfix_udelay): '<S116>/Integer Delay1' */
    controlMCUSlugsMKII_DWork.IntegerDelay1_X[0] = 0.0;
    controlMCUSlugsMKII_DWork.IntegerDelay1_X[1] = 0.0;

    /* InitializeConditions for S-Function (sfix_udelay): '<S117>/Integer Delay3' */
    controlMCUSlugsMKII_DWork.IntegerDelay3_X_at = 0.0F;

    /* InitializeConditions for S-Function (sfix_udelay): '<S100>/Integer Delay3' */
    controlMCUSlugsMKII_DWork.IntegerDelay3_X_fk = 0.0F;

    /* InitializeConditions for Embedded MATLAB: '<S89>/Embedded MATLAB Function' */
    EmbeddedMATLABFunction_Init
      (&controlMCUSlugsMKII_DWork.sf_EmbeddedMATLABFunction_l);

    /* InitializeConditions for S-Function (sfix_udelay): '<S96>/Integer Delay3' */
    controlMCUSlugsMKII_DWork.IntegerDelay3_X_e = 0.0F;

    /* InitializeConditions for S-Function (sfix_udelay): '<S110>/Integer Delay2' */
    controlMCUSlugsMKII_DWork.IntegerDelay2_X_d = 0.0F;

    /* InitializeConditions for Memory: '<S92>/Memory1' */
    controlMCUSlugsMKII_DWork.Memory1_PreviousInput_e = 0.0F;

    /* InitializeConditions for S-Function (sfix_udelay): '<S111>/Integer Delay3' */
    controlMCUSlugsMKII_DWork.IntegerDelay3_X_l = 0.0;

    /* InitializeConditions for S-Function (sfix_udelay): '<S110>/Integer Delay' */
    controlMCUSlugsMKII_DWork.IntegerDelay_X_i = 0.0;

    /* InitializeConditions for S-Function (sfix_udelay): '<S110>/Integer Delay1' */
    controlMCUSlugsMKII_DWork.IntegerDelay1_X_o[0] = 0.0;
    controlMCUSlugsMKII_DWork.IntegerDelay1_X_o[1] = 0.0;

    /* InitializeConditions for S-Function (sfix_udelay): '<S112>/Integer Delay3' */
    controlMCUSlugsMKII_DWork.IntegerDelay3_X_ex = 0.0F;

    /* InitializeConditions for S-Function (sfix_udelay): '<S98>/Integer Delay3' */
    controlMCUSlugsMKII_DWork.IntegerDelay3_X_nv = 0.0F;
    for (i = 0; i < 5; i++) {
      /* InitializeConditions for S-Function (sfix_udelay): '<S92>/NDelays' */
      controlMCUSlugsMKII_DWork.NDelays_X[i] = 0.0F;

      /* InitializeConditions for S-Function (sfix_udelay): '<S95>/NDelays' */
      controlMCUSlugsMKII_DWork.NDelays_X_c[i] = 0.0F;
    }

    /* InitializeConditions for S-Function (sfix_udelay): '<S120>/Integer Delay2' */
    controlMCUSlugsMKII_DWork.IntegerDelay2_X_n = 0.0F;

    /* InitializeConditions for Memory: '<S95>/Memory1' */
    controlMCUSlugsMKII_DWork.Memory1_PreviousInput_f = 0.0F;

    /* InitializeConditions for S-Function (sfix_udelay): '<S121>/Integer Delay3' */
    controlMCUSlugsMKII_DWork.IntegerDelay3_X_k = 0.0;

    /* InitializeConditions for S-Function (sfix_udelay): '<S120>/Integer Delay' */
    controlMCUSlugsMKII_DWork.IntegerDelay_X_g = 0.0;

    /* InitializeConditions for S-Function (sfix_udelay): '<S120>/Integer Delay1' */
    controlMCUSlugsMKII_DWork.IntegerDelay1_X_oa[0] = 0.0;
    controlMCUSlugsMKII_DWork.IntegerDelay1_X_oa[1] = 0.0;

    /* InitializeConditions for S-Function (sfix_udelay): '<S122>/Integer Delay3' */
    controlMCUSlugsMKII_DWork.IntegerDelay3_X_p = 0.0F;

    /* end of InitializeConditions for SubSystem: '<S2>/Longitudinal Channel' */

    /* InitializeConditions for S-Function (sfix_udelay): '<S19>/Integer Delay3' */
    controlMCUSlugsMKII_DWork.IntegerDelay3_X_b = 0.0F;

    /* InitializeConditions for atomic SubSystem: '<S2>/Lateral Channel' */

    /* InitializeConditions for S-Function (sfix_udelay): '<S62>/Integer Delay3' */
    controlMCUSlugsMKII_DWork.IntegerDelay3_X_nc = 0.0F;

    /* InitializeConditions for S-Function (sfix_udelay): '<S63>/Integer Delay3' */
    controlMCUSlugsMKII_DWork.IntegerDelay3_X_gw = 0.0F;

    /* InitializeConditions for S-Function (sfix_udelay): '<S53>/Integer Delay3' */
    controlMCUSlugsMKII_DWork.IntegerDelay3_X_h = 0.0F;

    /* InitializeConditions for Embedded MATLAB: '<S45>/Embedded MATLAB Function' */
    EmbeddedMATLABFunction_Init
      (&controlMCUSlugsMKII_DWork.sf_EmbeddedMATLABFunction_h);

    /* InitializeConditions for S-Function (sfix_udelay): '<S54>/Integer Delay3' */
    controlMCUSlugsMKII_DWork.IntegerDelay3_X_ae = 0.0F;

    /* InitializeConditions for atomic SubSystem: '<S14>/High Pass (Washout) Filter' */

    /* InitializeConditions for S-Function (sfix_udelay): '<S50>/Integer Delay' */
    controlMCUSlugsMKII_DWork.IntegerDelay_X_nm = 0.0F;

    /* InitializeConditions for S-Function (sfix_udelay): '<S50>/Integer Delay1' */
    controlMCUSlugsMKII_DWork.IntegerDelay1_X_l = 0.0F;

    /* end of InitializeConditions for SubSystem: '<S14>/High Pass (Washout) Filter' */

    /* InitializeConditions for S-Function (sfix_udelay): '<S52>/Integer Delay3' */
    controlMCUSlugsMKII_DWork.IntegerDelay3_X_b5 = 0.0F;

    /* InitializeConditions for S-Function (sfix_udelay): '<S83>/Integer Delay2' */
    controlMCUSlugsMKII_DWork.IntegerDelay2_X_g = 0.0F;

    /* InitializeConditions for Memory: '<S57>/Memory1' */
    controlMCUSlugsMKII_DWork.Memory1_PreviousInput_a = 0.0F;

    /* InitializeConditions for S-Function (sfix_udelay): '<S84>/Integer Delay3' */
    controlMCUSlugsMKII_DWork.IntegerDelay3_X_o = 0.0;

    /* InitializeConditions for S-Function (sfix_udelay): '<S83>/Integer Delay' */
    controlMCUSlugsMKII_DWork.IntegerDelay_X_i0 = 0.0;

    /* InitializeConditions for S-Function (sfix_udelay): '<S83>/Integer Delay1' */
    controlMCUSlugsMKII_DWork.IntegerDelay1_X_f[0] = 0.0;
    controlMCUSlugsMKII_DWork.IntegerDelay1_X_f[1] = 0.0;

    /* InitializeConditions for S-Function (sfix_udelay): '<S85>/Integer Delay3' */
    controlMCUSlugsMKII_DWork.IntegerDelay3_X_cn = 0.0F;

    /* InitializeConditions for S-Function (sfix_udelay): '<S51>/Integer Delay3' */
    controlMCUSlugsMKII_DWork.IntegerDelay3_X_mk = 0.0F;
    for (i = 0; i < 5; i++) {
      /* InitializeConditions for S-Function (sfix_udelay): '<S57>/NDelays' */
      controlMCUSlugsMKII_DWork.NDelays_X_e[i] = 0.0F;

      /* InitializeConditions for S-Function (sfix_udelay): '<S55>/NDelays' */
      controlMCUSlugsMKII_DWork.NDelays_X_m[i] = 0.0F;
    }

    /* InitializeConditions for S-Function (sfix_udelay): '<S67>/Integer Delay2' */
    controlMCUSlugsMKII_DWork.IntegerDelay2_X_j = 0.0F;

    /* InitializeConditions for Memory: '<S55>/Memory1' */
    controlMCUSlugsMKII_DWork.Memory1_PreviousInput_l = 0.0F;

    /* InitializeConditions for S-Function (sfix_udelay): '<S68>/Integer Delay3' */
    controlMCUSlugsMKII_DWork.IntegerDelay3_X_j = 0.0;

    /* InitializeConditions for S-Function (sfix_udelay): '<S67>/Integer Delay' */
    controlMCUSlugsMKII_DWork.IntegerDelay_X_n = 0.0;

    /* InitializeConditions for S-Function (sfix_udelay): '<S67>/Integer Delay1' */
    controlMCUSlugsMKII_DWork.IntegerDelay1_X_n[0] = 0.0;
    controlMCUSlugsMKII_DWork.IntegerDelay1_X_n[1] = 0.0;

    /* InitializeConditions for S-Function (sfix_udelay): '<S69>/Integer Delay3' */
    controlMCUSlugsMKII_DWork.IntegerDelay3_X_hp = 0.0F;

    /* end of InitializeConditions for SubSystem: '<S2>/Lateral Channel' */

    /* set "at time zero" to false */
    if (rtmIsFirstInitCond(controlMCUSlugsMKII_M)) {
      rtmSetFirstInitCond(controlMCUSlugsMKII_M, 0);
    }
  }
}

/* File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
