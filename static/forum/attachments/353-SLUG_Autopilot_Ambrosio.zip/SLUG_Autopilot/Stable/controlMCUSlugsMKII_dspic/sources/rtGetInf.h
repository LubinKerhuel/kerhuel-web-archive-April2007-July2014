/*
 * File: rtGetInf.h
 *
 * Real-Time Workshop code generated for Simulink model controlMCUSlugsMKII.
 *
 * Model version                        : 1.714
 * Real-Time Workshop file version      : 7.5  (R2010a)  25-Jan-2010
 * Real-Time Workshop file generated on : Tue Nov 23 13:12:51 2010
 * TLC version                          : 7.5 (Jan 19 2010)
 * C source code generated on           : Tue Nov 23 13:12:52 2010
 *--------------------------------------------------------------
 *   Embedded Coder for Microchip dsPIC family.                 |
 *   Generate .c and .h files from your Matlab/simulink model   |
 *   and compile the diagram to .hex and .coff file that can be |
 *   downloaded directly into the microcontroller               |
 *                                                              |
 * Licence Accorded to Blake Mills                              |
 *                     University of Colorado-Boulder           |
 *                                                              |
 *   Written by Lubin KERHUEL -  http://www.kerhuel.eu          |
 *  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - |
 *   Version 3.3a                              22-Nov-2010      |
 *   For Matlab 7.10            R2010a                          |
 *--------------------------------------------------------------
 */

#ifndef RTW_HEADER_rtGetInf_h_
#define RTW_HEADER_rtGetInf_h_
#include <stddef.h>
#include "rtwtypes.h"
#include "rt_nonfinite.h"

extern real_T rtGetInf(void);
extern real32_T rtGetInfF(void);
extern real_T rtGetMinusInf(void);
extern real32_T rtGetMinusInfF(void);

#endif                                 /* RTW_HEADER_rtGetInf_h_ */

/* File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
