/*
 * File: controlMCUSlugsMKII.h
 *
 * Real-Time Workshop code generated for Simulink model controlMCUSlugsMKII.
 *
 * Model version                        : 1.714
 * Real-Time Workshop file version      : 7.5  (R2010a)  25-Jan-2010
 * Real-Time Workshop file generated on : Tue Nov 23 13:12:51 2010
 * TLC version                          : 7.5 (Jan 19 2010)
 * C source code generated on           : Tue Nov 23 13:12:52 2010
 *--------------------------------------------------------------
 *   Embedded Coder for Microchip dsPIC family.                 |
 *   Generate .c and .h files from your Matlab/simulink model   |
 *   and compile the diagram to .hex and .coff file that can be |
 *   downloaded directly into the microcontroller               |
 *                                                              |
 * Licence Accorded to Blake Mills                              |
 *                     University of Colorado-Boulder           |
 *                                                              |
 *   Written by Lubin KERHUEL -  http://www.kerhuel.eu          |
 *  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - |
 *   Version 3.3a                              22-Nov-2010      |
 *   For Matlab 7.10            R2010a                          |
 *--------------------------------------------------------------
 */

#ifndef RTW_HEADER_controlMCUSlugsMKII_h_
#define RTW_HEADER_controlMCUSlugsMKII_h_
#ifndef controlMCUSlugsMKII_COMMON_INCLUDES_
# define controlMCUSlugsMKII_COMMON_INCLUDES_
#include <math.h>
#include <string.h>
#include "rtwtypes.h"
#include "rt_zcfcn.h"
#include "rt_nonfinite.h"
#include "rtGetInf.h"
#include "rtGetNaN.h"
#include "rt_MAXf_snf.h"
#include "rt_SATURATE.h"
#include "rt_SIGNf_snf.h"
#endif                                 /* controlMCUSlugsMKII_COMMON_INCLUDES_ */

#include "controlMCUSlugsMKII_types.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((void*) 0)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((void) 0)
#endif

#ifndef rtmStepTask
# define rtmStepTask(rtm, idx)         ((rtm)->Timing.TaskCounters.TID[(idx)] == 0)
#endif

#ifndef rtmGetStopRequested
# define rtmGetStopRequested(rtm)      ((void*) 0)
#endif

#ifndef rtmTaskCounter
# define rtmTaskCounter(rtm, idx)      ((rtm)->Timing.TaskCounters.TID[(idx)])
#endif

/* Block signals for system '<S45>/Embedded MATLAB Function' */
typedef struct {
  real32_T y;                          /* '<S45>/Embedded MATLAB Function' */
} rtB_EmbeddedMATLABFunction_cont;

/* Block states (auto storage) for system '<S45>/Embedded MATLAB Function' */
typedef struct {
  real_T a;                            /* '<S45>/Embedded MATLAB Function' */
  real_T b;                            /* '<S45>/Embedded MATLAB Function' */
  real32_T y_km1;                      /* '<S45>/Embedded MATLAB Function' */
  real32_T u_km1;                      /* '<S45>/Embedded MATLAB Function' */
  boolean_T a_not_empty;               /* '<S45>/Embedded MATLAB Function' */
} rtDW_EmbeddedMATLABFunction_con;

/* Block signals for system '<S70>/negprotect' */
typedef struct {
  real32_T zpVal;                      /* '<S70>/negprotect' */
} rtB_negprotect_controlMCUSlugsM;

/* Block signals for system '<S14>/myMux Fun1' */
typedef struct {
  real32_T y[3];                       /* '<S14>/myMux Fun1' */
} rtB_myMuxFun1_controlMCUSlugsMK;

/* Block signals for system '<S129>/Embedded MATLAB Function' */
typedef struct {
  real32_T xDoty;                      /* '<S129>/Embedded MATLAB Function' */
} rtB_EmbeddedMATLABFunction_co_p;

/* Block signals for system '<S150>/Embedded MATLAB Function' */
typedef struct {
  real32_T xDoty;                      /* '<S150>/Embedded MATLAB Function' */
} rtB_EmbeddedMATLABFunction_co_e;

/* Block signals for system '<S276>/Buffer IC Channel' */
typedef struct {
  uint16_T history[7];                 /* '<S276>/Buffer IC Channel' */
} rtB_BufferICChannel_controlMCUS;

/* Block states (auto storage) for system '<S276>/Buffer IC Channel' */
typedef struct {
  uint16_T oldValues[7];               /* '<S276>/Buffer IC Channel' */
} rtDW_BufferICChannel_controlMCU;

/* Block signals for system '<S333>/myMux Fun1' */
typedef struct {
  real32_T y[9];                       /* '<S333>/myMux Fun1' */
} rtB_myMuxFun1_controlMCUSlugs_p;

/* Block signals for system '<S334>/myMux Fun1' */
typedef struct {
  real32_T y[3];                       /* '<S334>/myMux Fun1' */
} rtB_myMuxFun1_controlMCUSlugs_b;

/* Block signals (auto storage) */
typedef struct {
  real_T IC;                           /* '<S139>/IC' */
  real_T Switch3;                      /* '<S182>/Switch3' */
  real_T swIncrement;                  /* '<S124>/Embedded MATLAB Function1' */
  real_T Switch3_n;                    /* '<S118>/Switch3' */
  real_T Switch3_k;                    /* '<S111>/Switch3' */
  real_T Switch3_o;                    /* '<S121>/Switch3' */
  real_T Switch3_g;                    /* '<S84>/Switch3' */
  real_T Switch3_na;                   /* '<S68>/Switch3' */
  real_T Subtract;                     /* '<S71>/Subtract' */
  real32_T GetMidLevelCommandsnavSupportc[3];/* '<Root>/Get MidLevel Commands [navSupport.c]' */
  real32_T GetDynamicPnavSupportc;     /* '<Root>/Get Dynamic P [navSupport.c]' */
  real32_T GetPidaccordingtoIndex[3];  /* '<S3>/Get Pid according to Index' */
  real32_T IntegerDelay;               /* '<S6>/Integer Delay' */
  real32_T GetXYZnavSupportc[3];       /* '<Root>/Get XYZ [navSupport.c]' */
  real32_T Switch3_ov;                 /* '<S17>/Switch3' */
  real32_T GetPidaccordingtoIndex1[3]; /* '<S3>/Get Pid according to Index1' */
  real32_T navSupportc[3];             /* '<S9>/[navSupport.c] ' */
  real32_T UnitConversion[3];          /* '<S309>/Unit Conversion' */
  real32_T CFunctionCall1;             /* '<S334>/C Function Call1' */
  real32_T CFunctionCall4;             /* '<S334>/C Function Call4' */
  real32_T CFunctionCall5;             /* '<S334>/C Function Call5' */
  real32_T CFunctionCall;              /* '<S334>/C Function Call' */
  real32_T CFunctionCall2;             /* '<S334>/C Function Call2' */
  real32_T CFunctionCall3;             /* '<S334>/C Function Call3' */
  real32_T GetAttitudenavSupportc[6];  /* '<S9>/Get Attitude [navSupport.c]' */
  real32_T CFunctionCall1_g;           /* '<S351>/C Function Call1' */
  real32_T CFunctionCall4_a;           /* '<S351>/C Function Call4' */
  real32_T CFunctionCall5_d;           /* '<S351>/C Function Call5' */
  real32_T CFunctionCall_i;            /* '<S351>/C Function Call' */
  real32_T CFunctionCall2_e;           /* '<S351>/C Function Call2' */
  real32_T CFunctionCall3_i;           /* '<S351>/C Function Call3' */
  real32_T Product[9];                 /* '<S9>/Product' */
  real32_T CFunctionCall_i0;           /* '<S317>/C Function Call' */
  real32_T u1;                         /* '<S318>/[-1,1]' */
  real32_T CFunctionCall_c;            /* '<S318>/C Function Call' */
  real32_T CFunctionCall_c5;           /* '<S316>/C Function Call' */
  real32_T Product1[3];                /* '<S9>/Product1' */
  real32_T GetPidaccordingtoIndex2[3]; /* '<S3>/Get Pid according to Index2' */
  real32_T GetVnednavSupportc[3];      /* '<Root>/Get Vned [navSupport.c]' */
  real32_T navSupportc_o[3];           /* '<Root>/[navSupport.c]' */
  real32_T navSupportc_n[3];           /* '<Root>/[navSupport.c]   ' */
  real32_T GetPidaccordingtoIndex3[3]; /* '<S3>/Get Pid according to Index3' */
  real32_T navSupportc_k[3];           /* '<S3>/[navSupport.c]' */
  real32_T apUtilsc;                   /* '<S20>/[apUtils.c]' */
  real32_T apUtilsc_p;                 /* '<S21>/[apUtils.c]' */
  real32_T Switch3_oe;                 /* '<S19>/Switch3' */
  real32_T navSupportc_g[3];           /* '<Root>/[navSupport.c] ' */
  real32_T GettheAccelerometersnavSupportc[3];/* '<S9>/Get the Accelerometers [navSupport.c]' */
  real32_T GettheAccelBiasnavSupportc[3];/* '<S9>/Get the Accel Bias [navSupport.c]' */
  real32_T y[6];                       /* '<S9>/myMux Fun2' */
  real32_T DataTypeConversion;         /* '<S286>/Data Type Conversion' */
  real32_T DataTypeConversion_f;       /* '<S287>/Data Type Conversion' */
  real32_T DataTypeConversion_b;       /* '<S288>/Data Type Conversion' */
  real32_T DataTypeConversion_c;       /* '<S289>/Data Type Conversion' */
  real32_T CFunctionCall_a;            /* '<S264>/C Function Call' */
  real32_T Switch3_h;                  /* '<S261>/Switch3' */
  real32_T Switch3_nn;                 /* '<S132>/Switch3' */
  real32_T Add;                        /* '<S238>/Add' */
  real32_T CFunctionCall_o;            /* '<S256>/C Function Call' */
  real32_T CFunctionCall_f;            /* '<S255>/C Function Call' */
  real32_T L1_vec[3];                  /* '<S238>/Add2' */
  real32_T CFunctionCall_m;            /* '<S247>/C Function Call' */
  real32_T Switch3_a;                  /* '<S254>/Switch3' */
  real32_T u1_h;                       /* '<S243>/[-1,1]' */
  real32_T CFunctionCall_h;            /* '<S243>/C Function Call' */
  real32_T CFunctionCall_e;            /* '<S269>/C Function Call' */
  real32_T Switch3_m;                  /* '<S268>/Switch3' */
  real32_T Diff;                       /* '<S196>/Diff' */
  real32_T CFunctionCall_j;            /* '<S197>/C Function Call' */
  real32_T Diff_o;                     /* '<S199>/Diff' */
  real32_T CFunctionCall_l;            /* '<S200>/C Function Call' */
  real32_T Diff_a;                     /* '<S202>/Diff' */
  real32_T CFunctionCall_ep;           /* '<S203>/C Function Call' */
  real32_T IC_e;                       /* '<S180>/IC' */
  real32_T Switch3_e;                  /* '<S137>/Switch3' */
  real32_T Divide;                     /* '<S127>/Divide' */
  real32_T CFunctionCall_g;            /* '<S272>/C Function Call' */
  real32_T Switch3_c;                  /* '<S271>/Switch3' */
  real32_T CFunctionCall_d[3];         /* '<S208>/C Function Call' */
  real32_T Switch[3];                  /* '<S125>/Switch' */
  real32_T CFunctionCall_a1[3];        /* '<S209>/C Function Call' */
  real32_T Reshape1[3];                /* '<S206>/Reshape1' */
  real32_T CFunctionCall_b;            /* '<S214>/C Function Call' */
  real32_T Divide_n[3];                /* '<S210>/Divide' */
  real32_T CFunctionCall_c0;           /* '<S221>/C Function Call' */
  real32_T Divide_p[3];                /* '<S211>/Divide' */
  real32_T y_e[4];                     /* '<S124>/myMux Fun2' */
  real32_T CFunctionCall_fg;           /* '<S188>/C Function Call' */
  real32_T Switch3_mv;                 /* '<S186>/Switch3' */
  real32_T UAVPos[3];                  /* '<S136>/UAV Pos' */
  real32_T CFunctionCall_aj[3];        /* '<S174>/C Function Call' */
  real32_T RhhcosphicoslambXe;         /* '<S175>/(Rh+h)cos(phi)*cos(lamb)=Xe' */
  real32_T RhhcosphisinlambYe;         /* '<S175>/(Rh+h)cos(phi)*sin(lamb)=Ye' */
  real32_T Ze;                         /* '<S175>/Ze' */
  real32_T IntegerDelay1[3];           /* '<S133>/Integer Delay1' */
  real32_T CFunctionCall_l0;           /* '<S167>/C Function Call' */
  real32_T CFunctionCall_mb;           /* '<S149>/C Function Call' */
  real32_T Divide_l[3];                /* '<S147>/Divide' */
  real32_T CFunctionCall_ir;           /* '<S166>/C Function Call' */
  real32_T Merge4;                     /* '<S145>/Merge4' */
  real32_T CFunctionCall_hb;           /* '<S163>/C Function Call' */
  real32_T CFunctionCall1_i;           /* '<S163>/C Function Call1' */
  real32_T CFunctionCall_ap[3];        /* '<S146>/C Function Call' */
  real32_T UEN2NEU[3];                 /* '<S144>/UEN 2 NEU' */
  real32_T IC_l;                       /* '<S133>/IC' */
  real32_T Add_g;                      /* '<S91>/Add' */
  real32_T CFunctionCall_ab;           /* '<S108>/C Function Call' */
  real32_T CFunctionCall_m4;           /* '<S113>/C Function Call' */
  real32_T Switch3_f;                  /* '<S99>/Switch3' */
  real32_T ScheduleLPF;                /* '<S15>/Schedule LPF' */
  real32_T Switch3_c1;                 /* '<S97>/Switch3' */
  real32_T Switch3_b;                  /* '<S117>/Switch3' */
  real32_T Switch3_mx;                 /* '<S100>/Switch3' */
  real32_T Switch3_kr;                 /* '<S96>/Switch3' */
  real32_T Switch3_p;                  /* '<S112>/Switch3' */
  real32_T Switch3_f3;                 /* '<S98>/Switch3' */
  real32_T Switch3_el;                 /* '<S122>/Switch3' */
  real32_T u060;                       /* '<S15>/[-60 60]' */
  real32_T CFunctionCall1_b;           /* '<S101>/C Function Call1' */
  real32_T y_j[2];                     /* '<S15>/myMux Fun1' */
  real32_T Switch3_gn;                 /* '<S62>/Switch3' */
  real32_T bankLimit;                  /* '<S49>/bank Limit' */
  real32_T CFunctionCall_in;           /* '<S64>/C Function Call' */
  real32_T Switch3_h4;                 /* '<S63>/Switch3' */
  real32_T PsiDotLimit;                /* '<S14>/Psi Dot  Limit' */
  real32_T Divide_m;                   /* '<S60>/Divide' */
  real32_T CFunctionCall_i4;           /* '<S86>/C Function Call' */
  real32_T Switch3_pa;                 /* '<S53>/Switch3' */
  real32_T navSupportc_l[3];           /* '<S14>/[navSupport.c]   ' */
  real32_T Switch3_fx;                 /* '<S54>/Switch3' */
  real32_T u2;                         /* '<S14>/[-2 2]' */
  real32_T Switch3_my;                 /* '<S52>/Switch3' */
  real32_T Switch3_pf;                 /* '<S85>/Switch3' */
  real32_T Switch3_i;                  /* '<S51>/Switch3' */
  real32_T Switch3_cv;                 /* '<S69>/Switch3' */
  real32_T bankLimit_a;                /* '<S70>/bank Limit' */
  real32_T CFunctionCall_gd;           /* '<S74>/C Function Call' */
  real32_T Divide_a;                   /* '<S73>/Divide' */
  real32_T CFunctionCall_id;           /* '<S80>/C Function Call' */
  real32_T Switch3_pq;                 /* '<S72>/Switch3' */
  real32_T c;                          /* '<S77>/Math Function' */
  real32_T c_k;                        /* '<S77>/1-c' */
  real32_T u2_o;                       /* '<S50>/[-2 2]' */
  real32_T Subtract_b;                 /* '<S24>/Subtract' */
  real32_T Switch3_cj;                 /* '<S26>/Switch3' */
  real32_T Subtract_c;                 /* '<S28>/Subtract' */
  real32_T Merge;                      /* '<S25>/Merge' */
  real32_T PsiDotLimit_g;              /* '<S13>/Psi Dot  Limit' */
  real32_T Switch3_ae;                 /* '<S27>/Switch3' */
  real32_T Switch3_gq;                 /* '<S43>/Switch3' */
  real32_T Switch3_im;                 /* '<S44>/Switch3' */
  real32_T T;                          /* '<S39>/-T' */
  real32_T CFunctionCall_dr;           /* '<S41>/C Function Call' */
  real32_T c_i;                        /* '<S39>/1-c' */
  real32_T T_i;                        /* '<S30>/-T' */
  real32_T CFunctionCall_p;            /* '<S32>/C Function Call' */
  real32_T c_kt;                       /* '<S30>/1-c' */
  int16_T DataTypeConversion2[3];      /* '<S14>/Data Type Conversion2' */
  uint16_T InputCapture_o1;            /* '<S277>/Input Capture' */
  uint16_T InputCapture_o2;            /* '<S277>/Input Capture' */
  uint16_T InputCapture_o3;            /* '<S277>/Input Capture' */
  uint16_T InputCapture_o4;            /* '<S277>/Input Capture' */
  uint16_T InputCapture_o5;            /* '<S277>/Input Capture' */
  uint16_T CalculusTimeStep_o1;        /* '<S11>/Calculus Time Step' */
  uint16_T CalculusTimeStep_o2;        /* '<S11>/Calculus Time Step' */
  uint16_T Merge_n[4];                 /* '<S291>/Merge' */
  uint16_T DataTypeConversion4;        /* '<S290>/Data Type Conversion4' */
  uint16_T DataTypeConversion2_e;      /* '<S280>/Data Type Conversion2' */
  uint16_T DataTypeConversion3;        /* '<S280>/Data Type Conversion3' */
  uint16_T DataTypeConversion1;        /* '<S280>/Data Type Conversion1' */
  uint16_T DataTypeConversion4_p;      /* '<S280>/Data Type Conversion4' */
  uint16_T y_d[5];                     /* '<S8>/myMux Fun1' */
  uint16_T ChoosetheMediannavSupportc; /* '<S279>/Choose the Median [navSupport.c]' */
  uint16_T ChoosetheMediannavSupportc1;/* '<S279>/Choose the Median [navSupport.c]1' */
  uint16_T ChoosetheMediannavSupportc2;/* '<S279>/Choose the Median [navSupport.c]2' */
  uint16_T ChoosetheMediannavSupportc3;/* '<S279>/Choose the Median [navSupport.c]3' */
  uint8_T GetControlTypenavSupportc;   /* '<S8>/Get Control Type [navSupport.c]' */
  uint8_T DataTypeConversion12;        /* '<S11>/Data Type Conversion12' */
  uint8_T DatafromGSgroundStationDriverc[103];/* '<S1>/Data from GS [groundStationDriver.c]' */
  uint8_T DatafromIPCinterProcCommSlavec[104];/* '<S1>/Data from IPC [interProcCommSlave.c]' */
  uint8_T ManualorAutonavSupportc;     /* '<S6>/Manual or Auto? [navSupport.c]' */
  uint8_T wpFlynavSupportc;            /* '<Root>/wp Fly? [navSupport.c]' */
  uint8_T GetMaxWPnavSupportc;         /* '<Root>/Get Max WP [navSupport.c]' */
  uint8_T CreateTelemetrySentencegroundSt[104];/* '<S8>/Create Telemetry  Sentence [groundStationDriver.c]' */
  uint8_T GetFilterOnOff;              /* '<S5>/GetFilterOnOff' */
  uint8_T GetPassSwitchesnavSupportc[4];/* '<S295>/Get Pass Switches [navSupport.c]' */
  uint8_T wp0;                         /* '<S124>/Embedded MATLAB Function' */
  uint8_T wp1;                         /* '<S124>/Embedded MATLAB Function' */
  uint8_T wp2;                         /* '<S124>/Embedded MATLAB Function' */
  boolean_T HitCrossing;               /* '<S278>/Hit  Crossing' */
  boolean_T IC_c;                      /* '<S278>/IC' */
  boolean_T DataTypeConversion1_e;     /* '<S5>/Data Type Conversion1' */
  boolean_T HitCrossing1;              /* '<S138>/Hit  Crossing1' */
  rtB_myMuxFun1_controlMCUSlugs_b sf_myMuxFun1_e;/* '<S9>/myMux Fun1' */
  rtB_myMuxFun1_controlMCUSlugs_b sf_myMuxFun2_c;/* '<S351>/myMux Fun2' */
  rtB_myMuxFun1_controlMCUSlugs_b sf_myMuxFun1_a;/* '<S351>/myMux Fun1' */
  rtB_myMuxFun1_controlMCUSlugs_p sf_myMuxFun1_m;/* '<S350>/myMux Fun1' */
  rtB_myMuxFun1_controlMCUSlugs_b sf_myMuxFun2;/* '<S334>/myMux Fun2' */
  rtB_myMuxFun1_controlMCUSlugs_b sf_myMuxFun1;/* '<S334>/myMux Fun1' */
  rtB_myMuxFun1_controlMCUSlugs_p sf_myMuxFun1_n;/* '<S333>/myMux Fun1' */
  rtB_BufferICChannel_controlMCUS sf_BufferICChannel3;/* '<S276>/Buffer IC Channel3' */
  rtB_BufferICChannel_controlMCUS sf_BufferICChannel2;/* '<S276>/Buffer IC Channel2' */
  rtB_BufferICChannel_controlMCUS sf_BufferICChannel1;/* '<S276>/Buffer IC Channel1' */
  rtB_BufferICChannel_controlMCUS sf_BufferICChannel;/* '<S276>/Buffer IC Channel' */
  rtB_myMuxFun1_controlMCUSlugsMK sf_myMuxFun2_l;/* '<S2>/myMux Fun2' */
  rtB_myMuxFun1_controlMCUSlugsMK sf_myMuxFun1_o;/* '<S16>/myMux Fun1' */
  rtB_negprotect_controlMCUSlugsM sf_negprotect1;/* '<S239>/negprotect1' */
  rtB_negprotect_controlMCUSlugsM sf_negprotect_h;/* '<S264>/negprotect' */
  rtB_negprotect_controlMCUSlugsM sf_negprotect_f;/* '<S255>/negprotect' */
  rtB_negprotect_controlMCUSlugsM sf_negprotect_fm;/* '<S237>/negprotect' */
  rtB_EmbeddedMATLABFunction_co_e sf_EmbeddedMATLABFunction_d;/* '<S248>/Embedded MATLAB Function' */
  rtB_negprotect_controlMCUSlugsM sf_negprotect_b;/* '<S247>/negprotect' */
  rtB_EmbeddedMATLABFunction_co_e sf_EmbeddedMATLABFunction_or;/* '<S222>/Embedded MATLAB Function' */
  rtB_negprotect_controlMCUSlugsM sf_negprotect_bp;/* '<S221>/negprotect' */
  rtB_EmbeddedMATLABFunction_co_e sf_EmbeddedMATLABFunction_hk;/* '<S215>/Embedded MATLAB Function' */
  rtB_negprotect_controlMCUSlugsM sf_negprotect_g;/* '<S214>/negprotect' */
  rtB_EmbeddedMATLABFunction_co_e sf_EmbeddedMATLABFunction_mg;/* '<S189>/Embedded MATLAB Function' */
  rtB_negprotect_controlMCUSlugsM sf_negprotect_l;/* '<S188>/negprotect' */
  rtB_EmbeddedMATLABFunction_co_p sf_EmbeddedMATLABFunction_n;/* '<S183>/Embedded MATLAB Function' */
  rtB_EmbeddedMATLABFunction_co_e sf_EmbeddedMATLABFunction_a;/* '<S150>/Embedded MATLAB Function' */
  rtB_negprotect_controlMCUSlugsM sf_negprotect_e;/* '<S149>/negprotect' */
  rtB_EmbeddedMATLABFunction_co_p sf_EmbeddedMATLABFunction_m;/* '<S129>/Embedded MATLAB Function' */
  rtB_negprotect_controlMCUSlugsM sf_negprotect_c;/* '<S113>/negprotect' */
  rtB_EmbeddedMATLABFunction_cont sf_EmbeddedMATLABFunction_i;/* '<S90>/Embedded MATLAB Function' */
  rtB_EmbeddedMATLABFunction_cont sf_EmbeddedMATLABFunction_l;/* '<S89>/Embedded MATLAB Function' */
  rtB_EmbeddedMATLABFunction_cont sf_EmbeddedMATLABFunction_p;/* '<S88>/Embedded MATLAB Function' */
  rtB_myMuxFun1_controlMCUSlugsMK sf_myMuxFun1_h;/* '<S14>/myMux Fun1' */
  rtB_negprotect_controlMCUSlugsM sf_negprotect;/* '<S70>/negprotect' */
  rtB_EmbeddedMATLABFunction_cont sf_EmbeddedMATLABFunction_h;/* '<S45>/Embedded MATLAB Function' */
} BlockIO_controlMCUSlugsMKII;

/* Block states (auto storage) for system '<Root>' */
typedef struct {
  real_T IntegerDelay2_X;              /* '<S124>/Integer Delay2' */
  real_T IntegerDelay2_X_l;            /* '<S139>/Integer Delay2' */
  real_T IntegerDelay3_X;              /* '<S182>/Integer Delay3' */
  real_T IntegerDelay3_X_c;            /* '<S118>/Integer Delay3' */
  real_T IntegerDelay_X;               /* '<S116>/Integer Delay' */
  real_T IntegerDelay1_X[2];           /* '<S116>/Integer Delay1' */
  real_T IntegerDelay3_X_l;            /* '<S111>/Integer Delay3' */
  real_T IntegerDelay_X_i;             /* '<S110>/Integer Delay' */
  real_T IntegerDelay1_X_o[2];         /* '<S110>/Integer Delay1' */
  real_T IntegerDelay3_X_k;            /* '<S121>/Integer Delay3' */
  real_T IntegerDelay_X_g;             /* '<S120>/Integer Delay' */
  real_T IntegerDelay1_X_oa[2];        /* '<S120>/Integer Delay1' */
  real_T IntegerDelay3_X_o;            /* '<S84>/Integer Delay3' */
  real_T IntegerDelay_X_i0;            /* '<S83>/Integer Delay' */
  real_T IntegerDelay1_X_f[2];         /* '<S83>/Integer Delay1' */
  real_T IntegerDelay3_X_j;            /* '<S68>/Integer Delay3' */
  real_T IntegerDelay_X_n;             /* '<S67>/Integer Delay' */
  real_T IntegerDelay1_X_n[2];         /* '<S67>/Integer Delay1' */
  real_T IntegerDelay1_X_f5;           /* '<S71>/Integer Delay1' */
  real_T Add3_DWORK1;                  /* '<S94>/Add3' */
  real32_T IntegerDelay_X_p;           /* '<S6>/Integer Delay' */
  real32_T IntegerDelay3_X_j5;         /* '<S17>/Integer Delay3' */
  real32_T IntegerDelay3_X_b;          /* '<S19>/Integer Delay3' */
  real32_T IntegerDelay3_X_lj;         /* '<S261>/Integer Delay3' */
  real32_T IntegerDelay3_X_b3;         /* '<S132>/Integer Delay3' */
  real32_T IntegerDelay3_X_g;          /* '<S254>/Integer Delay3' */
  real32_T IntegerDelay3_X_f;          /* '<S268>/Integer Delay3' */
  real32_T IntegerDelay3_X_a;          /* '<S124>/Integer Delay3' */
  real32_T IntegerDelay1_X_i;          /* '<S180>/Integer Delay1' */
  real32_T IntegerDelay2_X_e[2];       /* '<S180>/Integer Delay2' */
  real32_T UD_DSTATE;                  /* '<S196>/UD' */
  real32_T UD_DSTATE_e;                /* '<S199>/UD' */
  real32_T UD_DSTATE_h;                /* '<S202>/UD' */
  real32_T IntegerDelay3_X_n;          /* '<S137>/Integer Delay3' */
  real32_T IntegerDelay3_X_ch;         /* '<S271>/Integer Delay3' */
  real32_T IntegerDelay3_X_ft;         /* '<S186>/Integer Delay3' */
  real32_T IntegerDelay1_X_k[3];       /* '<S133>/Integer Delay1' */
  real32_T IntegerDelay2_X_e3[3];      /* '<S133>/Integer Delay2' */
  real32_T IntegerDelay3_X_i;          /* '<S99>/Integer Delay3' */
  real32_T IntegerDelay3_X_m;          /* '<S97>/Integer Delay3' */
  real32_T IntegerDelay2_X_lq;         /* '<S116>/Integer Delay2' */
  real32_T IntegerDelay3_X_at;         /* '<S117>/Integer Delay3' */
  real32_T IntegerDelay3_X_fk;         /* '<S100>/Integer Delay3' */
  real32_T IntegerDelay3_X_e;          /* '<S96>/Integer Delay3' */
  real32_T NDelays_X[5];               /* '<S92>/NDelays' */
  real32_T IntegerDelay2_X_d;          /* '<S110>/Integer Delay2' */
  real32_T IntegerDelay3_X_ex;         /* '<S112>/Integer Delay3' */
  real32_T IntegerDelay3_X_nv;         /* '<S98>/Integer Delay3' */
  real32_T NDelays_X_c[5];             /* '<S95>/NDelays' */
  real32_T IntegerDelay2_X_n;          /* '<S120>/Integer Delay2' */
  real32_T IntegerDelay3_X_p;          /* '<S122>/Integer Delay3' */
  real32_T IntegerDelay3_X_nc;         /* '<S62>/Integer Delay3' */
  real32_T IntegerDelay3_X_gw;         /* '<S63>/Integer Delay3' */
  real32_T IntegerDelay3_X_h;          /* '<S53>/Integer Delay3' */
  real32_T IntegerDelay3_X_ae;         /* '<S54>/Integer Delay3' */
  real32_T IntegerDelay3_X_b5;         /* '<S52>/Integer Delay3' */
  real32_T NDelays_X_e[5];             /* '<S57>/NDelays' */
  real32_T IntegerDelay2_X_g;          /* '<S83>/Integer Delay2' */
  real32_T IntegerDelay3_X_cn;         /* '<S85>/Integer Delay3' */
  real32_T IntegerDelay3_X_mk;         /* '<S51>/Integer Delay3' */
  real32_T NDelays_X_m[5];             /* '<S55>/NDelays' */
  real32_T IntegerDelay2_X_j;          /* '<S67>/Integer Delay2' */
  real32_T IntegerDelay3_X_hp;         /* '<S69>/Integer Delay3' */
  real32_T UD_DSTATE_o;                /* '<S79>/UD' */
  real32_T IntegerDelay_X_b;           /* '<S71>/Integer Delay' */
  real32_T IntegerDelay3_X_hc;         /* '<S72>/Integer Delay3' */
  real32_T IntegerDelay_X_nm;          /* '<S50>/Integer Delay' */
  real32_T IntegerDelay1_X_l;          /* '<S50>/Integer Delay1' */
  real32_T UD_DSTATE_l;                /* '<S33>/UD' */
  real32_T IntegerDelay_X_d;           /* '<S24>/Integer Delay' */
  real32_T IntegerDelay1_X_nc;         /* '<S24>/Integer Delay1' */
  real32_T IntegerDelay3_X_cw;         /* '<S26>/Integer Delay3' */
  real32_T UD_DSTATE_ld;               /* '<S42>/UD' */
  real32_T IntegerDelay_X_c;           /* '<S28>/Integer Delay' */
  real32_T IntegerDelay1_X_a;          /* '<S28>/Integer Delay1' */
  real32_T IntegerDelay_X_no;          /* '<S13>/Integer Delay' */
  real32_T IntegerDelay1_X_b;          /* '<S13>/Integer Delay1' */
  real32_T IntegerDelay3_X_gww;        /* '<S27>/Integer Delay3' */
  real32_T IntegerDelay_X_f;           /* '<S29>/Integer Delay' */
  real32_T IntegerDelay1_X_ny[2];      /* '<S29>/Integer Delay1' */
  real32_T IntegerDelay2_X_m;          /* '<S29>/Integer Delay2' */
  real32_T IntegerDelay3_X_oe;         /* '<S43>/Integer Delay3' */
  real32_T IntegerDelay3_X_oe1;        /* '<S44>/Integer Delay3' */
  real32_T PrevY;                      /* '<S15>/Rate Limiter' */
  real32_T Memory1_PreviousInput;      /* '<S94>/Memory1' */
  real32_T Memory1_PreviousInput_e;    /* '<S92>/Memory1' */
  real32_T Memory1_PreviousInput_f;    /* '<S95>/Memory1' */
  real32_T Memory1_PreviousInput_a;    /* '<S57>/Memory1' */
  real32_T Memory1_PreviousInput_l;    /* '<S55>/Memory1' */
  int_T HitCrossing_MODE;              /* '<S278>/Hit  Crossing' */
  int_T HitCrossing1_MODE;             /* '<S138>/Hit  Crossing1' */
  uint16_T internalTimer;              /* '<S124>/Embedded MATLAB Function1' */
  uint8_T IntegerDelay1_X_fi;          /* '<S140>/Integer Delay1' */
  boolean_T IntegerDelay2_X_k;         /* '<S278>/Integer Delay2' */
  boolean_T IntegerDelay1_X_p;         /* '<S138>/Integer Delay1' */
  uint8_T oldSw;                       /* '<S124>/Embedded MATLAB Function1' */
  uint8_T fromWP;                      /* '<S124>/Embedded MATLAB Function' */
  uint8_T toWP;                        /* '<S124>/Embedded MATLAB Function' */
  uint8_T totoWP;                      /* '<S124>/Embedded MATLAB Function' */
  boolean_T IC_FirstOutputTime;        /* '<S278>/IC' */
  boolean_T IC1_FirstOutputTime;       /* '<S124>/IC1' */
  boolean_T IC_FirstOutputTime_i;      /* '<S139>/IC' */
  boolean_T IC_FirstOutputTime_b;      /* '<S180>/IC' */
  boolean_T IC_FirstOutputTime_d;      /* '<S140>/IC' */
  boolean_T fromWP_not_empty;          /* '<S124>/Embedded MATLAB Function' */
  boolean_T IC_FirstOutputTime_k;      /* '<S133>/IC' */
  boolean_T IC_FirstOutputTime_e;      /* '<S71>/IC' */
  boolean_T IC_FirstOutputTime_g;      /* '<S24>/IC' */
  boolean_T IC_FirstOutputTime_p;      /* '<S28>/IC' */
  boolean_T L1OutputFeedbackControllerWithP;/* '<S2>/L1 Output Feedback Controller With  Projection Operator' */
  boolean_T SideslipCompensation_MODE; /* '<S14>/Sideslip Compensation' */
  rtDW_BufferICChannel_controlMCU sf_BufferICChannel3;/* '<S276>/Buffer IC Channel3' */
  rtDW_BufferICChannel_controlMCU sf_BufferICChannel2;/* '<S276>/Buffer IC Channel2' */
  rtDW_BufferICChannel_controlMCU sf_BufferICChannel1;/* '<S276>/Buffer IC Channel1' */
  rtDW_BufferICChannel_controlMCU sf_BufferICChannel;/* '<S276>/Buffer IC Channel' */
  rtDW_EmbeddedMATLABFunction_con sf_EmbeddedMATLABFunction_i;/* '<S90>/Embedded MATLAB Function' */
  rtDW_EmbeddedMATLABFunction_con sf_EmbeddedMATLABFunction_l;/* '<S89>/Embedded MATLAB Function' */
  rtDW_EmbeddedMATLABFunction_con sf_EmbeddedMATLABFunction_p;/* '<S88>/Embedded MATLAB Function' */
  rtDW_EmbeddedMATLABFunction_con sf_EmbeddedMATLABFunction_h;/* '<S45>/Embedded MATLAB Function' */
} D_Work_controlMCUSlugsMKII;

/* Zero-crossing (trigger) state */
typedef struct {
  ZCSigState HitCrossing_Input_ZCE;    /* '<S278>/Hit  Crossing' */
  ZCSigState HitCrossing1_Input_ZCE;   /* '<S138>/Hit  Crossing1' */
} PrevZCSigStates_controlMCUSlugs;

/* Invariant block signals (auto storage) */
typedef struct {
  const real_T Gain4;                  /* '<S290>/Gain4' */
  const real32_T e1;                   /* '<S236>/e^1' */
  const real32_T u;                    /* '<S236>/ ' */
  const real32_T Sum5;                 /* '<S236>/Sum5' */
  const real32_T e2;                   /* '<S233>/Sum3' */
  const real32_T e1_k;                 /* '<S231>/e^1' */
  const real32_T u_n;                  /* '<S231>/ ' */
  const real32_T Sum5_l;               /* '<S231>/Sum5' */
  const real32_T e2_c;                 /* '<S228>/Sum3' */
  const real32_T e1_c;                 /* '<S176>/e^1' */
  const real32_T u_k;                  /* '<S176>/ ' */
  const real32_T Sum5_lj;              /* '<S176>/Sum5' */
  const real32_T e2_i;                 /* '<S175>/Sum3' */
  const real32_T e1_cu;                /* '<S159>/e^1' */
  const real32_T u_a;                  /* '<S159>/ ' */
  const real32_T Sum5_c;               /* '<S159>/Sum5' */
  const real32_T e2_f;                 /* '<S156>/Sum3' */
  const real32_T Add3;                 /* '<S94>/Add3' */
  const real32_T Add4;                 /* '<S94>/Add4' */
  const real32_T Divide1;              /* '<S38>/Divide1' */
  const real32_T Divide2;              /* '<S38>/Divide2' */
  const boolean_T InitializeSPISSLasInput;/* '<Root>/Initialize SPI SSL as  Input' */
} ConstBlockIO_controlMCUSlugsMKI;

/* Constant parameters (auto storage) */
typedef struct {
  /* Pooled Parameter (Expression: )
   * Referenced by:
   *   '<S206>/UEN 2 NEU'
   *   '<S207>/UEN 2 NEU'
   *   '<S144>/UEN 2 NEU'
   */
  real32_T pooled49[9];
} ConstParam_controlMCUSlugsMKII;

/* Real-time Model Data Structure */
struct RT_MODEL_controlMCUSlugsMKII {
  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    uint32_T clockTick0;
    boolean_T firstInitCondFlag;
    struct {
      uint8_T TID[2];
    } TaskCounters;
  } Timing;
};

/* Block signals (auto storage) */
extern BlockIO_controlMCUSlugsMKII controlMCUSlugsMKII_B;

/* Block states (auto storage) */
extern D_Work_controlMCUSlugsMKII controlMCUSlugsMKII_DWork;
extern ConstBlockIO_controlMCUSlugsMKI controlMCUSlugsMKII_ConstB;/* constant block i/o */

/* Constant parameters (auto storage) */
extern const ConstParam_controlMCUSlugsMKII controlMCUSlugsMKII_ConstP;

/* External function called from main */
extern void controlMCUSlugsMKII_SetEventsForThisBaseStep(boolean_T *eventFlags);

/* Model entry point functions */
extern void controlMCUSlugsMKII_SetEventsForThisBaseStep(boolean_T *eventFlags);
extern void controlMCUSlugsMKII_initialize(boolean_T firstTime);
extern void controlMCUSlugsMKII_step(int_T tid);

/* Real-time Model object */
extern struct RT_MODEL_controlMCUSlugsMKII *controlMCUSlugsMKII_M;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : controlMCUSlugsMKII
 * '<S1>'   : controlMCUSlugsMKII/Data  Sources
 * '<S2>'   : controlMCUSlugsMKII/Inner Loop// Navigation
 * '<S3>'   : controlMCUSlugsMKII/PID Gains
 * '<S4>'   : controlMCUSlugsMKII/Pilot
 * '<S5>'   : controlMCUSlugsMKII/Pilot LED and HIL Control Pins
 * '<S6>'   : controlMCUSlugsMKII/Trim Vals
 * '<S7>'   : controlMCUSlugsMKII/Update  States
 * '<S8>'   : controlMCUSlugsMKII/Update PWM Commands and Send Telemetry
 * '<S9>'   : controlMCUSlugsMKII/get Nav Vars
 * '<S10>'  : controlMCUSlugsMKII/myMux Fun1
 * '<S11>'  : controlMCUSlugsMKII/Data  Sources/Compute Load
 * '<S12>'  : controlMCUSlugsMKII/Inner Loop// Navigation/Compute psi_dot_m
 * '<S13>'  : controlMCUSlugsMKII/Inner Loop// Navigation/L1 Output Feedback Controller With  Projection Operator
 * '<S14>'  : controlMCUSlugsMKII/Inner Loop// Navigation/Lateral Channel
 * '<S15>'  : controlMCUSlugsMKII/Inner Loop// Navigation/Longitudinal Channel
 * '<S16>'  : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation
 * '<S17>'  : controlMCUSlugsMKII/Inner Loop// Navigation/Protect NaNs
 * '<S18>'  : controlMCUSlugsMKII/Inner Loop// Navigation/myMux Fun2
 * '<S19>'  : controlMCUSlugsMKII/Inner Loop// Navigation/Compute psi_dot_m/Protect NaNs
 * '<S20>'  : controlMCUSlugsMKII/Inner Loop// Navigation/Compute psi_dot_m/Subsystem5
 * '<S21>'  : controlMCUSlugsMKII/Inner Loop// Navigation/Compute psi_dot_m/Subsystem7
 * '<S22>'  : controlMCUSlugsMKII/Inner Loop// Navigation/Compute psi_dot_m/Subsystem5/Environment Controller1
 * '<S23>'  : controlMCUSlugsMKII/Inner Loop// Navigation/Compute psi_dot_m/Subsystem7/Environment Controller
 * '<S24>'  : controlMCUSlugsMKII/Inner Loop// Navigation/L1 Output Feedback Controller With  Projection Operator/Control  Law
 * '<S25>'  : controlMCUSlugsMKII/Inner Loop// Navigation/L1 Output Feedback Controller With  Projection Operator/Projection Operator
 * '<S26>'  : controlMCUSlugsMKII/Inner Loop// Navigation/L1 Output Feedback Controller With  Projection Operator/Protect NaNs
 * '<S27>'  : controlMCUSlugsMKII/Inner Loop// Navigation/L1 Output Feedback Controller With  Projection Operator/Protect NaNs2
 * '<S28>'  : controlMCUSlugsMKII/Inner Loop// Navigation/L1 Output Feedback Controller With  Projection Operator/State Predictor
 * '<S29>'  : controlMCUSlugsMKII/Inner Loop// Navigation/L1 Output Feedback Controller With  Projection Operator/Trapezoidal Integrator
 * '<S30>'  : controlMCUSlugsMKII/Inner Loop// Navigation/L1 Output Feedback Controller With  Projection Operator/Control  Law/Compute Coef
 * '<S31>'  : controlMCUSlugsMKII/Inner Loop// Navigation/L1 Output Feedback Controller With  Projection Operator/Control  Law/Detect Change
 * '<S32>'  : controlMCUSlugsMKII/Inner Loop// Navigation/L1 Output Feedback Controller With  Projection Operator/Control  Law/Compute Coef/Subsystem11
 * '<S33>'  : controlMCUSlugsMKII/Inner Loop// Navigation/L1 Output Feedback Controller With  Projection Operator/Control  Law/Detect Change/Difference1
 * '<S34>'  : controlMCUSlugsMKII/Inner Loop// Navigation/L1 Output Feedback Controller With  Projection Operator/Projection Operator/Compare To Zero
 * '<S35>'  : controlMCUSlugsMKII/Inner Loop// Navigation/L1 Output Feedback Controller With  Projection Operator/Projection Operator/Compare To Zero1
 * '<S36>'  : controlMCUSlugsMKII/Inner Loop// Navigation/L1 Output Feedback Controller With  Projection Operator/Projection Operator/Enabled Subsystem
 * '<S37>'  : controlMCUSlugsMKII/Inner Loop// Navigation/L1 Output Feedback Controller With  Projection Operator/Projection Operator/Enabled Subsystem1
 * '<S38>'  : controlMCUSlugsMKII/Inner Loop// Navigation/L1 Output Feedback Controller With  Projection Operator/Projection Operator/F(theta)
 * '<S39>'  : controlMCUSlugsMKII/Inner Loop// Navigation/L1 Output Feedback Controller With  Projection Operator/State Predictor/Compute Coef
 * '<S40>'  : controlMCUSlugsMKII/Inner Loop// Navigation/L1 Output Feedback Controller With  Projection Operator/State Predictor/Detect Change
 * '<S41>'  : controlMCUSlugsMKII/Inner Loop// Navigation/L1 Output Feedback Controller With  Projection Operator/State Predictor/Compute Coef/Subsystem11
 * '<S42>'  : controlMCUSlugsMKII/Inner Loop// Navigation/L1 Output Feedback Controller With  Projection Operator/State Predictor/Detect Change/Difference1
 * '<S43>'  : controlMCUSlugsMKII/Inner Loop// Navigation/L1 Output Feedback Controller With  Projection Operator/Trapezoidal Integrator/Protect NaNs
 * '<S44>'  : controlMCUSlugsMKII/Inner Loop// Navigation/L1 Output Feedback Controller With  Projection Operator/Trapezoidal Integrator/Protect NaNs1
 * '<S45>'  : controlMCUSlugsMKII/Inner Loop// Navigation/Lateral Channel/0.5 sec  tau
 * '<S46>'  : controlMCUSlugsMKII/Inner Loop// Navigation/Lateral Channel/Angle Conversion
 * '<S47>'  : controlMCUSlugsMKII/Inner Loop// Navigation/Lateral Channel/Angle Conversion1
 * '<S48>'  : controlMCUSlugsMKII/Inner Loop// Navigation/Lateral Channel/Angle Conversion2
 * '<S49>'  : controlMCUSlugsMKII/Inner Loop// Navigation/Lateral Channel/Bank to Psi Dot
 * '<S50>'  : controlMCUSlugsMKII/Inner Loop// Navigation/Lateral Channel/High Pass (Washout) Filter
 * '<S51>'  : controlMCUSlugsMKII/Inner Loop// Navigation/Lateral Channel/Protect NaNs
 * '<S52>'  : controlMCUSlugsMKII/Inner Loop// Navigation/Lateral Channel/Protect NaNs1
 * '<S53>'  : controlMCUSlugsMKII/Inner Loop// Navigation/Lateral Channel/Protect NaNs2
 * '<S54>'  : controlMCUSlugsMKII/Inner Loop// Navigation/Lateral Channel/Protect NaNs3
 * '<S55>'  : controlMCUSlugsMKII/Inner Loop// Navigation/Lateral Channel/Roll Control [PID]
 * '<S56>'  : controlMCUSlugsMKII/Inner Loop// Navigation/Lateral Channel/Sideslip Compensation
 * '<S57>'  : controlMCUSlugsMKII/Inner Loop// Navigation/Lateral Channel/Yaw Damper [PID]
 * '<S58>'  : controlMCUSlugsMKII/Inner Loop// Navigation/Lateral Channel/myMux Fun1
 * '<S59>'  : controlMCUSlugsMKII/Inner Loop// Navigation/Lateral Channel/myMux Fun3
 * '<S60>'  : controlMCUSlugsMKII/Inner Loop// Navigation/Lateral Channel/psi_dot to Bank
 * '<S61>'  : controlMCUSlugsMKII/Inner Loop// Navigation/Lateral Channel/0.5 sec  tau/Embedded MATLAB Function
 * '<S62>'  : controlMCUSlugsMKII/Inner Loop// Navigation/Lateral Channel/Bank to Psi Dot/Protect NaNs
 * '<S63>'  : controlMCUSlugsMKII/Inner Loop// Navigation/Lateral Channel/Bank to Psi Dot/Protect NaNs1
 * '<S64>'  : controlMCUSlugsMKII/Inner Loop// Navigation/Lateral Channel/Bank to Psi Dot/Subsystem8
 * '<S65>'  : controlMCUSlugsMKII/Inner Loop// Navigation/Lateral Channel/Bank to Psi Dot/Subsystem8/Environment Controller
 * '<S66>'  : controlMCUSlugsMKII/Inner Loop// Navigation/Lateral Channel/Roll Control [PID]/Saturation Dynamic
 * '<S67>'  : controlMCUSlugsMKII/Inner Loop// Navigation/Lateral Channel/Roll Control [PID]/Trapezoidal Integrator
 * '<S68>'  : controlMCUSlugsMKII/Inner Loop// Navigation/Lateral Channel/Roll Control [PID]/Trapezoidal Integrator/Protect NaNs
 * '<S69>'  : controlMCUSlugsMKII/Inner Loop// Navigation/Lateral Channel/Roll Control [PID]/Trapezoidal Integrator/Protect NaNs1
 * '<S70>'  : controlMCUSlugsMKII/Inner Loop// Navigation/Lateral Channel/Sideslip Compensation/Bank to Psi Dot
 * '<S71>'  : controlMCUSlugsMKII/Inner Loop// Navigation/Lateral Channel/Sideslip Compensation/Low Pass
 * '<S72>'  : controlMCUSlugsMKII/Inner Loop// Navigation/Lateral Channel/Sideslip Compensation/Protect NaNs2
 * '<S73>'  : controlMCUSlugsMKII/Inner Loop// Navigation/Lateral Channel/Sideslip Compensation/psi_dot to Bank
 * '<S74>'  : controlMCUSlugsMKII/Inner Loop// Navigation/Lateral Channel/Sideslip Compensation/Bank to Psi Dot/Subsystem8
 * '<S75>'  : controlMCUSlugsMKII/Inner Loop// Navigation/Lateral Channel/Sideslip Compensation/Bank to Psi Dot/negprotect
 * '<S76>'  : controlMCUSlugsMKII/Inner Loop// Navigation/Lateral Channel/Sideslip Compensation/Bank to Psi Dot/Subsystem8/Environment Controller
 * '<S77>'  : controlMCUSlugsMKII/Inner Loop// Navigation/Lateral Channel/Sideslip Compensation/Low Pass/Compute Coef
 * '<S78>'  : controlMCUSlugsMKII/Inner Loop// Navigation/Lateral Channel/Sideslip Compensation/Low Pass/Detect Change
 * '<S79>'  : controlMCUSlugsMKII/Inner Loop// Navigation/Lateral Channel/Sideslip Compensation/Low Pass/Detect Change/Difference1
 * '<S80>'  : controlMCUSlugsMKII/Inner Loop// Navigation/Lateral Channel/Sideslip Compensation/psi_dot to Bank/Subsystem2
 * '<S81>'  : controlMCUSlugsMKII/Inner Loop// Navigation/Lateral Channel/Sideslip Compensation/psi_dot to Bank/Subsystem2/Environment Controller
 * '<S82>'  : controlMCUSlugsMKII/Inner Loop// Navigation/Lateral Channel/Yaw Damper [PID]/Saturation Dynamic
 * '<S83>'  : controlMCUSlugsMKII/Inner Loop// Navigation/Lateral Channel/Yaw Damper [PID]/Trapezoidal Integrator
 * '<S84>'  : controlMCUSlugsMKII/Inner Loop// Navigation/Lateral Channel/Yaw Damper [PID]/Trapezoidal Integrator/Protect NaNs
 * '<S85>'  : controlMCUSlugsMKII/Inner Loop// Navigation/Lateral Channel/Yaw Damper [PID]/Trapezoidal Integrator/Protect NaNs1
 * '<S86>'  : controlMCUSlugsMKII/Inner Loop// Navigation/Lateral Channel/psi_dot to Bank/Subsystem2
 * '<S87>'  : controlMCUSlugsMKII/Inner Loop// Navigation/Lateral Channel/psi_dot to Bank/Subsystem2/Environment Controller
 * '<S88>'  : controlMCUSlugsMKII/Inner Loop// Navigation/Longitudinal Channel/0.3 sec  tau for low speeds
 * '<S89>'  : controlMCUSlugsMKII/Inner Loop// Navigation/Longitudinal Channel/0.5 sec  tau for Turns
 * '<S90>'  : controlMCUSlugsMKII/Inner Loop// Navigation/Longitudinal Channel/5 sec tau for high speeds
 * '<S91>'  : controlMCUSlugsMKII/Inner Loop// Navigation/Longitudinal Channel/Air Density from Height
 * '<S92>'  : controlMCUSlugsMKII/Inner Loop// Navigation/Longitudinal Channel/Airspeed Hold [PID]
 * '<S93>'  : controlMCUSlugsMKII/Inner Loop// Navigation/Longitudinal Channel/Compute Airspeed
 * '<S94>'  : controlMCUSlugsMKII/Inner Loop// Navigation/Longitudinal Channel/Height Error to Pitch  Command [PI]
 * '<S95>'  : controlMCUSlugsMKII/Inner Loop// Navigation/Longitudinal Channel/Pitch To Elevator [PID]
 * '<S96>'  : controlMCUSlugsMKII/Inner Loop// Navigation/Longitudinal Channel/Protect NaNs
 * '<S97>'  : controlMCUSlugsMKII/Inner Loop// Navigation/Longitudinal Channel/Protect NaNs1
 * '<S98>'  : controlMCUSlugsMKII/Inner Loop// Navigation/Longitudinal Channel/Protect NaNs2
 * '<S99>'  : controlMCUSlugsMKII/Inner Loop// Navigation/Longitudinal Channel/Protect NaNs3
 * '<S100>' : controlMCUSlugsMKII/Inner Loop// Navigation/Longitudinal Channel/Protect NaNs4
 * '<S101>' : controlMCUSlugsMKII/Inner Loop// Navigation/Longitudinal Channel/Subsystem5
 * '<S102>' : controlMCUSlugsMKII/Inner Loop// Navigation/Longitudinal Channel/lowpass limit
 * '<S103>' : controlMCUSlugsMKII/Inner Loop// Navigation/Longitudinal Channel/myMux Fun1
 * '<S104>' : controlMCUSlugsMKII/Inner Loop// Navigation/Longitudinal Channel/0.3 sec  tau for low speeds/Embedded MATLAB Function
 * '<S105>' : controlMCUSlugsMKII/Inner Loop// Navigation/Longitudinal Channel/0.5 sec  tau for Turns/Embedded MATLAB Function
 * '<S106>' : controlMCUSlugsMKII/Inner Loop// Navigation/Longitudinal Channel/5 sec tau for high speeds/Embedded MATLAB Function
 * '<S107>' : controlMCUSlugsMKII/Inner Loop// Navigation/Longitudinal Channel/Air Density from Height/Length Conversion
 * '<S108>' : controlMCUSlugsMKII/Inner Loop// Navigation/Longitudinal Channel/Air Density from Height/Subsystem
 * '<S109>' : controlMCUSlugsMKII/Inner Loop// Navigation/Longitudinal Channel/Airspeed Hold [PID]/Saturation Dynamic
 * '<S110>' : controlMCUSlugsMKII/Inner Loop// Navigation/Longitudinal Channel/Airspeed Hold [PID]/Trapezoidal Integrator
 * '<S111>' : controlMCUSlugsMKII/Inner Loop// Navigation/Longitudinal Channel/Airspeed Hold [PID]/Trapezoidal Integrator/Protect NaNs
 * '<S112>' : controlMCUSlugsMKII/Inner Loop// Navigation/Longitudinal Channel/Airspeed Hold [PID]/Trapezoidal Integrator/Protect NaNs1
 * '<S113>' : controlMCUSlugsMKII/Inner Loop// Navigation/Longitudinal Channel/Compute Airspeed/Subsystem1
 * '<S114>' : controlMCUSlugsMKII/Inner Loop// Navigation/Longitudinal Channel/Compute Airspeed/Subsystem1/negprotect
 * '<S115>' : controlMCUSlugsMKII/Inner Loop// Navigation/Longitudinal Channel/Height Error to Pitch  Command [PI]/Saturation Dynamic
 * '<S116>' : controlMCUSlugsMKII/Inner Loop// Navigation/Longitudinal Channel/Height Error to Pitch  Command [PI]/Trapezoidal Integrator
 * '<S117>' : controlMCUSlugsMKII/Inner Loop// Navigation/Longitudinal Channel/Height Error to Pitch  Command [PI]/Trapezoidal Integrator/Protect NaNs
 * '<S118>' : controlMCUSlugsMKII/Inner Loop// Navigation/Longitudinal Channel/Height Error to Pitch  Command [PI]/Trapezoidal Integrator/Protect NaNs
 * '<S119>' : controlMCUSlugsMKII/Inner Loop// Navigation/Longitudinal Channel/Pitch To Elevator [PID]/Saturation Dynamic
 * '<S120>' : controlMCUSlugsMKII/Inner Loop// Navigation/Longitudinal Channel/Pitch To Elevator [PID]/Trapezoidal Integrator
 * '<S121>' : controlMCUSlugsMKII/Inner Loop// Navigation/Longitudinal Channel/Pitch To Elevator [PID]/Trapezoidal Integrator/Protect NaNs
 * '<S122>' : controlMCUSlugsMKII/Inner Loop// Navigation/Longitudinal Channel/Pitch To Elevator [PID]/Trapezoidal Integrator/Protect NaNs1
 * '<S123>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute Lateral Error
 * '<S124>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index
 * '<S125>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Get Wps Compute Frenet
 * '<S126>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Park, Deyst & How Lat Accel Cmd
 * '<S127>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/as_c to phi_c
 * '<S128>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/myMux Fun1
 * '<S129>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute Lateral Error/Subsystem3
 * '<S130>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute Lateral Error/Subsystem3/Embedded MATLAB Function
 * '<S131>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute Lateral Error/Subsystem3/Environment Controller
 * '<S132>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute Lateral Error/Subsystem3/Protect NaNs
 * '<S133>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Compute P
 * '<S134>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Embedded MATLAB Function
 * '<S135>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Embedded MATLAB Function1
 * '<S136>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Grab IC
 * '<S137>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Protect NaNs
 * '<S138>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Subsystem
 * '<S139>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Subsystem1
 * '<S140>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Switch when  in Line Segment
 * '<S141>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/myMux Fun2
 * '<S142>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Compute P/Compute R
 * '<S143>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Compute P/Compute T  in Frenet
 * '<S144>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Compute P/Geod2LTP1
 * '<S145>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Compute P/Get Circles
 * '<S146>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Compute P/get WP Coord from Index
 * '<S147>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Compute P/Compute T  in Frenet/Normalize Vector
 * '<S148>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Compute P/Compute T  in Frenet/Normalize Vector/Norm
 * '<S149>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Compute P/Compute T  in Frenet/Normalize Vector/Norm/Subsystem1
 * '<S150>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Compute P/Compute T  in Frenet/Normalize Vector/Norm/Subsystem3
 * '<S151>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Compute P/Compute T  in Frenet/Normalize Vector/Norm/Subsystem1/Environment Controller
 * '<S152>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Compute P/Compute T  in Frenet/Normalize Vector/Norm/Subsystem1/negprotect
 * '<S153>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Compute P/Compute T  in Frenet/Normalize Vector/Norm/Subsystem3/Embedded MATLAB Function
 * '<S154>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Compute P/Compute T  in Frenet/Normalize Vector/Norm/Subsystem3/Environment Controller
 * '<S155>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Compute P/Geod2LTP1/ECEF2LTP (UEN)
 * '<S156>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Compute P/Geod2LTP1/Geod2ECEF1
 * '<S157>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Compute P/Geod2LTP1/ECEF2LTP (UEN)/From Body to Universal1
 * '<S158>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Compute P/Geod2LTP1/ECEF2LTP (UEN)/From Body to Universal1/Rotation Matrix from Long////Lat
 * '<S159>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Compute P/Geod2LTP1/Geod2ECEF1/eccentricity^2
 * '<S160>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Compute P/Get Circles/Compute  Circles
 * '<S161>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Compute P/Get Circles/Compute CCW Angle From 2 Vectors
 * '<S162>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Compute P/Get Circles/Compute delta Left Turn
 * '<S163>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Compute P/Get Circles/Subsystem5
 * '<S164>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Compute P/Get Circles/compute delta Right Turn
 * '<S165>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Compute P/Get Circles/Compute CCW Angle From 2 Vectors/Embedded MATLAB Function1
 * '<S166>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Compute P/Get Circles/Compute CCW Angle From 2 Vectors/Subsystem1
 * '<S167>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Compute P/Get Circles/Compute CCW Angle From 2 Vectors/Subsystem4
 * '<S168>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Compute P/Get Circles/Compute CCW Angle From 2 Vectors/Subsystem1/Environment Controller
 * '<S169>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Compute P/Get Circles/Compute CCW Angle From 2 Vectors/Subsystem4/Environment Controller
 * '<S170>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Compute P/Get Circles/Subsystem5/Environment Controller
 * '<S171>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Compute P/Get Circles/Subsystem5/Environment Controller1
 * '<S172>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Compute P/Get Circles/Subsystem5/SinCos1
 * '<S173>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Grab IC/Compute GS Location
 * '<S174>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Grab IC/get GS Location (WP 11 is GS)
 * '<S175>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Grab IC/Compute GS Location/Geod2ECEF1
 * '<S176>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Grab IC/Compute GS Location/Geod2ECEF1/eccentricity^2
 * '<S177>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Switch when  in Line Segment/Compare To Zero
 * '<S178>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Switch when  in Line Segment/Compute  Projection
 * '<S179>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Switch when  in Line Segment/Compute Total Run
 * '<S180>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Switch when  in Line Segment/Subsystem1
 * '<S181>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Switch when  in Line Segment/WP Update
 * '<S182>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Switch when  in Line Segment/Compute  Projection/Protect NaNs
 * '<S183>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Switch when  in Line Segment/Compute  Projection/Subsystem3
 * '<S184>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Switch when  in Line Segment/Compute  Projection/Subsystem3/Embedded MATLAB Function
 * '<S185>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Switch when  in Line Segment/Compute Total Run/Compute Distance
 * '<S186>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Switch when  in Line Segment/Compute Total Run/Protect NaNs
 * '<S187>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Switch when  in Line Segment/Compute Total Run/Compute Distance/Norm
 * '<S188>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Switch when  in Line Segment/Compute Total Run/Compute Distance/Norm/Subsystem1
 * '<S189>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Switch when  in Line Segment/Compute Total Run/Compute Distance/Norm/Subsystem3
 * '<S190>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Switch when  in Line Segment/Compute Total Run/Compute Distance/Norm/Subsystem1/Environment Controller
 * '<S191>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Switch when  in Line Segment/Compute Total Run/Compute Distance/Norm/Subsystem1/negprotect
 * '<S192>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Switch when  in Line Segment/Compute Total Run/Compute Distance/Norm/Subsystem3/Embedded MATLAB Function
 * '<S193>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Switch when  in Line Segment/WP Update/Detect Change
 * '<S194>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Switch when  in Line Segment/WP Update/Detect Change1
 * '<S195>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Switch when  in Line Segment/WP Update/Detect Change2
 * '<S196>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Switch when  in Line Segment/WP Update/Detect Change/Difference1
 * '<S197>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Switch when  in Line Segment/WP Update/Detect Change/Subsystem9
 * '<S198>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Switch when  in Line Segment/WP Update/Detect Change/Subsystem9/Environment Controller
 * '<S199>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Switch when  in Line Segment/WP Update/Detect Change1/Difference1
 * '<S200>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Switch when  in Line Segment/WP Update/Detect Change1/Subsystem9
 * '<S201>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Switch when  in Line Segment/WP Update/Detect Change1/Subsystem9/Environment Controller
 * '<S202>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Switch when  in Line Segment/WP Update/Detect Change2/Difference1
 * '<S203>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Switch when  in Line Segment/WP Update/Detect Change2/Subsystem9
 * '<S204>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Compute WP Index/Switch when  in Line Segment/WP Update/Detect Change2/Subsystem9/Environment Controller
 * '<S205>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Get Wps Compute Frenet/Compute Frenet
 * '<S206>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Get Wps Compute Frenet/Geod2LTP1
 * '<S207>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Get Wps Compute Frenet/Geod2LTP2
 * '<S208>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Get Wps Compute Frenet/get WP Coord from Index
 * '<S209>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Get Wps Compute Frenet/get WP Coord from Index
 * '<S210>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Get Wps Compute Frenet/Compute Frenet/Normalize Vector
 * '<S211>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Get Wps Compute Frenet/Compute Frenet/Normalize Vector
 * '<S212>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Get Wps Compute Frenet/Compute Frenet/Select N  Terms
 * '<S213>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Get Wps Compute Frenet/Compute Frenet/Normalize Vector/Norm
 * '<S214>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Get Wps Compute Frenet/Compute Frenet/Normalize Vector/Norm/Subsystem1
 * '<S215>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Get Wps Compute Frenet/Compute Frenet/Normalize Vector/Norm/Subsystem3
 * '<S216>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Get Wps Compute Frenet/Compute Frenet/Normalize Vector/Norm/Subsystem1/Environment Controller
 * '<S217>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Get Wps Compute Frenet/Compute Frenet/Normalize Vector/Norm/Subsystem1/negprotect
 * '<S218>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Get Wps Compute Frenet/Compute Frenet/Normalize Vector/Norm/Subsystem3/Embedded MATLAB Function
 * '<S219>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Get Wps Compute Frenet/Compute Frenet/Normalize Vector/Norm/Subsystem3/Environment Controller
 * '<S220>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Get Wps Compute Frenet/Compute Frenet/Normalize Vector /Norm
 * '<S221>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Get Wps Compute Frenet/Compute Frenet/Normalize Vector /Norm/Subsystem1
 * '<S222>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Get Wps Compute Frenet/Compute Frenet/Normalize Vector /Norm/Subsystem3
 * '<S223>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Get Wps Compute Frenet/Compute Frenet/Normalize Vector /Norm/Subsystem1/Environment Controller
 * '<S224>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Get Wps Compute Frenet/Compute Frenet/Normalize Vector /Norm/Subsystem1/negprotect
 * '<S225>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Get Wps Compute Frenet/Compute Frenet/Normalize Vector /Norm/Subsystem3/Embedded MATLAB Function
 * '<S226>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Get Wps Compute Frenet/Compute Frenet/Normalize Vector /Norm/Subsystem3/Environment Controller
 * '<S227>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Get Wps Compute Frenet/Geod2LTP1/ECEF2LTP (UEN)
 * '<S228>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Get Wps Compute Frenet/Geod2LTP1/Geod2ECEF1
 * '<S229>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Get Wps Compute Frenet/Geod2LTP1/ECEF2LTP (UEN)/From Body to Universal1
 * '<S230>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Get Wps Compute Frenet/Geod2LTP1/ECEF2LTP (UEN)/From Body to Universal1/Rotation Matrix from Long////Lat
 * '<S231>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Get Wps Compute Frenet/Geod2LTP1/Geod2ECEF1/eccentricity^2
 * '<S232>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Get Wps Compute Frenet/Geod2LTP2/ECEF2LTP (UEN)
 * '<S233>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Get Wps Compute Frenet/Geod2LTP2/Geod2ECEF1
 * '<S234>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Get Wps Compute Frenet/Geod2LTP2/ECEF2LTP (UEN)/From Body to Universal1
 * '<S235>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Get Wps Compute Frenet/Geod2LTP2/ECEF2LTP (UEN)/From Body to Universal1/Rotation Matrix from Long////Lat
 * '<S236>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Get Wps Compute Frenet/Geod2LTP2/Geod2ECEF1/eccentricity^2
 * '<S237>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Park, Deyst & How Lat Accel Cmd/Compute Eta
 * '<S238>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Park, Deyst & How Lat Accel Cmd/Compute L2 Vector LINE MODE
 * '<S239>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Park, Deyst & How Lat Accel Cmd/GainSchedule L2 and Get Groundspeed
 * '<S240>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Park, Deyst & How Lat Accel Cmd/Park's Lateral Accel Command
 * '<S241>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Park, Deyst & How Lat Accel Cmd/Compute Eta/3x3 Cross Product
 * '<S242>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Park, Deyst & How Lat Accel Cmd/Compute Eta/Norm
 * '<S243>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Park, Deyst & How Lat Accel Cmd/Compute Eta/Subsystem6
 * '<S244>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Park, Deyst & How Lat Accel Cmd/Compute Eta/negprotect
 * '<S245>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Park, Deyst & How Lat Accel Cmd/Compute Eta/3x3 Cross Product/Subsystem
 * '<S246>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Park, Deyst & How Lat Accel Cmd/Compute Eta/3x3 Cross Product/Subsystem1
 * '<S247>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Park, Deyst & How Lat Accel Cmd/Compute Eta/Norm/Subsystem1
 * '<S248>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Park, Deyst & How Lat Accel Cmd/Compute Eta/Norm/Subsystem3
 * '<S249>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Park, Deyst & How Lat Accel Cmd/Compute Eta/Norm/Subsystem1/Environment Controller
 * '<S250>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Park, Deyst & How Lat Accel Cmd/Compute Eta/Norm/Subsystem1/negprotect
 * '<S251>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Park, Deyst & How Lat Accel Cmd/Compute Eta/Norm/Subsystem3/Embedded MATLAB Function
 * '<S252>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Park, Deyst & How Lat Accel Cmd/Compute Eta/Norm/Subsystem3/Environment Controller
 * '<S253>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Park, Deyst & How Lat Accel Cmd/Compute Eta/Subsystem6/Environment Controller
 * '<S254>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Park, Deyst & How Lat Accel Cmd/Compute Eta/Subsystem6/Protect NaNs
 * '<S255>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Park, Deyst & How Lat Accel Cmd/Compute L2 Vector LINE MODE/Subsystem1
 * '<S256>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Park, Deyst & How Lat Accel Cmd/Compute L2 Vector LINE MODE/Subsystem9
 * '<S257>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Park, Deyst & How Lat Accel Cmd/Compute L2 Vector LINE MODE/Subsystem1/Environment Controller
 * '<S258>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Park, Deyst & How Lat Accel Cmd/Compute L2 Vector LINE MODE/Subsystem1/negprotect
 * '<S259>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Park, Deyst & How Lat Accel Cmd/Compute L2 Vector LINE MODE/Subsystem9/Environment Controller
 * '<S260>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Park, Deyst & How Lat Accel Cmd/GainSchedule L2 and Get Groundspeed/Norm
 * '<S261>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Park, Deyst & How Lat Accel Cmd/GainSchedule L2 and Get Groundspeed/Protect NaNs
 * '<S262>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Park, Deyst & How Lat Accel Cmd/GainSchedule L2 and Get Groundspeed/negprotect1
 * '<S263>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Park, Deyst & How Lat Accel Cmd/GainSchedule L2 and Get Groundspeed/Norm /Square Vx and Vy  Only. Vz is not considered CAREFUL
 * '<S264>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Park, Deyst & How Lat Accel Cmd/GainSchedule L2 and Get Groundspeed/Norm /Subsystem1
 * '<S265>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Park, Deyst & How Lat Accel Cmd/GainSchedule L2 and Get Groundspeed/Norm /Square Vx and Vy  Only. Vz is not considered CAREFUL/Embedded MATLAB Function
 * '<S266>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Park, Deyst & How Lat Accel Cmd/GainSchedule L2 and Get Groundspeed/Norm /Subsystem1/Environment Controller
 * '<S267>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Park, Deyst & How Lat Accel Cmd/GainSchedule L2 and Get Groundspeed/Norm /Subsystem1/negprotect
 * '<S268>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Park, Deyst & How Lat Accel Cmd/Park's Lateral Accel Command/Protect NaNs
 * '<S269>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Park, Deyst & How Lat Accel Cmd/Park's Lateral Accel Command/Subsystem7
 * '<S270>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/Park, Deyst & How Lat Accel Cmd/Park's Lateral Accel Command/Subsystem7/Environment Controller
 * '<S271>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/as_c to phi_c/Protect NaNs
 * '<S272>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/as_c to phi_c/Subsystem2
 * '<S273>' : controlMCUSlugsMKII/Inner Loop// Navigation/Navigation/as_c to phi_c/Subsystem2/Environment Controller
 * '<S274>' : controlMCUSlugsMKII/Pilot/Increment Real World
 * '<S275>' : controlMCUSlugsMKII/Pilot/Wrap To Zero
 * '<S276>' : controlMCUSlugsMKII/Trim Vals/Bufffer IC
 * '<S277>' : controlMCUSlugsMKII/Trim Vals/Control Surface Input
 * '<S278>' : controlMCUSlugsMKII/Trim Vals/Detect Transition High to Low
 * '<S279>' : controlMCUSlugsMKII/Trim Vals/Grab I.C.
 * '<S280>' : controlMCUSlugsMKII/Trim Vals/Log  Trims Using PWM High [groundStationDriver.c]
 * '<S281>' : controlMCUSlugsMKII/Trim Vals/Bufffer IC/Buffer IC Channel
 * '<S282>' : controlMCUSlugsMKII/Trim Vals/Bufffer IC/Buffer IC Channel1
 * '<S283>' : controlMCUSlugsMKII/Trim Vals/Bufffer IC/Buffer IC Channel2
 * '<S284>' : controlMCUSlugsMKII/Trim Vals/Bufffer IC/Buffer IC Channel3
 * '<S285>' : controlMCUSlugsMKII/Trim Vals/Control Surface Input/myMux Fun5
 * '<S286>' : controlMCUSlugsMKII/Trim Vals/Grab I.C./Convert to Rad
 * '<S287>' : controlMCUSlugsMKII/Trim Vals/Grab I.C./Convert to Rad1
 * '<S288>' : controlMCUSlugsMKII/Trim Vals/Grab I.C./Convert to Rad2
 * '<S289>' : controlMCUSlugsMKII/Trim Vals/Grab I.C./Convert to Rad3
 * '<S290>' : controlMCUSlugsMKII/Trim Vals/Log  Trims Using PWM High [groundStationDriver.c]/Report Airspeed
 * '<S291>' : controlMCUSlugsMKII/Update PWM Commands and Send Telemetry/Generate PWM Signals Based on the Control Type
 * '<S292>' : controlMCUSlugsMKII/Update PWM Commands and Send Telemetry/myMux Fun1
 * '<S293>' : controlMCUSlugsMKII/Update PWM Commands and Send Telemetry/Generate PWM Signals Based on the Control Type/If  Control Type Is Manual
 * '<S294>' : controlMCUSlugsMKII/Update PWM Commands and Send Telemetry/Generate PWM Signals Based on the Control Type/If  Control Type Is Passthrough
 * '<S295>' : controlMCUSlugsMKII/Update PWM Commands and Send Telemetry/Generate PWM Signals Based on the Control Type/If  Control Type Is Selective Passthrough
 * '<S296>' : controlMCUSlugsMKII/Update PWM Commands and Send Telemetry/Generate PWM Signals Based on the Control Type/If  Control Type Is Wp Follow  or Inner Cmds
 * '<S297>' : controlMCUSlugsMKII/Update PWM Commands and Send Telemetry/Generate PWM Signals Based on the Control Type/If  Control Type Is Manual/myMux Fun1
 * '<S298>' : controlMCUSlugsMKII/Update PWM Commands and Send Telemetry/Generate PWM Signals Based on the Control Type/If  Control Type Is Passthrough/myMux Fun1
 * '<S299>' : controlMCUSlugsMKII/Update PWM Commands and Send Telemetry/Generate PWM Signals Based on the Control Type/If  Control Type Is Selective Passthrough/Convert to PWM
 * '<S300>' : controlMCUSlugsMKII/Update PWM Commands and Send Telemetry/Generate PWM Signals Based on the Control Type/If  Control Type Is Selective Passthrough/Convert to PWM1
 * '<S301>' : controlMCUSlugsMKII/Update PWM Commands and Send Telemetry/Generate PWM Signals Based on the Control Type/If  Control Type Is Selective Passthrough/Convert to PWM2
 * '<S302>' : controlMCUSlugsMKII/Update PWM Commands and Send Telemetry/Generate PWM Signals Based on the Control Type/If  Control Type Is Selective Passthrough/Convert to PWM3
 * '<S303>' : controlMCUSlugsMKII/Update PWM Commands and Send Telemetry/Generate PWM Signals Based on the Control Type/If  Control Type Is Selective Passthrough/myMux Fun1
 * '<S304>' : controlMCUSlugsMKII/Update PWM Commands and Send Telemetry/Generate PWM Signals Based on the Control Type/If  Control Type Is Wp Follow  or Inner Cmds/Convert to PWM
 * '<S305>' : controlMCUSlugsMKII/Update PWM Commands and Send Telemetry/Generate PWM Signals Based on the Control Type/If  Control Type Is Wp Follow  or Inner Cmds/Convert to PWM1
 * '<S306>' : controlMCUSlugsMKII/Update PWM Commands and Send Telemetry/Generate PWM Signals Based on the Control Type/If  Control Type Is Wp Follow  or Inner Cmds/Convert to PWM2
 * '<S307>' : controlMCUSlugsMKII/Update PWM Commands and Send Telemetry/Generate PWM Signals Based on the Control Type/If  Control Type Is Wp Follow  or Inner Cmds/Convert to PWM3
 * '<S308>' : controlMCUSlugsMKII/Update PWM Commands and Send Telemetry/Generate PWM Signals Based on the Control Type/If  Control Type Is Wp Follow  or Inner Cmds/myMux Fun1
 * '<S309>' : controlMCUSlugsMKII/get Nav Vars/Angle Conversion
 * '<S310>' : controlMCUSlugsMKII/get Nav Vars/Direction Cosine Matrix to Euler Angles
 * '<S311>' : controlMCUSlugsMKII/get Nav Vars/Embedded MATLAB Function
 * '<S312>' : controlMCUSlugsMKII/get Nav Vars/Euler Angles to  Direction Cosine Matrix1
 * '<S313>' : controlMCUSlugsMKII/get Nav Vars/Euler Angles to  Direction Cosine Matrix2
 * '<S314>' : controlMCUSlugsMKII/get Nav Vars/myMux Fun1
 * '<S315>' : controlMCUSlugsMKII/get Nav Vars/myMux Fun2
 * '<S316>' : controlMCUSlugsMKII/get Nav Vars/Direction Cosine Matrix to Euler Angles/Subsystem1
 * '<S317>' : controlMCUSlugsMKII/get Nav Vars/Direction Cosine Matrix to Euler Angles/Subsystem2
 * '<S318>' : controlMCUSlugsMKII/get Nav Vars/Direction Cosine Matrix to Euler Angles/Subsystem3
 * '<S319>' : controlMCUSlugsMKII/get Nav Vars/Direction Cosine Matrix to Euler Angles/cos(phi)cos(theta)
 * '<S320>' : controlMCUSlugsMKII/get Nav Vars/Direction Cosine Matrix to Euler Angles/cos(psi)cos(theta)
 * '<S321>' : controlMCUSlugsMKII/get Nav Vars/Direction Cosine Matrix to Euler Angles/sin(phi)cos(theta)
 * '<S322>' : controlMCUSlugsMKII/get Nav Vars/Direction Cosine Matrix to Euler Angles/sin(psi)cos(theta)
 * '<S323>' : controlMCUSlugsMKII/get Nav Vars/Direction Cosine Matrix to Euler Angles/sin(theta)
 * '<S324>' : controlMCUSlugsMKII/get Nav Vars/Euler Angles to  Direction Cosine Matrix1/A11
 * '<S325>' : controlMCUSlugsMKII/get Nav Vars/Euler Angles to  Direction Cosine Matrix1/A12
 * '<S326>' : controlMCUSlugsMKII/get Nav Vars/Euler Angles to  Direction Cosine Matrix1/A13
 * '<S327>' : controlMCUSlugsMKII/get Nav Vars/Euler Angles to  Direction Cosine Matrix1/A21
 * '<S328>' : controlMCUSlugsMKII/get Nav Vars/Euler Angles to  Direction Cosine Matrix1/A22
 * '<S329>' : controlMCUSlugsMKII/get Nav Vars/Euler Angles to  Direction Cosine Matrix1/A23
 * '<S330>' : controlMCUSlugsMKII/get Nav Vars/Euler Angles to  Direction Cosine Matrix1/A31
 * '<S331>' : controlMCUSlugsMKII/get Nav Vars/Euler Angles to  Direction Cosine Matrix1/A32
 * '<S332>' : controlMCUSlugsMKII/get Nav Vars/Euler Angles to  Direction Cosine Matrix1/A33
 * '<S333>' : controlMCUSlugsMKII/get Nav Vars/Euler Angles to  Direction Cosine Matrix1/Create Transformation Matrix
 * '<S334>' : controlMCUSlugsMKII/get Nav Vars/Euler Angles to  Direction Cosine Matrix1/Subsystem5
 * '<S335>' : controlMCUSlugsMKII/get Nav Vars/Euler Angles to  Direction Cosine Matrix1/Create Transformation Matrix/myMux Fun1
 * '<S336>' : controlMCUSlugsMKII/get Nav Vars/Euler Angles to  Direction Cosine Matrix1/Subsystem5/Environment Controller
 * '<S337>' : controlMCUSlugsMKII/get Nav Vars/Euler Angles to  Direction Cosine Matrix1/Subsystem5/Environment Controller1
 * '<S338>' : controlMCUSlugsMKII/get Nav Vars/Euler Angles to  Direction Cosine Matrix1/Subsystem5/SinCos1
 * '<S339>' : controlMCUSlugsMKII/get Nav Vars/Euler Angles to  Direction Cosine Matrix1/Subsystem5/myMux Fun1
 * '<S340>' : controlMCUSlugsMKII/get Nav Vars/Euler Angles to  Direction Cosine Matrix1/Subsystem5/myMux Fun2
 * '<S341>' : controlMCUSlugsMKII/get Nav Vars/Euler Angles to  Direction Cosine Matrix2/A11
 * '<S342>' : controlMCUSlugsMKII/get Nav Vars/Euler Angles to  Direction Cosine Matrix2/A12
 * '<S343>' : controlMCUSlugsMKII/get Nav Vars/Euler Angles to  Direction Cosine Matrix2/A13
 * '<S344>' : controlMCUSlugsMKII/get Nav Vars/Euler Angles to  Direction Cosine Matrix2/A21
 * '<S345>' : controlMCUSlugsMKII/get Nav Vars/Euler Angles to  Direction Cosine Matrix2/A22
 * '<S346>' : controlMCUSlugsMKII/get Nav Vars/Euler Angles to  Direction Cosine Matrix2/A23
 * '<S347>' : controlMCUSlugsMKII/get Nav Vars/Euler Angles to  Direction Cosine Matrix2/A31
 * '<S348>' : controlMCUSlugsMKII/get Nav Vars/Euler Angles to  Direction Cosine Matrix2/A32
 * '<S349>' : controlMCUSlugsMKII/get Nav Vars/Euler Angles to  Direction Cosine Matrix2/A33
 * '<S350>' : controlMCUSlugsMKII/get Nav Vars/Euler Angles to  Direction Cosine Matrix2/Create Transformation Matrix
 * '<S351>' : controlMCUSlugsMKII/get Nav Vars/Euler Angles to  Direction Cosine Matrix2/Subsystem5
 * '<S352>' : controlMCUSlugsMKII/get Nav Vars/Euler Angles to  Direction Cosine Matrix2/Create Transformation Matrix/myMux Fun1
 * '<S353>' : controlMCUSlugsMKII/get Nav Vars/Euler Angles to  Direction Cosine Matrix2/Subsystem5/Environment Controller
 * '<S354>' : controlMCUSlugsMKII/get Nav Vars/Euler Angles to  Direction Cosine Matrix2/Subsystem5/Environment Controller1
 * '<S355>' : controlMCUSlugsMKII/get Nav Vars/Euler Angles to  Direction Cosine Matrix2/Subsystem5/SinCos1
 * '<S356>' : controlMCUSlugsMKII/get Nav Vars/Euler Angles to  Direction Cosine Matrix2/Subsystem5/myMux Fun1
 * '<S357>' : controlMCUSlugsMKII/get Nav Vars/Euler Angles to  Direction Cosine Matrix2/Subsystem5/myMux Fun2
 */
#endif                                 /* RTW_HEADER_controlMCUSlugsMKII_h_ */

/* File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
