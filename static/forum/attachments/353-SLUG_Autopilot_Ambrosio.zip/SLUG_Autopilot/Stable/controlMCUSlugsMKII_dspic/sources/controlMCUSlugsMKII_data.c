/*
 * File: controlMCUSlugsMKII_data.c
 *
 * Real-Time Workshop code generated for Simulink model controlMCUSlugsMKII.
 *
 * Model version                        : 1.714
 * Real-Time Workshop file version      : 7.5  (R2010a)  25-Jan-2010
 * Real-Time Workshop file generated on : Tue Nov 23 13:12:51 2010
 * TLC version                          : 7.5 (Jan 19 2010)
 * C source code generated on           : Tue Nov 23 13:12:52 2010
 *--------------------------------------------------------------
 *   Embedded Coder for Microchip dsPIC family.                 |
 *   Generate .c and .h files from your Matlab/simulink model   |
 *   and compile the diagram to .hex and .coff file that can be |
 *   downloaded directly into the microcontroller               |
 *                                                              |
 * Licence Accorded to Blake Mills                              |
 *                     University of Colorado-Boulder           |
 *                                                              |
 *   Written by Lubin KERHUEL -  http://www.kerhuel.eu          |
 *  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - |
 *   Version 3.3a                              22-Nov-2010      |
 *   For Matlab 7.10            R2010a                          |
 *--------------------------------------------------------------
 */

#include "controlMCUSlugsMKII.h"
#include "controlMCUSlugsMKII_private.h"

/* Invariant block signals (auto storage) */
ConstBlockIO_controlMCUSlugsMKI controlMCUSlugsMKII_ConstB = {
  0.0
  ,                                    /* '<S290>/Gain4' */
  0.9966472387F
  ,                                    /* '<S236>/e^1' */
  0.9933057427F
  ,                                    /* '<S236>/ ' */
  0.006694257259F
  ,                                    /* '<S236>/Sum5' */
  0.9933057427F
  ,                                    /* '<S233>/Sum3' */
  0.9966472387F
  ,                                    /* '<S231>/e^1' */
  0.9933057427F
  ,                                    /* '<S231>/ ' */
  0.006694257259F
  ,                                    /* '<S231>/Sum5' */
  0.9933057427F
  ,                                    /* '<S228>/Sum3' */
  0.9966472387F
  ,                                    /* '<S176>/e^1' */
  0.9933057427F
  ,                                    /* '<S176>/ ' */
  0.006694257259F
  ,                                    /* '<S176>/Sum5' */
  0.9933057427F
  ,                                    /* '<S175>/Sum3' */
  0.9966472387F
  ,                                    /* '<S159>/e^1' */
  0.9933057427F
  ,                                    /* '<S159>/ ' */
  0.006694257259F
  ,                                    /* '<S159>/Sum5' */
  0.9933057427F
  ,                                    /* '<S156>/Sum3' */
  0.3490658402F
  ,                                    /* '<S94>/Add3' */
  -0.3490658402F
  ,                                    /* '<S94>/Add4' */
  4.0F
  ,                                    /* '<S38>/Divide1' */
  4.0F
  ,                                    /* '<S38>/Divide2' */
  0
  /* '<Root>/Initialize SPI SSL as  Input' */
};

/* Constant parameters (auto storage) */
const ConstParam_controlMCUSlugsMKII controlMCUSlugsMKII_ConstP = {
  /* Pooled Parameter (Expression: )
   * Referenced by:
   *   '<S206>/UEN 2 NEU'
   *   '<S207>/UEN 2 NEU'
   *   '<S144>/UEN 2 NEU'
   */
  { 0.0F, 0.0F, 1.0F, 0.0F, 1.0F, 0.0F, 1.0F, 0.0F, 0.0F }
};

/* File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
