#include "conversions.h"
#include "apDefinitions.h"

float bytesToFloat (unsigned char* inBytes){
	tFloatToChar convert;
	convert.chData[0] = inBytes[0];
	convert.chData[1] = inBytes[1];
	convert.chData[2] = inBytes[2];
	convert.chData[3] = inBytes[3];
	return convert.flData;
}

void floatToBytes (float inFloat, unsigned char* inBytes){
	tFloatToChar convert;
	convert.flData = inFloat;
	
	inBytes[0] = convert.chData[0];
	inBytes[1] = convert.chData[1];
	inBytes[2] = convert.chData[2];
	inBytes[3] = convert.chData[3];	
}

unsigned short bytesToUShort (unsigned char* inBytes){
	tUnsignedShortToChar convert;
	convert.chData[0] = inBytes[0];
	convert.chData[1] = inBytes[1];
	return convert.usData;
}

void uShortToBytes (unsigned short inUShort, unsigned char* inBytes){
	tUnsignedShortToChar convert;
	convert.usData = inUShort;
	
	inBytes[0] = convert.chData[0];
	inBytes[1] = convert.chData[1];
}

short bytesToShort (unsigned char* inBytes){
	tShortToChar convert;
	convert.chData[0] = inBytes[0];
	convert.chData[1] = inBytes[1];
	return convert.shData;
}

void shortToBytes (short inShort, unsigned char* inBytes){
	tShortToChar convert;
	convert.shData = inShort;
	
	inBytes[0] = convert.chData[0];
	inBytes[1] = convert.chData[1];
}
