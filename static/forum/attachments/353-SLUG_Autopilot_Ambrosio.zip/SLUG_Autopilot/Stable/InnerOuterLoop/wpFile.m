Xpoints = [0   1500 1500 400 400  -600];
Ypoints = [0   0    1500 600 1500 1500];
Zpoints = [500 500  500  500 500  500 ];

wpCount = length(Xpoints);

pauseOn = 1;