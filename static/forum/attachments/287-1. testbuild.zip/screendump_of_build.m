Model configured...
C30 Compiler found
C30 Compiler found
C30 Compiler found
C30 Compiler found
### Starting Real-Time Workshop build procedure for model: untitled
### Generating code into build directory: D:\microchip\MatlabSimulink\projects\1. testbuild\untitled_dspic\sources
PT### Invoking Target Language Compiler on untitled.rtw
	tlc
	-r
	D:\microchip\MatlabSimulink\projects\1. testbuild\untitled_dspic\sources\untitled.rtw
	D:\microchip\MatlabSimulink\dspic\dspic.tlc
	-OD:\microchip\MatlabSimulink\projects\1. testbuild\untitled_dspic\sources
	-ID:\microchip\MatlabSimulink\dspic
	-ID:\microchip\MatlabSimulink\blocks
	-ID:\microchip\MatlabSimulink\projects\1. testbuild\untitled_dspic\sources\tlc
	-ID:\MATLAB\R2007b\rtw\c\tlc\mw
	-ID:\MATLAB\R2007b\rtw\c\tlc\lib
	-ID:\MATLAB\R2007b\rtw\c\tlc\blocks
	-ID:\MATLAB\R2007b\rtw\c\tlc\fixpt
	-ID:\MATLAB\R2007b\stateflow\c\tlc
	-aEnforceIntegerDowncast=1
	-aFoldNonRolledExpr=1
	-aInlineInvariantSignals=0
	-aInlineParameters=0
	-aLocalBlockOutputs=1
	-aRollThreshold=5
	-aZeroInternalMemoryAtStartup=1
	-aZeroExternalMemoryAtStartup=1
	-aInitFltsAndDblsToZero=1
	-aGenerateReport=0
	-aGenCodeOnly=0
	-aRTWVerbose=1
	-aIncludeHyperlinkInReport=0
	-aLaunchReport=0
	-aGenerateTraceInfo=0
	-aForceParamTrailComments=0
	-aGenerateComments=1
	-aIgnoreCustomStorageClasses=0
	-aIncHierarchyInIds=0
	-aMaxRTWIdLen=31
	-aShowEliminatedStatements=0
	-aIncDataTypeInIds=0
	-aInsertBlockDesc=0
	-aSimulinkBlockComments=1
	-aInlinedPrmAccess="Literals"
	-aTargetFcnLib="ansi_tfl_table_tmw.mat"
	-aGenFloatMathFcnCalls="ANSI_C"
	-aIsPILTarget=0
	-aIncludeMdlTerminateFcn=0
	-aCombineOutputUpdateFcns=1
	-aSuppressErrorStatus=1
	-aERTCustomFileBanners=1
	-aLogVarNameModifier="rt_"
	-aGenerateFullHeader=1
	-aGenerateSampleERTMain=0
	-aMatFileLogging=0
	-aMultiInstanceERTCode=0
	-aPurelyIntegerCode=0
	-aPortableWordSizes=0
	-aGenerateErtSFunction=0
	-aGenerateASAP2=0
	-aExtMode=0
	-aExtModeStaticAlloc=0
	-aExtModeStaticAllocSize=1000000
	-aExtModeTransport=0
	-aExtModeTesting=0
	-aInlinedParameterPlacement="NonHierarchical"
	-aTargetOS="BareBoardExample"
	-aMultiInstanceErrorCode="Error"
	-aRateGroupingCode=1
	-aRTWCAPISignals=0
	-aRTWCAPIParams=0
	-aRootIOStructures=0
	-aERTCustomFileTemplate="dsPIC_main.tlc"
	-aGMAKE_PLACE="D:\MATLAB\R2007b\bin\win32\gmake"
	-aOPTIM_GCC="-mcpu=30f3012 -O3 -fschedule-insns -fschedule-insns2"
	-aLDFLAGS="-t --report-mem -Map ../untitled.map --heap 0  -cref"
	-aLDPICTYPE="-T C:\PROGRA~1\MICROC~1\MPLABC~2\support\dsPIC30F\gld\p30f3012.gld"
	-aLDLIBPIC="C:\PROGRA~1\MICROC~1\MPLABC~2\lib\libpic30-coff.a  C:\PROGRA~1\MICROC~1\MPLABC~2\lib\dsPIC30F\libp30f3012-coff.a C:\PROGRA~1\MICROC~1\MPLABC~2\lib\libc-coff.a C:\PROGRA~1\MICROC~1\MPLABC~2\lib\libm-coff.a"
	-aPIC_INCLUDES="-I C:\PROGRA~1\MICROC~1\MPLABC~2\include"
	-aPIC_REF="30f3012"
	-aGCCPATH=""
	-aGenerateTraceInfo=0
	-p10000
### Loading TLC function libraries
....
### Initial pass through model to cache user defined code
.
### Caching model source code
..........
### Writing main
.
### Writing header file untitled_types.h
### Writing header file untitled.h
.
### Writing source file untitled.c
### Writing header file untitled_private.h
### Writing header file autobuild.h
.
### Writing source file untitled_main.c
### TLC code generation complete.
### Evaluating PostCodeGenCommand specified in the model
     ----------------------------------------------------
     ----------------------------------------------------
Embedded Coder for dsPIC V3.1(17-Nov-2009) for Matlab R2007b.
Licence Accorded to  Demonstration Version
                     RTWdsPIC@kerhuel.eu
                     Author : Lubin KERHUEL
                     WEBSITE : http://www.kerhuel.eu/wiki
                     
                     SIRENE : 503 920 456
                     SIRET : 503 920 456 00012
 Facturation to :    Demo
                     Demo
                     Lubin KERHUEL
                     18 avenue Joseph Lieutaud
                     13260 Cassis
                     FRANCE
     ----------------------------------------------------
Check updates and new informations at :  www.kerhuel.eu 
     ----------------------------------------------------
.
### Processing Template Makefile: D:\microchip\MatlabSimulink\dspic\dspic_pic30_gcc.tmf
### Creating untitled.mk from D:\microchip\MatlabSimulink\dspic\dspic_pic30_gcc.tmf
### Building untitled: .\untitled.bat
 
D:\microchip\MatlabSimulink\projects\1. testbuild\untitled_dspic\sources>set MATLAB=D:\MATLAB\R2007b  
 
D:\microchip\MatlabSimulink\projects\1. testbuild\untitled_dspic\sources>"D:\MATLAB\R2007b\bin\win32\gmake" -f untitled.mk  GENERATE_REPORT=0 MULTI_INSTANCE_CODE=0 PORTABLE_WORDSIZES=0 GENERATE_ASAP2=0 TMW_EXTMODE_TESTING=0  
''pic30-gcc  -c -mcpu=30f3012 -O3 -fschedule-insns -fschedule-insns2	 -O   -I. -I..\.. -ID:\MATLAB\R2007b/simulink/include -ID:\MATLAB\R2007b/extern/include -ID:\MATLAB\R2007b/rtw/c/src -ID:\MATLAB\R2007b/rtw/c/ert -ID:\MATLAB\R2007b/rtw/c/src/ext_mode/common -ID:\MICROC~1\MATLAB~1\projects\1074C~1.TES\UNTITL~1\sources -ID:\MICROC~1\MATLAB~1\projects\1074C~1.TES -ID:\MATLAB\R2007b\rtw\c\libsrc   -I C:\PROGRA~1\MICROC~1\MPLABC~2\include    untitled_main.c 
''pic30-gcc  -c -mcpu=30f3012 -O3 -fschedule-insns -fschedule-insns2	 -O   -I. -I..\.. -ID:\MATLAB\R2007b/simulink/include -ID:\MATLAB\R2007b/extern/include -ID:\MATLAB\R2007b/rtw/c/src -ID:\MATLAB\R2007b/rtw/c/ert -ID:\MATLAB\R2007b/rtw/c/src/ext_mode/common -ID:\MICROC~1\MATLAB~1\projects\1074C~1.TES\UNTITL~1\sources -ID:\MICROC~1\MATLAB~1\projects\1074C~1.TES -ID:\MATLAB\R2007b\rtw\c\libsrc   -I C:\PROGRA~1\MICROC~1\MPLABC~2\include    untitled.c 
''pic30-gcc  -c -mcpu=30f3012 -O3 -fschedule-insns -fschedule-insns2	 -O   -I. -I..\.. -ID:\MATLAB\R2007b/simulink/include -ID:\MATLAB\R2007b/extern/include -ID:\MATLAB\R2007b/rtw/c/src -ID:\MATLAB\R2007b/rtw/c/ert -ID:\MATLAB\R2007b/rtw/c/src/ext_mode/common -ID:\MICROC~1\MATLAB~1\projects\1074C~1.TES\UNTITL~1\sources -ID:\MICROC~1\MATLAB~1\projects\1074C~1.TES -ID:\MATLAB\R2007b\rtw\c\libsrc   -I C:\PROGRA~1\MICROC~1\MPLABC~2\include    D:\MATLAB\R2007b\rtw\c\libsrc/rt_matmultandinccc_dbl.c 
D:\MATLAB\R2007b\rtw\c\libsrc/rt_matmultandinccc_dbl.c: In function 'rt_MatMultAndIncCC_Dbl': 
D:\MATLAB\R2007b\rtw\c\libsrc/rt_matmultandinccc_dbl.c:54: error: unrecognizable insn: 
(0x00f5a7f8) (insn 233 75 76 6 (set (reg:SF 2 w2 [ A2_val$im ]) 
        (mem/s/j:SF (plus:P16APSV (reg/v/f:P16APSV 14 w14 [orig:57 A2 ] [57]) 
                (const_int 4 [0x4])) [0 <variable>.im+0 S4 A16])) -1 (nil) 
    (nil)) 
D:\MATLAB\R2007b\rtw\c\libsrc/rt_matmultandinccc_dbl.c:54: internal compiler error: in extract_insn, at recog.c:2020 
Please submit a full bug report, 
with preprocessed source if appropriate. 
See <URL:http://support.microchip.com> for instructions. 
gmake: *** [rt_matmultandinccc_dbl.o] Error 255 
### Real-Time Workshop build procedure for model: 'untitled' aborted due to an error.
C30 Compiler found
C30 Compiler found
