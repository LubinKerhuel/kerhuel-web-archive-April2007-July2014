/*
 * File: untitled_main.c
 *
 * Real-Time Workshop code generated for Simulink model untitled.
 *
 * Model version                        : 1.8
 * Real-Time Workshop file version      : 7.0.1  (R2007b+)  21-Apr-2008
 * Real-Time Workshop file generated on : Sat Jan 16 23:11:21 2010
 * TLC version                          : 7.0 (Jul 26 2007)
 * C source code generated on           : Sat Jan 16 23:11:22 2010
 *--------------------------------------------------------------
 *   Embedded Coder for Microchip dsPIC family.                 |
 *   Generate .c and .h files from your Matlab/simulink model   |
 *   and compile the diagram to .hex and .coff file that can be |
 *   downloaded directly into the microcontroller               |
 *                                                              |
 * Licence Accorded to Demonstration Version                    |
 *                     Author : Lubin KERHUEL                   |
 *                                                              |
 *   Written by Lubin KERHUEL -  http://www.kerhuel.eu          |
 *  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - |
 *   Version 3.1                               17-Nov-2009      |
 *   For Matlab 7.5             R2007b                          |
 *--------------------------------------------------------------
 */

#include "untitled.h"
#include "untitled_private.h"

_FOSC(CSW_FSCM_OFF & HS)
  _FWDT(WDT_OFF)
  _FBORPOR(PBOR_OFF & PWRT_OFF & MCLR_DIS)
  _FGS(CODE_PROT_OFF)
  static boolean_T OverrunFlag = 0;
void rt_OneStep()
{
  /* Disable interrupts here */
  /* Save FPU context here (if necessary) */
  /* Re-enable timer or interrupt here */
  untitled_step();

  /* Disable interrupts here */
  /* Restore FPU context here (if necessary) */
  /* Enable interrupts here */
}

int main(void)
{
  /* Initialize model */
  untitled_initialize(1);
  for (;;) {
    /* Associate rt_OneStep() with a timer that executes at the base rate of the model */
    while (!_T1IF) ;
    _T1IF = 0;
    rt_OneStep();
  }
}

/* File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
