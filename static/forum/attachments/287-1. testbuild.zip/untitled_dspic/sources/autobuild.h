/*
 * File: autobuild.h
 *
 * Real-Time Workshop code generated for Simulink model untitled.
 *
 * Model version                        : 1.8
 * Real-Time Workshop file version      : 7.0.1  (R2007b+)  21-Apr-2008
 * Real-Time Workshop file generated on : Sat Jan 16 23:11:21 2010
 * TLC version                          : 7.0 (Jul 26 2007)
 * C source code generated on           : Sat Jan 16 23:11:22 2010
 *--------------------------------------------------------------
 *   Embedded Coder for Microchip dsPIC family.                 |
 *   Generate .c and .h files from your Matlab/simulink model   |
 *   and compile the diagram to .hex and .coff file that can be |
 *   downloaded directly into the microcontroller               |
 *                                                              |
 * Licence Accorded to Demonstration Version                    |
 *                     Author : Lubin KERHUEL                   |
 *                                                              |
 *   Written by Lubin KERHUEL -  http://www.kerhuel.eu          |
 *  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - |
 *   Version 3.1                               17-Nov-2009      |
 *   For Matlab 7.5             R2007b                          |
 *--------------------------------------------------------------
 */

#ifndef RTW_HEADER_autobuild_h_
#define RTW_HEADER_autobuild_h_
#include "untitled.h"
#define INCLUDE_FIRST_TIME_ARG         1
#endif                                 /* RTW_HEADER_autobuild_h_ */

/* File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
