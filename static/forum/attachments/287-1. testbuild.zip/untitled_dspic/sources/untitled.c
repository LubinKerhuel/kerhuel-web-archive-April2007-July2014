/*
 * File: untitled.c
 *
 * Real-Time Workshop code generated for Simulink model untitled.
 *
 * Model version                        : 1.8
 * Real-Time Workshop file version      : 7.0.1  (R2007b+)  21-Apr-2008
 * Real-Time Workshop file generated on : Sat Jan 16 23:11:21 2010
 * TLC version                          : 7.0 (Jul 26 2007)
 * C source code generated on           : Sat Jan 16 23:11:22 2010
 *--------------------------------------------------------------
 *   Embedded Coder for Microchip dsPIC family.                 |
 *   Generate .c and .h files from your Matlab/simulink model   |
 *   and compile the diagram to .hex and .coff file that can be |
 *   downloaded directly into the microcontroller               |
 *                                                              |
 * Licence Accorded to Demonstration Version                    |
 *                     Author : Lubin KERHUEL                   |
 *                                                              |
 *   Written by Lubin KERHUEL -  http://www.kerhuel.eu          |
 *  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - |
 *   Version 3.1                               17-Nov-2009      |
 *   For Matlab 7.5             R2007b                          |
 *--------------------------------------------------------------
 */

#include "untitled.h"
#include "untitled_private.h"

/* Model step function */
void untitled_step(void)
{
  /* (no output/update code required) */
}

/* Model initialize function */
void untitled_initialize(boolean_T firstTime)
{
  (void)firstTime;

  /* S-Function "dsPIC_MASTER" initialization Block: <Root>/Master */
  /* 0 testfcy 	*/
  /*  2.5E+006	*/
  /* CONFIG TIMER 1 for scheduling steps 	*/
  ConfigIntTimer1(T1_INT_PRIOR_0 & T1_INT_OFF);
  T1CON = 0x8000 ;                     /* T1_PS_1_1	*/
  PR1 = 2499;

  /* Configuration TRIS */
  /* Configuration ADCHS */
  ADPCFG = 0U;
}

/* File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
