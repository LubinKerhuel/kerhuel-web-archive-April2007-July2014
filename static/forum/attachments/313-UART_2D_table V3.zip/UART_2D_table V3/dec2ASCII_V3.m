% decimal to ASCII lookup
% use with Simulink Direct lookup table n-D block
%look-up table is zero based, so first entry in table is 
% ASCII code for the digit"0"
clear all

%     48 = 0
%     49 = 1
%     50 = 2
%     51 = 3
%     52 = 4
%     53 = 5
%     54 = 6
%     55 = 7
%     56 = 8
%     57 = 9
%     44 = ,
%     32 = [space]

% T00 = [48 48 48 48 48 48 48 48 48 48,
%      48 48 48 48 48 48 48 48 48 48,
%      48 49 50 51 52 53 54 55 56 57,
%      44 44 44 44 44 44 44 44 44 44,
%      32 32 32 32 32 32 32 32 32 32...;

T = ones(5,256);
T(4,:) = 44;
T(5,:) = 32;
for k=0:255
     T(3,k+1) = mod(k,10);
    T(2,k+1) = (mod(k,100)-T(3,k+1))/10;
    T(1,k+1) = floor(k/100);    
end

%      0     0     0     0     0     0     0     0     0     0     0...
%      0     0     0     0     0     0     0     0     0     0     1...
%      0     1     2     3     4     5     6     7     8     9     0...
%     44    44    44    44    44    44    44    44    44    44    44...
%     32    32    32    32    32    32    32    32    32    32    32...

for k=1:256
    T(3,k) = T(3,k) +48;
    T(2,k) = T(2,k) +48; 
    T(1,k) = T(1,k) +48;   
end

    
