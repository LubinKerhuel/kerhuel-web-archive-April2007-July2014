/*
 * File: UART_2D_tableV3.c
 *
 * Real-Time Workshop code generated for Simulink model UART_2D_tableV3.
 *
 * Model version                        : 1.83
 * Real-Time Workshop file version      : 7.3  (R2009a)  15-Jan-2009
 * Real-Time Workshop file generated on : Thu Apr 01 14:12:03 2010
 * TLC version                          : 7.3 (Jan 18 2009)
 * C source code generated on           : Thu Apr 01 14:12:04 2010
 */

#include "UART_2D_tableV3.h"
#include "UART_2D_tableV3_private.h"

/* Block signals (auto storage) */
BlockIO_UART_2D_tableV3 UART_2D_tableV3_B;

/* Model step function */
void UART_2D_tableV3_step(void)
{
  /* local block i/o variables */
  real_T rtb_DirectLookupTablenD[5];

  {
    int16_T i;
    real_T tmp;

    /* S-Function "UART_RX" Block: <Root>/Rx Input */
    {
      if (U1STAbits.URXDA != 0)
        _U1RXIF = 1;
      if (RxPtrHaut_Uart1 != RxPtrBas_Uart1) {
        UART_2D_tableV3_B.RxInput_o1 = (uint8_T) RxTab_Uart1[RxPtrBas_Uart1 ++];/* Use only the 8 low bytes or RxReg */
        RxPtrBas_Uart1 &= (Rx_BUFF_SIZE_Uart1-1);
        UART_2D_tableV3_B.RxInput_o2 = 1;
      } else {
        UART_2D_tableV3_B.RxInput_o1 = 0;
        UART_2D_tableV3_B.RxInput_o2 = 0;
      }
    }

    /* Outputs for enable SubSystem: '<Root>/Enabled Subsystem' incorporates:
     *  EnablePort: '<S1>/Enable'
     */
    if (UART_2D_tableV3_B.RxInput_o2) {
      /* S-Function (sfun_nddirectlook): '<S1>/Direct Lookup Table (n-D)' */
      /* LookupNDDirect: '<S1>/Direct Lookup Table (n-D)' */
      /* 2-dimensional Direct Look-Up returning a Column */
      (void) memcpy((void *)rtb_DirectLookupTablenD,(void *)
                    &UART_2D_tableV3_P.DirectLookupTablenD_table[5*
                    UART_2D_tableV3_B.RxInput_o1],
                    sizeof(real_T)*5U);

      /* DataTypeConversion: '<S1>/Data Type Conversion' */
      for (i = 0; i < 5; i++) {
        if (rtIsNaN(rtb_DirectLookupTablenD[i]) || rtIsInf
            (rtb_DirectLookupTablenD[i])) {
          tmp = 0.0;
        } else {
          tmp = fmod(floor(rtb_DirectLookupTablenD[i]), 256.0);
        }

        UART_2D_tableV3_B.DataTypeConversion[i] = tmp < 0.0 ? (uint8_T)
          (-((uint8_T)(-tmp))) : (uint8_T)tmp;
      }

      /* S-Function "UART_Tx" Block: <S1>/Tx Output */
      {
        uint8_T Tmp;

        {
          int_T i1;
          const uint8_T *u0 = UART_2D_tableV3_B.DataTypeConversion;
          for (i1=0; i1 < 5; i1++) {
            do {
              Tmp = ~(TxPtrHaut_Uart2 - TxPtrBas_Uart2);/* Tmp = 7 - (Haut - Bas) modulo 32	*/
              Tmp = Tmp & (32-1);
            } while (Tmp == 0);

            TxTab_Uart2[TxPtrHaut_Uart2] = u0[i1];
            TxPtrHaut_Uart2 = (TxPtrHaut_Uart2 + 1) & (32-1);
            _U2TXIF = 1;
            _U2TXIE = 1;
          }
        }
      }
    }

    /* end of Outputs for SubSystem: '<Root>/Enabled Subsystem' */
  }
}

/* Model initialize function */
void UART_2D_tableV3_initialize(boolean_T firstTime)
{
  (void)firstTime;

  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* block I/O */
  (void) memset(((void *) &UART_2D_tableV3_B),0,
                sizeof(BlockIO_UART_2D_tableV3));

  /* S-Function "dsPIC_MASTER" initialization Block: <Root>/Master */
  /* 0 testfcy 	*/
  /*  4.0E+007	*/
  /* CONFIG TIMER 1 for scheduling steps 	*/
  ConfigIntTimer1(T1_INT_PRIOR_0 & T1_INT_OFF);
  T1CON = 0x8000 ;                     /* T1_PS_1_1	*/
  PR1 = 7999;

  /* Configuration TRIS */
  /* Configuration ADCHS */
  AD1PCFGL = (0U);
  AD2PCFGL = (0U);
  AD1PCFGH = ((0U) & 65535);

  /* S-Function "dsPIC_UART_config" initialization Block: <Root>/UART Configuration */
  /* set priority */
  _U1RXIP = 0x0007 & 2;
  _U1TXIP = 0x0007 & 1;

  /* enable/disable interrupt */
  _U1RXIE = (3 != 0);
  _U1TXIE = 0;
  U1MODE = 0x8080 + 1024;
  U1STA = 0x0 + 1 + 0 + 192 + (1<<12);
  U1BRG = 21;
  TxPtrHaut_Uart1 = 0;
  TxPtrBas_Uart1 = 0;
  RxPtrHaut_Uart1 = 0;
  RxPtrBas_Uart1 = 0;
  _U1TXIF = 0;

  /* S-Function "dsPIC_UART_config" initialization Block: <Root>/UART Configuration1 */
  /* set priority */
  _U2RXIP = 0x0007 & 2;
  _U2TXIP = 0x0007 & 1;

  /* enable/disable interrupt */
  _U2RXIE = (3 != 0);
  _U2TXIE = 0;
  U2MODE = 0x8080 + 1024;
  U2STA = 0x0 + 1 + 1024 + 192 + (1<<12);
  U2BRG = 21;
  TxPtrHaut_Uart2 = 0;
  TxPtrBas_Uart2 = 0;
  RxPtrHaut_Uart2 = 0;
  RxPtrBas_Uart2 = 0;
  _U2TXIF = 0;
}

/* File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
