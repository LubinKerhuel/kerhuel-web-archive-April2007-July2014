/*
 * File: rtGetNaN.c
 *
 * Real-Time Workshop code generated for Simulink model UART_2D_tableV3.
 *
 * Model version                        : 1.83
 * Real-Time Workshop file version      : 7.3  (R2009a)  15-Jan-2009
 * Real-Time Workshop file generated on : Thu Apr 01 14:12:03 2010
 * TLC version                          : 7.3 (Jan 18 2009)
 * C source code generated on           : Thu Apr 01 14:12:04 2010
 */

/*
 * Abstract:
 *      Real-Time Workshop function to intialize non-finite, NaN
 */
#include "rtGetNaN.h"
#define NumBitsPerChar                 8

/* Function: rtGetNaN ==================================================
 * Abstract:
 *	Initialize rtNaN needed by the generated code.
 *	NaN is initialized as non-signaling. Assumes IEEE.
 */
real_T rtGetNaN(void)
{
  size_t bitsPerReal = sizeof(real_T) * (NumBitsPerChar);
  real_T nan = 0.0;
  if (bitsPerReal == 32) {
    nan = rtGetNaNF();
  } else {
    typedef struct {
      struct {
        uint32_T wordL;
        uint32_T wordH;
      } words;
    } LittleEndianIEEEDouble;

    union {
      LittleEndianIEEEDouble bitVal;
      real_T fltVal;
    } tmpVal;

    tmpVal.bitVal.words.wordH = 0xFFF80000;
    tmpVal.bitVal.words.wordL = 0x00000000;
    nan = tmpVal.fltVal;
  }

  return nan;
}

/* Function: rtGetNaNF ==================================================
 * Abstract:
 *	Initialize rtNaNF needed by the generated code.
 *	NaN is initialized as non-signaling. Assumes IEEE.
 */
real32_T rtGetNaNF(void)
{
  typedef struct {
    union {
      real32_T wordLreal;
      uint32_T wordLuint;
    } wordL;
  } IEEESingle;

  IEEESingle nanF;
  nanF.wordL.wordLuint = 0xFFC00000;
  return nanF.wordL.wordLreal;
}

#undef NumBitsPerChar

/* end rt_getNaN.c */

/* File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
