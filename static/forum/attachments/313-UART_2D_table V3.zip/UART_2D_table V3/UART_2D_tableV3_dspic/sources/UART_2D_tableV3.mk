#
# File: UART_2D_tableV3.mk
#
#--------------------------------------------------------------
#   Embedded Coder for Microchip dsPIC30/dsPIC33/PIC24 family. |
#   Generate .c and .h files from your Matlab/simulink model   |
#   and compile the diagram to .hex and .cof file that can be  |
#   downloaded directly into the microcontroller               |
#                                                              |
#      The Microchip name PIC, dsPIC, and MPLAB are            |
#      registered trademarks of Microchip Technology Inc.      |
#      MATLAB, Simulink, and Real-Time Workshop are            |
#      registered trademarks of The MathWorks, Inc.            |
#                                                              |
# Licence Accorded to Demonstration Version                    |
#                                                              |
#   Written by Lubin KERHUEL -  http://www.kerhuel.eu          |
#  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - |
#   Version 3.1                              17-Nov-2009       |
#--------------------------------------------------------------

#MAKE			 = "%MATLAB%\rtw\bin\win32\gmake"
#MAKE			 = "%MATLAB%\bin\win32\gmake"
MAKE 			 = "C:\PROGRA~1\MATLAB\R2009a\bin\win32\gmake"
HOST             = PC
BUILD            = yes
BUILD_SUCCESS    = *** Created
SYS_TARGET_FILE  = dspic.tlc

#---------------------- Tokens expanded by make_rtw ----------------------------
#
# The following tokens, when wrapped with "|>" and "<|" are expanded by the 
# Real-Time Workshop build procedure.
#   
MODEL               = UART_2D_tableV3
MODULES             = UART_2D_tableV3_data.c UART_2D_tableV3_main.c dsPIC_UART1_Interrupt.c dsPIC_UART2_Interrupt.c rtGetInf.c rtGetNaN.c rt_nonfinite.c 
MAKEFILE            = UART_2D_tableV3.mk
MATLAB_ROOT         = C:\Program Files\MATLAB\R2009a
ALT_MATLAB_ROOT     = C:\PROGRA~1\MATLAB\R2009a
S_FUNCTIONS         = 
S_FUNCTIONS_LIB     = 
NUMST               = 1
NCSTATES            = 0
COMPUTER            = PCWIN
BUILDARGS           =  GENERATE_REPORT=0 MULTI_INSTANCE_CODE=0 PORTABLE_WORDSIZES=0 GENERATE_ASAP2=0 TMW_EXTMODE_TESTING=0
MULTITASKING        = 0
MODELREFS           = 
SHARED_SRC          = 
SHARED_SRC_DIR      = 
SHARED_BIN_DIR      = 
SHARED_LIB          = 
GEN_SAMPLE_MAIN     = 0
TARGET_LANG_EXT     = c
EXT_MODE            = 0
EXTMODE_TRANSPORT   = 0
EXTMODE_STATIC      = 0
EXTMODE_STATIC_SIZE = 1000000
NUMST               = 1


#--------------------------- Model and reference models -----------------------
MODELLIB                  = UART_2D_tableV3lib.lib
MODELREF_LINK_LIBS        = 
MODELREF_INC_PATH         = 
RELATIVE_PATH_TO_ANCHOR   = ..\..
# NONE: standalone, SIM: modelref sim, RTW: modelref rtw
MODELREF_TARGET_TYPE       = NONE

# New : to support Continuous States ? find in "Upgrading from V3.2.1 or V3.2"
CPP_REQ_DEFINES = -DMODEL=$(MODEL) -DNUMST=$(NUMST) -DNCSTATES=$(NCSTATES) \
-DMAT_FILE=$(MAT_FILE)
-DINTEGER_CODE=$(INTEGER_CODE) \
-DONESTEPFCN=$(ONESTEPFCN) -DTERMFCN=$(TERMFCN) \
-DHAVESTDIO
-DMULTI_INSTANCE_CODE=$(MULTI_INSTANCE_CODE) \
-DADD_MDL_NAME_TO_GLOBALS=$(ADD_MDL_NAME_TO_GLOBALS)

#-- In the case when directory name contains space ---
ifneq ($(MATLAB_ROOT),$(ALT_MATLAB_ROOT))
MATLAB_ROOT := $(ALT_MATLAB_ROOT)
endif

# RTW option makevariables that are not expanded in the template makefile are
# automatically passed into make. To avoid this, create NOOP replacements.
# For this custom target, these ERT makevariables are not used.
#
NOOP = 0
NOOP = 0
NOOP = 0
NOOP = 1
NOOP = 0

#------------------------------ Tool Locations ---------------------------------
#


#-------------------------------- GNU Tools ------------------------------------
#
# You may need to modify the following variables if you have installed the GNU
# Tools in a different location.
#

GCCPATH	= ''

#$(GCCPATH)
CC   = $(GCCPATH)pic30-gcc 
CPP  = $(GCCPATH)pic30-gcc
LD   = $(GCCPATH)pic30-ld  
AR   = $(GCCPATH)pic30-ar -r

# parameter controlled from simulink

#-O3 -fschedule-insns -fschedule-insns2
OPTIM_GCC = -mcpu=33fJ256MC710 -O3 -fschedule-insns -fschedule-insns2	

#-t --report-mem -Map ../untitled.map --heap 0  -cref
LDFLAGS = -t --report-mem -Map ../untitled.map --heap 0  -cref

#-T C:\PROGRA~1\MICROC~1\MPLABC~1\support\gld\p30f2012.gld
LDPICTYPE = -T C:\PROGRA~1\MICROC~1\MPLABC~2\support\dsPIC33F\gld\p33fJ256MC710.gld

#-LC:\PROGRA~1\MICROC~1\MPLABC~1\lib\ -lp30F2012 -lm -lc -lpic30
LDLIBPIC = C:\PROGRA~1\MICROC~1\MPLABC~2\lib\libpic30-coff.a  C:\PROGRA~1\MICROC~1\MPLABC~2\lib\dsPIC33F\libp33fJ256MC710-coff.a C:\PROGRA~1\MICROC~1\MPLABC~2\lib\libc-coff.a C:\PROGRA~1\MICROC~1\MPLABC~2\lib\libm-coff.a

PIC_INCLUDES = -I C:\PROGRA~1\MICROC~1\MPLABC~2\include

PIC_REF = 33fJ256MC710

CC_OPTS   = $(OPTIM_GCC) -O 


#!pic30-coff-ld -t --cref --report-mem -Map ../untitled.map  --heap 0 -o ../untitled.coff -T C:\PROGRA~1\MICROC~1\MPLABC~1\support\gld\p30f2012.gld ert_main.o untitled.o C:\PROGRA~1\MICROC~1\MPLABC~1\lib\libp30F2012-coff.a  C:\PROGRA~1\MICROC~1\MPLABC~1\lib\libc-coff.a  dsp_rt.a rtwlib.a  C:\PROGRA~1\MICROC~1\MPLABC~1\lib\libpic30-coff.a C:\PROGRA~1\MICROC~1\MPLABC~1\src\libm\libm.a
#!pic30-coff-ld -t --report-mem -Map ../untitled.map  --heap 0 -cref -T C:\PROGRA~1\MICROC~1\MPLABC~1\support\gld\p30f2012.gld  -o ../untitled.coff  -LC:\PROGRA~1\MICROC~1\MPLABC~1\lib\ ert_main.o untitled.o  -lp30F2012 -lc rtwlib.a -lpic30 -lm
#!pic30-coff-ld -t --report-mem -Map ../untitled.map  --heap 0 -cref -T C:\PROGRA~1\MICROC~1\MPLABC~1\support\gld\p30f2012.gld  -o ../untitled.coff  -LC:\PROGRA~1\MICROC~1\MPLABC~1\lib\  untitled.o  ert_main.o rtwlib.a -lp30F2012 -lm -lc -lpic30
# -lpic30 � la fin !!
#!pic30-coff-ld -t --report-mem -Map ../untitled.map  --heap 0 -cref -T C:\PROGRA~1\MICROC~1\MPLABC~1\support\gld\p30f2012.gld  -o ../untitled.coff untitled_data.o untitled.o ert_main.o  rtwlib.a dsp_rt.a -LC:\PROGRA~1\MICROC~1\MPLABC~1\lib\ -lp30F2012 -lm -lc -lpic30
#------------------------------ Include Path -----------------------------------
#
MATLAB_INCLUDES = \
	-I$(MATLAB_ROOT)/simulink/include \
  -I$(MATLAB_ROOT)/extern/include \
	-I$(MATLAB_ROOT)/rtw/c/src \
	-I$(MATLAB_ROOT)/rtw/c/ert \
	-I$(MATLAB_ROOT)/rtw/c/src/ext_mode/common

# Additional includes 
#
ADD_INCLUDES = \
	-IC:\Users\ij8977\DOCUME~1\MICROC~1\work\UARTAL~1\UART_2~2\UART_2D_tableV3_dspic\sources \
	-IC:\Users\ij8977\DOCUME~1\MICROC~1\work\UARTAL~1\UART_2~2 \





USER_INCLUDES = 

SHARED_INCLUDES =
ifneq ($(SHARED_SRC_DIR),)
SHARED_INCLUDES = -I$(SHARED_SRC_DIR) 
endif

INCLUDES = -I. -I$(RELATIVE_PATH_TO_ANCHOR) $(MATLAB_INCLUDES) $(ADD_INCLUDES) \
           $(USER_INCLUDES) $(PIC_INCLUDES) $(MODELREF_INC_PATH) \
           $(SHARED_INCLUDES)

#-------------------------------- C Flags --------------------------------------
# General User Options 

CFLAGS    =$(CC_OPTS)  $(INCLUDES) 
CPPFLAGS = $(CC_OPTS)  $(INCLUDES)

LIBS =
 
LIBS += $(S_FUNCTIONS_LIB)

#----------------------------- Source Files ------------------------------------
SHARED_OUTPUT_OPTS = -o $@
SRCS = $(MODULES) $(S_FUNCTIONS)
ifeq ($(MODELREF_TARGET_TYPE), NONE)
  # Top-level model for RTW
  PRODUCT            = $(RELATIVE_PATH_TO_ANCHOR)/$(MODEL).hex
  BUILD_PRODUCT_TYPE = "executable"
  SRCS               += $(MODEL).$(TARGET_LANG_EXT)  $(EXT_SRC)

#ifeq ($(GEN_SAMPLE_MAIN),0)
#    SRCS += main.c
#  else
#    SRCS += ert_main.c
#  endif

else
  # sub-model for RTW
  PRODUCT            = $(MODELLIB)
  BUILD_PRODUCT_TYPE = "library"
endif


USER_SRCS =
USER_OBJS = $(addsuffix .o, $(basename $(USER_SRCS)))
LOCAL_USER_OBJS = $(notdir $(USER_OBJS))

OBJS      = $(addsuffix .o, $(basename $(SRCS))) $(USER_OBJS)
LINK_OBJS = $(addsuffix .o, $(basename $(SRCS))) $(LOCAL_USER_OBJS)

SHARED_SRC := $(wildcard $(SHARED_SRC))
SHARED_OBJS = $(addsuffix .o, $(basename $(SHARED_SRC)))

#--------------------------------- Rules ---------------------------------------
ifeq ($(MODELREF_TARGET_TYPE),NONE)
# Top-level model for RTW
$(PRODUCT) : $(RELATIVE_PATH_TO_ANCHOR)/$(MODEL).coff $(OBJS) $(SHARED_LIB) $(MODELREF_LINK_LIBS) $(LIBS)
	$(GCCPATH)pic30-bin2hex $(RELATIVE_PATH_TO_ANCHOR)/$(MODEL).coff 
		@echo "$(BUILD_SUCCESS) $(BUILD_PRODUCT_TYPE): $@"	


else
# sub-model for RTW
$(PRODUCT) : $(OBJS) $(SHARED_OBJS)
	@rm -f $(MODELLIB)
	$(AR) ruv $(MODELLIB) $(LINK_OBJS)
	@echo "### $(MODELLIB) Created"
	@echo "$(BUILD_SUCCESS) $(BUILD_PRODUCT_TYPE): $@"	
endif


$(RELATIVE_PATH_TO_ANCHOR)/$(MODEL).coff : $(OBJS) $(SHARED_LIB) $(MODELREF_LINK_LIBS) $(LIBS)
	$(LD) $(LDFLAGS) $(LDPICTYPE) -o $(RELATIVE_PATH_TO_ANCHOR)/$(MODEL).coff $(MODELREF_LINK_LIBS) $(LINK_OBJS) $(SYSLIBS) $(SHARED_LIB) $(LIBS) $(LDLIBPIC)
		@echo " ================================================================"
	    @echo "*** Embedded Target for dsPIC by Lubin KERHUEL - http://www.kerhuel.eu"
	    @echo " | Licence Accorded to Demonstration Version                    |"
		@echo " |                     RTWdsPIC@kerhuel.eu                      |"	    
	    @echo " |          Companie : Author : Lubin KERHUEL                   |" 
		@echo " |                     WEBSITE : http://www.kerhuel.eu/wiki     |"
		@echo " |                                                              |" 		
		@echo " |                     SIRENE : 503 920 456                     |"
		@echo " |                     SIRET : 503 920 456 00012                |"		 		
		@echo " | Financial Service : Demo                                     |"
		@echo " | Contact             Demo                                     |"
		@echo " |                     Lubin KERHUEL                            |"
		@echo " |                     18 avenue Joseph Lieutaud                |"
		@echo " |                     13260 Cassis                             |"
		@echo " |                     FRANCE                                   |"
	    @echo " | Version 3.1                               17-Nov-2009        |"
		@echo " | For Matlab 7.8             R2009a                            |"
		@echo " ================================================================"		 
		@echo "$(BUILD_SUCCESS) $(BUILD_PRODUCT_TYPE): $@"	
	
	
%.o : %.c
	$(CC) -c $(CFLAGS) $<

%.o : %.cpp
	$(CC) -c $(CPPFLAGS) $<

%.o : %.s
	$(CC) -c $< -Wa,-p=$(PIC_REF),-g
	
%.o : ../%.c
	$(CC) -c $(CFLAGS) $<

%.o : ../%.cpp
	$(CC) -c $(CPPFLAGS) $<
	
%.o : ../%.s
	$(CC) -c $< -Wa,-p=$(PIC_REF),-g

%.o : $(RELATIVE_PATH_TO_ANCHOR)/%.c
	$(CC) -c $(CFLAGS) $<

%.o : $(RELATIVE_PATH_TO_ANCHOR)/%.cpp
	$(CC) -c $(CPPFLAGS) $<
	
%.o : $(RELATIVE_PATH_TO_ANCHOR)/%.s
	$(CC) -c $< -Wa,-p=$(PIC_REF),-g
	

%.o : $(MATLAB_ROOT)/rtw/c/src/%.c
	$(CC) -c $(CFLAGS) $<

%.o : $(MATLAB_ROOT)/rtw/c/src/ext_mode/common/%.c
	$(CC) -c $(CFLAGS) $<

%.o : $(MATLAB_ROOT)/rtw/c/src/ext_mode/tcpip/%.c
	$(CC) -c $(CFLAGS) $<

%.o : $(MATLAB_ROOT)/rtw/c/src/ext_mode/custom/%.c
	$(CC) -c $(CFLAGS) $<

%.o : $(MATLAB_ROOT)\rtw\c\src/%.c
	$(CC) -c $(CFLAGS) $<


%.o : $(MATLAB_ROOT)\rtw\c\src/%.cpp
	$(CC) -c $(CPPFLAGS) $<


%.o : $(MATLAB_ROOT)\rtw\c\src/%.s
	$(CC) -c $< -Wa,-p=$(PIC_REF),-g


%.o : $(MATLAB_ROOT)/simulink/src/%.c
	$(CC) -c $(CFLAGS) $<

%.o : $(MATLAB_ROOT)/simulink/src/%.cpp
	$(CC) -c $(CPPFLAGS) $<

	
	
#------------------------------- Libraries -------------------------------------





#----------------------------- Dependencies ------------------------------------

$(OBJS) : $(MAKEFILE) rtw_proj.tmw

$(SHARED_OBJS) : $(SHARED_BIN_DIR)/%.o : $(SHARED_SRC_DIR)/%.c  
	$(CC) -c $(CFLAGS) $(SHARED_OUTPUT_OPTS) $<

$(SHARED_OBJS) : $(SHARED_BIN_DIR)/%.o : $(SHARED_SRC_DIR)/%.s  
	$(CC) -c $< -Wa,-p=$(PIC_REF),-g
	
$(SHARED_LIB) : $(SHARED_OBJS)
	@echo "### Creating $@ "
	$(AR) $@ $(SHARED_OBJS)
	@echo "### $@ Created "

