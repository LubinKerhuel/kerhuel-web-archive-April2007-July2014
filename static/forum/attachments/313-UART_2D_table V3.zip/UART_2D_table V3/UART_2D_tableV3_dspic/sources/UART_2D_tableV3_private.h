/*
 * File: UART_2D_tableV3_private.h
 *
 * Real-Time Workshop code generated for Simulink model UART_2D_tableV3.
 *
 * Model version                        : 1.83
 * Real-Time Workshop file version      : 7.3  (R2009a)  15-Jan-2009
 * Real-Time Workshop file generated on : Thu Apr 01 14:12:03 2010
 * TLC version                          : 7.3 (Jan 18 2009)
 * C source code generated on           : Thu Apr 01 14:12:04 2010
 */

#ifndef RTW_HEADER_UART_2D_tableV3_private_h_
#define RTW_HEADER_UART_2D_tableV3_private_h_
#include "rtwtypes.h"

/* dsPIC library */
#include "p33fxxxx.h"
#include "timer.h"
#define fcy                            40000000
#define Tx_BUFF_SIZE_Uart1             32
#define Rx_BUFF_SIZE_Uart1             32
#define Tx_BUFF_SIZE_Uart2             32
#define Rx_BUFF_SIZE_Uart2             32
#ifndef __RTWTYPES_H__
#error This file requires rtwtypes.h to be included
#else
#ifdef TMWTYPES_PREVIOUSLY_INCLUDED
#error This file requires rtwtypes.h to be included before tmwtypes.h
#else

/* Check for inclusion of an incorrect version of rtwtypes.h */
#ifndef RTWTYPES_ID_C08S16I16L32N16F1
#error This code was generated with a different "rtwtypes.h" than the file included
#endif                                 /* RTWTYPES_ID_C08S16I16L32N16F1 */
#endif                                 /* TMWTYPES_PREVIOUSLY_INCLUDED */
#endif                                 /* __RTWTYPES_H__ */

#define _SPI1EN                        (SPI1STATbits.SPIEN)
#define _SPI2EN                        (SPI2STATbits.SPIEN)

extern volatile uint8_T TxPtrHaut_Uart1 ;
extern volatile uint8_T TxPtrBas_Uart1 ;
extern volatile uint8_T TxTab_Uart1[Tx_BUFF_SIZE_Uart1];
extern volatile uint8_T RxPtrHaut_Uart1 ;
extern volatile uint8_T RxPtrBas_Uart1 ;
extern volatile uint8_T RxTab_Uart1[Rx_BUFF_SIZE_Uart1];
extern volatile uint8_T TxPtrHaut_Uart2 ;
extern volatile uint8_T TxPtrBas_Uart2 ;
extern volatile uint8_T TxTab_Uart2[Tx_BUFF_SIZE_Uart2];
extern volatile uint8_T RxPtrHaut_Uart2 ;
extern volatile uint8_T RxPtrBas_Uart2 ;
extern volatile uint8_T RxTab_Uart2[Rx_BUFF_SIZE_Uart2];

#endif                                 /* RTW_HEADER_UART_2D_tableV3_private_h_ */

/* File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
