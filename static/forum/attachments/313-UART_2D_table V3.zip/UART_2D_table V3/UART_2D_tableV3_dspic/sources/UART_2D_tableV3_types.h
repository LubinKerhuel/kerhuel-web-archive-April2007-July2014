/*
 * File: UART_2D_tableV3_types.h
 *
 * Real-Time Workshop code generated for Simulink model UART_2D_tableV3.
 *
 * Model version                        : 1.83
 * Real-Time Workshop file version      : 7.3  (R2009a)  15-Jan-2009
 * Real-Time Workshop file generated on : Thu Apr 01 14:12:03 2010
 * TLC version                          : 7.3 (Jan 18 2009)
 * C source code generated on           : Thu Apr 01 14:12:04 2010
 */

#ifndef RTW_HEADER_UART_2D_tableV3_types_h_
#define RTW_HEADER_UART_2D_tableV3_types_h_
#include "rtwtypes.h"

/* Parameters (auto storage) */
typedef struct Parameters_UART_2D_tableV3_ Parameters_UART_2D_tableV3;

#endif                                 /* RTW_HEADER_UART_2D_tableV3_types_h_ */

/* File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
