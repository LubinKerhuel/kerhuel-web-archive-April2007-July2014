/*
 * File: UART_2D_tableV3.h
 *
 * Real-Time Workshop code generated for Simulink model UART_2D_tableV3.
 *
 * Model version                        : 1.83
 * Real-Time Workshop file version      : 7.3  (R2009a)  15-Jan-2009
 * Real-Time Workshop file generated on : Thu Apr 01 14:12:03 2010
 * TLC version                          : 7.3 (Jan 18 2009)
 * C source code generated on           : Thu Apr 01 14:12:04 2010
 */

#ifndef RTW_HEADER_UART_2D_tableV3_h_
#define RTW_HEADER_UART_2D_tableV3_h_
#ifndef UART_2D_tableV3_COMMON_INCLUDES_
# define UART_2D_tableV3_COMMON_INCLUDES_
#include <math.h>
#include <string.h>
#include "rtwtypes.h"
#include "rtGetInf.h"
#include "rtGetNaN.h"
#include "rt_nonfinite.h"
#endif                                 /* UART_2D_tableV3_COMMON_INCLUDES_ */

#include "UART_2D_tableV3_types.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((void*) 0)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((void) 0)
#endif

#ifndef rtmGetStopRequested
# define rtmGetStopRequested(rtm)      ((void*) 0)
#endif

/* Block signals (auto storage) */
typedef struct {
  uint8_T RxInput_o1;                  /* '<Root>/Rx Input' */
  uint8_T DataTypeConversion[5];       /* '<S1>/Data Type Conversion' */
  boolean_T RxInput_o2;                /* '<Root>/Rx Input' */
} BlockIO_UART_2D_tableV3;

/* Parameters (auto storage) */
struct Parameters_UART_2D_tableV3_ {
  real_T DirectLookupTablenD_table[1280];/* Expression: mxTable
                                          * '<S1>/Direct Lookup Table (n-D)'
                                          */
};

/* Block parameters (auto storage) */
extern Parameters_UART_2D_tableV3 UART_2D_tableV3_P;

/* Block signals (auto storage) */
extern BlockIO_UART_2D_tableV3 UART_2D_tableV3_B;

/* Model entry point functions */
extern void UART_2D_tableV3_initialize(boolean_T firstTime);
extern void UART_2D_tableV3_step(void);

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : UART_2D_tableV3
 * '<S1>'   : UART_2D_tableV3/Enabled Subsystem
 */
#endif                                 /* RTW_HEADER_UART_2D_tableV3_h_ */

/* File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
