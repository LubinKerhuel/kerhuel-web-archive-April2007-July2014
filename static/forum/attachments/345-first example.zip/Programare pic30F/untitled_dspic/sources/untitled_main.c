/*
 * File: untitled_main.c
 *
 * Real-Time Workshop code generated for Simulink model untitled.
 *
 * Model version                        : 1.1
 * Real-Time Workshop file version      : 7.4  (R2009b)  29-Jun-2009
 * Real-Time Workshop file generated on : Mon Jun 14 14:45:58 2010
 * TLC version                          : 7.4 (Jul 14 2009)
 * C source code generated on           : Mon Jun 14 14:45:59 2010
 *--------------------------------------------------------------
 *   Embedded Coder for Microchip dsPIC family.                 |
 *   Generate .c and .h files from your Matlab/simulink model   |
 *   and compile the diagram to .hex and .coff file that can be |
 *   downloaded directly into the microcontroller               |
 *                                                              |
 * Licence Accorded to Demonstration Version                    |
 *                     Author : Lubin KERHUEL                   |
 *                                                              |
 *   Written by Lubin KERHUEL -  http://www.kerhuel.eu          |
 *  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - |
 *   Version 3.2b                              31-Mar-2010      |
 *   For Matlab 7.9             R2009b                          |
 *--------------------------------------------------------------
 */

#include "untitled.h"
#include "untitled_private.h"

/* trick : Microchip renames ICS_NONE in ICS_PGD (February 2010) ! */
#ifndef ICS_NONE
#define ICS_NONE                       ICS_PGD
#endif

_FOSC(CSW_FSCM_OFF & HS)
  _FWDT(WDT_OFF)
  _FBORPOR(PBOR_OFF & PWRT_OFF & MCLR_DIS)
  _FGS(CODE_PROT_OFF)
  _FICD( ICS_NONE )
  void rt_OneStep()
{
  /* Disable interrupts here */
  /* Save FPU context here (if necessary) */
  /* Re-enable timer or interrupt here */
  untitled_step();

  /* Get model outputs here */

  /* Disable interrupts here */
  /* Restore FPU context here (if necessary) */
  /* Enable interrupts here */
}

int main(void)
{
  /* Initialize model */
  untitled_initialize(1);
  for (;;) {
    /* Associate rt_OneStep() with a timer that executes at the base rate of the model */
    while (!_T1IF) ;
    _T1IF = 0;
    rt_OneStep();
  }
}

/* File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
