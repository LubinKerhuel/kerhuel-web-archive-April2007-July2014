/*
 * File: untitled.c
 *
 * Real-Time Workshop code generated for Simulink model untitled.
 *
 * Model version                        : 1.1
 * Real-Time Workshop file version      : 7.4  (R2009b)  29-Jun-2009
 * Real-Time Workshop file generated on : Mon Jun 14 14:45:58 2010
 * TLC version                          : 7.4 (Jul 14 2009)
 * C source code generated on           : Mon Jun 14 14:45:59 2010
 *--------------------------------------------------------------
 *   Embedded Coder for Microchip dsPIC family.                 |
 *   Generate .c and .h files from your Matlab/simulink model   |
 *   and compile the diagram to .hex and .coff file that can be |
 *   downloaded directly into the microcontroller               |
 *                                                              |
 * Licence Accorded to Demonstration Version                    |
 *                     Author : Lubin KERHUEL                   |
 *                                                              |
 *   Written by Lubin KERHUEL -  http://www.kerhuel.eu          |
 *  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - |
 *   Version 3.2b                              31-Mar-2010      |
 *   For Matlab 7.9             R2009b                          |
 *--------------------------------------------------------------
 */

#include "untitled.h"
#include "untitled_private.h"

/* Block signals (auto storage) */
BlockIO rtB;

/* Block states (auto storage) */
D_Work rtDWork;

/* Model step function */
void untitled_step(void)
{
  real_T tmp;

  /* DataTypeConversion: '<Root>/Data Type Conversion' incorporates:
   *  Sin: '<Root>/Sine Wave'
   */
  tmp = sin(((real_T)rtDWork.counter + rtP.SineWave_Offset) * 2.0 *
            3.1415926535897931E+000 / rtP.SineWave_NumSamp) * rtP.SineWave_Amp +
    rtP.SineWave_Bias;
  if (rtIsNaN(tmp) || rtIsInf(tmp)) {
    tmp = 0.0;
  } else {
    tmp = fmod(floor(tmp), 65536.0);
  }

  rtB.DataTypeConversion = tmp < 0.0 ? (uint16_T)(-((int16_T)(uint16_T)(-tmp))) :
    (uint16_T)tmp;

  /* S-Function "dsPIC_PWM_OC" Block: <Root>/Output Compare */
  {
    oc1up = rtB.DataTypeConversion;
    oc1Periode = rtP.Constant_Value;

    /* UP & Periode on Rising edge */
    if (oc1up == 0) {
      OC1CON = OC1CON & (65535-7);     /* turn off OC */
      _OC1IE = 0;
      LATDbits.LATD0 = 0;
    } else if (oc1up >= oc1Periode) {
      OC1CON = OC1CON & (65535-7);     /* turn off OC */
      _OC1IE = 0;
      LATDbits.LATD0 = 1;
    } else if (_OC1IE == 0) {
      OC1CON = OC1CON | 5;             /* turn on OC */
      _OC1IF = 1;                      /* Re-Enable Interrupt */
      _OC1IE = 1;                      /* Re-Enable Interrupt */
    }
  }

  /* Update for Sin: '<Root>/Sine Wave' */
  rtDWork.counter = rtDWork.counter + 1L;
  if ((real_T)rtDWork.counter == rtP.SineWave_NumSamp) {
    rtDWork.counter = 0L;
  }
}

/* Model initialize function */
void untitled_initialize(boolean_T firstTime)
{
  (void)firstTime;

  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* block I/O */
  (void) memset(((void *) &rtB),0,
                sizeof(BlockIO));

  /* states (dwork) */
  (void) memset((void *)&rtDWork, 0,
                sizeof(D_Work));

  /* S-Function "dsPIC_MASTER" initialization Block: <Root>/Master1 */
  /* 0 testfcy 	*/
  /*  2.5E+006	*/
  /* CONFIG TIMER 1 for scheduling steps 	*/
  ConfigIntTimer1(T1_INT_PRIOR_0 & T1_INT_OFF);
  T1CON = 0x8000 ;                     /* T1_PS_1_1	*/
  PR1 = 2499;

  /* Configuration TIMER 2 */
  ConfigIntTimer2(T2_INT_PRIOR_0 & T2_INT_OFF);
  OpenTimer2(T2_ON & T2_GATE_OFF &
             T2_PS_1_1 & T2_SOURCE_INT , 65535);

  /* Configuration TRIS */
  TRISD = 65534;

  /* Configuration ADCHS */
  ADPCFG = 0U;

  /* S-Function "dsPIC_PWM_out" initialization Block: <Root>/Output Compare */
  /* Initialise Output Capture */
  /*config output capture*/
  OpenOC1(0xDFFF & OC_TIMER2_SRC & OC_CONTINUE_PULSE, 501, 500);
  ConfigIntOC1(OC_INT_ON & OC_INT_PRIOR_3);
}

/* File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
