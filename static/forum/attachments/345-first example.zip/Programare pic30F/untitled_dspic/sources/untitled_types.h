/*
 * File: untitled_types.h
 *
 * Real-Time Workshop code generated for Simulink model untitled.
 *
 * Model version                        : 1.1
 * Real-Time Workshop file version      : 7.4  (R2009b)  29-Jun-2009
 * Real-Time Workshop file generated on : Mon Jun 14 14:45:58 2010
 * TLC version                          : 7.4 (Jul 14 2009)
 * C source code generated on           : Mon Jun 14 14:45:59 2010
 *--------------------------------------------------------------
 *   Embedded Coder for Microchip dsPIC family.                 |
 *   Generate .c and .h files from your Matlab/simulink model   |
 *   and compile the diagram to .hex and .coff file that can be |
 *   downloaded directly into the microcontroller               |
 *                                                              |
 * Licence Accorded to Demonstration Version                    |
 *                     Author : Lubin KERHUEL                   |
 *                                                              |
 *   Written by Lubin KERHUEL -  http://www.kerhuel.eu          |
 *  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - |
 *   Version 3.2b                              31-Mar-2010      |
 *   For Matlab 7.9             R2009b                          |
 *--------------------------------------------------------------
 */

#ifndef RTW_HEADER_untitled_types_h_
#define RTW_HEADER_untitled_types_h_
#include "rtwtypes.h"

/* Parameters (auto storage) */
typedef struct Parameters_ Parameters;

#endif                                 /* RTW_HEADER_untitled_types_h_ */

/* File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
