#include "p30fxxxx.h"
#include "untitled.h"
#include "untitled_private.h"
#include "outcompare.h"

volatile uint16_T oc1up;
volatile uint16_T oc1Periode;
void __attribute__((__interrupt__)) _OC1Interrupt(void)
{
  OC1R = (OC1R + oc1Periode) ;
  OC1RS = (OC1R + oc1up) ;
  _OC1IF = 0;
}
