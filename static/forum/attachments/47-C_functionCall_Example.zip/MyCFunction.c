
/* You may have to include the correct definition file provided you want to acces to peripheral. */
/* #include <p30f4013.h> */

void YourInitialisation(void)
{
	/* Let's configure here your peripheral. */  
}


unsigned char YourFunction(unsigned char Input)
{
	/* Your function here (get and write value from unsupported peripheral */
	
	unsigned char Temp;
	Temp = (Input * 5) + 10;

	return Temp;       
} 

void YourFunctionMultipleOutput(unsigned char Input01, unsigned char Input02, unsigned char* Output )
{
	/* Your function here (get and write value from unsupported peripheral */
	
	Output[1] = Input01 + Input02;
	Output[2] = Input01 * Input02;
} 

void YourFunctionMultipleOutput2(unsigned char* Input, unsigned char* Output )
{
	/* Your function here (get and write value from unsupported peripheral */
	
	Output[0] = Input[0] + Input[1];
	Output[1] = Input[0] * Input[1];
} 