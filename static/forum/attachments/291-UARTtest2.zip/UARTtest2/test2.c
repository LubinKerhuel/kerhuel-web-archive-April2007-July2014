/*
 * File: test2.c
 *
 * Real-Time Workshop code generated for Simulink model test2.
 *
 * Model version                        : 1.25
 * Real-Time Workshop file version      : 7.3  (R2009a)  15-Jan-2009
 * Real-Time Workshop file generated on : Tue Feb 09 12:46:01 2010
 * TLC version                          : 7.3 (Jan 18 2009)
 * C source code generated on           : Tue Feb 09 12:46:01 2010
 *--------------------------------------------------------------
 *   Embedded Coder for Microchip dsPIC family.                 |
 *   Generate .c and .h files from your Matlab/simulink model   |
 *   and compile the diagram to .hex and .coff file that can be |
 *   downloaded directly into the microcontroller               |
 *                                                              |
 * Licence Accorded to Demonstration Version                    |
 *                     Author : Lubin KERHUEL                   |
 *                                                              |
 *   Written by Lubin KERHUEL -  http://www.kerhuel.eu          |
 *  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - |
 *   Version 3.1                               17-Nov-2009      |
 *   For Matlab 7.8             R2009a                          |
 *--------------------------------------------------------------
 */

#include "test2.h"
#include "test2_private.h"

/* Block signals (auto storage) */
BlockIO_test2 test2_B;

/* Block states (auto storage) */
D_Work_test2 test2_DWork;

/* Model step function */
void test2_step(void)
{
  {
    uint8_T rtb_FixPtSum1;

    /* UnitDelay: '<S2>/Output' */
    rtb_FixPtSum1 = test2_DWork.Output_DSTATE;

    /* MultiPortSwitch: '<S1>/Output' incorporates:
     *  Constant: '<S1>/Vector'
     */
    test2_B.Output = test2_P.Vector_Value[(int16_T)test2_DWork.Output_DSTATE];

    /* DataTypeConversion: '<Root>/Data Type Conversion' incorporates:
     *  Constant: '<Root>/Constant1'
     *  S-Function (sfix_bitop): '<Root>/Bitwise Operator'
     */
    test2_B.DataTypeConversion = ((test2_B.Output & test2_P.Constant1_Value) !=
      0);

    /* DataTypeConversion: '<Root>/Data Type Conversion1' incorporates:
     *  Constant: '<Root>/Constant'
     *  S-Function (sfix_bitop): '<Root>/Bitwise Operator1'
     */
    test2_B.DataTypeConversion1 = ((test2_B.Output & test2_P.Constant_Value) !=
      0);

    /* DataTypeConversion: '<Root>/Data Type Conversion2' incorporates:
     *  Constant: '<Root>/Constant2'
     *  S-Function (sfix_bitop): '<Root>/Bitwise Operator2'
     */
    test2_B.DataTypeConversion2 = ((test2_B.Output & test2_P.Constant2_Value) !=
      0);

    /* DataTypeConversion: '<Root>/Data Type Conversion3' incorporates:
     *  Constant: '<Root>/Constant3'
     *  S-Function (sfix_bitop): '<Root>/Bitwise Operator3'
     */
    test2_B.DataTypeConversion3 = ((test2_B.Output & test2_P.Constant3_Value) !=
      0);

    /* S-Function "dsPIC_Digital_OutputWrite" Block: <Root>/Digital Output Write */
    LATAbits.LATA4 = test2_B.DataTypeConversion;
    LATAbits.LATA5 = test2_B.DataTypeConversion1;
    LATAbits.LATA6 = test2_B.DataTypeConversion2;
    LATAbits.LATA7 = test2_B.DataTypeConversion3;

    /* S-Function "UART_Tx" Block: <Root>/Tx Output */
    {
      uint8_T Tmp;
      do {
        Tmp = ~(TxPtrHaut_Uart2 - TxPtrBas_Uart2);/* Tmp = 7 - (Haut - Bas) modulo 32	*/
        Tmp = Tmp & (32-1);
      } while (Tmp == 0);

      TxTab_Uart2[TxPtrHaut_Uart2] = test2_B.Output;
      TxPtrHaut_Uart2 = (TxPtrHaut_Uart2 + 1) & (32-1);
      _U2TXIF = 1;
      _U2TXIE = 1;
    }

    /* Sum: '<S3>/FixPt Sum1' incorporates:
     *  Constant: '<S3>/FixPt Constant'
     */
    rtb_FixPtSum1 = (uint8_T)(uint16_T)(rtb_FixPtSum1 +
      test2_P.FixPtConstant_Value);

    /* Switch: '<S4>/FixPt Switch' */
    if (rtb_FixPtSum1 > test2_P.FixPtSwitch_Threshold) {
      rtb_FixPtSum1 = ((uint8_T)0U);
    }

    /* Update for UnitDelay: '<S2>/Output' */
    test2_DWork.Output_DSTATE = rtb_FixPtSum1;
  }
}

/* Model initialize function */
void test2_initialize(boolean_T firstTime)
{
  (void)firstTime;

  /* Registration code */

  /* block I/O */
  (void) memset(((void *) &test2_B),0,
                sizeof(BlockIO_test2));

  /* states (dwork) */
  (void) memset((void *)&test2_DWork, 0,
                sizeof(D_Work_test2));

  /* S-Function "dsPIC_MASTER" initialization Block: <Root>/Master */
  /* 0 testfcy 	*/
  /*  4.0E+006	*/
  /* CONFIG TIMER 1 for scheduling steps 	*/
  ConfigIntTimer1(T1_INT_PRIOR_0 & T1_INT_OFF);
  T1CON = 0x8010 ;                     /* T1_PS_1_8	*/
  PR1 = 49999;

  /* Configuration TRIS */
  TRISA = 65295;

  /* Configuration ADCHS */
  AD1PCFGL = (0U);
  AD2PCFGL = (0U);
  AD1PCFGH = ((192U) & 65535);

  /* S-Function "dsPIC_UART_config" initialization Block: <Root>/UART Configuration */
  /* set priority */
  _U2RXIP = 0x0007 & 2;
  _U2TXIP = 0x0007 & 1;

  /* enable/disable interrupt */
  _U2RXIE = (3 != 0);
  _U2TXIE = 0;
  U2MODE = 0x8080 + 1024;
  U2STA = 0x0 + 1 + 1024 + 192 + (1<<12);
  U2BRG = 25;
  TxPtrHaut_Uart2 = 0;
  TxPtrBas_Uart2 = 0;
  RxPtrHaut_Uart2 = 0;
  RxPtrBas_Uart2 = 0;
  _U2TXIF = 0;

  /* InitializeConditions for UnitDelay: '<S2>/Output' */
  test2_DWork.Output_DSTATE = test2_P.Output_X0;
}

/* File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
