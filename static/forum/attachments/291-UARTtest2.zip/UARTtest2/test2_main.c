/*
 * File: test2_main.c
 *
 * Real-Time Workshop code generated for Simulink model test2.
 *
 * Model version                        : 1.25
 * Real-Time Workshop file version      : 7.3  (R2009a)  15-Jan-2009
 * Real-Time Workshop file generated on : Tue Feb 09 12:46:01 2010
 * TLC version                          : 7.3 (Jan 18 2009)
 * C source code generated on           : Tue Feb 09 12:46:01 2010
 *--------------------------------------------------------------
 *   Embedded Coder for Microchip dsPIC family.                 |
 *   Generate .c and .h files from your Matlab/simulink model   |
 *   and compile the diagram to .hex and .coff file that can be |
 *   downloaded directly into the microcontroller               |
 *                                                              |
 * Licence Accorded to Demonstration Version                    |
 *                     Author : Lubin KERHUEL                   |
 *                                                              |
 *   Written by Lubin KERHUEL -  http://www.kerhuel.eu          |
 *  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - |
 *   Version 3.1                               17-Nov-2009      |
 *   For Matlab 7.8             R2009a                          |
 *--------------------------------------------------------------
 */

#include "test2.h"
#include "test2_private.h"

_FSS( RSS_NO_RAM & SSS_NO_FLASH & SWRP_WRPROTECT_OFF )
  _FGS( GCP_OFF & GSS_OFF & GWRP_OFF )
  _FOSCSEL( FNOSC_PRI & IESO_OFF & 0xFFFF )
  _FOSC( FCKSM_CSDCMD & OSCIOFNC_OFF & POSCMD_XT)
  _FPOR( FPWRT_PWR1 )
  _FWDT( FWDTEN_OFF )
  _FICD( JTAGEN_OFF )
  static boolean_T OverrunFlag = 0;
void rt_OneStep()
{
  /* Disable interrupts here */
  /* Save FPU context here (if necessary) */
  /* Re-enable timer or interrupt here */
  test2_step();

  /* Get model outputs here */

  /* Disable interrupts here */
  /* Restore FPU context here (if necessary) */
  /* Enable interrupts here */
}

int main(void)
{
  PLLFBD = 0;                          /* configure clock speed */
  CLKDIV = 0;

  /* Initialize model */
  test2_initialize(1);
  for (;;) {
    /* Associate rt_OneStep() with a timer that executes at the base rate of the model */
    while (!_T1IF) ;
    _T1IF = 0;
    rt_OneStep();
  }
}

/* File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
