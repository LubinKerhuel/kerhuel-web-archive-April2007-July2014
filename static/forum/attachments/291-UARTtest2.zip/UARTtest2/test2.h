/*
 * File: test2.h
 *
 * Real-Time Workshop code generated for Simulink model test2.
 *
 * Model version                        : 1.25
 * Real-Time Workshop file version      : 7.3  (R2009a)  15-Jan-2009
 * Real-Time Workshop file generated on : Tue Feb 09 12:46:01 2010
 * TLC version                          : 7.3 (Jan 18 2009)
 * C source code generated on           : Tue Feb 09 12:46:01 2010
 *--------------------------------------------------------------
 *   Embedded Coder for Microchip dsPIC family.                 |
 *   Generate .c and .h files from your Matlab/simulink model   |
 *   and compile the diagram to .hex and .coff file that can be |
 *   downloaded directly into the microcontroller               |
 *                                                              |
 * Licence Accorded to Demonstration Version                    |
 *                     Author : Lubin KERHUEL                   |
 *                                                              |
 *   Written by Lubin KERHUEL -  http://www.kerhuel.eu          |
 *  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - |
 *   Version 3.1                               17-Nov-2009      |
 *   For Matlab 7.8             R2009a                          |
 *--------------------------------------------------------------
 */

#ifndef RTW_HEADER_test2_h_
#define RTW_HEADER_test2_h_
#ifndef test2_COMMON_INCLUDES_
# define test2_COMMON_INCLUDES_
#include <string.h>
#include "rtwtypes.h"
#endif                                 /* test2_COMMON_INCLUDES_ */

#include "test2_types.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((void*) 0)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((void) 0)
#endif

#ifndef rtmGetStopRequested
# define rtmGetStopRequested(rtm)      ((void*) 0)
#endif

/* Block signals (auto storage) */
typedef struct {
  uint8_T Output;                      /* '<S1>/Output' */
  boolean_T DataTypeConversion;        /* '<Root>/Data Type Conversion' */
  boolean_T DataTypeConversion1;       /* '<Root>/Data Type Conversion1' */
  boolean_T DataTypeConversion2;       /* '<Root>/Data Type Conversion2' */
  boolean_T DataTypeConversion3;       /* '<Root>/Data Type Conversion3' */
} BlockIO_test2;

/* Block states (auto storage) for system '<Root>' */
typedef struct {
  uint8_T Output_DSTATE;               /* '<S2>/Output' */
} D_Work_test2;

/* Parameters (auto storage) */
struct Parameters_test2_ {
  uint8_T Output_X0;                   /* Computed Parameter: X0
                                        * '<S2>/Output'
                                        */
  uint8_T Vector_Value[16];            /* Computed Parameter: Value
                                        * '<S1>/Vector'
                                        */
  uint8_T Constant1_Value;             /* Computed Parameter: Value
                                        * '<Root>/Constant1'
                                        */
  uint8_T Constant_Value;              /* Computed Parameter: Value
                                        * '<Root>/Constant'
                                        */
  uint8_T Constant2_Value;             /* Computed Parameter: Value
                                        * '<Root>/Constant2'
                                        */
  uint8_T Constant3_Value;             /* Computed Parameter: Value
                                        * '<Root>/Constant3'
                                        */
  uint8_T FixPtConstant_Value;         /* Computed Parameter: Value
                                        * '<S3>/FixPt Constant'
                                        */
  uint8_T FixPtSwitch_Threshold;       /* Computed Parameter: Threshold
                                        * '<S4>/FixPt Switch'
                                        */
};

/* Block parameters (auto storage) */
extern Parameters_test2 test2_P;

/* Block signals (auto storage) */
extern BlockIO_test2 test2_B;

/* Block states (auto storage) */
extern D_Work_test2 test2_DWork;

/* Model entry point functions */
extern void test2_initialize(boolean_T firstTime);
extern void test2_step(void);

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : test2
 * '<S1>'   : test2/Repeating Sequence Stair
 * '<S2>'   : test2/Repeating Sequence Stair/LimitedCounter
 * '<S3>'   : test2/Repeating Sequence Stair/LimitedCounter/Increment Real World
 * '<S4>'   : test2/Repeating Sequence Stair/LimitedCounter/Wrap To Zero
 */
#endif                                 /* RTW_HEADER_test2_h_ */

/* File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
