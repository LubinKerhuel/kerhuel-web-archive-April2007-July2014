/*
 * File: autobuild.h
 *
 * Real-Time Workshop code generated for Simulink model test2.
 *
 * Model version                        : 1.25
 * Real-Time Workshop file version      : 7.3  (R2009a)  15-Jan-2009
 * Real-Time Workshop file generated on : Tue Feb 09 12:46:01 2010
 * TLC version                          : 7.3 (Jan 18 2009)
 * C source code generated on           : Tue Feb 09 12:46:01 2010
 *--------------------------------------------------------------
 *   Embedded Coder for Microchip dsPIC family.                 |
 *   Generate .c and .h files from your Matlab/simulink model   |
 *   and compile the diagram to .hex and .coff file that can be |
 *   downloaded directly into the microcontroller               |
 *                                                              |
 * Licence Accorded to Demonstration Version                    |
 *                     Author : Lubin KERHUEL                   |
 *                                                              |
 *   Written by Lubin KERHUEL -  http://www.kerhuel.eu          |
 *  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - |
 *   Version 3.1                               17-Nov-2009      |
 *   For Matlab 7.8             R2009a                          |
 *--------------------------------------------------------------
 */

#ifndef RTW_HEADER_autobuild_h_
#define RTW_HEADER_autobuild_h_
#include "test2.h"
#define INCLUDE_FIRST_TIME_ARG         1
#endif                                 /* RTW_HEADER_autobuild_h_ */

/* File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */
