#include "rtwtypes.h"
#include <spi.h>
    
#if defined(__dsPIC33F__)
    #include "p33Fxxxx.h"
    uint16_T Spi1TxBuffA[16] __attribute__((space(dma)));
    uint16_T Spi1TxBuffB[16] __attribute__((space(dma)));
#else 
    #include "p30fxxxx.h"
#endif
    
#if defined(__dsPIC33F__)
/*=============================================================================
_DMA0Init(): Initialise DMA0 for SPI Data Transmission 
=============================================================================*/
// DMA0 configuration
// Direction: Read from DMA RAM and write to SPI buffer
// AMODE: Register Indirect with Post-Increment mode
// MODE: Continuous, Ping-Pong Enabled
// IRQ: SPI

void cfgDma0SpiTx(void)
{

	DMA0CON = 0x2002;	
	/* =============================================
	DMA0CONbits.CHEN    = 0;        // Channel Enable
	DMA0CONbits.SIZE    = 0;        // Data Transfer Size
	DMA0CONbits.DIR     = 1;        // Transfer Direction
	DMA0CONbits.HALF    = 0;        // Block transfer interrupt select
	
	DMA0CONbits.NULLW   = 0;        // Null Data periphereal write
	
	DMA0CONbits.AMODE   = 0;        // DMA Channel Addressing mode
	
	DMA0CONbits.MODE    = 2;        // DMA Channel Operating Mode
	=============================================  */			
		
	DMA0CNT = 15;						
	/*=============================================
	16 Bytes
	=============================================  */
	    
	DMA0REQ = 0x000A;					
    /* =============================================
	DMA0REQbits.FORCE   = 0;        // Force DMA Transfer
	
	DMA0REQbits.IRQSEL  = 10;       // DMA Periphereal IRQ number
	=============================================  */	
	
	DMA0PAD = (volatile unsigned int) &SPI1BUF;
	/* =============================================
	PAD     = (volatile unsigned int)&SPIBUF;        // Periphereal Address Register
	=============================================  */
	
	DMA0STA= __builtin_dmaoffset(Spi1TxBuffA);
	/*=============================================
	DMA0STA =  __builtin_dmaoffset (&SpiTxBuffA);   // DPSRAM Start Address Offset Register A
	============================================= */
	
	
	DMA0STB= __builtin_dmaoffset(Spi1TxBuffB);
	/*=============================================
	DMA0STB =   __builtin_dmaoffset(&SpiTxBuffB)   // DPSRAM Start Address Offset Register B
	============================================= */
	
	IFS0bits.DMA0IF  = 0;			// Clear DMA interrupt flag
	IEC0bits.DMA0IE  = 1;			// Enable DMA interrupt
	DMA0CONbits.CHEN = 1;			// Enable DMA Channel	
	
}
#endif

void cfgSpi1Slave(void)
{

   // Clear and disable the interrupts
    IFS0bits.SPI1IF     = 0;    //Clear the Interrupt Flag
    IEC0bits.SPI1IE     = 0;    //disable the Interrupt
    
    #if defined (__dsPIC33f__)
        // SPI1CON1 Register Settings
        SPI1CON1bits.DISSCK = 0;    //Internal Serial Clock is Enabled.
        SPI1CON1bits.DISSDO = 0;    //SDOx pin is controlled by the module.
        SPI1CON1bits.MODE16 = 1;    //Communication is word-wide (16 bits).
        SPI1CON1bits.SMP    = 0;    //Input Data is sampled at the middle of data output time.
        SPI1CON1bits.CKE    = 0;    //Serial output data changes on transition from
                                    //Idle clock state to active clock state
        SPI1CON1bits.CKP    = 0;    //Idle state for clock is a low level;
                                    //active state is a high level
        SPI1CON1bits.MSTEN  = 0;    //Slave Mode Enabled
        
        // Configfure the clock
        SPI1CON1bits.SPRE   = 6;    //Secondary prescaler to 2:1
        SPI1CON1bits.PPRE   = 2;    //Primary prescaler 4:1
    
        // SPI1CON2 Register Settings
        SPI1CON2bits.FRMEN  = 1;    // Enable framed mode
        SPI1CON2bits.SPIFSD = 0;    // SSL output, thus Frame Master
        SPI1CON2bits.FRMPOL = 0;    // Frame Sync is active low
        SPI1CON2bits.FRMDLY = 1;    // Frame Sync pulse coincides with first clock pulse  
        IFS0bits.SPI1IF     = 0;    //Clear the Interrupt Flag
        IEC0bits.SPI1IE     = 1;    //Enable the Interrupt
        
    #else
        SPI1CONbits.DISSDO  = 0;    //SDOx pin is controlled by the module.
        SPI1CONbits.MODE16  = 1;    //Communication is word-wide (16 bits).
        SPI1CONbits.SMP     = 0;    //Input Data is sampled at the middle of data output time.
        SPI1CONbits.CKE     = 0;    //Serial output data changes on transition from
                                    //Idle clock state to active clock state
        SPI1CONbits.CKP     = 0;    //Idle state for clock is a low level;
                                    //active state is a high level
        SPI1CONbits.MSTEN   = 0;    //Slave Mode Enabled
         // Configfure the clock
        SPI1CONbits.SPRE    = 6;    //Secondary prescaler to 2:1
        SPI1CONbits.PPRE    = 1;    //Primary prescaler 16:1
  
        // SPI1CON2 Register Settings
        SPI1CONbits.FRMEN   = 0;    // Enable framed mode
        SPI1CONbits.SPIFSD  = 0;    // SSL output, thus Frame Master
        
        // Configure SSL Pin as output
        ADPCFG = ADPCFG | 0xFFFF;
        


    #endif
    // Enable the module and the interrupts
    SPI1STATbits.SPIEN  = 1;    //Enable SPI Module

    
    #if defined (__dsPIC33F__)
        DMA0REQbits.FORCE   = 1;    // Force First word after Enabling SPI
        while(DMA0REQbits.FORCE==1);
    #endif
}

/*=============================================================================
Initialise SPI Buffer
=============================================================================*/
#if defined(__dsPIC33F__)
void initSPIBuff(void)
{
    unsigned int i;
    for(i=0;i<16;i++)
        Spi1TxBuffA[i]=i;
    for(i=0;i<16;i++)
        Spi1TxBuffB[i]=16+i;	
}
#endif

void configDMATx(void)
{
    #if defined(__dsPIC33F__)
        initSPIBuff();
        cfgDma0SpiTx();
    #endif
    cfgSpi1Slave();
}


void myPutSPI(uint16_T *data2send)
{
    uint8_T length = (uint8_T) *(data2send);
    PORTBbits.RB2 = 1;
    putsSPI1(length, (data2send + 2));
    PORTBbits.RB2 = 0;
}

/*=============================================================================
Interrupt Service Routines.
=============================================================================*/
#if defined(__dsPIC33F__)
void __attribute__((interrupt, no_auto_psv)) _DMA0Interrupt(void)

{

    IFS0bits.DMA0IF = 0;		// Clear the DMA0 Interrupt Flag;
    //PORTBbits.RB2   = 1;

}
#endif